﻿namespace SMFS
{
    partial class TimeClock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TimeClock));
            this.panelAll = new System.Windows.Forms.Panel();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabMain = new System.Windows.Forms.TabPage();
            this.panelMainAll = new System.Windows.Forms.Panel();
            this.panelMainTop = new System.Windows.Forms.Panel();
            this.dgv = new DevExpress.XtraGrid.GridControl();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.approveAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showPTOHistoryToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editEmployeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gridMain = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.dateBand = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.gridColumn1 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn24 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.bandedGridColumn78 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn95 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn17 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemPictureEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit();
            this.bandedGridColumn15 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn16 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.totalBand = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn5 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn6 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn22 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandPunch1 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn11 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandPunch2 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn4 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn3 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandPunch3 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn1 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn2 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandPunch4 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn7 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn8 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandPunch5 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn10 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn9 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandSalary = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.gridColumn7 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn62 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn63 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn65 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn66 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn23 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn20 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn21 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn25 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandholiday = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn13 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn14 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandPTO = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn12 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn18 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn26 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn49 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn50 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridNotes = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn27 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn19 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn48 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.tabReport = new System.Windows.Forms.TabPage();
            this.panelReportAll = new System.Windows.Forms.Panel();
            this.panelReportBottom = new System.Windows.Forms.Panel();
            this.dgv4 = new DevExpress.XtraGrid.GridControl();
            this.gridMain4 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand1 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn28 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn29 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.bandedGridColumn30 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn31 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn32 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemPictureEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit();
            this.bandedGridColumn33 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn34 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn41 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn59 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn42 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand2 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn35 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn36 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn37 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn38 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn39 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn60 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn45 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand3 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn40 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand4 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.gridBand5 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.gridBand6 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.gridBand7 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.gridBand8 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn51 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn52 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn53 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand9 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn54 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn55 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn43 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn46 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand10 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn56 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn57 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn58 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn44 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn47 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand11 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn61 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelReportTop = new System.Windows.Forms.Panel();
            this.btnGenerateReport = new DevExpress.XtraEditors.SimpleButton();
            this.tabPTO = new System.Windows.Forms.TabPage();
            this.panelPTOAll = new System.Windows.Forms.Panel();
            this.panelPTOBottom = new System.Windows.Forms.Panel();
            this.dgv2 = new DevExpress.XtraGrid.GridControl();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.swapPTODockedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn19 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn20 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn21 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn22 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn23 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn24 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn25 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn26 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn27 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn28 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn29 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn30 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn31 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn32 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn33 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn34 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn52 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.bar1 = new DevExpress.XtraBars.Bar();
            this.barSubItem1 = new DevExpress.XtraBars.BarSubItem();
            this.barSubItem7 = new DevExpress.XtraBars.BarSubItem();
            this.menuItemPrintPreview = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonPrintAll = new DevExpress.XtraBars.BarButtonItem();
            this.menuItemPrint = new DevExpress.XtraBars.BarButtonItem();
            this.menuItemExit = new DevExpress.XtraBars.BarButtonItem();
            this.menuPayPeriods = new DevExpress.XtraBars.BarSubItem();
            this.menuSupervisors = new DevExpress.XtraBars.BarSubItem();
            this.menuOptions = new DevExpress.XtraBars.BarSubItem();
            this.menuAddHolidays = new DevExpress.XtraBars.BarButtonItem();
            this.menuEditPreferences = new DevExpress.XtraBars.BarButtonItem();
            this.menuSetPassword = new DevExpress.XtraBars.BarButtonItem();
            this.menuEditHourStatus = new DevExpress.XtraBars.BarButtonItem();
            this.menuAddNewEmployee = new DevExpress.XtraBars.BarButtonItem();
            this.menuExportPTO = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem9 = new DevExpress.XtraBars.BarSubItem();
            this.menuEmployeeList = new DevExpress.XtraBars.BarButtonItem();
            this.menuHelpItem = new DevExpress.XtraBars.BarButtonItem();
            this.menuEditHelp = new DevExpress.XtraBars.BarButtonItem();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.barSubItem2 = new DevExpress.XtraBars.BarSubItem();
            this.menuItemSkins = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem3 = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem4 = new DevExpress.XtraBars.BarSubItem();
            this.menuImportPayroll = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.menuItemFindPanel = new DevExpress.XtraBars.BarCheckItem();
            this.barSubItem5 = new DevExpress.XtraBars.BarSubItem();
            this.menuItemLoadContributions = new DevExpress.XtraBars.BarButtonItem();
            this.menuItemLoadMonthlyPSFiles = new DevExpress.XtraBars.BarButtonItem();
            this.menuItemLoadDepartInfo = new DevExpress.XtraBars.BarButtonItem();
            this.menuItemCalcDiff = new DevExpress.XtraBars.BarButtonItem();
            this.menuItemCalcDoctorProd = new DevExpress.XtraBars.BarButtonItem();
            this.menuItemLoadAccruals = new DevExpress.XtraBars.BarButtonItem();
            this.menuItemCalcTotals = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem6 = new DevExpress.XtraBars.BarSubItem();
            this.menuChkInvestOpt = new DevExpress.XtraBars.BarCheckItem();
            this.menuChkAccrual = new DevExpress.XtraBars.BarCheckItem();
            this.menuChkDepartment = new DevExpress.XtraBars.BarCheckItem();
            this.menuChkContributions = new DevExpress.XtraBars.BarCheckItem();
            this.menuChkPayroll = new DevExpress.XtraBars.BarCheckItem();
            this.menuChkPsDetail = new DevExpress.XtraBars.BarCheckItem();
            this.menuChkDifferences = new DevExpress.XtraBars.BarCheckItem();
            this.menuImportRates = new DevExpress.XtraBars.BarButtonItem();
            this.menuReportPrint = new DevExpress.XtraBars.BarButtonItem();
            this.barReport = new DevExpress.XtraBars.BarSubItem();
            this.menuReportPrintPreview = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.menuChkSalary = new DevExpress.XtraBars.BarCheckItem();
            this.menuChkYearend = new DevExpress.XtraBars.BarCheckItem();
            this.menuItemYearend = new DevExpress.XtraBars.BarButtonItem();
            this.menuItemDoctorDistribution = new DevExpress.XtraBars.BarButtonItem();
            this.btnDailySummary = new DevExpress.XtraBars.BarButtonItem();
            this.menuItemView = new DevExpress.XtraBars.BarSubItem();
            this.menuItemPrimary = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.btnProcedureData = new DevExpress.XtraBars.BarButtonItem();
            this.menuItemOverhead = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem8 = new DevExpress.XtraBars.BarSubItem();
            this.menuItemEditOverhead = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.menuFormats = new DevExpress.XtraBars.BarSubItem();
            this.menuSkins = new DevExpress.XtraBars.BarButtonItem();
            this.menuDetailReport = new DevExpress.XtraBars.BarButtonItem();
            this.menuEditTimeSheetHelp = new DevExpress.XtraBars.BarButtonItem();
            this.menuHelp = new DevExpress.XtraBars.BarSubItem();
            this.menuClockInOut = new DevExpress.XtraBars.BarButtonItem();
            this.menuHelpEmployeeList = new DevExpress.XtraBars.BarButtonItem();
            this.menuHelpSalary = new DevExpress.XtraBars.BarSubItem();
            this.menuSalaryPunchIn = new DevExpress.XtraBars.BarButtonItem();
            this.menuSalaryEmployeeList = new DevExpress.XtraBars.BarButtonItem();
            this.menuTimeOff = new DevExpress.XtraBars.BarSubItem();
            this.barButtonItem6 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem7 = new DevExpress.XtraBars.BarButtonItem();
            this.barSubItem10 = new DevExpress.XtraBars.BarSubItem();
            this.panelPTOTop = new System.Windows.Forms.Panel();
            this.tabDetail = new System.Windows.Forms.TabPage();
            this.panelDetailAll = new System.Windows.Forms.Panel();
            this.panelDetailBottom = new System.Windows.Forms.Panel();
            this.rtb = new System.Windows.Forms.RichTextBox();
            this.dgv3 = new DevExpress.XtraGrid.GridControl();
            this.gridView3 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn55 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.panelDetailTop = new System.Windows.Forms.Panel();
            this.chkOddPunches = new System.Windows.Forms.CheckBox();
            this.chkUnder80 = new System.Windows.Forms.CheckBox();
            this.chkErrors = new System.Windows.Forms.CheckBox();
            this.chkAll = new System.Windows.Forms.CheckBox();
            this.btnDoDetail = new System.Windows.Forms.Button();
            this.tabMyTimeOff = new System.Windows.Forms.TabPage();
            this.panelTimeOffAll = new System.Windows.Forms.Panel();
            this.panelTimeOffBottom = new System.Windows.Forms.Panel();
            this.dgv5 = new DevExpress.XtraGrid.GridControl();
            this.gridView5 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn37 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn42 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn41 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.gridColumn40 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn39 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn35 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn36 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn48 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn38 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.panelTimeOffTop = new System.Windows.Forms.Panel();
            this.txtHireDate = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDecember = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtPTOtaken = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnSaveVacation = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.btnRequestTimeOff = new System.Windows.Forms.Button();
            this.tabTimeOffProc = new System.Windows.Forms.TabPage();
            this.panelTimeOffProcAll = new System.Windows.Forms.Panel();
            this.panelTimeOffProcBottom = new System.Windows.Forms.Panel();
            this.dgv6 = new DevExpress.XtraGrid.GridControl();
            this.gridView6 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn43 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn44 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn45 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemCheckEdit5 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.gridColumn46 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn47 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn49 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn50 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn51 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn53 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn54 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn56 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn58 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn59 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn60 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn61 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.panelTimeOffProcTop = new System.Windows.Forms.Panel();
            this.btnCalendar = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbMyProc = new System.Windows.Forms.ComboBox();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.tabContractLabor = new System.Windows.Forms.TabPage();
            this.panelContractAll = new System.Windows.Forms.Panel();
            this.panelContractBottom = new System.Windows.Forms.Panel();
            this.dgv7 = new DevExpress.XtraGrid.GridControl();
            this.gridMain7 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand12 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn70 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn68 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn67 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn69 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn72 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn74 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn75 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn76 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn64 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn79 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn77 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn71 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn73 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn80 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.panelContractTop = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.tabPageOther = new System.Windows.Forms.TabPage();
            this.panelOtherAll = new System.Windows.Forms.Panel();
            this.panelOtherBottom = new System.Windows.Forms.Panel();
            this.dgv8 = new DevExpress.XtraGrid.GridControl();
            this.gridMain8 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand13 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn81 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn82 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn83 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn84 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn85 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn86 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn87 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn88 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn89 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn90 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn91 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn92 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn93 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn94 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridView4 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.panelOtherTop = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panelTop = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.chkManagerApproved = new System.Windows.Forms.CheckBox();
            this.chkEmployeeApproved = new System.Windows.Forms.CheckBox();
            this.btnDecimal = new DevExpress.XtraEditors.SimpleButton();
            this.lblTimeApprovedBy = new System.Windows.Forms.Label();
            this.btnClock = new DevExpress.XtraEditors.SimpleButton();
            this.txtCycleNote = new System.Windows.Forms.TextBox();
            this.lblCycleNote = new System.Windows.Forms.Label();
            this.chkUnapproved = new System.Windows.Forms.CheckBox();
            this.btnAddNextPunch = new System.Windows.Forms.Button();
            this.btnPunchIn1 = new System.Windows.Forms.Button();
            this.picEmployee = new System.Windows.Forms.PictureBox();
            this.btnPunchOut5 = new System.Windows.Forms.Button();
            this.btnError = new System.Windows.Forms.Button();
            this.btnPunchIn3 = new System.Windows.Forms.Button();
            this.btnPunchOut1 = new System.Windows.Forms.Button();
            this.btnSpyGlass = new DevExpress.XtraEditors.SimpleButton();
            this.btnPunchOut3 = new System.Windows.Forms.Button();
            this.btnAddPunch = new System.Windows.Forms.Button();
            this.btnPunchIn5 = new System.Windows.Forms.Button();
            this.txtDecemberPTO = new System.Windows.Forms.TextBox();
            this.btnPunchOut2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnPunchIn4 = new System.Windows.Forms.Button();
            this.txtAvailablePTO = new System.Windows.Forms.TextBox();
            this.btnPunchOut4 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPunchIn2 = new System.Windows.Forms.Button();
            this.lblTo = new DevExpress.XtraEditors.LabelControl();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.DateControl_Backward = new DevExpress.XtraEditors.SimpleButton();
            this.DateControl_Forward = new DevExpress.XtraEditors.SimpleButton();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.printingSystem1 = new DevExpress.XtraPrinting.PrintingSystem(this.components);
            this.printableComponentLink1 = new DevExpress.XtraPrinting.PrintableComponentLink(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblPostingAsOf = new System.Windows.Forms.Label();
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuClearRow = new System.Windows.Forms.ToolStripMenuItem();
            this.clearCellToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip4 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.panelAll.SuspendLayout();
            this.panelBottom.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabMain.SuspendLayout();
            this.panelMainAll.SuspendLayout();
            this.panelMainTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit1)).BeginInit();
            this.tabReport.SuspendLayout();
            this.panelReportAll.SuspendLayout();
            this.panelReportBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit2)).BeginInit();
            this.panelReportTop.SuspendLayout();
            this.tabPTO.SuspendLayout();
            this.panelPTOAll.SuspendLayout();
            this.panelPTOBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            this.tabDetail.SuspendLayout();
            this.panelDetailAll.SuspendLayout();
            this.panelDetailBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).BeginInit();
            this.panelDetailTop.SuspendLayout();
            this.tabMyTimeOff.SuspendLayout();
            this.panelTimeOffAll.SuspendLayout();
            this.panelTimeOffBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.CalendarTimeProperties)).BeginInit();
            this.panelTimeOffTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.tabTimeOffProc.SuspendLayout();
            this.panelTimeOffProcAll.SuspendLayout();
            this.panelTimeOffProcBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit5)).BeginInit();
            this.panelTimeOffProcTop.SuspendLayout();
            this.tabContractLabor.SuspendLayout();
            this.panelContractAll.SuspendLayout();
            this.panelContractBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.panelContractTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.tabPageOther.SuspendLayout();
            this.panelOtherAll.SuspendLayout();
            this.panelOtherBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).BeginInit();
            this.panelOtherTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picEmployee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.printingSystem1)).BeginInit();
            this.contextMenuStrip3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelAll
            // 
            this.panelAll.Controls.Add(this.panelBottom);
            this.panelAll.Controls.Add(this.panelTop);
            this.panelAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAll.Location = new System.Drawing.Point(0, 25);
            this.panelAll.Name = "panelAll";
            this.panelAll.Size = new System.Drawing.Size(1228, 642);
            this.panelAll.TabIndex = 0;
            // 
            // panelBottom
            // 
            this.panelBottom.Controls.Add(this.tabControl1);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBottom.Location = new System.Drawing.Point(0, 41);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(1228, 601);
            this.panelBottom.TabIndex = 2;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabMain);
            this.tabControl1.Controls.Add(this.tabReport);
            this.tabControl1.Controls.Add(this.tabPTO);
            this.tabControl1.Controls.Add(this.tabDetail);
            this.tabControl1.Controls.Add(this.tabMyTimeOff);
            this.tabControl1.Controls.Add(this.tabTimeOffProc);
            this.tabControl1.Controls.Add(this.tabContractLabor);
            this.tabControl1.Controls.Add(this.tabPageOther);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1228, 601);
            this.tabControl1.TabIndex = 118;
            this.tabControl1.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabControl1_DrawItem);
            this.tabControl1.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl1_Selected);
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.panelMainAll);
            this.tabMain.Location = new System.Drawing.Point(4, 26);
            this.tabMain.Name = "tabMain";
            this.tabMain.Padding = new System.Windows.Forms.Padding(3);
            this.tabMain.Size = new System.Drawing.Size(1220, 571);
            this.tabMain.TabIndex = 0;
            this.tabMain.Text = "TimeSheet";
            this.tabMain.UseVisualStyleBackColor = true;
            // 
            // panelMainAll
            // 
            this.panelMainAll.Controls.Add(this.panelMainTop);
            this.panelMainAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMainAll.Location = new System.Drawing.Point(3, 3);
            this.panelMainAll.Name = "panelMainAll";
            this.panelMainAll.Size = new System.Drawing.Size(1214, 565);
            this.panelMainAll.TabIndex = 4;
            // 
            // panelMainTop
            // 
            this.panelMainTop.Controls.Add(this.dgv);
            this.panelMainTop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelMainTop.Location = new System.Drawing.Point(0, 0);
            this.panelMainTop.Name = "panelMainTop";
            this.panelMainTop.Size = new System.Drawing.Size(1214, 565);
            this.panelMainTop.TabIndex = 5;
            // 
            // dgv
            // 
            this.dgv.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(5);
            this.dgv.Location = new System.Drawing.Point(0, 0);
            this.dgv.MainView = this.gridMain;
            this.dgv.Name = "dgv";
            this.dgv.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1,
            this.repositoryItemPictureEdit1});
            this.dgv.Size = new System.Drawing.Size(1214, 565);
            this.dgv.TabIndex = 3;
            this.dgv.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain});
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.approveAllToolStripMenuItem,
            this.showPTOHistoryToolStripMenuItem1,
            this.editEmployeeToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(196, 76);
            // 
            // approveAllToolStripMenuItem
            // 
            this.approveAllToolStripMenuItem.Name = "approveAllToolStripMenuItem";
            this.approveAllToolStripMenuItem.Size = new System.Drawing.Size(195, 24);
            this.approveAllToolStripMenuItem.Text = "Approve All";
            this.approveAllToolStripMenuItem.Click += new System.EventHandler(this.approveAllToolStripMenuItem_Click);
            // 
            // showPTOHistoryToolStripMenuItem1
            // 
            this.showPTOHistoryToolStripMenuItem1.Name = "showPTOHistoryToolStripMenuItem1";
            this.showPTOHistoryToolStripMenuItem1.Size = new System.Drawing.Size(195, 24);
            this.showPTOHistoryToolStripMenuItem1.Text = "Show PTO History";
            this.showPTOHistoryToolStripMenuItem1.Click += new System.EventHandler(this.showPTOHistoryToolStripMenuItem1_Click);
            // 
            // editEmployeeToolStripMenuItem
            // 
            this.editEmployeeToolStripMenuItem.Name = "editEmployeeToolStripMenuItem";
            this.editEmployeeToolStripMenuItem.Size = new System.Drawing.Size(195, 24);
            this.editEmployeeToolStripMenuItem.Text = "Edit Employee";
            this.editEmployeeToolStripMenuItem.Click += new System.EventHandler(this.editEmployeeToolStripMenuItem_Click);
            // 
            // gridMain
            // 
            this.gridMain.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(203)))), ((int)(((byte)(147)))));
            this.gridMain.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(203)))), ((int)(((byte)(147)))));
            this.gridMain.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(30)))), ((int)(((byte)(96)))));
            this.gridMain.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(233)))), ((int)(((byte)(177)))));
            this.gridMain.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(233)))), ((int)(((byte)(177)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(239)))), ((int)(((byte)(196)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(233)))), ((int)(((byte)(177)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(233)))), ((int)(((byte)(177)))));
            this.gridMain.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain.Appearance.EvenRow.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.Options.UseFont = true;
            this.gridMain.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(90)))), ((int)(((byte)(156)))));
            this.gridMain.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(0)))), ((int)(((byte)(66)))));
            this.gridMain.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.gridMain.Appearance.FixedLine.BackColor2 = System.Drawing.Color.Yellow;
            this.gridMain.Appearance.FixedLine.BorderColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FixedLine.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain.Appearance.FixedLine.Options.UseBorderColor = true;
            this.gridMain.Appearance.FixedLine.Options.UseForeColor = true;
            this.gridMain.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FocusedCell.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Purple;
            this.gridMain.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedCell.Options.UseFont = true;
            this.gridMain.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain.Appearance.FocusedRow.BackColor = System.Drawing.Color.Yellow;
            this.gridMain.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.Yellow;
            this.gridMain.Appearance.FocusedRow.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedRow.Options.UseFont = true;
            this.gridMain.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain.Appearance.FooterPanel.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseFont = true;
            this.gridMain.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(223)))), ((int)(((byte)(167)))));
            this.gridMain.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(223)))), ((int)(((byte)(167)))));
            this.gridMain.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(0)))), ((int)(((byte)(66)))));
            this.gridMain.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(165)))), ((int)(((byte)(47)))));
            this.gridMain.Appearance.GroupRow.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(234)))), ((int)(((byte)(207)))));
            this.gridMain.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(40)))), ((int)(((byte)(106)))));
            this.gridMain.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Yellow;
            this.gridMain.Appearance.HideSelectionRow.BackColor2 = System.Drawing.Color.Yellow;
            this.gridMain.Appearance.HideSelectionRow.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.Options.UseFont = true;
            this.gridMain.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(234)))), ((int)(((byte)(207)))));
            this.gridMain.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.OddRow.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain.Appearance.OddRow.Options.UseFont = true;
            this.gridMain.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(217)))));
            this.gridMain.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.Preview.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(165)))), ((int)(((byte)(47)))));
            this.gridMain.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain.Appearance.Preview.Options.UseFont = true;
            this.gridMain.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.Row.Options.UseBackColor = true;
            this.gridMain.Appearance.Row.Options.UseFont = true;
            this.gridMain.Appearance.Row.Options.UseForeColor = true;
            this.gridMain.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(233)))), ((int)(((byte)(177)))));
            this.gridMain.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.BackColor = System.Drawing.Color.Yellow;
            this.gridMain.Appearance.SelectedRow.BackColor2 = System.Drawing.Color.Yellow;
            this.gridMain.Appearance.SelectedRow.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.Options.UseFont = true;
            this.gridMain.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.TopNewRow.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain.Appearance.TopNewRow.Options.UseFont = true;
            this.gridMain.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.dateBand,
            this.totalBand,
            this.bandPunch1,
            this.bandPunch2,
            this.bandPunch3,
            this.bandPunch4,
            this.bandPunch5,
            this.bandSalary,
            this.bandholiday,
            this.bandPTO,
            this.gridNotes});
            this.gridMain.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.gridColumn1,
            this.bandedGridColumn78,
            this.gridColumn2,
            this.bandedGridColumn95,
            this.gridColumn5,
            this.gridColumn7,
            this.bandedGridColumn5,
            this.bandedGridColumn6,
            this.bandedGridColumn22,
            this.gridColumn6,
            this.gridColumn3,
            this.gridColumn4,
            this.bandedGridColumn4,
            this.bandedGridColumn3,
            this.bandedGridColumn1,
            this.bandedGridColumn2,
            this.bandedGridColumn7,
            this.bandedGridColumn8,
            this.bandedGridColumn10,
            this.bandedGridColumn9,
            this.bandedGridColumn11,
            this.bandedGridColumn12,
            this.bandedGridColumn18,
            this.bandedGridColumn26,
            this.bandedGridColumn49,
            this.bandedGridColumn50,
            this.bandedGridColumn13,
            this.bandedGridColumn14,
            this.bandedGridColumn15,
            this.bandedGridColumn16,
            this.bandedGridColumn17,
            this.bandedGridColumn19,
            this.bandedGridColumn20,
            this.bandedGridColumn21,
            this.bandedGridColumn62,
            this.bandedGridColumn63,
            this.bandedGridColumn65,
            this.bandedGridColumn66,
            this.bandedGridColumn25,
            this.bandedGridColumn23,
            this.bandedGridColumn24,
            this.bandedGridColumn27,
            this.bandedGridColumn48});
            this.gridMain.GridControl = this.dgv;
            this.gridMain.GroupCount = 1;
            this.gridMain.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "total", this.gridColumn7, "{0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "vacation", this.bandedGridColumn62, "{0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "holiday", this.bandedGridColumn63, "{0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "sick", this.bandedGridColumn65, "{0:0,0.00}")});
            this.gridMain.Name = "gridMain";
            this.gridMain.OptionsLayout.StoreAllOptions = true;
            this.gridMain.OptionsLayout.StoreAppearance = true;
            this.gridMain.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridMain.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain.OptionsView.ShowFooter = true;
            this.gridMain.OptionsView.ShowGroupPanel = false;
            this.gridMain.PaintStyleName = "Skin";
            this.gridMain.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.bandedGridColumn78, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.gridMain.RowCellClick += new DevExpress.XtraGrid.Views.Grid.RowCellClickEventHandler(this.gridMain_RowCellClick);
            this.gridMain.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMain_CustomDrawCell);
            this.gridMain.RowStyle += new DevExpress.XtraGrid.Views.Grid.RowStyleEventHandler(this.gridMain_RowStyle);
            this.gridMain.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.gridMain_CustomSummaryCalculate);
            this.gridMain.ShownEditor += new System.EventHandler(this.gridMain_ShownEditor);
            this.gridMain.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMain_CellValueChanged);
            this.gridMain.CellValueChanging += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMain_CellValueChanging);
            this.gridMain.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain_CustomColumnDisplayText);
            this.gridMain.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gridMain_KeyDown);
            this.gridMain.MouseDown += new System.Windows.Forms.MouseEventHandler(this.gridMain_MouseDown);
            this.gridMain.Click += new System.EventHandler(this.gridMain_Click);
            this.gridMain.DoubleClick += new System.EventHandler(this.gridMain_DoubleClick);
            this.gridMain.ValidatingEditor += new DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventHandler(this.gridMain_ValidatingEditor);
            // 
            // dateBand
            // 
            this.dateBand.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.dateBand.AppearanceHeader.Options.UseBackColor = true;
            this.dateBand.AppearanceHeader.Options.UseBorderColor = true;
            this.dateBand.AppearanceHeader.Options.UseFont = true;
            this.dateBand.AppearanceHeader.Options.UseTextOptions = true;
            this.dateBand.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.dateBand.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.dateBand.Caption = "Date Information";
            this.dateBand.Columns.Add(this.gridColumn1);
            this.dateBand.Columns.Add(this.bandedGridColumn24);
            this.dateBand.Columns.Add(this.bandedGridColumn78);
            this.dateBand.Columns.Add(this.gridColumn2);
            this.dateBand.Columns.Add(this.bandedGridColumn95);
            this.dateBand.Columns.Add(this.gridColumn5);
            this.dateBand.Columns.Add(this.bandedGridColumn17);
            this.dateBand.Columns.Add(this.bandedGridColumn15);
            this.dateBand.Columns.Add(this.bandedGridColumn16);
            this.dateBand.MinWidth = 16;
            this.dateBand.Name = "dateBand";
            this.dateBand.RowCount = 2;
            this.dateBand.VisibleIndex = 0;
            this.dateBand.Width = 798;
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn1.Caption = "Num";
            this.gridColumn1.FieldName = "num";
            this.gridColumn1.MinWidth = 30;
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.FixedWidth = true;
            this.gridColumn1.OptionsColumn.ReadOnly = true;
            this.gridColumn1.Visible = true;
            this.gridColumn1.Width = 56;
            // 
            // bandedGridColumn24
            // 
            this.bandedGridColumn24.Caption = "Approve";
            this.bandedGridColumn24.ColumnEdit = this.repositoryItemCheckEdit1;
            this.bandedGridColumn24.FieldName = "approve";
            this.bandedGridColumn24.MinWidth = 30;
            this.bandedGridColumn24.Name = "bandedGridColumn24";
            this.bandedGridColumn24.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn24.Visible = true;
            this.bandedGridColumn24.Width = 118;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.CheckedChanged += new System.EventHandler(this.repositoryItemCheckEdit1_CheckedChanged_1);
            // 
            // bandedGridColumn78
            // 
            this.bandedGridColumn78.Caption = "What Week";
            this.bandedGridColumn78.FieldName = "week";
            this.bandedGridColumn78.MinWidth = 29;
            this.bandedGridColumn78.Name = "bandedGridColumn78";
            this.bandedGridColumn78.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn78.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn78.Width = 110;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn2.Caption = "Date";
            this.gridColumn2.FieldName = "date";
            this.gridColumn2.MinWidth = 30;
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.OptionsColumn.FixedWidth = true;
            this.gridColumn2.OptionsColumn.ReadOnly = true;
            this.gridColumn2.Visible = true;
            this.gridColumn2.Width = 92;
            // 
            // bandedGridColumn95
            // 
            this.bandedGridColumn95.Caption = "Date";
            this.bandedGridColumn95.FieldName = "newDate";
            this.bandedGridColumn95.MinWidth = 25;
            this.bandedGridColumn95.Name = "bandedGridColumn95";
            this.bandedGridColumn95.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn95.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn95.Visible = true;
            this.bandedGridColumn95.Width = 94;
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn5.Caption = "Day";
            this.gridColumn5.FieldName = "day";
            this.gridColumn5.MinWidth = 30;
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.OptionsColumn.FixedWidth = true;
            this.gridColumn5.OptionsColumn.ReadOnly = true;
            this.gridColumn5.Visible = true;
            this.gridColumn5.Width = 91;
            // 
            // bandedGridColumn17
            // 
            this.bandedGridColumn17.Caption = "Pic";
            this.bandedGridColumn17.ColumnEdit = this.repositoryItemPictureEdit1;
            this.bandedGridColumn17.FieldName = "picture";
            this.bandedGridColumn17.MinWidth = 30;
            this.bandedGridColumn17.Name = "bandedGridColumn17";
            this.bandedGridColumn17.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn17.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn17.Visible = true;
            this.bandedGridColumn17.Width = 30;
            // 
            // repositoryItemPictureEdit1
            // 
            this.repositoryItemPictureEdit1.Name = "repositoryItemPictureEdit1";
            this.repositoryItemPictureEdit1.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            // 
            // bandedGridColumn15
            // 
            this.bandedGridColumn15.Caption = "Empno";
            this.bandedGridColumn15.FieldName = "empno";
            this.bandedGridColumn15.MinWidth = 30;
            this.bandedGridColumn15.Name = "bandedGridColumn15";
            this.bandedGridColumn15.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn15.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn15.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn15.Visible = true;
            this.bandedGridColumn15.Width = 79;
            // 
            // bandedGridColumn16
            // 
            this.bandedGridColumn16.Caption = "Name";
            this.bandedGridColumn16.FieldName = "name";
            this.bandedGridColumn16.MinWidth = 30;
            this.bandedGridColumn16.Name = "bandedGridColumn16";
            this.bandedGridColumn16.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn16.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn16.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn16.Visible = true;
            this.bandedGridColumn16.Width = 238;
            // 
            // totalBand
            // 
            this.totalBand.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.totalBand.AppearanceHeader.Options.UseBackColor = true;
            this.totalBand.AppearanceHeader.Options.UseBorderColor = true;
            this.totalBand.AppearanceHeader.Options.UseFont = true;
            this.totalBand.AppearanceHeader.Options.UseForeColor = true;
            this.totalBand.AppearanceHeader.Options.UseTextOptions = true;
            this.totalBand.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.totalBand.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.totalBand.Caption = "Totals";
            this.totalBand.Columns.Add(this.bandedGridColumn5);
            this.totalBand.Columns.Add(this.bandedGridColumn6);
            this.totalBand.Columns.Add(this.bandedGridColumn22);
            this.totalBand.Columns.Add(this.gridColumn6);
            this.totalBand.MinWidth = 16;
            this.totalBand.Name = "totalBand";
            this.totalBand.RowCount = 2;
            this.totalBand.Visible = false;
            this.totalBand.VisibleIndex = -1;
            this.totalBand.Width = 280;
            // 
            // bandedGridColumn5
            // 
            this.bandedGridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn5.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn5.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn5.Caption = "Week 1";
            this.bandedGridColumn5.FieldName = "week1";
            this.bandedGridColumn5.MinWidth = 30;
            this.bandedGridColumn5.Name = "bandedGridColumn5";
            this.bandedGridColumn5.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn5.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn5.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn5.Visible = true;
            this.bandedGridColumn5.Width = 70;
            // 
            // bandedGridColumn6
            // 
            this.bandedGridColumn6.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn6.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn6.Caption = "Week 2";
            this.bandedGridColumn6.FieldName = "week2";
            this.bandedGridColumn6.MinWidth = 30;
            this.bandedGridColumn6.Name = "bandedGridColumn6";
            this.bandedGridColumn6.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn6.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn6.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn6.Visible = true;
            this.bandedGridColumn6.Width = 70;
            // 
            // bandedGridColumn22
            // 
            this.bandedGridColumn22.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn22.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn22.Caption = "Overtime";
            this.bandedGridColumn22.FieldName = "overtime";
            this.bandedGridColumn22.MinWidth = 30;
            this.bandedGridColumn22.Name = "bandedGridColumn22";
            this.bandedGridColumn22.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn22.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn22.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn22.Visible = true;
            this.bandedGridColumn22.Width = 70;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn6.Caption = "Hours";
            this.gridColumn6.FieldName = "hours";
            this.gridColumn6.MinWidth = 30;
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.OptionsColumn.FixedWidth = true;
            this.gridColumn6.OptionsColumn.ReadOnly = true;
            this.gridColumn6.Visible = true;
            this.gridColumn6.Width = 70;
            // 
            // bandPunch1
            // 
            this.bandPunch1.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.bandPunch1.AppearanceHeader.Options.UseBackColor = true;
            this.bandPunch1.AppearanceHeader.Options.UseBorderColor = true;
            this.bandPunch1.AppearanceHeader.Options.UseFont = true;
            this.bandPunch1.AppearanceHeader.Options.UseForeColor = true;
            this.bandPunch1.AppearanceHeader.Options.UseTextOptions = true;
            this.bandPunch1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandPunch1.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.bandPunch1.Caption = "Punch 1";
            this.bandPunch1.Columns.Add(this.bandedGridColumn11);
            this.bandPunch1.Columns.Add(this.gridColumn3);
            this.bandPunch1.Columns.Add(this.gridColumn4);
            this.bandPunch1.MinWidth = 16;
            this.bandPunch1.Name = "bandPunch1";
            this.bandPunch1.VisibleIndex = 1;
            this.bandPunch1.Width = 140;
            // 
            // bandedGridColumn11
            // 
            this.bandedGridColumn11.Caption = "Here";
            this.bandedGridColumn11.ColumnEdit = this.repositoryItemCheckEdit1;
            this.bandedGridColumn11.FieldName = "here";
            this.bandedGridColumn11.MinWidth = 30;
            this.bandedGridColumn11.Name = "bandedGridColumn11";
            this.bandedGridColumn11.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn11.Width = 79;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn3.Caption = "In";
            this.gridColumn3.FieldName = "in1";
            this.gridColumn3.MinWidth = 30;
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.FixedWidth = true;
            this.gridColumn3.Visible = true;
            this.gridColumn3.Width = 70;
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn4.Caption = "Out";
            this.gridColumn4.FieldName = "out1";
            this.gridColumn4.MinWidth = 30;
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.FixedWidth = true;
            this.gridColumn4.Visible = true;
            this.gridColumn4.Width = 70;
            // 
            // bandPunch2
            // 
            this.bandPunch2.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.bandPunch2.AppearanceHeader.Options.UseBackColor = true;
            this.bandPunch2.AppearanceHeader.Options.UseBorderColor = true;
            this.bandPunch2.AppearanceHeader.Options.UseFont = true;
            this.bandPunch2.AppearanceHeader.Options.UseForeColor = true;
            this.bandPunch2.AppearanceHeader.Options.UseTextOptions = true;
            this.bandPunch2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandPunch2.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.bandPunch2.Caption = "Punch 2";
            this.bandPunch2.Columns.Add(this.bandedGridColumn4);
            this.bandPunch2.Columns.Add(this.bandedGridColumn3);
            this.bandPunch2.MinWidth = 16;
            this.bandPunch2.Name = "bandPunch2";
            this.bandPunch2.VisibleIndex = 2;
            this.bandPunch2.Width = 140;
            // 
            // bandedGridColumn4
            // 
            this.bandedGridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn4.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn4.Caption = "In";
            this.bandedGridColumn4.FieldName = "in2";
            this.bandedGridColumn4.MinWidth = 30;
            this.bandedGridColumn4.Name = "bandedGridColumn4";
            this.bandedGridColumn4.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn4.Visible = true;
            this.bandedGridColumn4.Width = 70;
            // 
            // bandedGridColumn3
            // 
            this.bandedGridColumn3.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn3.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn3.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn3.Caption = "Out";
            this.bandedGridColumn3.FieldName = "out2";
            this.bandedGridColumn3.MinWidth = 30;
            this.bandedGridColumn3.Name = "bandedGridColumn3";
            this.bandedGridColumn3.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn3.Visible = true;
            this.bandedGridColumn3.Width = 70;
            // 
            // bandPunch3
            // 
            this.bandPunch3.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.bandPunch3.AppearanceHeader.Options.UseBackColor = true;
            this.bandPunch3.AppearanceHeader.Options.UseBorderColor = true;
            this.bandPunch3.AppearanceHeader.Options.UseFont = true;
            this.bandPunch3.AppearanceHeader.Options.UseForeColor = true;
            this.bandPunch3.AppearanceHeader.Options.UseTextOptions = true;
            this.bandPunch3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandPunch3.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.bandPunch3.Caption = "Punch 3";
            this.bandPunch3.Columns.Add(this.bandedGridColumn1);
            this.bandPunch3.Columns.Add(this.bandedGridColumn2);
            this.bandPunch3.MinWidth = 16;
            this.bandPunch3.Name = "bandPunch3";
            this.bandPunch3.VisibleIndex = 3;
            this.bandPunch3.Width = 140;
            // 
            // bandedGridColumn1
            // 
            this.bandedGridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn1.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.bandedGridColumn1.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn1.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn1.Caption = "In";
            this.bandedGridColumn1.FieldName = "in3";
            this.bandedGridColumn1.MinWidth = 30;
            this.bandedGridColumn1.Name = "bandedGridColumn1";
            this.bandedGridColumn1.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn1.Visible = true;
            this.bandedGridColumn1.Width = 70;
            // 
            // bandedGridColumn2
            // 
            this.bandedGridColumn2.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn2.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.bandedGridColumn2.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn2.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn2.Caption = "Out";
            this.bandedGridColumn2.FieldName = "out3";
            this.bandedGridColumn2.MinWidth = 30;
            this.bandedGridColumn2.Name = "bandedGridColumn2";
            this.bandedGridColumn2.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn2.Visible = true;
            this.bandedGridColumn2.Width = 70;
            // 
            // bandPunch4
            // 
            this.bandPunch4.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.bandPunch4.AppearanceHeader.Options.UseFont = true;
            this.bandPunch4.AppearanceHeader.Options.UseTextOptions = true;
            this.bandPunch4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandPunch4.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.bandPunch4.Caption = "Punch 4";
            this.bandPunch4.Columns.Add(this.bandedGridColumn7);
            this.bandPunch4.Columns.Add(this.bandedGridColumn8);
            this.bandPunch4.MinWidth = 16;
            this.bandPunch4.Name = "bandPunch4";
            this.bandPunch4.VisibleIndex = 4;
            this.bandPunch4.Width = 140;
            // 
            // bandedGridColumn7
            // 
            this.bandedGridColumn7.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn7.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn7.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.bandedGridColumn7.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn7.Caption = "In";
            this.bandedGridColumn7.FieldName = "in4";
            this.bandedGridColumn7.MinWidth = 30;
            this.bandedGridColumn7.Name = "bandedGridColumn7";
            this.bandedGridColumn7.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn7.Visible = true;
            this.bandedGridColumn7.Width = 70;
            // 
            // bandedGridColumn8
            // 
            this.bandedGridColumn8.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn8.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn8.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn8.Caption = "Out";
            this.bandedGridColumn8.FieldName = "out4";
            this.bandedGridColumn8.MinWidth = 30;
            this.bandedGridColumn8.Name = "bandedGridColumn8";
            this.bandedGridColumn8.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn8.Visible = true;
            this.bandedGridColumn8.Width = 70;
            // 
            // bandPunch5
            // 
            this.bandPunch5.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.bandPunch5.AppearanceHeader.Options.UseFont = true;
            this.bandPunch5.AppearanceHeader.Options.UseTextOptions = true;
            this.bandPunch5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandPunch5.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.bandPunch5.Caption = "Punch 5";
            this.bandPunch5.Columns.Add(this.bandedGridColumn10);
            this.bandPunch5.Columns.Add(this.bandedGridColumn9);
            this.bandPunch5.MinWidth = 16;
            this.bandPunch5.Name = "bandPunch5";
            this.bandPunch5.VisibleIndex = 5;
            this.bandPunch5.Width = 140;
            // 
            // bandedGridColumn10
            // 
            this.bandedGridColumn10.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn10.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn10.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.bandedGridColumn10.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn10.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn10.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn10.Caption = "In";
            this.bandedGridColumn10.FieldName = "in5";
            this.bandedGridColumn10.MinWidth = 30;
            this.bandedGridColumn10.Name = "bandedGridColumn10";
            this.bandedGridColumn10.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn10.Visible = true;
            this.bandedGridColumn10.Width = 70;
            // 
            // bandedGridColumn9
            // 
            this.bandedGridColumn9.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn9.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn9.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn9.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn9.Caption = "Out";
            this.bandedGridColumn9.FieldName = "out5";
            this.bandedGridColumn9.MinWidth = 30;
            this.bandedGridColumn9.Name = "bandedGridColumn9";
            this.bandedGridColumn9.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn9.Visible = true;
            this.bandedGridColumn9.Width = 70;
            // 
            // bandSalary
            // 
            this.bandSalary.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.bandSalary.AppearanceHeader.Options.UseFont = true;
            this.bandSalary.AppearanceHeader.Options.UseTextOptions = true;
            this.bandSalary.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandSalary.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.bandSalary.Caption = "Other";
            this.bandSalary.Columns.Add(this.gridColumn7);
            this.bandSalary.Columns.Add(this.bandedGridColumn62);
            this.bandSalary.Columns.Add(this.bandedGridColumn63);
            this.bandSalary.Columns.Add(this.bandedGridColumn65);
            this.bandSalary.Columns.Add(this.bandedGridColumn66);
            this.bandSalary.Columns.Add(this.bandedGridColumn23);
            this.bandSalary.Columns.Add(this.bandedGridColumn20);
            this.bandSalary.Columns.Add(this.bandedGridColumn21);
            this.bandSalary.Columns.Add(this.bandedGridColumn25);
            this.bandSalary.MinWidth = 16;
            this.bandSalary.Name = "bandSalary";
            this.bandSalary.VisibleIndex = 6;
            this.bandSalary.Width = 451;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn7.Caption = "Hours Worked";
            this.gridColumn7.FieldName = "total";
            this.gridColumn7.MinWidth = 30;
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.OptionsColumn.FixedWidth = true;
            this.gridColumn7.OptionsColumn.ReadOnly = true;
            this.gridColumn7.Visible = true;
            this.gridColumn7.Width = 80;
            // 
            // bandedGridColumn62
            // 
            this.bandedGridColumn62.Caption = "Vacation";
            this.bandedGridColumn62.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn62.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn62.FieldName = "vacation";
            this.bandedGridColumn62.MinWidth = 34;
            this.bandedGridColumn62.Name = "bandedGridColumn62";
            this.bandedGridColumn62.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn62.Visible = true;
            this.bandedGridColumn62.Width = 78;
            // 
            // bandedGridColumn63
            // 
            this.bandedGridColumn63.Caption = "Holiday";
            this.bandedGridColumn63.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn63.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn63.FieldName = "holiday";
            this.bandedGridColumn63.MinWidth = 34;
            this.bandedGridColumn63.Name = "bandedGridColumn63";
            this.bandedGridColumn63.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn63.Visible = true;
            this.bandedGridColumn63.Width = 76;
            // 
            // bandedGridColumn65
            // 
            this.bandedGridColumn65.Caption = "Sick";
            this.bandedGridColumn65.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn65.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn65.FieldName = "sick";
            this.bandedGridColumn65.MinWidth = 34;
            this.bandedGridColumn65.Name = "bandedGridColumn65";
            this.bandedGridColumn65.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn65.Visible = true;
            this.bandedGridColumn65.Width = 56;
            // 
            // bandedGridColumn66
            // 
            this.bandedGridColumn66.Caption = "Other";
            this.bandedGridColumn66.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn66.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn66.FieldName = "other";
            this.bandedGridColumn66.MinWidth = 34;
            this.bandedGridColumn66.Name = "bandedGridColumn66";
            this.bandedGridColumn66.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn66.OptionsColumn.AllowFocus = false;
            this.bandedGridColumn66.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn66.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn66.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "other", "{0:0,0.00}")});
            this.bandedGridColumn66.Visible = true;
            this.bandedGridColumn66.Width = 63;
            // 
            // bandedGridColumn23
            // 
            this.bandedGridColumn23.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn23.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn23.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.bandedGridColumn23.Caption = "Notes";
            this.bandedGridColumn23.FieldName = "notes";
            this.bandedGridColumn23.MinWidth = 30;
            this.bandedGridColumn23.Name = "bandedGridColumn23";
            this.bandedGridColumn23.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn23.Visible = true;
            this.bandedGridColumn23.Width = 98;
            // 
            // bandedGridColumn20
            // 
            this.bandedGridColumn20.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn20.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn20.Caption = "Full";
            this.bandedGridColumn20.ColumnEdit = this.repositoryItemCheckEdit1;
            this.bandedGridColumn20.FieldName = "full";
            this.bandedGridColumn20.MinWidth = 30;
            this.bandedGridColumn20.Name = "bandedGridColumn20";
            this.bandedGridColumn20.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn20.Width = 118;
            // 
            // bandedGridColumn21
            // 
            this.bandedGridColumn21.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn21.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn21.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn21.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn21.Caption = "Out";
            this.bandedGridColumn21.FieldName = "part";
            this.bandedGridColumn21.MinWidth = 30;
            this.bandedGridColumn21.Name = "bandedGridColumn21";
            this.bandedGridColumn21.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn21.Width = 104;
            // 
            // bandedGridColumn25
            // 
            this.bandedGridColumn25.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn25.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn25.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn25.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn25.Caption = "Partial";
            this.bandedGridColumn25.FieldName = "worked";
            this.bandedGridColumn25.MinWidth = 30;
            this.bandedGridColumn25.Name = "bandedGridColumn25";
            this.bandedGridColumn25.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn25.Width = 104;
            // 
            // bandholiday
            // 
            this.bandholiday.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.bandholiday.AppearanceHeader.Options.UseFont = true;
            this.bandholiday.AppearanceHeader.Options.UseTextOptions = true;
            this.bandholiday.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandholiday.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.bandholiday.Caption = "Holiday";
            this.bandholiday.Columns.Add(this.bandedGridColumn13);
            this.bandholiday.Columns.Add(this.bandedGridColumn14);
            this.bandholiday.MinWidth = 16;
            this.bandholiday.Name = "bandholiday";
            this.bandholiday.VisibleIndex = 7;
            this.bandholiday.Width = 236;
            // 
            // bandedGridColumn13
            // 
            this.bandedGridColumn13.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn13.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn13.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn13.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn13.Caption = "Holiday 1";
            this.bandedGridColumn13.FieldName = "holiday1";
            this.bandedGridColumn13.MinWidth = 30;
            this.bandedGridColumn13.Name = "bandedGridColumn13";
            this.bandedGridColumn13.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn13.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn13.Visible = true;
            this.bandedGridColumn13.Width = 118;
            // 
            // bandedGridColumn14
            // 
            this.bandedGridColumn14.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn14.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn14.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn14.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn14.Caption = "Holiday 2";
            this.bandedGridColumn14.FieldName = "holiday2";
            this.bandedGridColumn14.MinWidth = 30;
            this.bandedGridColumn14.Name = "bandedGridColumn14";
            this.bandedGridColumn14.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn14.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn14.Visible = true;
            this.bandedGridColumn14.Width = 118;
            // 
            // bandPTO
            // 
            this.bandPTO.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.bandPTO.AppearanceHeader.Options.UseFont = true;
            this.bandPTO.AppearanceHeader.Options.UseTextOptions = true;
            this.bandPTO.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandPTO.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.bandPTO.Caption = "PTO";
            this.bandPTO.Columns.Add(this.bandedGridColumn12);
            this.bandPTO.Columns.Add(this.bandedGridColumn18);
            this.bandPTO.Columns.Add(this.bandedGridColumn26);
            this.bandPTO.Columns.Add(this.bandedGridColumn49);
            this.bandPTO.Columns.Add(this.bandedGridColumn50);
            this.bandPTO.MinWidth = 16;
            this.bandPTO.Name = "bandPTO";
            this.bandPTO.VisibleIndex = 8;
            this.bandPTO.Width = 528;
            // 
            // bandedGridColumn12
            // 
            this.bandedGridColumn12.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn12.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn12.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn12.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn12.Caption = "PTO";
            this.bandedGridColumn12.FieldName = "pto";
            this.bandedGridColumn12.MinWidth = 30;
            this.bandedGridColumn12.Name = "bandedGridColumn12";
            this.bandedGridColumn12.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn12.Visible = true;
            this.bandedGridColumn12.Width = 104;
            // 
            // bandedGridColumn18
            // 
            this.bandedGridColumn18.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn18.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn18.Caption = "PTO(?)";
            this.bandedGridColumn18.FieldName = "qpto";
            this.bandedGridColumn18.MinWidth = 30;
            this.bandedGridColumn18.Name = "bandedGridColumn18";
            this.bandedGridColumn18.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn18.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn18.Visible = true;
            this.bandedGridColumn18.Width = 104;
            // 
            // bandedGridColumn26
            // 
            this.bandedGridColumn26.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn26.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn26.Caption = "Dock";
            this.bandedGridColumn26.FieldName = "docked";
            this.bandedGridColumn26.MinWidth = 30;
            this.bandedGridColumn26.Name = "bandedGridColumn26";
            this.bandedGridColumn26.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn26.Visible = true;
            this.bandedGridColumn26.Width = 104;
            // 
            // bandedGridColumn49
            // 
            this.bandedGridColumn49.Caption = "Dock(?)";
            this.bandedGridColumn49.FieldName = "qdocked";
            this.bandedGridColumn49.MinWidth = 30;
            this.bandedGridColumn49.Name = "bandedGridColumn49";
            this.bandedGridColumn49.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn49.Visible = true;
            this.bandedGridColumn49.Width = 112;
            // 
            // bandedGridColumn50
            // 
            this.bandedGridColumn50.Caption = "Paid";
            this.bandedGridColumn50.FieldName = "paid";
            this.bandedGridColumn50.MinWidth = 30;
            this.bandedGridColumn50.Name = "bandedGridColumn50";
            this.bandedGridColumn50.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn50.Visible = true;
            this.bandedGridColumn50.Width = 104;
            // 
            // gridNotes
            // 
            this.gridNotes.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gridNotes.AppearanceHeader.Options.UseFont = true;
            this.gridNotes.AppearanceHeader.Options.UseTextOptions = true;
            this.gridNotes.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gridNotes.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridNotes.Caption = "Notes";
            this.gridNotes.Columns.Add(this.bandedGridColumn27);
            this.gridNotes.MinWidth = 16;
            this.gridNotes.Name = "gridNotes";
            this.gridNotes.VisibleIndex = 9;
            this.gridNotes.Width = 98;
            // 
            // bandedGridColumn27
            // 
            this.bandedGridColumn27.Caption = "Cycle Notes";
            this.bandedGridColumn27.FieldName = "cyclenotes";
            this.bandedGridColumn27.MinWidth = 30;
            this.bandedGridColumn27.Name = "bandedGridColumn27";
            this.bandedGridColumn27.Width = 100;
            // 
            // bandedGridColumn19
            // 
            this.bandedGridColumn19.Caption = "jobcode";
            this.bandedGridColumn19.FieldName = "jobcode";
            this.bandedGridColumn19.MinWidth = 30;
            this.bandedGridColumn19.Name = "bandedGridColumn19";
            this.bandedGridColumn19.Width = 118;
            // 
            // bandedGridColumn48
            // 
            this.bandedGridColumn48.Caption = "AllowPTO";
            this.bandedGridColumn48.FieldName = "allowpto";
            this.bandedGridColumn48.MinWidth = 30;
            this.bandedGridColumn48.Name = "bandedGridColumn48";
            this.bandedGridColumn48.Width = 118;
            // 
            // tabReport
            // 
            this.tabReport.Controls.Add(this.panelReportAll);
            this.tabReport.Location = new System.Drawing.Point(4, 26);
            this.tabReport.Name = "tabReport";
            this.tabReport.Size = new System.Drawing.Size(1220, 571);
            this.tabReport.TabIndex = 2;
            this.tabReport.Text = "Time Report";
            this.tabReport.UseVisualStyleBackColor = true;
            // 
            // panelReportAll
            // 
            this.panelReportAll.Controls.Add(this.panelReportBottom);
            this.panelReportAll.Controls.Add(this.panelReportTop);
            this.panelReportAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelReportAll.Location = new System.Drawing.Point(0, 0);
            this.panelReportAll.Name = "panelReportAll";
            this.panelReportAll.Size = new System.Drawing.Size(1220, 571);
            this.panelReportAll.TabIndex = 0;
            // 
            // panelReportBottom
            // 
            this.panelReportBottom.Controls.Add(this.dgv4);
            this.panelReportBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelReportBottom.Location = new System.Drawing.Point(0, 10);
            this.panelReportBottom.Name = "panelReportBottom";
            this.panelReportBottom.Size = new System.Drawing.Size(1220, 561);
            this.panelReportBottom.TabIndex = 2;
            // 
            // dgv4
            // 
            this.dgv4.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv4.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(5);
            this.dgv4.Location = new System.Drawing.Point(0, 0);
            this.dgv4.MainView = this.gridMain4;
            this.dgv4.Name = "dgv4";
            this.dgv4.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit3,
            this.repositoryItemPictureEdit2});
            this.dgv4.Size = new System.Drawing.Size(1220, 561);
            this.dgv4.TabIndex = 4;
            this.dgv4.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain4});
            // 
            // gridMain4
            // 
            this.gridMain4.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(203)))), ((int)(((byte)(147)))));
            this.gridMain4.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(203)))), ((int)(((byte)(147)))));
            this.gridMain4.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain4.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(30)))), ((int)(((byte)(96)))));
            this.gridMain4.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain4.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(233)))), ((int)(((byte)(177)))));
            this.gridMain4.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain4.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(233)))), ((int)(((byte)(177)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(239)))), ((int)(((byte)(196)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(233)))), ((int)(((byte)(177)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain4.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(233)))), ((int)(((byte)(177)))));
            this.gridMain4.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain4.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain4.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain4.Appearance.EvenRow.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain4.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.EvenRow.Options.UseFont = true;
            this.gridMain4.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain4.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(90)))), ((int)(((byte)(156)))));
            this.gridMain4.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain4.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(0)))), ((int)(((byte)(66)))));
            this.gridMain4.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain4.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain4.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.gridMain4.Appearance.FixedLine.BackColor2 = System.Drawing.Color.Yellow;
            this.gridMain4.Appearance.FixedLine.BorderColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FixedLine.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain4.Appearance.FixedLine.Options.UseBorderColor = true;
            this.gridMain4.Appearance.FixedLine.Options.UseForeColor = true;
            this.gridMain4.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FocusedCell.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain4.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Purple;
            this.gridMain4.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedCell.Options.UseFont = true;
            this.gridMain4.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain4.Appearance.FocusedRow.BackColor = System.Drawing.Color.Yellow;
            this.gridMain4.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.Yellow;
            this.gridMain4.Appearance.FocusedRow.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain4.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedRow.Options.UseFont = true;
            this.gridMain4.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain4.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain4.Appearance.FooterPanel.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain4.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.FooterPanel.Options.UseFont = true;
            this.gridMain4.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain4.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain4.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(223)))), ((int)(((byte)(167)))));
            this.gridMain4.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(223)))), ((int)(((byte)(167)))));
            this.gridMain4.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(0)))), ((int)(((byte)(66)))));
            this.gridMain4.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain4.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(165)))), ((int)(((byte)(47)))));
            this.gridMain4.Appearance.GroupRow.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain4.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(234)))), ((int)(((byte)(207)))));
            this.gridMain4.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain4.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain4.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain4.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(40)))), ((int)(((byte)(106)))));
            this.gridMain4.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain4.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Yellow;
            this.gridMain4.Appearance.HideSelectionRow.BackColor2 = System.Drawing.Color.Yellow;
            this.gridMain4.Appearance.HideSelectionRow.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain4.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.HideSelectionRow.Options.UseFont = true;
            this.gridMain4.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.HorzLine.BackColor = System.Drawing.Color.Wheat;
            this.gridMain4.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain4.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(234)))), ((int)(((byte)(207)))));
            this.gridMain4.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.OddRow.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain4.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain4.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.OddRow.Options.UseFont = true;
            this.gridMain4.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(217)))));
            this.gridMain4.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.Preview.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain4.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(165)))), ((int)(((byte)(47)))));
            this.gridMain4.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain4.Appearance.Preview.Options.UseFont = true;
            this.gridMain4.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain4.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain4.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.Row.Options.UseBackColor = true;
            this.gridMain4.Appearance.Row.Options.UseFont = true;
            this.gridMain4.Appearance.Row.Options.UseForeColor = true;
            this.gridMain4.Appearance.RowSeparator.BackColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(233)))), ((int)(((byte)(177)))));
            this.gridMain4.Appearance.RowSeparator.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain4.Appearance.RowSeparator.Options.UseForeColor = true;
            this.gridMain4.Appearance.SelectedRow.BackColor = System.Drawing.Color.Yellow;
            this.gridMain4.Appearance.SelectedRow.BackColor2 = System.Drawing.Color.Yellow;
            this.gridMain4.Appearance.SelectedRow.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain4.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.SelectedRow.Options.UseFont = true;
            this.gridMain4.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.TopNewRow.Font = new System.Drawing.Font("Tahoma", 10F);
            this.gridMain4.Appearance.TopNewRow.Options.UseFont = true;
            this.gridMain4.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(213)))), ((int)(((byte)(157)))));
            this.gridMain4.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain4.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand1,
            this.gridBand2,
            this.gridBand3,
            this.gridBand4,
            this.gridBand5,
            this.gridBand6,
            this.gridBand7,
            this.gridBand8,
            this.gridBand9,
            this.gridBand10,
            this.gridBand11});
            this.gridMain4.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain4.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn28,
            this.bandedGridColumn30,
            this.bandedGridColumn31,
            this.bandedGridColumn35,
            this.bandedGridColumn36,
            this.bandedGridColumn37,
            this.bandedGridColumn38,
            this.bandedGridColumn39,
            this.bandedGridColumn40,
            this.bandedGridColumn56,
            this.bandedGridColumn57,
            this.bandedGridColumn58,
            this.bandedGridColumn54,
            this.bandedGridColumn55,
            this.bandedGridColumn33,
            this.bandedGridColumn34,
            this.bandedGridColumn32,
            this.bandedGridColumn61,
            this.bandedGridColumn51,
            this.bandedGridColumn52,
            this.bandedGridColumn53,
            this.bandedGridColumn59,
            this.bandedGridColumn29,
            this.bandedGridColumn60,
            this.bandedGridColumn42,
            this.bandedGridColumn41,
            this.bandedGridColumn43,
            this.bandedGridColumn44,
            this.bandedGridColumn45,
            this.bandedGridColumn46,
            this.bandedGridColumn47});
            this.gridMain4.GridControl = this.dgv4;
            this.gridMain4.Name = "gridMain4";
            this.gridMain4.OptionsLayout.StoreAllOptions = true;
            this.gridMain4.OptionsLayout.StoreAppearance = true;
            this.gridMain4.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain4.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain4.OptionsView.ShowGroupPanel = false;
            this.gridMain4.PaintStyleName = "Skin";
            this.gridMain4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.gridMain4_MouseDown);
            this.gridMain4.Click += new System.EventHandler(this.gridMain4_Click);
            // 
            // gridBand1
            // 
            this.gridBand1.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridBand1.AppearanceHeader.Options.UseBackColor = true;
            this.gridBand1.AppearanceHeader.Options.UseBorderColor = true;
            this.gridBand1.AppearanceHeader.Options.UseFont = true;
            this.gridBand1.AppearanceHeader.Options.UseTextOptions = true;
            this.gridBand1.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridBand1.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridBand1.Caption = "Date Information";
            this.gridBand1.Columns.Add(this.bandedGridColumn28);
            this.gridBand1.Columns.Add(this.bandedGridColumn29);
            this.gridBand1.Columns.Add(this.bandedGridColumn30);
            this.gridBand1.Columns.Add(this.bandedGridColumn31);
            this.gridBand1.Columns.Add(this.bandedGridColumn32);
            this.gridBand1.Columns.Add(this.bandedGridColumn33);
            this.gridBand1.Columns.Add(this.bandedGridColumn34);
            this.gridBand1.Columns.Add(this.bandedGridColumn41);
            this.gridBand1.Columns.Add(this.bandedGridColumn59);
            this.gridBand1.Columns.Add(this.bandedGridColumn42);
            this.gridBand1.Name = "gridBand1";
            this.gridBand1.RowCount = 2;
            this.gridBand1.VisibleIndex = 0;
            this.gridBand1.Width = 515;
            // 
            // bandedGridColumn28
            // 
            this.bandedGridColumn28.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn28.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn28.Caption = "Num";
            this.bandedGridColumn28.FieldName = "num";
            this.bandedGridColumn28.MinWidth = 19;
            this.bandedGridColumn28.Name = "bandedGridColumn28";
            this.bandedGridColumn28.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn28.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn28.Visible = true;
            this.bandedGridColumn28.Width = 40;
            // 
            // bandedGridColumn29
            // 
            this.bandedGridColumn29.Caption = "Approve";
            this.bandedGridColumn29.ColumnEdit = this.repositoryItemCheckEdit3;
            this.bandedGridColumn29.FieldName = "approve";
            this.bandedGridColumn29.MinWidth = 19;
            this.bandedGridColumn29.Name = "bandedGridColumn29";
            this.bandedGridColumn29.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn29.Visible = true;
            // 
            // repositoryItemCheckEdit3
            // 
            this.repositoryItemCheckEdit3.AutoHeight = false;
            this.repositoryItemCheckEdit3.Name = "repositoryItemCheckEdit3";
            this.repositoryItemCheckEdit3.CheckedChanged += new System.EventHandler(this.repositoryItemCheckEdit3_CheckedChanged);
            // 
            // bandedGridColumn30
            // 
            this.bandedGridColumn30.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn30.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn30.Caption = "Date";
            this.bandedGridColumn30.FieldName = "date";
            this.bandedGridColumn30.MinWidth = 19;
            this.bandedGridColumn30.Name = "bandedGridColumn30";
            this.bandedGridColumn30.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn30.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn30.Width = 80;
            // 
            // bandedGridColumn31
            // 
            this.bandedGridColumn31.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn31.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn31.Caption = "Day";
            this.bandedGridColumn31.FieldName = "day";
            this.bandedGridColumn31.MinWidth = 19;
            this.bandedGridColumn31.Name = "bandedGridColumn31";
            this.bandedGridColumn31.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn31.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn31.Width = 80;
            // 
            // bandedGridColumn32
            // 
            this.bandedGridColumn32.Caption = "Pic";
            this.bandedGridColumn32.ColumnEdit = this.repositoryItemPictureEdit2;
            this.bandedGridColumn32.FieldName = "picture";
            this.bandedGridColumn32.MinWidth = 19;
            this.bandedGridColumn32.Name = "bandedGridColumn32";
            this.bandedGridColumn32.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn32.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn32.Width = 19;
            // 
            // repositoryItemPictureEdit2
            // 
            this.repositoryItemPictureEdit2.Name = "repositoryItemPictureEdit2";
            this.repositoryItemPictureEdit2.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            // 
            // bandedGridColumn33
            // 
            this.bandedGridColumn33.Caption = "Empno";
            this.bandedGridColumn33.FieldName = "empno";
            this.bandedGridColumn33.MinWidth = 19;
            this.bandedGridColumn33.Name = "bandedGridColumn33";
            this.bandedGridColumn33.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn33.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn33.Visible = true;
            this.bandedGridColumn33.Width = 50;
            // 
            // bandedGridColumn34
            // 
            this.bandedGridColumn34.Caption = "Name";
            this.bandedGridColumn34.FieldName = "name";
            this.bandedGridColumn34.MinWidth = 19;
            this.bandedGridColumn34.Name = "bandedGridColumn34";
            this.bandedGridColumn34.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn34.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn34.Visible = true;
            this.bandedGridColumn34.Width = 150;
            // 
            // bandedGridColumn41
            // 
            this.bandedGridColumn41.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic);
            this.bandedGridColumn41.AppearanceCell.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bandedGridColumn41.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn41.AppearanceCell.Options.UseForeColor = true;
            this.bandedGridColumn41.Caption = "Supervisor";
            this.bandedGridColumn41.FieldName = "supervisor";
            this.bandedGridColumn41.MinWidth = 19;
            this.bandedGridColumn41.Name = "bandedGridColumn41";
            this.bandedGridColumn41.RowIndex = 1;
            this.bandedGridColumn41.Visible = true;
            this.bandedGridColumn41.Width = 99;
            // 
            // bandedGridColumn59
            // 
            this.bandedGridColumn59.AppearanceCell.ForeColor = System.Drawing.Color.Red;
            this.bandedGridColumn59.AppearanceCell.Options.UseForeColor = true;
            this.bandedGridColumn59.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn59.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn59.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.bandedGridColumn59.Caption = "Notes";
            this.bandedGridColumn59.FieldName = "notes";
            this.bandedGridColumn59.MinWidth = 19;
            this.bandedGridColumn59.Name = "bandedGridColumn59";
            this.bandedGridColumn59.RowIndex = 1;
            this.bandedGridColumn59.Visible = true;
            this.bandedGridColumn59.Width = 415;
            // 
            // bandedGridColumn42
            // 
            this.bandedGridColumn42.AppearanceCell.ForeColor = System.Drawing.Color.Red;
            this.bandedGridColumn42.AppearanceCell.Options.UseForeColor = true;
            this.bandedGridColumn42.Caption = "Spacer";
            this.bandedGridColumn42.FieldName = "spacer";
            this.bandedGridColumn42.MinWidth = 19;
            this.bandedGridColumn42.Name = "bandedGridColumn42";
            this.bandedGridColumn42.RowIndex = 2;
            this.bandedGridColumn42.Visible = true;
            this.bandedGridColumn42.Width = 515;
            // 
            // gridBand2
            // 
            this.gridBand2.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridBand2.AppearanceHeader.Options.UseBackColor = true;
            this.gridBand2.AppearanceHeader.Options.UseBorderColor = true;
            this.gridBand2.AppearanceHeader.Options.UseFont = true;
            this.gridBand2.AppearanceHeader.Options.UseForeColor = true;
            this.gridBand2.AppearanceHeader.Options.UseTextOptions = true;
            this.gridBand2.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridBand2.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridBand2.Caption = "Totals";
            this.gridBand2.Columns.Add(this.bandedGridColumn35);
            this.gridBand2.Columns.Add(this.bandedGridColumn36);
            this.gridBand2.Columns.Add(this.bandedGridColumn37);
            this.gridBand2.Columns.Add(this.bandedGridColumn38);
            this.gridBand2.Columns.Add(this.bandedGridColumn39);
            this.gridBand2.Columns.Add(this.bandedGridColumn60);
            this.gridBand2.Columns.Add(this.bandedGridColumn45);
            this.gridBand2.Name = "gridBand2";
            this.gridBand2.RowCount = 2;
            this.gridBand2.VisibleIndex = 1;
            this.gridBand2.Width = 365;
            // 
            // bandedGridColumn35
            // 
            this.bandedGridColumn35.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bandedGridColumn35.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn35.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn35.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn35.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn35.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn35.Caption = "Total";
            this.bandedGridColumn35.FieldName = "total";
            this.bandedGridColumn35.MinWidth = 19;
            this.bandedGridColumn35.Name = "bandedGridColumn35";
            this.bandedGridColumn35.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn35.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn35.Visible = true;
            // 
            // bandedGridColumn36
            // 
            this.bandedGridColumn36.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.bandedGridColumn36.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn36.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn36.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn36.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn36.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn36.Caption = "Week 1";
            this.bandedGridColumn36.FieldName = "week1";
            this.bandedGridColumn36.MinWidth = 19;
            this.bandedGridColumn36.Name = "bandedGridColumn36";
            this.bandedGridColumn36.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn36.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn36.Visible = true;
            // 
            // bandedGridColumn37
            // 
            this.bandedGridColumn37.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.bandedGridColumn37.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn37.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn37.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn37.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn37.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn37.Caption = "Week 2";
            this.bandedGridColumn37.FieldName = "week2";
            this.bandedGridColumn37.MinWidth = 19;
            this.bandedGridColumn37.Name = "bandedGridColumn37";
            this.bandedGridColumn37.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn37.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn37.Visible = true;
            // 
            // bandedGridColumn38
            // 
            this.bandedGridColumn38.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.bandedGridColumn38.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn38.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn38.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn38.Caption = "Overtime";
            this.bandedGridColumn38.FieldName = "overtime";
            this.bandedGridColumn38.MinWidth = 19;
            this.bandedGridColumn38.Name = "bandedGridColumn38";
            this.bandedGridColumn38.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn38.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn38.Visible = true;
            // 
            // bandedGridColumn39
            // 
            this.bandedGridColumn39.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.bandedGridColumn39.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn39.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn39.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn39.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn39.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn39.Caption = "Hours";
            this.bandedGridColumn39.FieldName = "hours";
            this.bandedGridColumn39.MinWidth = 19;
            this.bandedGridColumn39.Name = "bandedGridColumn39";
            this.bandedGridColumn39.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn39.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn39.Visible = true;
            this.bandedGridColumn39.Width = 65;
            // 
            // bandedGridColumn60
            // 
            this.bandedGridColumn60.AppearanceCell.ForeColor = System.Drawing.Color.Blue;
            this.bandedGridColumn60.AppearanceCell.Options.UseForeColor = true;
            this.bandedGridColumn60.Caption = "Cycle Notes";
            this.bandedGridColumn60.FieldName = "cyclenotes";
            this.bandedGridColumn60.MinWidth = 19;
            this.bandedGridColumn60.Name = "bandedGridColumn60";
            this.bandedGridColumn60.RowIndex = 1;
            this.bandedGridColumn60.Visible = true;
            this.bandedGridColumn60.Width = 365;
            // 
            // bandedGridColumn45
            // 
            this.bandedGridColumn45.AppearanceCell.ForeColor = System.Drawing.Color.Red;
            this.bandedGridColumn45.AppearanceCell.Options.UseForeColor = true;
            this.bandedGridColumn45.Caption = "Spacer2";
            this.bandedGridColumn45.FieldName = "spacer2";
            this.bandedGridColumn45.MinWidth = 19;
            this.bandedGridColumn45.Name = "bandedGridColumn45";
            this.bandedGridColumn45.RowIndex = 2;
            this.bandedGridColumn45.Visible = true;
            this.bandedGridColumn45.Width = 365;
            // 
            // gridBand3
            // 
            this.gridBand3.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridBand3.AppearanceHeader.Options.UseBackColor = true;
            this.gridBand3.AppearanceHeader.Options.UseBorderColor = true;
            this.gridBand3.AppearanceHeader.Options.UseFont = true;
            this.gridBand3.AppearanceHeader.Options.UseForeColor = true;
            this.gridBand3.AppearanceHeader.Options.UseTextOptions = true;
            this.gridBand3.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridBand3.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.gridBand3.Caption = "Punch 1";
            this.gridBand3.Columns.Add(this.bandedGridColumn40);
            this.gridBand3.Name = "gridBand3";
            this.gridBand3.Visible = false;
            this.gridBand3.VisibleIndex = -1;
            this.gridBand3.Width = 85;
            // 
            // bandedGridColumn40
            // 
            this.bandedGridColumn40.Caption = "Here";
            this.bandedGridColumn40.ColumnEdit = this.repositoryItemCheckEdit3;
            this.bandedGridColumn40.FieldName = "here";
            this.bandedGridColumn40.MinWidth = 19;
            this.bandedGridColumn40.Name = "bandedGridColumn40";
            this.bandedGridColumn40.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn40.Width = 50;
            // 
            // gridBand4
            // 
            this.gridBand4.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridBand4.AppearanceHeader.Options.UseBackColor = true;
            this.gridBand4.AppearanceHeader.Options.UseBorderColor = true;
            this.gridBand4.AppearanceHeader.Options.UseFont = true;
            this.gridBand4.AppearanceHeader.Options.UseForeColor = true;
            this.gridBand4.AppearanceHeader.Options.UseTextOptions = true;
            this.gridBand4.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridBand4.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.gridBand4.Caption = "Punch 2";
            this.gridBand4.Name = "gridBand4";
            this.gridBand4.Visible = false;
            this.gridBand4.VisibleIndex = -1;
            this.gridBand4.Width = 85;
            // 
            // gridBand5
            // 
            this.gridBand5.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridBand5.AppearanceHeader.Options.UseBackColor = true;
            this.gridBand5.AppearanceHeader.Options.UseBorderColor = true;
            this.gridBand5.AppearanceHeader.Options.UseFont = true;
            this.gridBand5.AppearanceHeader.Options.UseForeColor = true;
            this.gridBand5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridBand5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridBand5.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.gridBand5.Caption = "Punch 3";
            this.gridBand5.Name = "gridBand5";
            this.gridBand5.Visible = false;
            this.gridBand5.VisibleIndex = -1;
            this.gridBand5.Width = 65;
            // 
            // gridBand6
            // 
            this.gridBand6.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridBand6.AppearanceHeader.Options.UseFont = true;
            this.gridBand6.AppearanceHeader.Options.UseTextOptions = true;
            this.gridBand6.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridBand6.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.gridBand6.Caption = "Punch 4";
            this.gridBand6.Name = "gridBand6";
            this.gridBand6.Visible = false;
            this.gridBand6.VisibleIndex = -1;
            this.gridBand6.Width = 65;
            // 
            // gridBand7
            // 
            this.gridBand7.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridBand7.AppearanceHeader.Options.UseFont = true;
            this.gridBand7.AppearanceHeader.Options.UseTextOptions = true;
            this.gridBand7.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridBand7.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.gridBand7.Caption = "Punch 5";
            this.gridBand7.Name = "gridBand7";
            this.gridBand7.Visible = false;
            this.gridBand7.VisibleIndex = -1;
            this.gridBand7.Width = 65;
            // 
            // gridBand8
            // 
            this.gridBand8.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gridBand8.AppearanceHeader.Options.UseFont = true;
            this.gridBand8.AppearanceHeader.Options.UseTextOptions = true;
            this.gridBand8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridBand8.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridBand8.Caption = "Salaried";
            this.gridBand8.Columns.Add(this.bandedGridColumn51);
            this.gridBand8.Columns.Add(this.bandedGridColumn52);
            this.gridBand8.Columns.Add(this.bandedGridColumn53);
            this.gridBand8.Name = "gridBand8";
            this.gridBand8.Visible = false;
            this.gridBand8.VisibleIndex = -1;
            this.gridBand8.Width = 205;
            // 
            // bandedGridColumn51
            // 
            this.bandedGridColumn51.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn51.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn51.Caption = "Full";
            this.bandedGridColumn51.ColumnEdit = this.repositoryItemCheckEdit3;
            this.bandedGridColumn51.FieldName = "full";
            this.bandedGridColumn51.MinWidth = 19;
            this.bandedGridColumn51.Name = "bandedGridColumn51";
            this.bandedGridColumn51.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn51.Visible = true;
            // 
            // bandedGridColumn52
            // 
            this.bandedGridColumn52.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn52.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn52.Caption = "Part";
            this.bandedGridColumn52.FieldName = "part";
            this.bandedGridColumn52.MinWidth = 19;
            this.bandedGridColumn52.Name = "bandedGridColumn52";
            this.bandedGridColumn52.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn52.Visible = true;
            this.bandedGridColumn52.Width = 65;
            // 
            // bandedGridColumn53
            // 
            this.bandedGridColumn53.Caption = "Worked";
            this.bandedGridColumn53.FieldName = "worked";
            this.bandedGridColumn53.MinWidth = 19;
            this.bandedGridColumn53.Name = "bandedGridColumn53";
            this.bandedGridColumn53.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn53.Visible = true;
            this.bandedGridColumn53.Width = 65;
            // 
            // gridBand9
            // 
            this.gridBand9.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridBand9.AppearanceHeader.Options.UseFont = true;
            this.gridBand9.AppearanceHeader.Options.UseTextOptions = true;
            this.gridBand9.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridBand9.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridBand9.Caption = "Holiday";
            this.gridBand9.Columns.Add(this.bandedGridColumn54);
            this.gridBand9.Columns.Add(this.bandedGridColumn55);
            this.gridBand9.Columns.Add(this.bandedGridColumn43);
            this.gridBand9.Columns.Add(this.bandedGridColumn46);
            this.gridBand9.Name = "gridBand9";
            this.gridBand9.VisibleIndex = 2;
            this.gridBand9.Width = 150;
            // 
            // bandedGridColumn54
            // 
            this.bandedGridColumn54.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn54.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn54.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn54.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn54.Caption = "Holiday 1";
            this.bandedGridColumn54.FieldName = "holiday1";
            this.bandedGridColumn54.MinWidth = 19;
            this.bandedGridColumn54.Name = "bandedGridColumn54";
            this.bandedGridColumn54.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn54.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn54.Visible = true;
            // 
            // bandedGridColumn55
            // 
            this.bandedGridColumn55.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn55.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn55.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn55.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn55.Caption = "Holiday 2";
            this.bandedGridColumn55.FieldName = "holiday2";
            this.bandedGridColumn55.MinWidth = 19;
            this.bandedGridColumn55.Name = "bandedGridColumn55";
            this.bandedGridColumn55.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn55.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn55.Visible = true;
            // 
            // bandedGridColumn43
            // 
            this.bandedGridColumn43.AppearanceCell.BackColor = System.Drawing.Color.Transparent;
            this.bandedGridColumn43.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic);
            this.bandedGridColumn43.AppearanceCell.Options.UseBackColor = true;
            this.bandedGridColumn43.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn43.Caption = "Avail PTO";
            this.bandedGridColumn43.FieldName = "available";
            this.bandedGridColumn43.MinWidth = 19;
            this.bandedGridColumn43.Name = "bandedGridColumn43";
            this.bandedGridColumn43.RowIndex = 1;
            this.bandedGridColumn43.Visible = true;
            this.bandedGridColumn43.Width = 150;
            // 
            // bandedGridColumn46
            // 
            this.bandedGridColumn46.AppearanceCell.ForeColor = System.Drawing.Color.Red;
            this.bandedGridColumn46.AppearanceCell.Options.UseForeColor = true;
            this.bandedGridColumn46.Caption = "Spacer3";
            this.bandedGridColumn46.FieldName = "spacer3";
            this.bandedGridColumn46.MinWidth = 19;
            this.bandedGridColumn46.Name = "bandedGridColumn46";
            this.bandedGridColumn46.RowIndex = 2;
            this.bandedGridColumn46.Visible = true;
            this.bandedGridColumn46.Width = 150;
            // 
            // gridBand10
            // 
            this.gridBand10.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gridBand10.AppearanceHeader.Options.UseFont = true;
            this.gridBand10.AppearanceHeader.Options.UseTextOptions = true;
            this.gridBand10.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridBand10.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridBand10.Caption = "PTO";
            this.gridBand10.Columns.Add(this.bandedGridColumn56);
            this.gridBand10.Columns.Add(this.bandedGridColumn57);
            this.gridBand10.Columns.Add(this.bandedGridColumn58);
            this.gridBand10.Columns.Add(this.bandedGridColumn44);
            this.gridBand10.Columns.Add(this.bandedGridColumn47);
            this.gridBand10.Name = "gridBand10";
            this.gridBand10.VisibleIndex = 3;
            this.gridBand10.Width = 130;
            // 
            // bandedGridColumn56
            // 
            this.bandedGridColumn56.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn56.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn56.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn56.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn56.Caption = "PTO";
            this.bandedGridColumn56.FieldName = "pto";
            this.bandedGridColumn56.MinWidth = 19;
            this.bandedGridColumn56.Name = "bandedGridColumn56";
            this.bandedGridColumn56.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn56.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn56.Width = 65;
            // 
            // bandedGridColumn57
            // 
            this.bandedGridColumn57.AppearanceCell.BackColor = System.Drawing.Color.Yellow;
            this.bandedGridColumn57.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.bandedGridColumn57.AppearanceCell.Options.UseBackColor = true;
            this.bandedGridColumn57.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn57.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn57.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn57.Caption = "PTO(?)";
            this.bandedGridColumn57.FieldName = "qpto";
            this.bandedGridColumn57.MinWidth = 19;
            this.bandedGridColumn57.Name = "bandedGridColumn57";
            this.bandedGridColumn57.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn57.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn57.Visible = true;
            this.bandedGridColumn57.Width = 65;
            // 
            // bandedGridColumn58
            // 
            this.bandedGridColumn58.AppearanceCell.BackColor = System.Drawing.Color.Yellow;
            this.bandedGridColumn58.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.bandedGridColumn58.AppearanceCell.Options.UseBackColor = true;
            this.bandedGridColumn58.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn58.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn58.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn58.Caption = "Docked";
            this.bandedGridColumn58.FieldName = "docked";
            this.bandedGridColumn58.MinWidth = 19;
            this.bandedGridColumn58.Name = "bandedGridColumn58";
            this.bandedGridColumn58.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn58.Visible = true;
            this.bandedGridColumn58.Width = 65;
            // 
            // bandedGridColumn44
            // 
            this.bandedGridColumn44.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic);
            this.bandedGridColumn44.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn44.Caption = "December PTO";
            this.bandedGridColumn44.FieldName = "december";
            this.bandedGridColumn44.MinWidth = 19;
            this.bandedGridColumn44.Name = "bandedGridColumn44";
            this.bandedGridColumn44.RowIndex = 1;
            this.bandedGridColumn44.Visible = true;
            this.bandedGridColumn44.Width = 130;
            // 
            // bandedGridColumn47
            // 
            this.bandedGridColumn47.Caption = "Spacer4";
            this.bandedGridColumn47.FieldName = "spacer4";
            this.bandedGridColumn47.MinWidth = 19;
            this.bandedGridColumn47.Name = "bandedGridColumn47";
            this.bandedGridColumn47.RowIndex = 2;
            this.bandedGridColumn47.Visible = true;
            // 
            // gridBand11
            // 
            this.gridBand11.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.gridBand11.AppearanceHeader.Options.UseFont = true;
            this.gridBand11.AppearanceHeader.Options.UseTextOptions = true;
            this.gridBand11.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.gridBand11.AppearanceHeader.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Center;
            this.gridBand11.Caption = "Notes";
            this.gridBand11.Name = "gridBand11";
            this.gridBand11.Visible = false;
            this.gridBand11.VisibleIndex = -1;
            this.gridBand11.Width = 163;
            // 
            // bandedGridColumn61
            // 
            this.bandedGridColumn61.Caption = "jobcode";
            this.bandedGridColumn61.FieldName = "jobcode";
            this.bandedGridColumn61.MinWidth = 19;
            this.bandedGridColumn61.Name = "bandedGridColumn61";
            // 
            // panelReportTop
            // 
            this.panelReportTop.Controls.Add(this.btnGenerateReport);
            this.panelReportTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelReportTop.Location = new System.Drawing.Point(0, 0);
            this.panelReportTop.Name = "panelReportTop";
            this.panelReportTop.Size = new System.Drawing.Size(1220, 10);
            this.panelReportTop.TabIndex = 1;
            // 
            // btnGenerateReport
            // 
            this.btnGenerateReport.Location = new System.Drawing.Point(3, 16);
            this.btnGenerateReport.Name = "btnGenerateReport";
            this.btnGenerateReport.Size = new System.Drawing.Size(114, 31);
            this.btnGenerateReport.TabIndex = 4;
            this.btnGenerateReport.Text = "Generate Report";
            this.btnGenerateReport.Click += new System.EventHandler(this.btnGenerateReport_Click);
            // 
            // tabPTO
            // 
            this.tabPTO.Controls.Add(this.panelPTOAll);
            this.tabPTO.Location = new System.Drawing.Point(4, 26);
            this.tabPTO.Name = "tabPTO";
            this.tabPTO.Padding = new System.Windows.Forms.Padding(3);
            this.tabPTO.Size = new System.Drawing.Size(1220, 571);
            this.tabPTO.TabIndex = 1;
            this.tabPTO.Text = "PTO";
            this.tabPTO.UseVisualStyleBackColor = true;
            // 
            // panelPTOAll
            // 
            this.panelPTOAll.Controls.Add(this.panelPTOBottom);
            this.panelPTOAll.Controls.Add(this.panelPTOTop);
            this.panelPTOAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPTOAll.Location = new System.Drawing.Point(3, 3);
            this.panelPTOAll.Name = "panelPTOAll";
            this.panelPTOAll.Size = new System.Drawing.Size(1214, 565);
            this.panelPTOAll.TabIndex = 3;
            // 
            // panelPTOBottom
            // 
            this.panelPTOBottom.Controls.Add(this.dgv2);
            this.panelPTOBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelPTOBottom.Location = new System.Drawing.Point(0, 39);
            this.panelPTOBottom.Name = "panelPTOBottom";
            this.panelPTOBottom.Size = new System.Drawing.Size(1214, 526);
            this.panelPTOBottom.TabIndex = 5;
            // 
            // dgv2
            // 
            this.dgv2.ContextMenuStrip = this.contextMenuStrip2;
            this.dgv2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.dgv2.Location = new System.Drawing.Point(0, 0);
            this.dgv2.MainView = this.gridView2;
            this.dgv2.MenuManager = this.barManager1;
            this.dgv2.Name = "dgv2";
            this.dgv2.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit2});
            this.dgv2.Size = new System.Drawing.Size(1214, 526);
            this.dgv2.TabIndex = 2;
            this.dgv2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView2});
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.swapPTODockedToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(229, 28);
            // 
            // swapPTODockedToolStripMenuItem
            // 
            this.swapPTODockedToolStripMenuItem.Name = "swapPTODockedToolStripMenuItem";
            this.swapPTODockedToolStripMenuItem.Size = new System.Drawing.Size(228, 24);
            this.swapPTODockedToolStripMenuItem.Text = "Swap PTO and Docked";
            this.swapPTODockedToolStripMenuItem.Click += new System.EventHandler(this.swapPTODockedToolStripMenuItem_Click);
            // 
            // gridView2
            // 
            this.gridView2.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.gridView2.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridView2.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.gridView2.Appearance.OddRow.Options.UseBackColor = true;
            this.gridView2.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.gridView2.Appearance.Row.Options.UseBackColor = true;
            this.gridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn18,
            this.gridColumn10,
            this.gridColumn19,
            this.gridColumn20,
            this.gridColumn21,
            this.gridColumn22,
            this.gridColumn23,
            this.gridColumn24,
            this.gridColumn25,
            this.gridColumn26,
            this.gridColumn8,
            this.gridColumn27,
            this.gridColumn28,
            this.gridColumn29,
            this.gridColumn9,
            this.gridColumn30,
            this.gridColumn31,
            this.gridColumn32,
            this.gridColumn33,
            this.gridColumn34,
            this.gridColumn52});
            this.gridView2.GridControl = this.dgv2;
            this.gridView2.Name = "gridView2";
            this.gridView2.OptionsSelection.MultiSelect = true;
            this.gridView2.OptionsView.EnableAppearanceEvenRow = true;
            this.gridView2.OptionsView.EnableAppearanceOddRow = true;
            this.gridView2.OptionsView.ShowGroupPanel = false;
            this.gridView2.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridView2_CustomDrawCell);
            // 
            // gridColumn18
            // 
            this.gridColumn18.Caption = "Num";
            this.gridColumn18.FieldName = "num";
            this.gridColumn18.MinWidth = 19;
            this.gridColumn18.Name = "gridColumn18";
            this.gridColumn18.OptionsColumn.FixedWidth = true;
            this.gridColumn18.Visible = true;
            this.gridColumn18.VisibleIndex = 0;
            this.gridColumn18.Width = 30;
            // 
            // gridColumn10
            // 
            this.gridColumn10.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn10.Caption = "Approve";
            this.gridColumn10.ColumnEdit = this.repositoryItemCheckEdit2;
            this.gridColumn10.FieldName = "approve";
            this.gridColumn10.MinWidth = 19;
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 1;
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            // 
            // gridColumn19
            // 
            this.gridColumn19.Caption = "Emp #";
            this.gridColumn19.FieldName = "empno";
            this.gridColumn19.MinWidth = 19;
            this.gridColumn19.Name = "gridColumn19";
            this.gridColumn19.OptionsColumn.AllowEdit = false;
            this.gridColumn19.OptionsColumn.FixedWidth = true;
            this.gridColumn19.Visible = true;
            this.gridColumn19.VisibleIndex = 2;
            this.gridColumn19.Width = 40;
            // 
            // gridColumn20
            // 
            this.gridColumn20.Caption = "Employee Name";
            this.gridColumn20.FieldName = "name";
            this.gridColumn20.MinWidth = 19;
            this.gridColumn20.Name = "gridColumn20";
            this.gridColumn20.OptionsColumn.AllowEdit = false;
            this.gridColumn20.OptionsColumn.FixedWidth = true;
            this.gridColumn20.Visible = true;
            this.gridColumn20.VisibleIndex = 3;
            this.gridColumn20.Width = 125;
            // 
            // gridColumn21
            // 
            this.gridColumn21.Caption = "Hire Date";
            this.gridColumn21.FieldName = "hiredate";
            this.gridColumn21.MinWidth = 19;
            this.gridColumn21.Name = "gridColumn21";
            this.gridColumn21.OptionsColumn.FixedWidth = true;
            // 
            // gridColumn22
            // 
            this.gridColumn22.Caption = "PTO Available";
            this.gridColumn22.DisplayFormat.FormatString = "N2";
            this.gridColumn22.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn22.FieldName = "pto_now";
            this.gridColumn22.MinWidth = 19;
            this.gridColumn22.Name = "gridColumn22";
            this.gridColumn22.OptionsColumn.AllowEdit = false;
            this.gridColumn22.OptionsColumn.FixedWidth = true;
            this.gridColumn22.Visible = true;
            this.gridColumn22.VisibleIndex = 5;
            // 
            // gridColumn23
            // 
            this.gridColumn23.Caption = "PTO Inc";
            this.gridColumn23.DisplayFormat.FormatString = "N2";
            this.gridColumn23.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn23.FieldName = "pto_inc";
            this.gridColumn23.MinWidth = 19;
            this.gridColumn23.Name = "gridColumn23";
            this.gridColumn23.OptionsColumn.AllowEdit = false;
            this.gridColumn23.OptionsColumn.FixedWidth = true;
            this.gridColumn23.Visible = true;
            this.gridColumn23.VisibleIndex = 6;
            this.gridColumn23.Width = 50;
            // 
            // gridColumn24
            // 
            this.gridColumn24.Caption = "December PTO";
            this.gridColumn24.DisplayFormat.FormatString = "N2";
            this.gridColumn24.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn24.FieldName = "december";
            this.gridColumn24.MinWidth = 19;
            this.gridColumn24.Name = "gridColumn24";
            this.gridColumn24.OptionsColumn.AllowEdit = false;
            this.gridColumn24.OptionsColumn.FixedWidth = true;
            this.gridColumn24.Visible = true;
            this.gridColumn24.VisibleIndex = 7;
            this.gridColumn24.Width = 80;
            // 
            // gridColumn25
            // 
            this.gridColumn25.Caption = "Status";
            this.gridColumn25.FieldName = "status";
            this.gridColumn25.MinWidth = 19;
            this.gridColumn25.Name = "gridColumn25";
            this.gridColumn25.OptionsColumn.AllowEdit = false;
            this.gridColumn25.OptionsColumn.FixedWidth = true;
            this.gridColumn25.Visible = true;
            this.gridColumn25.VisibleIndex = 4;
            this.gridColumn25.Width = 50;
            // 
            // gridColumn26
            // 
            this.gridColumn26.Caption = "Vacation";
            this.gridColumn26.DisplayFormat.FormatString = "N2";
            this.gridColumn26.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn26.FieldName = "vacation";
            this.gridColumn26.MinWidth = 19;
            this.gridColumn26.Name = "gridColumn26";
            this.gridColumn26.OptionsColumn.AllowEdit = false;
            this.gridColumn26.OptionsColumn.FixedWidth = true;
            this.gridColumn26.Visible = true;
            this.gridColumn26.VisibleIndex = 8;
            this.gridColumn26.Width = 50;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "New PTO";
            this.gridColumn8.DisplayFormat.FormatString = "N2";
            this.gridColumn8.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn8.FieldName = "pto";
            this.gridColumn8.MinWidth = 19;
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.FixedWidth = true;
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 13;
            this.gridColumn8.Width = 65;
            // 
            // gridColumn27
            // 
            this.gridColumn27.Caption = "Holiday";
            this.gridColumn27.DisplayFormat.FormatString = "N2";
            this.gridColumn27.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn27.FieldName = "holiday";
            this.gridColumn27.MinWidth = 19;
            this.gridColumn27.Name = "gridColumn27";
            this.gridColumn27.OptionsColumn.AllowEdit = false;
            this.gridColumn27.OptionsColumn.FixedWidth = true;
            this.gridColumn27.Visible = true;
            this.gridColumn27.VisibleIndex = 10;
            this.gridColumn27.Width = 50;
            // 
            // gridColumn28
            // 
            this.gridColumn28.Caption = "Sick";
            this.gridColumn28.DisplayFormat.FormatString = "N2";
            this.gridColumn28.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn28.FieldName = "sick";
            this.gridColumn28.MinWidth = 19;
            this.gridColumn28.Name = "gridColumn28";
            this.gridColumn28.OptionsColumn.AllowEdit = false;
            this.gridColumn28.OptionsColumn.FixedWidth = true;
            this.gridColumn28.Visible = true;
            this.gridColumn28.VisibleIndex = 11;
            this.gridColumn28.Width = 50;
            // 
            // gridColumn29
            // 
            this.gridColumn29.Caption = "No Pay";
            this.gridColumn29.DisplayFormat.FormatString = "N2";
            this.gridColumn29.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn29.FieldName = "no_pay";
            this.gridColumn29.MinWidth = 19;
            this.gridColumn29.Name = "gridColumn29";
            this.gridColumn29.OptionsColumn.AllowEdit = false;
            this.gridColumn29.OptionsColumn.FixedWidth = true;
            this.gridColumn29.Visible = true;
            this.gridColumn29.VisibleIndex = 9;
            this.gridColumn29.Width = 50;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "Docked";
            this.gridColumn9.DisplayFormat.FormatString = "N2";
            this.gridColumn9.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn9.FieldName = "docked";
            this.gridColumn9.MinWidth = 19;
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.FixedWidth = true;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 14;
            this.gridColumn9.Width = 50;
            // 
            // gridColumn30
            // 
            this.gridColumn30.Caption = "Other";
            this.gridColumn30.DisplayFormat.FormatString = "N2";
            this.gridColumn30.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn30.FieldName = "other";
            this.gridColumn30.MinWidth = 19;
            this.gridColumn30.Name = "gridColumn30";
            this.gridColumn30.OptionsColumn.AllowEdit = false;
            this.gridColumn30.OptionsColumn.FixedWidth = true;
            this.gridColumn30.Visible = true;
            this.gridColumn30.VisibleIndex = 12;
            this.gridColumn30.Width = 50;
            // 
            // gridColumn31
            // 
            this.gridColumn31.Caption = "Bank";
            this.gridColumn31.DisplayFormat.FormatString = "N2";
            this.gridColumn31.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn31.FieldName = "bank";
            this.gridColumn31.MinWidth = 19;
            this.gridColumn31.Name = "gridColumn31";
            this.gridColumn31.OptionsColumn.FixedWidth = true;
            this.gridColumn31.Width = 50;
            // 
            // gridColumn32
            // 
            this.gridColumn32.Caption = "Paid";
            this.gridColumn32.DisplayFormat.FormatString = "N2";
            this.gridColumn32.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn32.FieldName = "paid";
            this.gridColumn32.MinWidth = 19;
            this.gridColumn32.Name = "gridColumn32";
            this.gridColumn32.OptionsColumn.FixedWidth = true;
            this.gridColumn32.Width = 50;
            // 
            // gridColumn33
            // 
            this.gridColumn33.Caption = "Med";
            this.gridColumn33.FieldName = "medical";
            this.gridColumn33.MinWidth = 19;
            this.gridColumn33.Name = "gridColumn33";
            this.gridColumn33.Width = 38;
            // 
            // gridColumn34
            // 
            this.gridColumn34.Caption = "Den";
            this.gridColumn34.FieldName = "dental";
            this.gridColumn34.MinWidth = 19;
            this.gridColumn34.Name = "gridColumn34";
            this.gridColumn34.Width = 38;
            // 
            // gridColumn52
            // 
            this.gridColumn52.Caption = "Comment";
            this.gridColumn52.FieldName = "comment";
            this.gridColumn52.MinWidth = 19;
            this.gridColumn52.Name = "gridColumn52";
            this.gridColumn52.Visible = true;
            this.gridColumn52.VisibleIndex = 15;
            this.gridColumn52.Width = 737;
            // 
            // barManager1
            // 
            this.barManager1.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar1});
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barSubItem1,
            this.menuItemExit,
            this.barSubItem2,
            this.menuItemSkins,
            this.barSubItem3,
            this.barButtonItem1,
            this.barSubItem4,
            this.menuImportPayroll,
            this.barButtonItem2,
            this.menuItemFindPanel,
            this.barSubItem5,
            this.menuItemLoadContributions,
            this.menuItemLoadMonthlyPSFiles,
            this.menuItemLoadDepartInfo,
            this.menuItemCalcDiff,
            this.menuItemCalcDoctorProd,
            this.menuItemLoadAccruals,
            this.menuItemCalcTotals,
            this.barSubItem6,
            this.menuChkInvestOpt,
            this.menuChkAccrual,
            this.menuChkDepartment,
            this.menuChkContributions,
            this.menuChkPayroll,
            this.menuChkPsDetail,
            this.menuChkDifferences,
            this.menuImportRates,
            this.menuItemPrint,
            this.menuReportPrint,
            this.barSubItem7,
            this.barReport,
            this.menuItemPrintPreview,
            this.menuReportPrintPreview,
            this.barButtonItem3,
            this.menuChkSalary,
            this.menuChkYearend,
            this.menuItemYearend,
            this.menuItemDoctorDistribution,
            this.btnDailySummary,
            this.menuItemView,
            this.menuItemPrimary,
            this.barButtonItem5,
            this.btnProcedureData,
            this.menuItemOverhead,
            this.barSubItem8,
            this.menuItemEditOverhead,
            this.menuPayPeriods,
            this.barButtonItem4,
            this.menuSupervisors,
            this.menuOptions,
            this.menuAddHolidays,
            this.barSubItem9,
            this.menuEmployeeList,
            this.menuFormats,
            this.menuSkins,
            this.menuDetailReport,
            this.menuEditPreferences,
            this.menuSetPassword,
            this.menuEditHourStatus,
            this.menuEditTimeSheetHelp,
            this.menuHelp,
            this.menuClockInOut,
            this.menuHelpEmployeeList,
            this.menuHelpSalary,
            this.menuSalaryPunchIn,
            this.menuSalaryEmployeeList,
            this.menuEditHelp,
            this.menuHelpItem,
            this.menuTimeOff,
            this.barButtonItem6,
            this.menuAddNewEmployee,
            this.menuExportPTO,
            this.barButtonItem7,
            this.barSubItem10,
            this.barButtonPrintAll});
            this.barManager1.MaxItemId = 76;
            // 
            // bar1
            // 
            this.bar1.BarName = "Tools";
            this.bar1.DockCol = 0;
            this.bar1.DockRow = 0;
            this.bar1.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.bar1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.menuPayPeriods),
            new DevExpress.XtraBars.LinkPersistInfo(this.menuSupervisors),
            new DevExpress.XtraBars.LinkPersistInfo(this.menuOptions),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem9),
            new DevExpress.XtraBars.LinkPersistInfo(this.menuHelpItem),
            new DevExpress.XtraBars.LinkPersistInfo(this.menuEditHelp)});
            this.bar1.OptionsBar.AllowQuickCustomization = false;
            this.bar1.Text = "Tools";
            // 
            // barSubItem1
            // 
            this.barSubItem1.Caption = "File";
            this.barSubItem1.Id = 0;
            this.barSubItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem7),
            new DevExpress.XtraBars.LinkPersistInfo(this.menuItemExit)});
            this.barSubItem1.Name = "barSubItem1";
            // 
            // barSubItem7
            // 
            this.barSubItem7.Caption = "Print";
            this.barSubItem7.Id = 32;
            this.barSubItem7.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.menuItemPrintPreview),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonPrintAll),
            new DevExpress.XtraBars.LinkPersistInfo(this.menuItemPrint)});
            this.barSubItem7.Name = "barSubItem7";
            // 
            // menuItemPrintPreview
            // 
            this.menuItemPrintPreview.Caption = "Print Preview";
            this.menuItemPrintPreview.Id = 33;
            this.menuItemPrintPreview.Name = "menuItemPrintPreview";
            this.menuItemPrintPreview.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuItemPrintPreview_ItemClick);
            // 
            // barButtonPrintAll
            // 
            this.barButtonPrintAll.Caption = "Print All";
            this.barButtonPrintAll.Id = 75;
            this.barButtonPrintAll.Name = "barButtonPrintAll";
            this.barButtonPrintAll.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonPrintAll_ItemClick);
            // 
            // menuItemPrint
            // 
            this.menuItemPrint.Caption = "Print";
            this.menuItemPrint.Id = 31;
            this.menuItemPrint.Name = "menuItemPrint";
            this.menuItemPrint.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuItemPrint_ItemClick);
            // 
            // menuItemExit
            // 
            this.menuItemExit.Caption = "Exit";
            this.menuItemExit.Id = 1;
            this.menuItemExit.Name = "menuItemExit";
            this.menuItemExit.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuItemExit_ItemClick);
            // 
            // menuPayPeriods
            // 
            this.menuPayPeriods.Caption = "PayPeriods";
            this.menuPayPeriods.Id = 47;
            this.menuPayPeriods.Name = "menuPayPeriods";
            // 
            // menuSupervisors
            // 
            this.menuSupervisors.Caption = "Supervisors";
            this.menuSupervisors.Id = 49;
            this.menuSupervisors.Name = "menuSupervisors";
            // 
            // menuOptions
            // 
            this.menuOptions.Caption = "Options";
            this.menuOptions.Id = 50;
            this.menuOptions.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.menuAddHolidays),
            new DevExpress.XtraBars.LinkPersistInfo(this.menuEditPreferences),
            new DevExpress.XtraBars.LinkPersistInfo(this.menuSetPassword),
            new DevExpress.XtraBars.LinkPersistInfo(this.menuEditHourStatus),
            new DevExpress.XtraBars.LinkPersistInfo(this.menuAddNewEmployee),
            new DevExpress.XtraBars.LinkPersistInfo(this.menuExportPTO)});
            this.menuOptions.Name = "menuOptions";
            // 
            // menuAddHolidays
            // 
            this.menuAddHolidays.Caption = "Add Holidays";
            this.menuAddHolidays.Id = 51;
            this.menuAddHolidays.Name = "menuAddHolidays";
            this.menuAddHolidays.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuAddHolidays_ItemClick);
            // 
            // menuEditPreferences
            // 
            this.menuEditPreferences.Caption = "Edit Preferences";
            this.menuEditPreferences.Id = 57;
            this.menuEditPreferences.Name = "menuEditPreferences";
            this.menuEditPreferences.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuEditPreferences_ItemClick);
            // 
            // menuSetPassword
            // 
            this.menuSetPassword.Caption = "Set Password";
            this.menuSetPassword.Id = 58;
            this.menuSetPassword.Name = "menuSetPassword";
            this.menuSetPassword.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuSetPassword_ItemClick);
            // 
            // menuEditHourStatus
            // 
            this.menuEditHourStatus.Caption = "Edit Employee Hour Status";
            this.menuEditHourStatus.Id = 59;
            this.menuEditHourStatus.Name = "menuEditHourStatus";
            this.menuEditHourStatus.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuEditHourStatus_ItemClick);
            // 
            // menuAddNewEmployee
            // 
            this.menuAddNewEmployee.Caption = "Add New Employee";
            this.menuAddNewEmployee.Id = 71;
            this.menuAddNewEmployee.Name = "menuAddNewEmployee";
            this.menuAddNewEmployee.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuAddNewEmployee_ItemClick);
            // 
            // menuExportPTO
            // 
            this.menuExportPTO.Caption = "Export PTO";
            this.menuExportPTO.Id = 72;
            this.menuExportPTO.Name = "menuExportPTO";
            this.menuExportPTO.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuExportPTO_ItemClick);
            // 
            // barSubItem9
            // 
            this.barSubItem9.Caption = "Employees";
            this.barSubItem9.Id = 52;
            this.barSubItem9.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.menuEmployeeList)});
            this.barSubItem9.Name = "barSubItem9";
            // 
            // menuEmployeeList
            // 
            this.menuEmployeeList.Caption = "Employee List";
            this.menuEmployeeList.Id = 53;
            this.menuEmployeeList.Name = "menuEmployeeList";
            this.menuEmployeeList.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuEmployeeList_ItemClick);
            // 
            // menuHelpItem
            // 
            this.menuHelpItem.Caption = "Help";
            this.menuHelpItem.Id = 68;
            this.menuHelpItem.Name = "menuHelpItem";
            this.menuHelpItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuHelpItem_ItemClick);
            // 
            // menuEditHelp
            // 
            this.menuEditHelp.Caption = "Edit Help";
            this.menuEditHelp.Id = 67;
            this.menuEditHelp.Name = "menuEditHelp";
            this.menuEditHelp.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuEditHelp_ItemClick);
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Manager = this.barManager1;
            this.barDockControlTop.Size = new System.Drawing.Size(1228, 25);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 667);
            this.barDockControlBottom.Manager = this.barManager1;
            this.barDockControlBottom.Size = new System.Drawing.Size(1228, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 25);
            this.barDockControlLeft.Manager = this.barManager1;
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 642);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1228, 25);
            this.barDockControlRight.Manager = this.barManager1;
            this.barDockControlRight.Size = new System.Drawing.Size(0, 642);
            // 
            // barSubItem2
            // 
            this.barSubItem2.Caption = "Formats";
            this.barSubItem2.Id = 2;
            this.barSubItem2.Name = "barSubItem2";
            // 
            // menuItemSkins
            // 
            this.menuItemSkins.Caption = "Select Skin";
            this.menuItemSkins.Id = 3;
            this.menuItemSkins.Name = "menuItemSkins";
            // 
            // barSubItem3
            // 
            this.barSubItem3.Id = 6;
            this.barSubItem3.Name = "barSubItem3";
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "Payroll";
            this.barButtonItem1.Id = 5;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // barSubItem4
            // 
            this.barSubItem4.Caption = "Options";
            this.barSubItem4.Id = 7;
            this.barSubItem4.Name = "barSubItem4";
            // 
            // menuImportPayroll
            // 
            this.menuImportPayroll.Caption = "Payroll";
            this.menuImportPayroll.Id = 8;
            this.menuImportPayroll.Name = "menuImportPayroll";
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "barButtonItem2";
            this.barButtonItem2.Id = 9;
            this.barButtonItem2.Name = "barButtonItem2";
            // 
            // menuItemFindPanel
            // 
            this.menuItemFindPanel.Caption = "Find Panel";
            this.menuItemFindPanel.Id = 10;
            this.menuItemFindPanel.Name = "menuItemFindPanel";
            // 
            // barSubItem5
            // 
            this.barSubItem5.Caption = "YearEnd";
            this.barSubItem5.Id = 14;
            this.barSubItem5.Name = "barSubItem5";
            // 
            // menuItemLoadContributions
            // 
            this.menuItemLoadContributions.Caption = "Load Contribution Requirements";
            this.menuItemLoadContributions.Id = 15;
            this.menuItemLoadContributions.Name = "menuItemLoadContributions";
            // 
            // menuItemLoadMonthlyPSFiles
            // 
            this.menuItemLoadMonthlyPSFiles.Caption = "Load Employee Contributions Paid";
            this.menuItemLoadMonthlyPSFiles.Id = 16;
            this.menuItemLoadMonthlyPSFiles.Name = "menuItemLoadMonthlyPSFiles";
            // 
            // menuItemLoadDepartInfo
            // 
            this.menuItemLoadDepartInfo.Caption = "Load Department Info";
            this.menuItemLoadDepartInfo.Id = 17;
            this.menuItemLoadDepartInfo.Name = "menuItemLoadDepartInfo";
            // 
            // menuItemCalcDiff
            // 
            this.menuItemCalcDiff.Caption = "Calculation Differences";
            this.menuItemCalcDiff.Id = 18;
            this.menuItemCalcDiff.Name = "menuItemCalcDiff";
            // 
            // menuItemCalcDoctorProd
            // 
            this.menuItemCalcDoctorProd.Caption = "Load Doctor Production";
            this.menuItemCalcDoctorProd.Id = 19;
            this.menuItemCalcDoctorProd.Name = "menuItemCalcDoctorProd";
            // 
            // menuItemLoadAccruals
            // 
            this.menuItemLoadAccruals.Caption = "Load Doctors Accruals";
            this.menuItemLoadAccruals.Id = 20;
            this.menuItemLoadAccruals.Name = "menuItemLoadAccruals";
            // 
            // menuItemCalcTotals
            // 
            this.menuItemCalcTotals.Caption = "Calculate Totals Row";
            this.menuItemCalcTotals.Id = 21;
            this.menuItemCalcTotals.Name = "menuItemCalcTotals";
            // 
            // barSubItem6
            // 
            this.barSubItem6.Caption = "View";
            this.barSubItem6.Id = 22;
            this.barSubItem6.Name = "barSubItem6";
            // 
            // menuChkInvestOpt
            // 
            this.menuChkInvestOpt.Caption = "Investment Options";
            this.menuChkInvestOpt.Id = 23;
            this.menuChkInvestOpt.Name = "menuChkInvestOpt";
            // 
            // menuChkAccrual
            // 
            this.menuChkAccrual.Caption = "Accrual and Adjustments";
            this.menuChkAccrual.Id = 24;
            this.menuChkAccrual.Name = "menuChkAccrual";
            // 
            // menuChkDepartment
            // 
            this.menuChkDepartment.Caption = "Department and Production";
            this.menuChkDepartment.Id = 25;
            this.menuChkDepartment.Name = "menuChkDepartment";
            // 
            // menuChkContributions
            // 
            this.menuChkContributions.Caption = "Contributions Paid";
            this.menuChkContributions.Id = 26;
            this.menuChkContributions.Name = "menuChkContributions";
            // 
            // menuChkPayroll
            // 
            this.menuChkPayroll.Caption = "Payroll Information";
            this.menuChkPayroll.Id = 27;
            this.menuChkPayroll.Name = "menuChkPayroll";
            // 
            // menuChkPsDetail
            // 
            this.menuChkPsDetail.Caption = "Contributions Required";
            this.menuChkPsDetail.Id = 28;
            this.menuChkPsDetail.Name = "menuChkPsDetail";
            // 
            // menuChkDifferences
            // 
            this.menuChkDifferences.Caption = "Differences";
            this.menuChkDifferences.Id = 29;
            this.menuChkDifferences.Name = "menuChkDifferences";
            // 
            // menuImportRates
            // 
            this.menuImportRates.Caption = "Rates";
            this.menuImportRates.Id = 30;
            this.menuImportRates.Name = "menuImportRates";
            // 
            // menuReportPrint
            // 
            this.menuReportPrint.Caption = "Report Print";
            this.menuReportPrint.Id = 31;
            this.menuReportPrint.Name = "menuReportPrint";
            this.menuReportPrint.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuReportPrint_ItemClick);
            // 
            // barReport
            // 
            this.barReport.Caption = "Report";
            this.barReport.Id = 32;
            this.barReport.Name = "barReport";
            // 
            // menuReportPrintPreview
            // 
            this.menuReportPrintPreview.Caption = "Report Print Preview";
            this.menuReportPrintPreview.Id = 33;
            this.menuReportPrintPreview.Name = "menuReportPrintPreview";
            this.menuReportPrintPreview.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuReportPrintPreview_ItemClick);
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "barButtonItem3";
            this.barButtonItem3.Id = 34;
            this.barButtonItem3.Name = "barButtonItem3";
            // 
            // menuChkSalary
            // 
            this.menuChkSalary.Caption = "Salary Information";
            this.menuChkSalary.Id = 35;
            this.menuChkSalary.Name = "menuChkSalary";
            // 
            // menuChkYearend
            // 
            this.menuChkYearend.Caption = "Yearend";
            this.menuChkYearend.Id = 36;
            this.menuChkYearend.Name = "menuChkYearend";
            // 
            // menuItemYearend
            // 
            this.menuItemYearend.Caption = "Calculate Yearend";
            this.menuItemYearend.Id = 37;
            this.menuItemYearend.Name = "menuItemYearend";
            // 
            // menuItemDoctorDistribution
            // 
            this.menuItemDoctorDistribution.Caption = "Calculate Doctor Distribution";
            this.menuItemDoctorDistribution.Id = 38;
            this.menuItemDoctorDistribution.Name = "menuItemDoctorDistribution";
            // 
            // btnDailySummary
            // 
            this.btnDailySummary.Caption = "Daily Summary File";
            this.btnDailySummary.Id = 39;
            this.btnDailySummary.Name = "btnDailySummary";
            // 
            // menuItemView
            // 
            this.menuItemView.Caption = "View";
            this.menuItemView.Id = 40;
            this.menuItemView.Name = "menuItemView";
            // 
            // menuItemPrimary
            // 
            this.menuItemPrimary.Caption = "Primary Display";
            this.menuItemPrimary.Id = 41;
            this.menuItemPrimary.Name = "menuItemPrimary";
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "Insurances";
            this.barButtonItem5.Id = 42;
            this.barButtonItem5.Name = "barButtonItem5";
            // 
            // btnProcedureData
            // 
            this.btnProcedureData.Caption = "Add Procedure Data";
            this.btnProcedureData.Id = 43;
            this.btnProcedureData.Name = "btnProcedureData";
            // 
            // menuItemOverhead
            // 
            this.menuItemOverhead.Caption = "Calculate Overhead";
            this.menuItemOverhead.Id = 44;
            this.menuItemOverhead.Name = "menuItemOverhead";
            // 
            // barSubItem8
            // 
            this.barSubItem8.Caption = "Edit";
            this.barSubItem8.Id = 45;
            this.barSubItem8.Name = "barSubItem8";
            // 
            // menuItemEditOverhead
            // 
            this.menuItemEditOverhead.Caption = "Edit Overhead Master";
            this.menuItemEditOverhead.Id = 46;
            this.menuItemEditOverhead.Name = "menuItemEditOverhead";
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "barButtonItem4";
            this.barButtonItem4.Id = 48;
            this.barButtonItem4.Name = "barButtonItem4";
            // 
            // menuFormats
            // 
            this.menuFormats.Caption = "Formats";
            this.menuFormats.Id = 54;
            this.menuFormats.Name = "menuFormats";
            // 
            // menuSkins
            // 
            this.menuSkins.Caption = "Select Skins and Colors";
            this.menuSkins.Id = 55;
            this.menuSkins.Name = "menuSkins";
            this.menuSkins.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuSkins_ItemClick);
            // 
            // menuDetailReport
            // 
            this.menuDetailReport.Caption = "Pay Period Detail Report";
            this.menuDetailReport.Id = 56;
            this.menuDetailReport.Name = "menuDetailReport";
            this.menuDetailReport.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.menuDetailReport_ItemClick);
            // 
            // menuEditTimeSheetHelp
            // 
            this.menuEditTimeSheetHelp.Caption = "Edit TimeSheet Help";
            this.menuEditTimeSheetHelp.Id = 60;
            this.menuEditTimeSheetHelp.Name = "menuEditTimeSheetHelp";
            // 
            // menuHelp
            // 
            this.menuHelp.Caption = "Help";
            this.menuHelp.Id = 61;
            this.menuHelp.Name = "menuHelp";
            // 
            // menuClockInOut
            // 
            this.menuClockInOut.Caption = "Clock In and Out";
            this.menuClockInOut.Id = 62;
            this.menuClockInOut.Name = "menuClockInOut";
            // 
            // menuHelpEmployeeList
            // 
            this.menuHelpEmployeeList.Caption = "Employee List";
            this.menuHelpEmployeeList.Id = 63;
            this.menuHelpEmployeeList.Name = "menuHelpEmployeeList";
            // 
            // menuHelpSalary
            // 
            this.menuHelpSalary.Caption = "Help";
            this.menuHelpSalary.Id = 64;
            this.menuHelpSalary.Name = "menuHelpSalary";
            // 
            // menuSalaryPunchIn
            // 
            this.menuSalaryPunchIn.Caption = "Punching a Work Day";
            this.menuSalaryPunchIn.Id = 65;
            this.menuSalaryPunchIn.Name = "menuSalaryPunchIn";
            // 
            // menuSalaryEmployeeList
            // 
            this.menuSalaryEmployeeList.Caption = "Employee List";
            this.menuSalaryEmployeeList.Id = 66;
            this.menuSalaryEmployeeList.Name = "menuSalaryEmployeeList";
            // 
            // menuTimeOff
            // 
            this.menuTimeOff.Caption = "TimeOff";
            this.menuTimeOff.Id = 69;
            this.menuTimeOff.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonItem6)});
            this.menuTimeOff.Name = "menuTimeOff";
            // 
            // barButtonItem6
            // 
            this.barButtonItem6.Caption = "Request Time Off";
            this.barButtonItem6.Id = 70;
            this.barButtonItem6.Name = "barButtonItem6";
            // 
            // barButtonItem7
            // 
            this.barButtonItem7.Caption = "Print All Preview";
            this.barButtonItem7.Id = 73;
            this.barButtonItem7.Name = "barButtonItem7";
            // 
            // barSubItem10
            // 
            this.barSubItem10.Caption = "Print All";
            this.barSubItem10.Id = 74;
            this.barSubItem10.Name = "barSubItem10";
            // 
            // panelPTOTop
            // 
            this.panelPTOTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelPTOTop.Location = new System.Drawing.Point(0, 0);
            this.panelPTOTop.Name = "panelPTOTop";
            this.panelPTOTop.Size = new System.Drawing.Size(1214, 39);
            this.panelPTOTop.TabIndex = 4;
            // 
            // tabDetail
            // 
            this.tabDetail.Controls.Add(this.panelDetailAll);
            this.tabDetail.Location = new System.Drawing.Point(4, 26);
            this.tabDetail.Name = "tabDetail";
            this.tabDetail.Size = new System.Drawing.Size(1220, 571);
            this.tabDetail.TabIndex = 3;
            this.tabDetail.Text = "Detail";
            this.tabDetail.UseVisualStyleBackColor = true;
            // 
            // panelDetailAll
            // 
            this.panelDetailAll.Controls.Add(this.panelDetailBottom);
            this.panelDetailAll.Controls.Add(this.panelDetailTop);
            this.panelDetailAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDetailAll.Location = new System.Drawing.Point(0, 0);
            this.panelDetailAll.Name = "panelDetailAll";
            this.panelDetailAll.Size = new System.Drawing.Size(1220, 571);
            this.panelDetailAll.TabIndex = 0;
            // 
            // panelDetailBottom
            // 
            this.panelDetailBottom.Controls.Add(this.rtb);
            this.panelDetailBottom.Controls.Add(this.dgv3);
            this.panelDetailBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDetailBottom.Location = new System.Drawing.Point(0, 47);
            this.panelDetailBottom.Name = "panelDetailBottom";
            this.panelDetailBottom.Size = new System.Drawing.Size(1220, 524);
            this.panelDetailBottom.TabIndex = 2;
            // 
            // rtb
            // 
            this.rtb.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtb.Location = new System.Drawing.Point(738, 136);
            this.rtb.Name = "rtb";
            this.rtb.Size = new System.Drawing.Size(100, 96);
            this.rtb.TabIndex = 3;
            this.rtb.Text = "";
            // 
            // dgv3
            // 
            this.dgv3.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(5);
            this.dgv3.Location = new System.Drawing.Point(150, 44);
            this.dgv3.MainView = this.gridView3;
            this.dgv3.MenuManager = this.barManager1;
            this.dgv3.Name = "dgv3";
            this.dgv3.Size = new System.Drawing.Size(400, 200);
            this.dgv3.TabIndex = 2;
            this.dgv3.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView3});
            // 
            // gridView3
            // 
            this.gridView3.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn55});
            this.gridView3.GridControl = this.dgv3;
            this.gridView3.Name = "gridView3";
            this.gridView3.OptionsView.ShowColumnHeaders = false;
            this.gridView3.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn55
            // 
            this.gridColumn55.AppearanceCell.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridColumn55.AppearanceCell.Options.UseFont = true;
            this.gridColumn55.Caption = "Line";
            this.gridColumn55.FieldName = "line";
            this.gridColumn55.MinWidth = 19;
            this.gridColumn55.Name = "gridColumn55";
            this.gridColumn55.Visible = true;
            this.gridColumn55.VisibleIndex = 0;
            this.gridColumn55.Width = 299;
            // 
            // panelDetailTop
            // 
            this.panelDetailTop.Controls.Add(this.chkOddPunches);
            this.panelDetailTop.Controls.Add(this.chkUnder80);
            this.panelDetailTop.Controls.Add(this.chkErrors);
            this.panelDetailTop.Controls.Add(this.chkAll);
            this.panelDetailTop.Controls.Add(this.btnDoDetail);
            this.panelDetailTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDetailTop.Location = new System.Drawing.Point(0, 0);
            this.panelDetailTop.Name = "panelDetailTop";
            this.panelDetailTop.Size = new System.Drawing.Size(1220, 47);
            this.panelDetailTop.TabIndex = 1;
            // 
            // chkOddPunches
            // 
            this.chkOddPunches.AutoSize = true;
            this.chkOddPunches.Location = new System.Drawing.Point(570, 16);
            this.chkOddPunches.Name = "chkOddPunches";
            this.chkOddPunches.Size = new System.Drawing.Size(174, 21);
            this.chkOddPunches.TabIndex = 4;
            this.chkOddPunches.Text = "Report Punches Over 6";
            this.chkOddPunches.UseVisualStyleBackColor = true;
            this.chkOddPunches.CheckedChanged += new System.EventHandler(this.chkOddPunches_CheckedChanged);
            // 
            // chkUnder80
            // 
            this.chkUnder80.AutoSize = true;
            this.chkUnder80.Location = new System.Drawing.Point(427, 16);
            this.chkUnder80.Name = "chkUnder80";
            this.chkUnder80.Size = new System.Drawing.Size(173, 21);
            this.chkUnder80.TabIndex = 3;
            this.chkUnder80.Text = "Report Under 80 Hours";
            this.chkUnder80.UseVisualStyleBackColor = true;
            this.chkUnder80.CheckedChanged += new System.EventHandler(this.chkUnder80_CheckedChanged);
            // 
            // chkErrors
            // 
            this.chkErrors.AutoSize = true;
            this.chkErrors.Location = new System.Drawing.Point(305, 16);
            this.chkErrors.Name = "chkErrors";
            this.chkErrors.Size = new System.Drawing.Size(145, 21);
            this.chkErrors.TabIndex = 2;
            this.chkErrors.Text = "Report Errors Only";
            this.chkErrors.UseVisualStyleBackColor = true;
            this.chkErrors.CheckedChanged += new System.EventHandler(this.chkErrors_CheckedChanged);
            // 
            // chkAll
            // 
            this.chkAll.AutoSize = true;
            this.chkAll.Checked = true;
            this.chkAll.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkAll.Location = new System.Drawing.Point(217, 16);
            this.chkAll.Name = "chkAll";
            this.chkAll.Size = new System.Drawing.Size(88, 21);
            this.chkAll.TabIndex = 1;
            this.chkAll.Text = "Report All";
            this.chkAll.UseVisualStyleBackColor = true;
            // 
            // btnDoDetail
            // 
            this.btnDoDetail.Location = new System.Drawing.Point(8, 12);
            this.btnDoDetail.Name = "btnDoDetail";
            this.btnDoDetail.Size = new System.Drawing.Size(131, 23);
            this.btnDoDetail.TabIndex = 0;
            this.btnDoDetail.Text = "Generate Report";
            this.btnDoDetail.UseVisualStyleBackColor = true;
            this.btnDoDetail.Click += new System.EventHandler(this.btnDoDetail_Click);
            // 
            // tabMyTimeOff
            // 
            this.tabMyTimeOff.Controls.Add(this.panelTimeOffAll);
            this.tabMyTimeOff.Location = new System.Drawing.Point(4, 26);
            this.tabMyTimeOff.Name = "tabMyTimeOff";
            this.tabMyTimeOff.Size = new System.Drawing.Size(1220, 571);
            this.tabMyTimeOff.TabIndex = 4;
            this.tabMyTimeOff.Text = "My TimeOff";
            this.tabMyTimeOff.UseVisualStyleBackColor = true;
            // 
            // panelTimeOffAll
            // 
            this.panelTimeOffAll.Controls.Add(this.panelTimeOffBottom);
            this.panelTimeOffAll.Controls.Add(this.panelTimeOffTop);
            this.panelTimeOffAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTimeOffAll.Location = new System.Drawing.Point(0, 0);
            this.panelTimeOffAll.Name = "panelTimeOffAll";
            this.panelTimeOffAll.Size = new System.Drawing.Size(1220, 571);
            this.panelTimeOffAll.TabIndex = 0;
            // 
            // panelTimeOffBottom
            // 
            this.panelTimeOffBottom.Controls.Add(this.dgv5);
            this.panelTimeOffBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTimeOffBottom.Location = new System.Drawing.Point(0, 41);
            this.panelTimeOffBottom.Name = "panelTimeOffBottom";
            this.panelTimeOffBottom.Size = new System.Drawing.Size(1220, 530);
            this.panelTimeOffBottom.TabIndex = 2;
            // 
            // dgv5
            // 
            this.dgv5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv5.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.dgv5.Location = new System.Drawing.Point(0, 0);
            this.dgv5.MainView = this.gridView5;
            this.dgv5.MenuManager = this.barManager1;
            this.dgv5.Name = "dgv5";
            this.dgv5.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit4,
            this.repositoryItemDateEdit1});
            this.dgv5.Size = new System.Drawing.Size(1220, 530);
            this.dgv5.TabIndex = 3;
            this.dgv5.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView5});
            // 
            // gridView5
            // 
            this.gridView5.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.gridView5.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridView5.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.gridView5.Appearance.OddRow.Options.UseBackColor = true;
            this.gridView5.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.gridView5.Appearance.Row.Options.UseBackColor = true;
            this.gridView5.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridView5.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridView5.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn11,
            this.gridColumn37,
            this.gridColumn12,
            this.gridColumn42,
            this.gridColumn13,
            this.gridColumn14,
            this.gridColumn41,
            this.gridColumn40,
            this.gridColumn39,
            this.gridColumn15,
            this.gridColumn17,
            this.gridColumn16,
            this.gridColumn35,
            this.gridColumn36,
            this.gridColumn48,
            this.gridColumn38});
            this.gridView5.GridControl = this.dgv5;
            this.gridView5.Name = "gridView5";
            this.gridView5.OptionsView.ColumnAutoWidth = false;
            this.gridView5.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridView5.OptionsView.EnableAppearanceEvenRow = true;
            this.gridView5.OptionsView.EnableAppearanceOddRow = true;
            this.gridView5.OptionsView.ShowGroupPanel = false;
            this.gridView5.ShowingEditor += new System.ComponentModel.CancelEventHandler(this.gridView5_ShowingEditor);
            this.gridView5.ShownEditor += new System.EventHandler(this.gridView5_ShownEditor);
            this.gridView5.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridView5_CellValueChanged);
            this.gridView5.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridView5_CustomColumnDisplayText);
            this.gridView5.ValidatingEditor += new DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventHandler(this.gridView5_ValidatingEditor);
            // 
            // gridColumn11
            // 
            this.gridColumn11.Caption = "Num";
            this.gridColumn11.FieldName = "num";
            this.gridColumn11.MinWidth = 19;
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.OptionsColumn.FixedWidth = true;
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 0;
            this.gridColumn11.Width = 40;
            // 
            // gridColumn37
            // 
            this.gridColumn37.Caption = "Date";
            this.gridColumn37.FieldName = "date";
            this.gridColumn37.MinWidth = 19;
            this.gridColumn37.Name = "gridColumn37";
            this.gridColumn37.OptionsColumn.AllowEdit = false;
            this.gridColumn37.OptionsColumn.FixedWidth = true;
            this.gridColumn37.Visible = true;
            this.gridColumn37.VisibleIndex = 1;
            // 
            // gridColumn12
            // 
            this.gridColumn12.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn12.Caption = "Approved";
            this.gridColumn12.ColumnEdit = this.repositoryItemCheckEdit4;
            this.gridColumn12.FieldName = "approved";
            this.gridColumn12.MinWidth = 19;
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.OptionsColumn.AllowEdit = false;
            this.gridColumn12.OptionsColumn.FixedWidth = true;
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 2;
            this.gridColumn12.Width = 69;
            // 
            // repositoryItemCheckEdit4
            // 
            this.repositoryItemCheckEdit4.AutoHeight = false;
            this.repositoryItemCheckEdit4.Name = "repositoryItemCheckEdit4";
            this.repositoryItemCheckEdit4.CheckedChanged += new System.EventHandler(this.repositoryItemCheckEdit4_CheckedChanged);
            // 
            // gridColumn42
            // 
            this.gridColumn42.Caption = "Approved By";
            this.gridColumn42.FieldName = "approvedby";
            this.gridColumn42.MinWidth = 19;
            this.gridColumn42.Name = "gridColumn42";
            this.gridColumn42.OptionsColumn.AllowEdit = false;
            this.gridColumn42.OptionsColumn.FixedWidth = true;
            this.gridColumn42.Visible = true;
            this.gridColumn42.VisibleIndex = 3;
            this.gridColumn42.Width = 100;
            // 
            // gridColumn13
            // 
            this.gridColumn13.Caption = "Emp #";
            this.gridColumn13.FieldName = "empno";
            this.gridColumn13.MinWidth = 19;
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.OptionsColumn.AllowEdit = false;
            this.gridColumn13.OptionsColumn.FixedWidth = true;
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 4;
            this.gridColumn13.Width = 86;
            // 
            // gridColumn14
            // 
            this.gridColumn14.Caption = "Employee Name";
            this.gridColumn14.FieldName = "name";
            this.gridColumn14.MinWidth = 19;
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.OptionsColumn.AllowEdit = false;
            this.gridColumn14.OptionsColumn.FixedWidth = true;
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 5;
            this.gridColumn14.Width = 110;
            // 
            // gridColumn41
            // 
            this.gridColumn41.Caption = "From Date";
            this.gridColumn41.ColumnEdit = this.repositoryItemDateEdit1;
            this.gridColumn41.FieldName = "fromdate";
            this.gridColumn41.MinWidth = 19;
            this.gridColumn41.Name = "gridColumn41";
            this.gridColumn41.OptionsColumn.FixedWidth = true;
            this.gridColumn41.Visible = true;
            this.gridColumn41.VisibleIndex = 6;
            this.gridColumn41.Width = 87;
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            // 
            // gridColumn40
            // 
            this.gridColumn40.Caption = "To Date";
            this.gridColumn40.ColumnEdit = this.repositoryItemDateEdit1;
            this.gridColumn40.FieldName = "todate";
            this.gridColumn40.MinWidth = 19;
            this.gridColumn40.Name = "gridColumn40";
            this.gridColumn40.OptionsColumn.FixedWidth = true;
            this.gridColumn40.Visible = true;
            this.gridColumn40.VisibleIndex = 7;
            this.gridColumn40.Width = 82;
            // 
            // gridColumn39
            // 
            this.gridColumn39.Caption = "Hours";
            this.gridColumn39.FieldName = "hours";
            this.gridColumn39.MinWidth = 19;
            this.gridColumn39.Name = "gridColumn39";
            this.gridColumn39.OptionsColumn.AllowEdit = false;
            this.gridColumn39.OptionsColumn.FixedWidth = true;
            this.gridColumn39.Visible = true;
            this.gridColumn39.VisibleIndex = 8;
            this.gridColumn39.Width = 62;
            // 
            // gridColumn15
            // 
            this.gridColumn15.Caption = "Hire Date";
            this.gridColumn15.FieldName = "hiredate";
            this.gridColumn15.MinWidth = 19;
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.OptionsColumn.AllowEdit = false;
            this.gridColumn15.OptionsColumn.FixedWidth = true;
            // 
            // gridColumn17
            // 
            this.gridColumn17.Caption = "PTO Taken";
            this.gridColumn17.DisplayFormat.FormatString = "N2";
            this.gridColumn17.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn17.FieldName = "pto_taken";
            this.gridColumn17.MinWidth = 25;
            this.gridColumn17.Name = "gridColumn17";
            this.gridColumn17.OptionsColumn.AllowEdit = false;
            this.gridColumn17.OptionsColumn.FixedWidth = true;
            this.gridColumn17.Visible = true;
            this.gridColumn17.VisibleIndex = 9;
            this.gridColumn17.Width = 69;
            // 
            // gridColumn16
            // 
            this.gridColumn16.Caption = "PTO Available";
            this.gridColumn16.DisplayFormat.FormatString = "N2";
            this.gridColumn16.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn16.FieldName = "pto_now";
            this.gridColumn16.MinWidth = 19;
            this.gridColumn16.Name = "gridColumn16";
            this.gridColumn16.OptionsColumn.AllowEdit = false;
            this.gridColumn16.OptionsColumn.FixedWidth = true;
            this.gridColumn16.Visible = true;
            this.gridColumn16.VisibleIndex = 10;
            this.gridColumn16.Width = 74;
            // 
            // gridColumn35
            // 
            this.gridColumn35.Caption = "Annual Total";
            this.gridColumn35.DisplayFormat.FormatString = "N2";
            this.gridColumn35.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn35.FieldName = "december";
            this.gridColumn35.MinWidth = 19;
            this.gridColumn35.Name = "gridColumn35";
            this.gridColumn35.OptionsColumn.AllowEdit = false;
            this.gridColumn35.OptionsColumn.FixedWidth = true;
            this.gridColumn35.Visible = true;
            this.gridColumn35.VisibleIndex = 11;
            this.gridColumn35.Width = 74;
            // 
            // gridColumn36
            // 
            this.gridColumn36.Caption = "Status";
            this.gridColumn36.FieldName = "status";
            this.gridColumn36.MinWidth = 19;
            this.gridColumn36.Name = "gridColumn36";
            this.gridColumn36.OptionsColumn.AllowEdit = false;
            this.gridColumn36.OptionsColumn.FixedWidth = true;
            this.gridColumn36.Width = 50;
            // 
            // gridColumn48
            // 
            this.gridColumn48.Caption = "Comment";
            this.gridColumn48.FieldName = "comment";
            this.gridColumn48.MinWidth = 19;
            this.gridColumn48.Name = "gridColumn48";
            this.gridColumn48.OptionsColumn.FixedWidth = true;
            this.gridColumn48.Visible = true;
            this.gridColumn48.VisibleIndex = 12;
            this.gridColumn48.Width = 219;
            // 
            // gridColumn38
            // 
            this.gridColumn38.Caption = "Record";
            this.gridColumn38.FieldName = "record";
            this.gridColumn38.MinWidth = 19;
            this.gridColumn38.Name = "gridColumn38";
            this.gridColumn38.OptionsColumn.AllowEdit = false;
            this.gridColumn38.OptionsColumn.FixedWidth = true;
            // 
            // panelTimeOffTop
            // 
            this.panelTimeOffTop.Controls.Add(this.txtHireDate);
            this.panelTimeOffTop.Controls.Add(this.label9);
            this.panelTimeOffTop.Controls.Add(this.txtDecember);
            this.panelTimeOffTop.Controls.Add(this.label8);
            this.panelTimeOffTop.Controls.Add(this.txtPTOtaken);
            this.panelTimeOffTop.Controls.Add(this.label7);
            this.panelTimeOffTop.Controls.Add(this.btnSaveVacation);
            this.panelTimeOffTop.Controls.Add(this.pictureBox5);
            this.panelTimeOffTop.Controls.Add(this.btnRequestTimeOff);
            this.panelTimeOffTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTimeOffTop.Location = new System.Drawing.Point(0, 0);
            this.panelTimeOffTop.Name = "panelTimeOffTop";
            this.panelTimeOffTop.Size = new System.Drawing.Size(1220, 41);
            this.panelTimeOffTop.TabIndex = 1;
            // 
            // txtHireDate
            // 
            this.txtHireDate.Location = new System.Drawing.Point(975, 6);
            this.txtHireDate.Name = "txtHireDate";
            this.txtHireDate.Size = new System.Drawing.Size(88, 24);
            this.txtHireDate.TabIndex = 145;
            this.txtHireDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(900, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 17);
            this.label9.TabIndex = 144;
            this.label9.Text = "Hire Date :";
            // 
            // txtDecember
            // 
            this.txtDecember.Location = new System.Drawing.Point(816, 6);
            this.txtDecember.Name = "txtDecember";
            this.txtDecember.Size = new System.Drawing.Size(65, 24);
            this.txtDecember.TabIndex = 143;
            this.txtDecember.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(719, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 17);
            this.label8.TabIndex = 142;
            this.label8.Text = "Annual Total :";
            // 
            // txtPTOtaken
            // 
            this.txtPTOtaken.Location = new System.Drawing.Point(614, 6);
            this.txtPTOtaken.Name = "txtPTOtaken";
            this.txtPTOtaken.Size = new System.Drawing.Size(65, 24);
            this.txtPTOtaken.TabIndex = 141;
            this.txtPTOtaken.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(530, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 17);
            this.label7.TabIndex = 140;
            this.label7.Text = "PTO Taken :";
            // 
            // btnSaveVacation
            // 
            this.btnSaveVacation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSaveVacation.Location = new System.Drawing.Point(291, 9);
            this.btnSaveVacation.Name = "btnSaveVacation";
            this.btnSaveVacation.Size = new System.Drawing.Size(75, 23);
            this.btnSaveVacation.TabIndex = 139;
            this.btnSaveVacation.Text = "Save";
            this.btnSaveVacation.UseVisualStyleBackColor = false;
            this.btnSaveVacation.Click += new System.EventHandler(this.btnSaveVacation_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(197, 7);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(36, 28);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 138;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // btnRequestTimeOff
            // 
            this.btnRequestTimeOff.Location = new System.Drawing.Point(8, 9);
            this.btnRequestTimeOff.Name = "btnRequestTimeOff";
            this.btnRequestTimeOff.Size = new System.Drawing.Size(131, 23);
            this.btnRequestTimeOff.TabIndex = 1;
            this.btnRequestTimeOff.Text = "Request Time Off";
            this.btnRequestTimeOff.UseVisualStyleBackColor = true;
            this.btnRequestTimeOff.Click += new System.EventHandler(this.btnRequestTimeOff_Click);
            // 
            // tabTimeOffProc
            // 
            this.tabTimeOffProc.Controls.Add(this.panelTimeOffProcAll);
            this.tabTimeOffProc.Location = new System.Drawing.Point(4, 25);
            this.tabTimeOffProc.Name = "tabTimeOffProc";
            this.tabTimeOffProc.Size = new System.Drawing.Size(192, 71);
            this.tabTimeOffProc.TabIndex = 5;
            this.tabTimeOffProc.Text = "Employees TimeOff";
            this.tabTimeOffProc.UseVisualStyleBackColor = true;
            // 
            // panelTimeOffProcAll
            // 
            this.panelTimeOffProcAll.Controls.Add(this.panelTimeOffProcBottom);
            this.panelTimeOffProcAll.Controls.Add(this.panelTimeOffProcTop);
            this.panelTimeOffProcAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTimeOffProcAll.Location = new System.Drawing.Point(0, 0);
            this.panelTimeOffProcAll.Name = "panelTimeOffProcAll";
            this.panelTimeOffProcAll.Size = new System.Drawing.Size(192, 71);
            this.panelTimeOffProcAll.TabIndex = 0;
            // 
            // panelTimeOffProcBottom
            // 
            this.panelTimeOffProcBottom.Controls.Add(this.dgv6);
            this.panelTimeOffProcBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTimeOffProcBottom.Location = new System.Drawing.Point(0, 38);
            this.panelTimeOffProcBottom.Name = "panelTimeOffProcBottom";
            this.panelTimeOffProcBottom.Size = new System.Drawing.Size(192, 33);
            this.panelTimeOffProcBottom.TabIndex = 2;
            // 
            // dgv6
            // 
            this.dgv6.ContextMenuStrip = this.contextMenuStrip2;
            this.dgv6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv6.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.dgv6.Location = new System.Drawing.Point(0, 0);
            this.dgv6.MainView = this.gridView6;
            this.dgv6.MenuManager = this.barManager1;
            this.dgv6.Name = "dgv6";
            this.dgv6.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit5});
            this.dgv6.Size = new System.Drawing.Size(192, 33);
            this.dgv6.TabIndex = 4;
            this.dgv6.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView6});
            // 
            // gridView6
            // 
            this.gridView6.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.gridView6.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridView6.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.gridView6.Appearance.OddRow.Options.UseBackColor = true;
            this.gridView6.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.gridView6.Appearance.Row.Options.UseBackColor = true;
            this.gridView6.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn43,
            this.gridColumn44,
            this.gridColumn45,
            this.gridColumn46,
            this.gridColumn47,
            this.gridColumn49,
            this.gridColumn50,
            this.gridColumn51,
            this.gridColumn53,
            this.gridColumn54,
            this.gridColumn56,
            this.gridColumn58,
            this.gridColumn59,
            this.gridColumn60,
            this.gridColumn61});
            this.gridView6.GridControl = this.dgv6;
            this.gridView6.Name = "gridView6";
            this.gridView6.OptionsView.ColumnAutoWidth = false;
            this.gridView6.OptionsView.EnableAppearanceEvenRow = true;
            this.gridView6.OptionsView.EnableAppearanceOddRow = true;
            this.gridView6.OptionsView.ShowGroupPanel = false;
            this.gridView6.PaintStyleName = "Skin";
            // 
            // gridColumn43
            // 
            this.gridColumn43.Caption = "Num";
            this.gridColumn43.FieldName = "num";
            this.gridColumn43.MinWidth = 19;
            this.gridColumn43.Name = "gridColumn43";
            this.gridColumn43.OptionsColumn.FixedWidth = true;
            this.gridColumn43.Visible = true;
            this.gridColumn43.VisibleIndex = 0;
            this.gridColumn43.Width = 30;
            // 
            // gridColumn44
            // 
            this.gridColumn44.Caption = "Date";
            this.gridColumn44.FieldName = "date";
            this.gridColumn44.MinWidth = 19;
            this.gridColumn44.Name = "gridColumn44";
            this.gridColumn44.OptionsColumn.FixedWidth = true;
            this.gridColumn44.Visible = true;
            this.gridColumn44.VisibleIndex = 1;
            this.gridColumn44.Width = 73;
            // 
            // gridColumn45
            // 
            this.gridColumn45.AppearanceHeader.Options.UseTextOptions = true;
            this.gridColumn45.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridColumn45.Caption = "Approved";
            this.gridColumn45.ColumnEdit = this.repositoryItemCheckEdit5;
            this.gridColumn45.FieldName = "approved";
            this.gridColumn45.MinWidth = 19;
            this.gridColumn45.Name = "gridColumn45";
            this.gridColumn45.OptionsColumn.FixedWidth = true;
            this.gridColumn45.Visible = true;
            this.gridColumn45.VisibleIndex = 2;
            this.gridColumn45.Width = 68;
            // 
            // repositoryItemCheckEdit5
            // 
            this.repositoryItemCheckEdit5.AutoHeight = false;
            this.repositoryItemCheckEdit5.Name = "repositoryItemCheckEdit5";
            this.repositoryItemCheckEdit5.CheckedChanged += new System.EventHandler(this.repositoryItemCheckEdit5_CheckedChanged);
            // 
            // gridColumn46
            // 
            this.gridColumn46.Caption = "Approved By";
            this.gridColumn46.FieldName = "approvedby";
            this.gridColumn46.MinWidth = 19;
            this.gridColumn46.Name = "gridColumn46";
            this.gridColumn46.OptionsColumn.FixedWidth = true;
            this.gridColumn46.Visible = true;
            this.gridColumn46.VisibleIndex = 3;
            this.gridColumn46.Width = 125;
            // 
            // gridColumn47
            // 
            this.gridColumn47.Caption = "Emp #";
            this.gridColumn47.FieldName = "empno";
            this.gridColumn47.MinWidth = 19;
            this.gridColumn47.Name = "gridColumn47";
            this.gridColumn47.OptionsColumn.AllowEdit = false;
            this.gridColumn47.OptionsColumn.FixedWidth = true;
            this.gridColumn47.Visible = true;
            this.gridColumn47.VisibleIndex = 4;
            this.gridColumn47.Width = 79;
            // 
            // gridColumn49
            // 
            this.gridColumn49.Caption = "Employee Name";
            this.gridColumn49.FieldName = "name";
            this.gridColumn49.MinWidth = 19;
            this.gridColumn49.Name = "gridColumn49";
            this.gridColumn49.OptionsColumn.AllowEdit = false;
            this.gridColumn49.OptionsColumn.FixedWidth = true;
            this.gridColumn49.Visible = true;
            this.gridColumn49.VisibleIndex = 5;
            this.gridColumn49.Width = 125;
            // 
            // gridColumn50
            // 
            this.gridColumn50.Caption = "From Date";
            this.gridColumn50.FieldName = "fromdate";
            this.gridColumn50.MinWidth = 19;
            this.gridColumn50.Name = "gridColumn50";
            this.gridColumn50.OptionsColumn.FixedWidth = true;
            this.gridColumn50.Visible = true;
            this.gridColumn50.VisibleIndex = 7;
            this.gridColumn50.Width = 86;
            // 
            // gridColumn51
            // 
            this.gridColumn51.Caption = "To Date";
            this.gridColumn51.FieldName = "todate";
            this.gridColumn51.MinWidth = 19;
            this.gridColumn51.Name = "gridColumn51";
            this.gridColumn51.OptionsColumn.FixedWidth = true;
            this.gridColumn51.Visible = true;
            this.gridColumn51.VisibleIndex = 8;
            this.gridColumn51.Width = 93;
            // 
            // gridColumn53
            // 
            this.gridColumn53.Caption = "Hours";
            this.gridColumn53.FieldName = "hours";
            this.gridColumn53.MinWidth = 19;
            this.gridColumn53.Name = "gridColumn53";
            this.gridColumn53.OptionsColumn.FixedWidth = true;
            this.gridColumn53.Visible = true;
            this.gridColumn53.VisibleIndex = 9;
            this.gridColumn53.Width = 69;
            // 
            // gridColumn54
            // 
            this.gridColumn54.Caption = "Hire Date";
            this.gridColumn54.FieldName = "hiredate";
            this.gridColumn54.MinWidth = 19;
            this.gridColumn54.Name = "gridColumn54";
            this.gridColumn54.OptionsColumn.FixedWidth = true;
            // 
            // gridColumn56
            // 
            this.gridColumn56.Caption = "PTO Available";
            this.gridColumn56.DisplayFormat.FormatString = "N2";
            this.gridColumn56.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn56.FieldName = "pto_now";
            this.gridColumn56.MinWidth = 19;
            this.gridColumn56.Name = "gridColumn56";
            this.gridColumn56.OptionsColumn.AllowEdit = false;
            this.gridColumn56.OptionsColumn.FixedWidth = true;
            this.gridColumn56.Visible = true;
            this.gridColumn56.VisibleIndex = 10;
            // 
            // gridColumn58
            // 
            this.gridColumn58.Caption = "December PTO";
            this.gridColumn58.DisplayFormat.FormatString = "N2";
            this.gridColumn58.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn58.FieldName = "december";
            this.gridColumn58.MinWidth = 19;
            this.gridColumn58.Name = "gridColumn58";
            this.gridColumn58.OptionsColumn.AllowEdit = false;
            this.gridColumn58.OptionsColumn.FixedWidth = true;
            this.gridColumn58.Visible = true;
            this.gridColumn58.VisibleIndex = 11;
            this.gridColumn58.Width = 80;
            // 
            // gridColumn59
            // 
            this.gridColumn59.Caption = "Status";
            this.gridColumn59.FieldName = "status";
            this.gridColumn59.MinWidth = 19;
            this.gridColumn59.Name = "gridColumn59";
            this.gridColumn59.OptionsColumn.AllowEdit = false;
            this.gridColumn59.OptionsColumn.FixedWidth = true;
            this.gridColumn59.Visible = true;
            this.gridColumn59.VisibleIndex = 6;
            this.gridColumn59.Width = 50;
            // 
            // gridColumn60
            // 
            this.gridColumn60.Caption = "Comment";
            this.gridColumn60.FieldName = "comment";
            this.gridColumn60.MinWidth = 19;
            this.gridColumn60.Name = "gridColumn60";
            this.gridColumn60.OptionsColumn.FixedWidth = true;
            this.gridColumn60.Visible = true;
            this.gridColumn60.VisibleIndex = 12;
            this.gridColumn60.Width = 680;
            // 
            // gridColumn61
            // 
            this.gridColumn61.Caption = "Record";
            this.gridColumn61.FieldName = "record";
            this.gridColumn61.MinWidth = 19;
            this.gridColumn61.Name = "gridColumn61";
            this.gridColumn61.OptionsColumn.FixedWidth = true;
            // 
            // panelTimeOffProcTop
            // 
            this.panelTimeOffProcTop.Controls.Add(this.btnCalendar);
            this.panelTimeOffProcTop.Controls.Add(this.label3);
            this.panelTimeOffProcTop.Controls.Add(this.cmbMyProc);
            this.panelTimeOffProcTop.Controls.Add(this.simpleButton1);
            this.panelTimeOffProcTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTimeOffProcTop.Location = new System.Drawing.Point(0, 0);
            this.panelTimeOffProcTop.Name = "panelTimeOffProcTop";
            this.panelTimeOffProcTop.Size = new System.Drawing.Size(192, 38);
            this.panelTimeOffProcTop.TabIndex = 1;
            // 
            // btnCalendar
            // 
            this.btnCalendar.Location = new System.Drawing.Point(269, 6);
            this.btnCalendar.Name = "btnCalendar";
            this.btnCalendar.Size = new System.Drawing.Size(115, 23);
            this.btnCalendar.TabIndex = 122;
            this.btnCalendar.Text = "Show Calendar";
            this.btnCalendar.UseVisualStyleBackColor = true;
            this.btnCalendar.Click += new System.EventHandler(this.btnCalendar_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(136, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 17);
            this.label3.TabIndex = 121;
            this.label3.Text = "Requests to Show";
            // 
            // cmbMyProc
            // 
            this.cmbMyProc.FormattingEnabled = true;
            this.cmbMyProc.Items.AddRange(new object[] {
            "All",
            "Approved",
            "UnApproved"});
            this.cmbMyProc.Location = new System.Drawing.Point(57, 8);
            this.cmbMyProc.Name = "cmbMyProc";
            this.cmbMyProc.Size = new System.Drawing.Size(73, 25);
            this.cmbMyProc.TabIndex = 120;
            this.cmbMyProc.Text = "All";
            this.cmbMyProc.SelectedIndexChanged += new System.EventHandler(this.cmbMyProc_SelectedIndexChanged);
            // 
            // simpleButton1
            // 
            this.simpleButton1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton1.ImageOptions.Image")));
            this.simpleButton1.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleRight;
            this.simpleButton1.Location = new System.Drawing.Point(16, 8);
            this.simpleButton1.Margin = new System.Windows.Forms.Padding(0);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(27, 20);
            this.simpleButton1.TabIndex = 119;
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // tabContractLabor
            // 
            this.tabContractLabor.Controls.Add(this.panelContractAll);
            this.tabContractLabor.Location = new System.Drawing.Point(4, 25);
            this.tabContractLabor.Name = "tabContractLabor";
            this.tabContractLabor.Size = new System.Drawing.Size(192, 71);
            this.tabContractLabor.TabIndex = 6;
            this.tabContractLabor.Text = "PartTime Services";
            this.tabContractLabor.UseVisualStyleBackColor = true;
            // 
            // panelContractAll
            // 
            this.panelContractAll.Controls.Add(this.panelContractBottom);
            this.panelContractAll.Controls.Add(this.panelContractTop);
            this.panelContractAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContractAll.Location = new System.Drawing.Point(0, 0);
            this.panelContractAll.Name = "panelContractAll";
            this.panelContractAll.Size = new System.Drawing.Size(192, 71);
            this.panelContractAll.TabIndex = 0;
            // 
            // panelContractBottom
            // 
            this.panelContractBottom.Controls.Add(this.dgv7);
            this.panelContractBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelContractBottom.Location = new System.Drawing.Point(0, 46);
            this.panelContractBottom.Name = "panelContractBottom";
            this.panelContractBottom.Size = new System.Drawing.Size(192, 25);
            this.panelContractBottom.TabIndex = 2;
            // 
            // dgv7
            // 
            this.dgv7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv7.Location = new System.Drawing.Point(0, 0);
            this.dgv7.LookAndFeel.SkinName = "Foggy";
            this.dgv7.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv7.MainView = this.gridMain7;
            this.dgv7.Name = "dgv7";
            this.dgv7.Size = new System.Drawing.Size(192, 25);
            this.dgv7.TabIndex = 13;
            this.dgv7.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain7,
            this.gridView1});
            // 
            // gridMain7
            // 
            this.gridMain7.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain7.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain7.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain7.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain7.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain7.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain7.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain7.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain7.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain7.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain7.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain7.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain7.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain7.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain7.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain7.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain7.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain7.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain7.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain7.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain7.Appearance.EvenRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain7.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.EvenRow.Options.UseBorderColor = true;
            this.gridMain7.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain7.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain7.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain7.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain7.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain7.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain7.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.FilterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(114)))), ((int)(((byte)(113)))));
            this.gridMain7.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain7.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain7.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain7.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(192)))), ((int)(((byte)(157)))));
            this.gridMain7.Appearance.FocusedRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(219)))), ((int)(((byte)(188)))));
            this.gridMain7.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.FocusedRow.Options.UseBorderColor = true;
            this.gridMain7.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain7.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain7.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain7.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain7.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain7.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain7.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain7.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain7.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain7.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(242)))), ((int)(((byte)(213)))));
            this.gridMain7.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.GroupPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain7.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain7.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain7.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain7.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain7.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain7.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain7.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain7.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(230)))), ((int)(((byte)(203)))));
            this.gridMain7.Appearance.HideSelectionRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(230)))), ((int)(((byte)(203)))));
            this.gridMain7.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.HideSelectionRow.Options.UseBorderColor = true;
            this.gridMain7.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain7.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain7.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain7.Appearance.OddRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain7.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.OddRow.Options.UseBorderColor = true;
            this.gridMain7.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(252)))), ((int)(((byte)(247)))));
            this.gridMain7.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain7.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(148)))), ((int)(((byte)(148)))));
            this.gridMain7.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain7.Appearance.Preview.Options.UseFont = true;
            this.gridMain7.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain7.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain7.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9F);
            this.gridMain7.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.Row.Options.UseBackColor = true;
            this.gridMain7.Appearance.Row.Options.UseFont = true;
            this.gridMain7.Appearance.Row.Options.UseForeColor = true;
            this.gridMain7.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain7.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain7.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(215)))), ((int)(((byte)(188)))));
            this.gridMain7.Appearance.SelectedRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(230)))), ((int)(((byte)(203)))));
            this.gridMain7.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.SelectedRow.Options.UseBorderColor = true;
            this.gridMain7.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain7.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain7.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain7.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain7.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand12});
            this.gridMain7.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain7.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn70,
            this.bandedGridColumn71,
            this.bandedGridColumn73,
            this.bandedGridColumn68,
            this.bandedGridColumn67,
            this.bandedGridColumn69,
            this.bandedGridColumn72,
            this.bandedGridColumn74,
            this.bandedGridColumn75,
            this.bandedGridColumn76,
            this.bandedGridColumn77,
            this.bandedGridColumn64,
            this.bandedGridColumn79,
            this.bandedGridColumn80});
            this.gridMain7.GridControl = this.dgv7;
            this.gridMain7.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "hours", this.bandedGridColumn79, "{0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "paymentAmount", this.bandedGridColumn77, "{0:0,0.00}")});
            this.gridMain7.Name = "gridMain7";
            this.gridMain7.OptionsBehavior.AutoPopulateColumns = false;
            this.gridMain7.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.MouseDown;
            this.gridMain7.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridMain7.OptionsPrint.AutoWidth = false;
            this.gridMain7.OptionsPrint.PrintBandHeader = false;
            this.gridMain7.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain7.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain7.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain7.OptionsView.ShowBands = false;
            this.gridMain7.OptionsView.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowAlways;
            this.gridMain7.OptionsView.ShowFooter = true;
            this.gridMain7.OptionsView.ShowGroupPanel = false;
            this.gridMain7.PaintStyleName = "Style3D";
            this.gridMain7.ShownEditor += new System.EventHandler(this.gridMain7_ShownEditor);
            this.gridMain7.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMain7_CellValueChanged);
            this.gridMain7.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain7_CustomColumnDisplayText);
            // 
            // gridBand12
            // 
            this.gridBand12.Caption = "gridBand1";
            this.gridBand12.Columns.Add(this.bandedGridColumn70);
            this.gridBand12.Columns.Add(this.bandedGridColumn68);
            this.gridBand12.Columns.Add(this.bandedGridColumn67);
            this.gridBand12.Columns.Add(this.bandedGridColumn69);
            this.gridBand12.Columns.Add(this.bandedGridColumn72);
            this.gridBand12.Columns.Add(this.bandedGridColumn74);
            this.gridBand12.Columns.Add(this.bandedGridColumn75);
            this.gridBand12.Columns.Add(this.bandedGridColumn76);
            this.gridBand12.Columns.Add(this.bandedGridColumn64);
            this.gridBand12.Columns.Add(this.bandedGridColumn79);
            this.gridBand12.Columns.Add(this.bandedGridColumn77);
            this.gridBand12.Columns.Add(this.bandedGridColumn71);
            this.gridBand12.Columns.Add(this.bandedGridColumn73);
            this.gridBand12.MinWidth = 14;
            this.gridBand12.Name = "gridBand12";
            this.gridBand12.VisibleIndex = 0;
            this.gridBand12.Width = 1009;
            // 
            // bandedGridColumn70
            // 
            this.bandedGridColumn70.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn70.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn70.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn70.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn70.Caption = "Num";
            this.bandedGridColumn70.FieldName = "num";
            this.bandedGridColumn70.MinWidth = 27;
            this.bandedGridColumn70.Name = "bandedGridColumn70";
            this.bandedGridColumn70.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn70.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn70.Visible = true;
            this.bandedGridColumn70.Width = 49;
            // 
            // bandedGridColumn68
            // 
            this.bandedGridColumn68.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn68.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn68.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn68.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn68.Caption = "Date";
            this.bandedGridColumn68.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn68.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn68.FieldName = "date";
            this.bandedGridColumn68.MinWidth = 29;
            this.bandedGridColumn68.Name = "bandedGridColumn68";
            this.bandedGridColumn68.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn68.Visible = true;
            this.bandedGridColumn68.Width = 78;
            // 
            // bandedGridColumn67
            // 
            this.bandedGridColumn67.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn67.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn67.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn67.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn67.Caption = "Funeral No";
            this.bandedGridColumn67.FieldName = "funeralNo";
            this.bandedGridColumn67.MinWidth = 29;
            this.bandedGridColumn67.Name = "bandedGridColumn67";
            this.bandedGridColumn67.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn67.Visible = true;
            this.bandedGridColumn67.Width = 78;
            // 
            // bandedGridColumn69
            // 
            this.bandedGridColumn69.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn69.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn69.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn69.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn69.Caption = "Deceased Name";
            this.bandedGridColumn69.FieldName = "deceasedName";
            this.bandedGridColumn69.MinWidth = 29;
            this.bandedGridColumn69.Name = "bandedGridColumn69";
            this.bandedGridColumn69.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn69.Visible = true;
            this.bandedGridColumn69.Width = 110;
            // 
            // bandedGridColumn72
            // 
            this.bandedGridColumn72.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn72.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn72.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn72.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn72.Caption = "Service Provided";
            this.bandedGridColumn72.FieldName = "service";
            this.bandedGridColumn72.MinWidth = 29;
            this.bandedGridColumn72.Name = "bandedGridColumn72";
            this.bandedGridColumn72.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn72.Visible = true;
            this.bandedGridColumn72.Width = 182;
            // 
            // bandedGridColumn74
            // 
            this.bandedGridColumn74.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn74.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn74.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn74.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn74.Caption = "Called By";
            this.bandedGridColumn74.FieldName = "calledBy";
            this.bandedGridColumn74.MinWidth = 29;
            this.bandedGridColumn74.Name = "bandedGridColumn74";
            this.bandedGridColumn74.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn74.Visible = true;
            this.bandedGridColumn74.Width = 72;
            // 
            // bandedGridColumn75
            // 
            this.bandedGridColumn75.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn75.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn75.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn75.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn75.Caption = "Time Beginning";
            this.bandedGridColumn75.FieldName = "timeIn1";
            this.bandedGridColumn75.MinWidth = 29;
            this.bandedGridColumn75.Name = "bandedGridColumn75";
            this.bandedGridColumn75.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn75.Visible = true;
            this.bandedGridColumn75.Width = 74;
            // 
            // bandedGridColumn76
            // 
            this.bandedGridColumn76.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn76.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn76.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn76.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn76.Caption = "Time Ending";
            this.bandedGridColumn76.FieldName = "timeOut1";
            this.bandedGridColumn76.MinWidth = 29;
            this.bandedGridColumn76.Name = "bandedGridColumn76";
            this.bandedGridColumn76.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn76.Visible = true;
            this.bandedGridColumn76.Width = 71;
            // 
            // bandedGridColumn64
            // 
            this.bandedGridColumn64.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn64.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn64.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn64.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn64.Caption = "Rate";
            this.bandedGridColumn64.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn64.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn64.FieldName = "rate";
            this.bandedGridColumn64.MinWidth = 29;
            this.bandedGridColumn64.Name = "bandedGridColumn64";
            this.bandedGridColumn64.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn64.Visible = true;
            this.bandedGridColumn64.Width = 91;
            // 
            // bandedGridColumn79
            // 
            this.bandedGridColumn79.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn79.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn79.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn79.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn79.Caption = "Hours";
            this.bandedGridColumn79.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn79.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn79.FieldName = "hours";
            this.bandedGridColumn79.MinWidth = 25;
            this.bandedGridColumn79.Name = "bandedGridColumn79";
            this.bandedGridColumn79.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn79.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn79.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn79.Visible = true;
            this.bandedGridColumn79.Width = 94;
            // 
            // bandedGridColumn77
            // 
            this.bandedGridColumn77.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn77.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn77.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn77.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn77.Caption = "Amount to be Paid";
            this.bandedGridColumn77.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn77.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn77.FieldName = "paymentAmount";
            this.bandedGridColumn77.MinWidth = 29;
            this.bandedGridColumn77.Name = "bandedGridColumn77";
            this.bandedGridColumn77.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn77.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn77.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn77.Visible = true;
            this.bandedGridColumn77.Width = 110;
            // 
            // bandedGridColumn71
            // 
            this.bandedGridColumn71.Caption = "record";
            this.bandedGridColumn71.FieldName = "record";
            this.bandedGridColumn71.MinWidth = 27;
            this.bandedGridColumn71.Name = "bandedGridColumn71";
            this.bandedGridColumn71.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn71.Width = 101;
            // 
            // bandedGridColumn73
            // 
            this.bandedGridColumn73.Caption = "Time Stamp";
            this.bandedGridColumn73.FieldName = "tmstamp";
            this.bandedGridColumn73.MinWidth = 27;
            this.bandedGridColumn73.Name = "bandedGridColumn73";
            this.bandedGridColumn73.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn73.Width = 163;
            // 
            // bandedGridColumn80
            // 
            this.bandedGridColumn80.Caption = "What Week";
            this.bandedGridColumn80.FieldName = "week";
            this.bandedGridColumn80.MinWidth = 25;
            this.bandedGridColumn80.Name = "bandedGridColumn80";
            this.bandedGridColumn80.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn80.Width = 94;
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.dgv7;
            this.gridView1.Name = "gridView1";
            // 
            // panelContractTop
            // 
            this.panelContractTop.Controls.Add(this.label6);
            this.panelContractTop.Controls.Add(this.pictureBox1);
            this.panelContractTop.Controls.Add(this.pictureBox11);
            this.panelContractTop.Controls.Add(this.pictureBox12);
            this.panelContractTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelContractTop.Location = new System.Drawing.Point(0, 0);
            this.panelContractTop.Name = "panelContractTop";
            this.panelContractTop.Size = new System.Drawing.Size(192, 46);
            this.panelContractTop.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(337, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(181, 23);
            this.label6.TabIndex = 133;
            this.label6.Text = "PartTime Services";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(10, 11);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(34, 27);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 128;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(130, 10);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(36, 28);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 127;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(73, 11);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(36, 28);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 126;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Tag = "Add Site";
            this.pictureBox12.Click += new System.EventHandler(this.pictureBox12_Click);
            // 
            // tabPageOther
            // 
            this.tabPageOther.Controls.Add(this.panelOtherAll);
            this.tabPageOther.Location = new System.Drawing.Point(4, 25);
            this.tabPageOther.Name = "tabPageOther";
            this.tabPageOther.Size = new System.Drawing.Size(192, 71);
            this.tabPageOther.TabIndex = 7;
            this.tabPageOther.Text = "Other";
            this.tabPageOther.UseVisualStyleBackColor = true;
            // 
            // panelOtherAll
            // 
            this.panelOtherAll.Controls.Add(this.panelOtherBottom);
            this.panelOtherAll.Controls.Add(this.panelOtherTop);
            this.panelOtherAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelOtherAll.Location = new System.Drawing.Point(0, 0);
            this.panelOtherAll.Name = "panelOtherAll";
            this.panelOtherAll.Size = new System.Drawing.Size(192, 71);
            this.panelOtherAll.TabIndex = 0;
            // 
            // panelOtherBottom
            // 
            this.panelOtherBottom.Controls.Add(this.dgv8);
            this.panelOtherBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelOtherBottom.Location = new System.Drawing.Point(0, 46);
            this.panelOtherBottom.Name = "panelOtherBottom";
            this.panelOtherBottom.Size = new System.Drawing.Size(192, 25);
            this.panelOtherBottom.TabIndex = 2;
            // 
            // dgv8
            // 
            this.dgv8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv8.Location = new System.Drawing.Point(0, 0);
            this.dgv8.LookAndFeel.SkinName = "Foggy";
            this.dgv8.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv8.MainView = this.gridMain8;
            this.dgv8.Name = "dgv8";
            this.dgv8.Size = new System.Drawing.Size(192, 25);
            this.dgv8.TabIndex = 14;
            this.dgv8.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain8,
            this.gridView4});
            // 
            // gridMain8
            // 
            this.gridMain8.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain8.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain8.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain8.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain8.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain8.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain8.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain8.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain8.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain8.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain8.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain8.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain8.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain8.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain8.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain8.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain8.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain8.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain8.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain8.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain8.Appearance.EvenRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain8.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.EvenRow.Options.UseBorderColor = true;
            this.gridMain8.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain8.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain8.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain8.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain8.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain8.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain8.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.FilterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(114)))), ((int)(((byte)(113)))));
            this.gridMain8.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain8.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain8.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain8.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain8.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(192)))), ((int)(((byte)(157)))));
            this.gridMain8.Appearance.FocusedRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(219)))), ((int)(((byte)(188)))));
            this.gridMain8.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.FocusedRow.Options.UseBorderColor = true;
            this.gridMain8.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain8.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain8.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain8.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain8.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain8.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain8.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain8.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain8.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain8.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain8.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(242)))), ((int)(((byte)(213)))));
            this.gridMain8.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.GroupPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain8.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain8.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain8.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain8.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain8.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain8.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain8.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain8.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(230)))), ((int)(((byte)(203)))));
            this.gridMain8.Appearance.HideSelectionRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(230)))), ((int)(((byte)(203)))));
            this.gridMain8.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.HideSelectionRow.Options.UseBorderColor = true;
            this.gridMain8.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain8.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain8.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain8.Appearance.OddRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain8.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.OddRow.Options.UseBorderColor = true;
            this.gridMain8.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(252)))), ((int)(((byte)(247)))));
            this.gridMain8.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain8.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(148)))), ((int)(((byte)(148)))));
            this.gridMain8.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain8.Appearance.Preview.Options.UseFont = true;
            this.gridMain8.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain8.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain8.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 9F);
            this.gridMain8.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.Row.Options.UseBackColor = true;
            this.gridMain8.Appearance.Row.Options.UseFont = true;
            this.gridMain8.Appearance.Row.Options.UseForeColor = true;
            this.gridMain8.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain8.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain8.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(215)))), ((int)(((byte)(188)))));
            this.gridMain8.Appearance.SelectedRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(230)))), ((int)(((byte)(203)))));
            this.gridMain8.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.SelectedRow.Options.UseBorderColor = true;
            this.gridMain8.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain8.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain8.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain8.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain8.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain8.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand13});
            this.gridMain8.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain8.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn81,
            this.bandedGridColumn92,
            this.bandedGridColumn93,
            this.bandedGridColumn82,
            this.bandedGridColumn83,
            this.bandedGridColumn84,
            this.bandedGridColumn85,
            this.bandedGridColumn86,
            this.bandedGridColumn87,
            this.bandedGridColumn88,
            this.bandedGridColumn91,
            this.bandedGridColumn89,
            this.bandedGridColumn90,
            this.bandedGridColumn94});
            this.gridMain8.GridControl = this.dgv8;
            this.gridMain8.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "hours", this.bandedGridColumn90, "{0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "paymentAmount", this.bandedGridColumn91, "{0:0,0.00}")});
            this.gridMain8.Name = "gridMain8";
            this.gridMain8.OptionsBehavior.AutoPopulateColumns = false;
            this.gridMain8.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.MouseDown;
            this.gridMain8.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridMain8.OptionsPrint.AutoWidth = false;
            this.gridMain8.OptionsPrint.PrintBandHeader = false;
            this.gridMain8.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain8.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain8.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain8.OptionsView.ShowBands = false;
            this.gridMain8.OptionsView.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowAlways;
            this.gridMain8.OptionsView.ShowFooter = true;
            this.gridMain8.OptionsView.ShowGroupPanel = false;
            this.gridMain8.PaintStyleName = "Style3D";
            this.gridMain8.ShownEditor += new System.EventHandler(this.gridMain8_ShownEditor);
            this.gridMain8.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMain8_CellValueChanged);
            this.gridMain8.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain8_CustomColumnDisplayText);
            this.gridMain8.ValidatingEditor += new DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventHandler(this.gridMain8_ValidatingEditor);
            // 
            // gridBand13
            // 
            this.gridBand13.Caption = "gridBand1";
            this.gridBand13.Columns.Add(this.bandedGridColumn81);
            this.gridBand13.Columns.Add(this.bandedGridColumn82);
            this.gridBand13.Columns.Add(this.bandedGridColumn83);
            this.gridBand13.Columns.Add(this.bandedGridColumn84);
            this.gridBand13.Columns.Add(this.bandedGridColumn85);
            this.gridBand13.Columns.Add(this.bandedGridColumn86);
            this.gridBand13.Columns.Add(this.bandedGridColumn87);
            this.gridBand13.Columns.Add(this.bandedGridColumn88);
            this.gridBand13.Columns.Add(this.bandedGridColumn89);
            this.gridBand13.Columns.Add(this.bandedGridColumn90);
            this.gridBand13.Columns.Add(this.bandedGridColumn91);
            this.gridBand13.Columns.Add(this.bandedGridColumn92);
            this.gridBand13.Columns.Add(this.bandedGridColumn93);
            this.gridBand13.MinWidth = 14;
            this.gridBand13.Name = "gridBand13";
            this.gridBand13.VisibleIndex = 0;
            this.gridBand13.Width = 770;
            // 
            // bandedGridColumn81
            // 
            this.bandedGridColumn81.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn81.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn81.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn81.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn81.Caption = "Num";
            this.bandedGridColumn81.FieldName = "num";
            this.bandedGridColumn81.MinWidth = 27;
            this.bandedGridColumn81.Name = "bandedGridColumn81";
            this.bandedGridColumn81.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn81.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn81.Visible = true;
            this.bandedGridColumn81.Width = 49;
            // 
            // bandedGridColumn82
            // 
            this.bandedGridColumn82.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn82.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn82.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn82.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn82.Caption = "Date";
            this.bandedGridColumn82.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn82.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn82.FieldName = "date";
            this.bandedGridColumn82.MinWidth = 29;
            this.bandedGridColumn82.Name = "bandedGridColumn82";
            this.bandedGridColumn82.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn82.Visible = true;
            this.bandedGridColumn82.Width = 78;
            // 
            // bandedGridColumn83
            // 
            this.bandedGridColumn83.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn83.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn83.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn83.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn83.Caption = "Funeral No";
            this.bandedGridColumn83.FieldName = "funeralNo";
            this.bandedGridColumn83.MinWidth = 29;
            this.bandedGridColumn83.Name = "bandedGridColumn83";
            this.bandedGridColumn83.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn83.Visible = true;
            this.bandedGridColumn83.Width = 78;
            // 
            // bandedGridColumn84
            // 
            this.bandedGridColumn84.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn84.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn84.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn84.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn84.Caption = "Deceased Name";
            this.bandedGridColumn84.FieldName = "deceasedName";
            this.bandedGridColumn84.MinWidth = 29;
            this.bandedGridColumn84.Name = "bandedGridColumn84";
            this.bandedGridColumn84.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn84.Visible = true;
            this.bandedGridColumn84.Width = 110;
            // 
            // bandedGridColumn85
            // 
            this.bandedGridColumn85.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn85.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn85.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn85.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn85.Caption = "Service Provided";
            this.bandedGridColumn85.FieldName = "service";
            this.bandedGridColumn85.MinWidth = 29;
            this.bandedGridColumn85.Name = "bandedGridColumn85";
            this.bandedGridColumn85.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn85.Visible = true;
            this.bandedGridColumn85.Width = 182;
            // 
            // bandedGridColumn86
            // 
            this.bandedGridColumn86.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn86.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn86.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn86.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn86.Caption = "Called By";
            this.bandedGridColumn86.FieldName = "calledBy";
            this.bandedGridColumn86.MinWidth = 29;
            this.bandedGridColumn86.Name = "bandedGridColumn86";
            this.bandedGridColumn86.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn86.Visible = true;
            this.bandedGridColumn86.Width = 72;
            // 
            // bandedGridColumn87
            // 
            this.bandedGridColumn87.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn87.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn87.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn87.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn87.Caption = "Time Beginning";
            this.bandedGridColumn87.FieldName = "timeIn1";
            this.bandedGridColumn87.MinWidth = 29;
            this.bandedGridColumn87.Name = "bandedGridColumn87";
            this.bandedGridColumn87.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn87.Width = 74;
            // 
            // bandedGridColumn88
            // 
            this.bandedGridColumn88.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn88.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn88.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn88.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn88.Caption = "Time Ending";
            this.bandedGridColumn88.FieldName = "timeOut1";
            this.bandedGridColumn88.MinWidth = 29;
            this.bandedGridColumn88.Name = "bandedGridColumn88";
            this.bandedGridColumn88.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn88.Width = 71;
            // 
            // bandedGridColumn89
            // 
            this.bandedGridColumn89.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn89.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn89.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn89.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn89.Caption = "Rate";
            this.bandedGridColumn89.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn89.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn89.FieldName = "rate";
            this.bandedGridColumn89.MinWidth = 29;
            this.bandedGridColumn89.Name = "bandedGridColumn89";
            this.bandedGridColumn89.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn89.Visible = true;
            this.bandedGridColumn89.Width = 91;
            // 
            // bandedGridColumn90
            // 
            this.bandedGridColumn90.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn90.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn90.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn90.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn90.Caption = "Hours";
            this.bandedGridColumn90.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn90.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn90.FieldName = "hours";
            this.bandedGridColumn90.MinWidth = 25;
            this.bandedGridColumn90.Name = "bandedGridColumn90";
            this.bandedGridColumn90.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn90.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn90.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn90.Width = 94;
            // 
            // bandedGridColumn91
            // 
            this.bandedGridColumn91.AppearanceCell.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn91.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn91.AppearanceHeader.Font = new System.Drawing.Font("Tahoma", 9F);
            this.bandedGridColumn91.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn91.Caption = "Amount to be Paid";
            this.bandedGridColumn91.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn91.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn91.FieldName = "paymentAmount";
            this.bandedGridColumn91.MinWidth = 29;
            this.bandedGridColumn91.Name = "bandedGridColumn91";
            this.bandedGridColumn91.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn91.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn91.OptionsColumn.ReadOnly = true;
            this.bandedGridColumn91.Visible = true;
            this.bandedGridColumn91.Width = 110;
            // 
            // bandedGridColumn92
            // 
            this.bandedGridColumn92.Caption = "record";
            this.bandedGridColumn92.FieldName = "record";
            this.bandedGridColumn92.MinWidth = 27;
            this.bandedGridColumn92.Name = "bandedGridColumn92";
            this.bandedGridColumn92.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn92.Width = 101;
            // 
            // bandedGridColumn93
            // 
            this.bandedGridColumn93.Caption = "Time Stamp";
            this.bandedGridColumn93.FieldName = "tmstamp";
            this.bandedGridColumn93.MinWidth = 27;
            this.bandedGridColumn93.Name = "bandedGridColumn93";
            this.bandedGridColumn93.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn93.Width = 163;
            // 
            // bandedGridColumn94
            // 
            this.bandedGridColumn94.Caption = "What Week";
            this.bandedGridColumn94.FieldName = "week";
            this.bandedGridColumn94.MinWidth = 25;
            this.bandedGridColumn94.Name = "bandedGridColumn94";
            this.bandedGridColumn94.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn94.Width = 94;
            // 
            // gridView4
            // 
            this.gridView4.GridControl = this.dgv8;
            this.gridView4.Name = "gridView4";
            // 
            // panelOtherTop
            // 
            this.panelOtherTop.Controls.Add(this.label5);
            this.panelOtherTop.Controls.Add(this.pictureBox2);
            this.panelOtherTop.Controls.Add(this.pictureBox3);
            this.panelOtherTop.Controls.Add(this.pictureBox4);
            this.panelOtherTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelOtherTop.Location = new System.Drawing.Point(0, 0);
            this.panelOtherTop.Name = "panelOtherTop";
            this.panelOtherTop.Size = new System.Drawing.Size(192, 46);
            this.panelOtherTop.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(354, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(149, 23);
            this.label5.TabIndex = 132;
            this.label5.Text = "Other Services";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(26, 12);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(34, 27);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 131;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(146, 11);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(36, 28);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 130;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(89, 12);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(36, 28);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 129;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Tag = "Add Site";
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // panelTop
            // 
            this.panelTop.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.panelTop.Controls.Add(this.label4);
            this.panelTop.Controls.Add(this.chkManagerApproved);
            this.panelTop.Controls.Add(this.chkEmployeeApproved);
            this.panelTop.Controls.Add(this.btnDecimal);
            this.panelTop.Controls.Add(this.lblTimeApprovedBy);
            this.panelTop.Controls.Add(this.btnClock);
            this.panelTop.Controls.Add(this.txtCycleNote);
            this.panelTop.Controls.Add(this.lblCycleNote);
            this.panelTop.Controls.Add(this.chkUnapproved);
            this.panelTop.Controls.Add(this.btnAddNextPunch);
            this.panelTop.Controls.Add(this.btnPunchIn1);
            this.panelTop.Controls.Add(this.picEmployee);
            this.panelTop.Controls.Add(this.btnPunchOut5);
            this.panelTop.Controls.Add(this.btnError);
            this.panelTop.Controls.Add(this.btnPunchIn3);
            this.panelTop.Controls.Add(this.btnPunchOut1);
            this.panelTop.Controls.Add(this.btnSpyGlass);
            this.panelTop.Controls.Add(this.btnPunchOut3);
            this.panelTop.Controls.Add(this.btnAddPunch);
            this.panelTop.Controls.Add(this.btnPunchIn5);
            this.panelTop.Controls.Add(this.txtDecemberPTO);
            this.panelTop.Controls.Add(this.btnPunchOut2);
            this.panelTop.Controls.Add(this.label2);
            this.panelTop.Controls.Add(this.btnPunchIn4);
            this.panelTop.Controls.Add(this.txtAvailablePTO);
            this.panelTop.Controls.Add(this.btnPunchOut4);
            this.panelTop.Controls.Add(this.label1);
            this.panelTop.Controls.Add(this.btnPunchIn2);
            this.panelTop.Controls.Add(this.lblTo);
            this.panelTop.Controls.Add(this.dateTimePicker2);
            this.panelTop.Controls.Add(this.DateControl_Backward);
            this.panelTop.Controls.Add(this.DateControl_Forward);
            this.panelTop.Controls.Add(this.dateTimePicker1);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1228, 41);
            this.panelTop.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(346, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 17);
            this.label4.TabIndex = 130;
            this.label4.Text = "label4";
            this.label4.Visible = false;
            // 
            // chkManagerApproved
            // 
            this.chkManagerApproved.AutoSize = true;
            this.chkManagerApproved.Location = new System.Drawing.Point(835, 10);
            this.chkManagerApproved.Name = "chkManagerApproved";
            this.chkManagerApproved.Size = new System.Drawing.Size(146, 21);
            this.chkManagerApproved.TabIndex = 129;
            this.chkManagerApproved.Text = "Manager Approved";
            this.chkManagerApproved.UseVisualStyleBackColor = true;
            this.chkManagerApproved.CheckedChanged += new System.EventHandler(this.chkManagerApproved_CheckedChanged);
            // 
            // chkEmployeeApproved
            // 
            this.chkEmployeeApproved.AutoSize = true;
            this.chkEmployeeApproved.Location = new System.Drawing.Point(664, 10);
            this.chkEmployeeApproved.Name = "chkEmployeeApproved";
            this.chkEmployeeApproved.Size = new System.Drawing.Size(154, 21);
            this.chkEmployeeApproved.TabIndex = 128;
            this.chkEmployeeApproved.Text = "Employee Approved";
            this.chkEmployeeApproved.UseVisualStyleBackColor = true;
            this.chkEmployeeApproved.CheckedChanged += new System.EventHandler(this.chkEmployeeApproved_CheckedChanged);
            // 
            // btnDecimal
            // 
            this.btnDecimal.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.btnDecimal.Appearance.Options.UseBackColor = true;
            this.btnDecimal.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnDecimal.ImageOptions.Image")));
            this.btnDecimal.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleRight;
            this.btnDecimal.Location = new System.Drawing.Point(1567, 10);
            this.btnDecimal.Margin = new System.Windows.Forms.Padding(0);
            this.btnDecimal.Name = "btnDecimal";
            this.btnDecimal.Size = new System.Drawing.Size(106, 36);
            this.btnDecimal.TabIndex = 127;
            this.btnDecimal.Click += new System.EventHandler(this.btnDecimal_Click);
            // 
            // lblTimeApprovedBy
            // 
            this.lblTimeApprovedBy.AutoSize = true;
            this.lblTimeApprovedBy.Location = new System.Drawing.Point(891, 92);
            this.lblTimeApprovedBy.Name = "lblTimeApprovedBy";
            this.lblTimeApprovedBy.Size = new System.Drawing.Size(0, 17);
            this.lblTimeApprovedBy.TabIndex = 125;
            // 
            // btnClock
            // 
            this.btnClock.Appearance.BackColor = System.Drawing.Color.Transparent;
            this.btnClock.Appearance.Options.UseBackColor = true;
            this.btnClock.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnClock.ImageOptions.Image")));
            this.btnClock.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleRight;
            this.btnClock.Location = new System.Drawing.Point(1473, 12);
            this.btnClock.Margin = new System.Windows.Forms.Padding(0);
            this.btnClock.Name = "btnClock";
            this.btnClock.Size = new System.Drawing.Size(40, 34);
            this.btnClock.TabIndex = 126;
            this.btnClock.Click += new System.EventHandler(this.btnClock_Click);
            // 
            // txtCycleNote
            // 
            this.txtCycleNote.Location = new System.Drawing.Point(93, 88);
            this.txtCycleNote.Name = "txtCycleNote";
            this.txtCycleNote.Size = new System.Drawing.Size(805, 24);
            this.txtCycleNote.TabIndex = 123;
            this.txtCycleNote.Leave += new System.EventHandler(this.txtCycleNote_Leave);
            // 
            // lblCycleNote
            // 
            this.lblCycleNote.AutoSize = true;
            this.lblCycleNote.Location = new System.Drawing.Point(11, 92);
            this.lblCycleNote.Name = "lblCycleNote";
            this.lblCycleNote.Size = new System.Drawing.Size(83, 17);
            this.lblCycleNote.TabIndex = 122;
            this.lblCycleNote.Text = "Cycle Note :";
            // 
            // chkUnapproved
            // 
            this.chkUnapproved.AutoSize = true;
            this.chkUnapproved.Location = new System.Drawing.Point(923, 88);
            this.chkUnapproved.Name = "chkUnapproved";
            this.chkUnapproved.Size = new System.Drawing.Size(144, 21);
            this.chkUnapproved.TabIndex = 121;
            this.chkUnapproved.Text = "Show Unapproved";
            this.chkUnapproved.UseVisualStyleBackColor = true;
            this.chkUnapproved.CheckedChanged += new System.EventHandler(this.chkUnapproved_CheckedChanged);
            // 
            // btnAddNextPunch
            // 
            this.btnAddNextPunch.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.btnAddNextPunch.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddNextPunch.Location = new System.Drawing.Point(1035, 41);
            this.btnAddNextPunch.Name = "btnAddNextPunch";
            this.btnAddNextPunch.Size = new System.Drawing.Size(141, 28);
            this.btnAddNextPunch.TabIndex = 120;
            this.btnAddNextPunch.Text = "Add Next Punch";
            this.btnAddNextPunch.UseVisualStyleBackColor = false;
            this.btnAddNextPunch.Click += new System.EventHandler(this.btnAddNextPunch_Click);
            // 
            // btnPunchIn1
            // 
            this.btnPunchIn1.Location = new System.Drawing.Point(453, 130);
            this.btnPunchIn1.Name = "btnPunchIn1";
            this.btnPunchIn1.Size = new System.Drawing.Size(56, 21);
            this.btnPunchIn1.TabIndex = 111;
            this.btnPunchIn1.Text = "Punch";
            this.btnPunchIn1.UseVisualStyleBackColor = true;
            this.btnPunchIn1.Visible = false;
            this.btnPunchIn1.Click += new System.EventHandler(this.btnPunch_Click);
            // 
            // picEmployee
            // 
            this.picEmployee.Location = new System.Drawing.Point(610, 3);
            this.picEmployee.Name = "picEmployee";
            this.picEmployee.Size = new System.Drawing.Size(33, 35);
            this.picEmployee.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picEmployee.TabIndex = 119;
            this.picEmployee.TabStop = false;
            this.picEmployee.Click += new System.EventHandler(this.picEmployee_Click);
            // 
            // btnPunchOut5
            // 
            this.btnPunchOut5.Location = new System.Drawing.Point(1058, 129);
            this.btnPunchOut5.Name = "btnPunchOut5";
            this.btnPunchOut5.Size = new System.Drawing.Size(56, 20);
            this.btnPunchOut5.TabIndex = 117;
            this.btnPunchOut5.Text = "Punch";
            this.btnPunchOut5.UseVisualStyleBackColor = true;
            this.btnPunchOut5.Visible = false;
            this.btnPunchOut5.Click += new System.EventHandler(this.btnPunch_Click);
            // 
            // btnError
            // 
            this.btnError.BackColor = System.Drawing.Color.DarkRed;
            this.btnError.ForeColor = System.Drawing.Color.White;
            this.btnError.Location = new System.Drawing.Point(5, 6);
            this.btnError.Name = "btnError";
            this.btnError.Size = new System.Drawing.Size(70, 28);
            this.btnError.TabIndex = 118;
            this.btnError.Text = "ERROR(s)";
            this.btnError.UseVisualStyleBackColor = false;
            this.btnError.Click += new System.EventHandler(this.btnError_Click);
            // 
            // btnPunchIn3
            // 
            this.btnPunchIn3.Location = new System.Drawing.Point(738, 130);
            this.btnPunchIn3.Name = "btnPunchIn3";
            this.btnPunchIn3.Size = new System.Drawing.Size(56, 21);
            this.btnPunchIn3.TabIndex = 114;
            this.btnPunchIn3.Text = "Punch";
            this.btnPunchIn3.UseVisualStyleBackColor = true;
            this.btnPunchIn3.Visible = false;
            this.btnPunchIn3.Click += new System.EventHandler(this.btnPunch_Click);
            // 
            // btnPunchOut1
            // 
            this.btnPunchOut1.Location = new System.Drawing.Point(515, 130);
            this.btnPunchOut1.Name = "btnPunchOut1";
            this.btnPunchOut1.Size = new System.Drawing.Size(56, 21);
            this.btnPunchOut1.TabIndex = 112;
            this.btnPunchOut1.Text = "Punch";
            this.btnPunchOut1.UseVisualStyleBackColor = true;
            this.btnPunchOut1.Visible = false;
            this.btnPunchOut1.Click += new System.EventHandler(this.btnPunch_Click);
            // 
            // btnSpyGlass
            // 
            this.btnSpyGlass.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnSpyGlass.ImageOptions.Image")));
            this.btnSpyGlass.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleRight;
            this.btnSpyGlass.Location = new System.Drawing.Point(581, 12);
            this.btnSpyGlass.Margin = new System.Windows.Forms.Padding(0);
            this.btnSpyGlass.Name = "btnSpyGlass";
            this.btnSpyGlass.Size = new System.Drawing.Size(27, 20);
            this.btnSpyGlass.TabIndex = 118;
            this.btnSpyGlass.Click += new System.EventHandler(this.btnSpyGlass_Click);
            // 
            // btnPunchOut3
            // 
            this.btnPunchOut3.Location = new System.Drawing.Point(805, 131);
            this.btnPunchOut3.Name = "btnPunchOut3";
            this.btnPunchOut3.Size = new System.Drawing.Size(56, 20);
            this.btnPunchOut3.TabIndex = 115;
            this.btnPunchOut3.Text = "Punch";
            this.btnPunchOut3.UseVisualStyleBackColor = true;
            this.btnPunchOut3.Visible = false;
            this.btnPunchOut3.Click += new System.EventHandler(this.btnPunch_Click);
            // 
            // btnAddPunch
            // 
            this.btnAddPunch.Location = new System.Drawing.Point(1008, 7);
            this.btnAddPunch.Name = "btnAddPunch";
            this.btnAddPunch.Size = new System.Drawing.Size(121, 28);
            this.btnAddPunch.TabIndex = 115;
            this.btnAddPunch.Text = "Add Punch Combo";
            this.btnAddPunch.UseVisualStyleBackColor = true;
            this.btnAddPunch.Click += new System.EventHandler(this.btnAddPunch_Click);
            // 
            // btnPunchIn5
            // 
            this.btnPunchIn5.Location = new System.Drawing.Point(997, 129);
            this.btnPunchIn5.Name = "btnPunchIn5";
            this.btnPunchIn5.Size = new System.Drawing.Size(56, 21);
            this.btnPunchIn5.TabIndex = 116;
            this.btnPunchIn5.Text = "Punch";
            this.btnPunchIn5.UseVisualStyleBackColor = true;
            this.btnPunchIn5.Visible = false;
            this.btnPunchIn5.Click += new System.EventHandler(this.btnPunch_Click);
            // 
            // txtDecemberPTO
            // 
            this.txtDecemberPTO.Location = new System.Drawing.Point(965, 43);
            this.txtDecemberPTO.Name = "txtDecemberPTO";
            this.txtDecemberPTO.Size = new System.Drawing.Size(49, 24);
            this.txtDecemberPTO.TabIndex = 114;
            // 
            // btnPunchOut2
            // 
            this.btnPunchOut2.Location = new System.Drawing.Point(664, 131);
            this.btnPunchOut2.Name = "btnPunchOut2";
            this.btnPunchOut2.Size = new System.Drawing.Size(56, 20);
            this.btnPunchOut2.TabIndex = 114;
            this.btnPunchOut2.Text = "Punch";
            this.btnPunchOut2.UseVisualStyleBackColor = true;
            this.btnPunchOut2.Visible = false;
            this.btnPunchOut2.Click += new System.EventHandler(this.btnPunch_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(855, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 17);
            this.label2.TabIndex = 113;
            this.label2.Text = "December PTO :";
            // 
            // btnPunchIn4
            // 
            this.btnPunchIn4.Location = new System.Drawing.Point(869, 130);
            this.btnPunchIn4.Name = "btnPunchIn4";
            this.btnPunchIn4.Size = new System.Drawing.Size(56, 21);
            this.btnPunchIn4.TabIndex = 115;
            this.btnPunchIn4.Text = "Punch";
            this.btnPunchIn4.UseVisualStyleBackColor = true;
            this.btnPunchIn4.Visible = false;
            this.btnPunchIn4.Click += new System.EventHandler(this.btnPunch_Click);
            // 
            // txtAvailablePTO
            // 
            this.txtAvailablePTO.Location = new System.Drawing.Point(787, 43);
            this.txtAvailablePTO.Name = "txtAvailablePTO";
            this.txtAvailablePTO.Size = new System.Drawing.Size(49, 24);
            this.txtAvailablePTO.TabIndex = 112;
            // 
            // btnPunchOut4
            // 
            this.btnPunchOut4.Location = new System.Drawing.Point(931, 130);
            this.btnPunchOut4.Name = "btnPunchOut4";
            this.btnPunchOut4.Size = new System.Drawing.Size(56, 20);
            this.btnPunchOut4.TabIndex = 116;
            this.btnPunchOut4.Text = "Punch";
            this.btnPunchOut4.UseVisualStyleBackColor = true;
            this.btnPunchOut4.Visible = false;
            this.btnPunchOut4.Click += new System.EventHandler(this.btnPunch_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(683, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 17);
            this.label1.TabIndex = 111;
            this.label1.Text = "Available PTO :";
            // 
            // btnPunchIn2
            // 
            this.btnPunchIn2.Location = new System.Drawing.Point(587, 130);
            this.btnPunchIn2.Name = "btnPunchIn2";
            this.btnPunchIn2.Size = new System.Drawing.Size(56, 21);
            this.btnPunchIn2.TabIndex = 113;
            this.btnPunchIn2.Text = "Punch";
            this.btnPunchIn2.UseVisualStyleBackColor = true;
            this.btnPunchIn2.Visible = false;
            this.btnPunchIn2.Click += new System.EventHandler(this.btnPunch_Click);
            // 
            // lblTo
            // 
            this.lblTo.Location = new System.Drawing.Point(311, 14);
            this.lblTo.Name = "lblTo";
            this.lblTo.Size = new System.Drawing.Size(21, 16);
            this.lblTo.TabIndex = 110;
            this.lblTo.Text = "-to-";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(334, 10);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(201, 24);
            this.dateTimePicker2.TabIndex = 109;
            // 
            // DateControl_Backward
            // 
            this.DateControl_Backward.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("DateControl_Backward.ImageOptions.Image")));
            this.DateControl_Backward.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleRight;
            this.DateControl_Backward.Location = new System.Drawing.Point(77, 11);
            this.DateControl_Backward.Margin = new System.Windows.Forms.Padding(0);
            this.DateControl_Backward.Name = "DateControl_Backward";
            this.DateControl_Backward.Size = new System.Drawing.Size(26, 20);
            this.DateControl_Backward.TabIndex = 108;
            this.DateControl_Backward.Click += new System.EventHandler(this.DateControl_Backward_Click);
            // 
            // DateControl_Forward
            // 
            this.DateControl_Forward.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("DateControl_Forward.ImageOptions.Image")));
            this.DateControl_Forward.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleRight;
            this.DateControl_Forward.Location = new System.Drawing.Point(539, 11);
            this.DateControl_Forward.Margin = new System.Windows.Forms.Padding(0);
            this.DateControl_Forward.Name = "DateControl_Forward";
            this.DateControl_Forward.Size = new System.Drawing.Size(26, 21);
            this.DateControl_Forward.TabIndex = 107;
            this.DateControl_Forward.Click += new System.EventHandler(this.DateControl_Forward_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(107, 10);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(201, 24);
            this.dateTimePicker1.TabIndex = 106;
            this.dateTimePicker1.TabStop = false;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // printingSystem1
            // 
            this.printingSystem1.Links.AddRange(new object[] {
            this.printableComponentLink1});
            // 
            // printableComponentLink1
            // 
            this.printableComponentLink1.Component = this.dgv;
            this.printableComponentLink1.PrintingSystemBase = this.printingSystem1;
            this.printableComponentLink1.CreateDetailHeaderArea += new DevExpress.XtraPrinting.CreateAreaEventHandler(this.printableComponentLink1_CreateDetailHeaderArea);
            this.printableComponentLink1.CreateMarginalHeaderArea += new DevExpress.XtraPrinting.CreateAreaEventHandler(this.printableComponentLink1_CreateMarginalHeaderArea);
            this.printableComponentLink1.BeforeCreateAreas += new System.EventHandler(this.printableComponentLink1_BeforeCreateAreas);
            this.printableComponentLink1.AfterCreateAreas += new System.EventHandler(this.printableComponentLink1_AfterCreateAreas);
            // 
            // timer1
            // 
            this.timer1.Interval = 15000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblPostingAsOf
            // 
            this.lblPostingAsOf.AutoSize = true;
            this.lblPostingAsOf.BackColor = System.Drawing.SystemColors.Control;
            this.lblPostingAsOf.Location = new System.Drawing.Point(784, 8);
            this.lblPostingAsOf.Name = "lblPostingAsOf";
            this.lblPostingAsOf.Size = new System.Drawing.Size(91, 17);
            this.lblPostingAsOf.TabIndex = 126;
            this.lblPostingAsOf.Text = "Last Posting :";
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuClearRow,
            this.clearCellToolStripMenuItem});
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(146, 52);
            // 
            // menuClearRow
            // 
            this.menuClearRow.Name = "menuClearRow";
            this.menuClearRow.Size = new System.Drawing.Size(145, 24);
            this.menuClearRow.Text = "Clear Row";
            this.menuClearRow.Click += new System.EventHandler(this.menuClearRow_Click);
            // 
            // clearCellToolStripMenuItem
            // 
            this.clearCellToolStripMenuItem.Name = "clearCellToolStripMenuItem";
            this.clearCellToolStripMenuItem.Size = new System.Drawing.Size(145, 24);
            this.clearCellToolStripMenuItem.Text = "Clear Cell";
            this.clearCellToolStripMenuItem.Click += new System.EventHandler(this.clearCellToolStripMenuItem_Click);
            // 
            // contextMenuStrip4
            // 
            this.contextMenuStrip4.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip4.Name = "contextMenuStrip4";
            this.contextMenuStrip4.Size = new System.Drawing.Size(61, 4);
            // 
            // TimeClock
            // 
            this.Appearance.BackColor = System.Drawing.Color.White;
            this.Appearance.Options.UseBackColor = true;
            this.Appearance.Options.UseFont = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1228, 667);
            this.Controls.Add(this.lblPostingAsOf);
            this.Controls.Add(this.panelAll);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "TimeClock";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TimeClock";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TimeClock_FormClosing);
            this.Load += new System.EventHandler(this.TimeClock_Load);
            this.panelAll.ResumeLayout(false);
            this.panelBottom.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabMain.ResumeLayout(false);
            this.panelMainAll.ResumeLayout(false);
            this.panelMainTop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit1)).EndInit();
            this.tabReport.ResumeLayout(false);
            this.panelReportAll.ResumeLayout(false);
            this.panelReportBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit2)).EndInit();
            this.panelReportTop.ResumeLayout(false);
            this.tabPTO.ResumeLayout(false);
            this.panelPTOAll.ResumeLayout(false);
            this.panelPTOBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            this.tabDetail.ResumeLayout(false);
            this.panelDetailAll.ResumeLayout(false);
            this.panelDetailBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).EndInit();
            this.panelDetailTop.ResumeLayout(false);
            this.panelDetailTop.PerformLayout();
            this.tabMyTimeOff.ResumeLayout(false);
            this.panelTimeOffAll.ResumeLayout(false);
            this.panelTimeOffBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            this.panelTimeOffTop.ResumeLayout(false);
            this.panelTimeOffTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.tabTimeOffProc.ResumeLayout(false);
            this.panelTimeOffProcAll.ResumeLayout(false);
            this.panelTimeOffProcBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit5)).EndInit();
            this.panelTimeOffProcTop.ResumeLayout(false);
            this.panelTimeOffProcTop.PerformLayout();
            this.tabContractLabor.ResumeLayout(false);
            this.panelContractAll.ResumeLayout(false);
            this.panelContractBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.panelContractTop.ResumeLayout(false);
            this.panelContractTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.tabPageOther.ResumeLayout(false);
            this.panelOtherAll.ResumeLayout(false);
            this.panelOtherBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).EndInit();
            this.panelOtherTop.ResumeLayout(false);
            this.panelOtherTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picEmployee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.printingSystem1)).EndInit();
            this.contextMenuStrip3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelAll;
        private System.Windows.Forms.Panel panelBottom;
        private DevExpress.XtraGrid.GridControl dgv;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn gridColumn1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn gridColumn2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn gridColumn5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn gridColumn3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn gridColumn4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn gridColumn6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn gridColumn7;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.Bar bar1;
        private DevExpress.XtraBars.BarSubItem barSubItem1;
        private DevExpress.XtraBars.BarSubItem barReport;
        private DevExpress.XtraBars.BarSubItem barSubItem7;
        private DevExpress.XtraBars.BarButtonItem menuItemPrintPreview;
        private DevExpress.XtraBars.BarButtonItem menuReportPrintPreview;
        private DevExpress.XtraBars.BarButtonItem menuItemPrint;
        private DevExpress.XtraBars.BarButtonItem menuReportPrint;
        private DevExpress.XtraBars.BarButtonItem menuItemExit;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarSubItem barSubItem2;
        private DevExpress.XtraBars.BarButtonItem menuItemSkins;
        private DevExpress.XtraBars.BarSubItem barSubItem3;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarSubItem barSubItem4;
        private DevExpress.XtraBars.BarButtonItem menuImportPayroll;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.BarCheckItem menuItemFindPanel;
        private DevExpress.XtraBars.BarSubItem barSubItem5;
        private DevExpress.XtraBars.BarButtonItem menuItemLoadContributions;
        private DevExpress.XtraBars.BarButtonItem menuItemLoadMonthlyPSFiles;
        private DevExpress.XtraBars.BarButtonItem menuItemLoadDepartInfo;
        private DevExpress.XtraBars.BarButtonItem menuItemCalcDiff;
        private DevExpress.XtraBars.BarButtonItem menuItemCalcDoctorProd;
        private DevExpress.XtraBars.BarButtonItem menuItemLoadAccruals;
        private DevExpress.XtraBars.BarButtonItem menuItemCalcTotals;
        private DevExpress.XtraBars.BarSubItem barSubItem6;
        private DevExpress.XtraBars.BarCheckItem menuChkInvestOpt;
        private DevExpress.XtraBars.BarCheckItem menuChkAccrual;
        private DevExpress.XtraBars.BarCheckItem menuChkDepartment;
        private DevExpress.XtraBars.BarCheckItem menuChkContributions;
        private DevExpress.XtraBars.BarCheckItem menuChkPayroll;
        private DevExpress.XtraBars.BarCheckItem menuChkPsDetail;
        private DevExpress.XtraBars.BarCheckItem menuChkDifferences;
        private DevExpress.XtraBars.BarButtonItem menuImportRates;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraBars.BarCheckItem menuChkSalary;
        private DevExpress.XtraBars.BarCheckItem menuChkYearend;
        private DevExpress.XtraBars.BarButtonItem menuItemYearend;
        private DevExpress.XtraBars.BarButtonItem menuItemDoctorDistribution;
        private DevExpress.XtraBars.BarButtonItem btnDailySummary;
        private DevExpress.XtraBars.BarSubItem menuItemView;
        private DevExpress.XtraBars.BarButtonItem menuItemPrimary;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem btnProcedureData;
        private DevExpress.XtraBars.BarButtonItem menuItemOverhead;
        private DevExpress.XtraBars.BarSubItem barSubItem8;
        private DevExpress.XtraBars.BarButtonItem menuItemEditOverhead;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn7;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn9;
        private DevExpress.XtraPrinting.PrintingSystem printingSystem1;
        private DevExpress.XtraPrinting.PrintableComponentLink printableComponentLink1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn11;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraBars.BarSubItem menuPayPeriods;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn12;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn13;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn14;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn15;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn16;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn17;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn18;
        private DevExpress.XtraBars.BarSubItem menuSupervisors;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn19;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn20;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn21;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn22;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn23;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn24;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem approveAllToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn25;
        private DevExpress.XtraBars.BarSubItem menuOptions;
        private DevExpress.XtraBars.BarButtonItem menuAddHolidays;
        private DevExpress.XtraBars.BarSubItem barSubItem9;
        private DevExpress.XtraBars.BarButtonItem menuEmployeeList;
        private DevExpress.XtraBars.BarSubItem menuFormats;
        private DevExpress.XtraBars.BarButtonItem menuSkins;
        private DevExpress.XtraBars.BarButtonItem menuDetailReport;
        private DevExpress.XtraBars.BarButtonItem menuEditPreferences;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn26;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabMain;
        private System.Windows.Forms.TabPage tabPTO;
        private DevExpress.XtraGrid.GridControl dgv2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn18;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn19;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn20;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn21;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn22;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn23;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn24;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn25;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn26;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn27;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn28;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn29;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn30;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn31;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn32;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn33;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn34;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn52;
        private System.Windows.Forms.Panel panelPTOAll;
        private System.Windows.Forms.Panel panelPTOBottom;
        private System.Windows.Forms.Panel panelPTOTop;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn27;
        private DevExpress.XtraBars.BarButtonItem menuSetPassword;
        private System.Windows.Forms.TabPage tabReport;
        private System.Windows.Forms.Panel panelReportAll;
        private System.Windows.Forms.Panel panelReportBottom;
        private System.Windows.Forms.Panel panelReportTop;
        private DevExpress.XtraEditors.SimpleButton btnGenerateReport;
        private DevExpress.XtraGrid.GridControl dgv4;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn28;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn29;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn30;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn31;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn32;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn33;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn34;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn59;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn35;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn36;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn37;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn38;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn39;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn60;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn40;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn51;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn52;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn53;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn54;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn55;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn56;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn57;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn58;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn61;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn42;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn41;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn43;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn44;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn45;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn46;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand1;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand2;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand3;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand4;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand5;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand6;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand7;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand8;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand9;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn47;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand11;
        private DevExpress.XtraBars.BarButtonItem menuEditHourStatus;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem swapPTODockedToolStripMenuItem;
        private System.Windows.Forms.TabPage tabDetail;
        private System.Windows.Forms.Panel panelDetailAll;
        private System.Windows.Forms.Panel panelDetailBottom;
        private System.Windows.Forms.Panel panelDetailTop;
        private DevExpress.XtraGrid.GridControl dgv3;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn55;
        private System.Windows.Forms.RichTextBox rtb;
        private System.Windows.Forms.Button btnDoDetail;
        private System.Windows.Forms.CheckBox chkOddPunches;
        private System.Windows.Forms.CheckBox chkUnder80;
        private System.Windows.Forms.CheckBox chkErrors;
        private System.Windows.Forms.CheckBox chkAll;
        private DevExpress.XtraBars.BarButtonItem menuEditTimeSheetHelp;
        private DevExpress.XtraBars.BarSubItem menuHelp;
        private DevExpress.XtraBars.BarButtonItem menuClockInOut;
        private DevExpress.XtraBars.BarButtonItem menuHelpEmployeeList;
        private DevExpress.XtraBars.BarSubItem menuHelpSalary;
        private DevExpress.XtraBars.BarButtonItem menuSalaryPunchIn;
        private DevExpress.XtraBars.BarButtonItem menuSalaryEmployeeList;
        private DevExpress.XtraBars.BarButtonItem menuEditHelp;
        private DevExpress.XtraBars.BarButtonItem menuHelpItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn48;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblPostingAsOf;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.ToolStripMenuItem showPTOHistoryToolStripMenuItem1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip4;
        private DevExpress.XtraBars.BarSubItem menuTimeOff;
        private DevExpress.XtraBars.BarButtonItem barButtonItem6;
        private System.Windows.Forms.TabPage tabMyTimeOff;
        private System.Windows.Forms.Panel panelTimeOffAll;
        private System.Windows.Forms.Panel panelTimeOffBottom;
        private DevExpress.XtraGrid.GridControl dgv5;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn37;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn16;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn35;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn36;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn48;
        private System.Windows.Forms.Panel panelTimeOffTop;
        private System.Windows.Forms.TabPage tabTimeOffProc;
        private System.Windows.Forms.Button btnRequestTimeOff;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn38;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn41;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn40;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn39;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn42;
        private System.Windows.Forms.Panel panelTimeOffProcAll;
        private System.Windows.Forms.Panel panelTimeOffProcBottom;
        private DevExpress.XtraGrid.GridControl dgv6;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn43;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn44;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn45;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn46;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn47;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn49;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn50;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn51;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn53;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn54;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn56;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn58;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn59;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn60;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn61;
        private System.Windows.Forms.Panel panelTimeOffProcTop;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbMyProc;
        private DevExpress.XtraBars.BarButtonItem menuAddNewEmployee;
        private DevExpress.XtraBars.BarButtonItem menuExportPTO;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn49;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn50;
        private System.Windows.Forms.ToolStripMenuItem editEmployeeToolStripMenuItem;
        private System.Windows.Forms.TabPage tabContractLabor;
        private System.Windows.Forms.Panel panelContractAll;
        private System.Windows.Forms.Panel panelContractBottom;
        private System.Windows.Forms.Panel panelContractTop;
        private DevExpress.XtraGrid.GridControl dgv7;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain7;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn70;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn71;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn73;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn64;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private System.Windows.Forms.Button btnCalendar;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn68;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand12;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn67;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn69;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn72;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn74;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn75;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn76;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn77;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem7;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn62;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn63;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn65;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn66;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn78;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand dateBand;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand totalBand;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand bandPunch1;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand bandPunch2;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand bandPunch3;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand bandPunch4;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand bandPunch5;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand bandSalary;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand bandholiday;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand bandPTO;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridNotes;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn79;
        private System.Windows.Forms.Panel panelMainAll;
        private System.Windows.Forms.Panel panelMainTop;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.CheckBox chkManagerApproved;
        private System.Windows.Forms.CheckBox chkEmployeeApproved;
        private DevExpress.XtraEditors.SimpleButton btnDecimal;
        private System.Windows.Forms.Label lblTimeApprovedBy;
        private DevExpress.XtraEditors.SimpleButton btnClock;
        private System.Windows.Forms.TextBox txtCycleNote;
        private System.Windows.Forms.Label lblCycleNote;
        private System.Windows.Forms.CheckBox chkUnapproved;
        private System.Windows.Forms.Button btnAddNextPunch;
        private System.Windows.Forms.Button btnPunchIn1;
        private System.Windows.Forms.PictureBox picEmployee;
        private System.Windows.Forms.Button btnPunchOut5;
        private System.Windows.Forms.Button btnError;
        private System.Windows.Forms.Button btnPunchIn3;
        private System.Windows.Forms.Button btnPunchOut1;
        private DevExpress.XtraEditors.SimpleButton btnSpyGlass;
        private System.Windows.Forms.Button btnPunchOut3;
        private System.Windows.Forms.Button btnAddPunch;
        private System.Windows.Forms.Button btnPunchIn5;
        private System.Windows.Forms.TextBox txtDecemberPTO;
        private System.Windows.Forms.Button btnPunchOut2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnPunchIn4;
        private System.Windows.Forms.TextBox txtAvailablePTO;
        private System.Windows.Forms.Button btnPunchOut4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPunchIn2;
        private DevExpress.XtraEditors.LabelControl lblTo;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private DevExpress.XtraEditors.SimpleButton DateControl_Backward;
        private DevExpress.XtraEditors.SimpleButton DateControl_Forward;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn80;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabPage tabPageOther;
        private System.Windows.Forms.Panel panelOtherAll;
        private System.Windows.Forms.Panel panelOtherBottom;
        private DevExpress.XtraGrid.GridControl dgv8;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain8;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand13;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn81;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn82;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn83;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn84;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn85;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn86;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn87;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn88;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn89;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn90;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn91;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn92;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn93;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn94;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView4;
        private System.Windows.Forms.Panel panelOtherTop;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn95;
        private System.Windows.Forms.ToolStripMenuItem menuClearRow;
        private DevExpress.XtraBars.BarButtonItem barButtonPrintAll;
        private DevExpress.XtraBars.BarSubItem barSubItem10;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.ToolStripMenuItem clearCellToolStripMenuItem;
        private System.Windows.Forms.Button btnSaveVacation;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn17;
        private System.Windows.Forms.TextBox txtPTOtaken;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDecember;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtHireDate;
        private System.Windows.Forms.Label label9;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
    }
}