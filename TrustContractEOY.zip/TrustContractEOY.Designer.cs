﻿namespace SMFS
{
    partial class TrustContractEOY
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrustContractEOY));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.screenOptionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lockScreenFormatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unlockScreenFormatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelAll = new System.Windows.Forms.Panel();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabDetail = new System.Windows.Forms.TabPage();
            this.dgv = new DevExpress.XtraGrid.GridControl();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.gridMain = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand5 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn1 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn6 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn4 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn19 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn12 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn3 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn7 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn2 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn179 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn8 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn142 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn9 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn10 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn102 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn95 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn97 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn96 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn11 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn15 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn5 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn14 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn13 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn143 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn186 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn187 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn188 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn189 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn190 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn16 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn17 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox3 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.tabSummary = new System.Windows.Forms.TabPage();
            this.dgv9 = new DevExpress.XtraGrid.GridControl();
            this.gridMain9 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand9 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn226 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn227 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn228 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn229 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn230 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn241 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn231 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn232 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn233 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn234 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn235 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn236 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn237 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn238 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn239 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn240 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox9 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.tabPrePostRiles = new System.Windows.Forms.TabPage();
            this.dgv2 = new DevExpress.XtraGrid.GridControl();
            this.gridMain2 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand1 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn21 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn243 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn245 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn244 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn246 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn247 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn22 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn98 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn144 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn23 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn242 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn99 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn101 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn103 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn248 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn249 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn24 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn100 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn191 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn193 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn194 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn192 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn195 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.tabHU = new System.Windows.Forms.TabPage();
            this.dgv3 = new DevExpress.XtraGrid.GridControl();
            this.gridMain3 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand2 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn18 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn20 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn25 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn26 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn27 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn28 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn29 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn30 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn31 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn32 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn33 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn34 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn35 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn36 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn37 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn38 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn39 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn40 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn126 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn127 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn128 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn129 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn145 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn146 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn180 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn196 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn197 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn198 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn199 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn200 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox2 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.tabJPN = new System.Windows.Forms.TabPage();
            this.dgv4 = new DevExpress.XtraGrid.GridControl();
            this.gridMain4 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand3 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn41 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn42 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn43 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn44 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn45 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn46 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn47 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn48 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn49 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn50 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn51 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn52 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn53 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn54 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn55 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn56 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn57 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn58 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn130 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn131 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn132 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn133 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn147 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn148 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn181 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn201 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn202 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn203 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn204 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn205 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox4 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.tabNMOC = new System.Windows.Forms.TabPage();
            this.dgv5 = new DevExpress.XtraGrid.GridControl();
            this.gridMain5 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand4 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn59 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn60 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn61 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn62 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn63 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn64 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn65 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn66 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn67 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn68 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn69 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn70 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn71 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn72 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn73 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn74 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn75 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn76 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn134 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn135 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn136 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn137 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn149 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn150 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn182 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn206 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn207 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn208 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn209 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn210 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox5 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.tabCem = new System.Windows.Forms.TabPage();
            this.dgv6 = new DevExpress.XtraGrid.GridControl();
            this.gridMain6 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand6 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn77 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn78 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn79 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn80 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn81 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn82 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn83 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn84 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn85 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn86 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn87 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn88 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn89 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn90 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn91 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn92 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn93 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn94 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn138 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn139 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn140 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn141 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn151 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn152 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn183 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn211 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn212 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn213 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn214 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn215 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox6 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.tabAFA = new System.Windows.Forms.TabPage();
            this.dgv8 = new DevExpress.XtraGrid.GridControl();
            this.gridMain8 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand8 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn155 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn156 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn157 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn158 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn159 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn160 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn161 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn162 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn163 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn164 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn165 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn166 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn167 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn168 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn169 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn170 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn171 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn172 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn173 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn174 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn175 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn176 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn177 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn178 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn184 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn216 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn217 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn218 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn219 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn220 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox8 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.tabNoContract = new System.Windows.Forms.TabPage();
            this.dgv7 = new DevExpress.XtraGrid.GridControl();
            this.gridMain7 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand7 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn104 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn105 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn106 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn107 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn108 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn109 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn110 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn111 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn112 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn113 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn114 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn115 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn116 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn117 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn118 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn119 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn120 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn121 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn122 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn123 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn124 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn125 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn153 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn154 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn185 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn221 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn222 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn223 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn224 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn225 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox7 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.panelTop = new System.Windows.Forms.Panel();
            this.chkRestoreDetail = new System.Windows.Forms.CheckBox();
            this.cmbSelectColumns = new System.Windows.Forms.ComboBox();
            this.btnSelectColumns = new System.Windows.Forms.Button();
            this.chkIncludeSMFS = new System.Windows.Forms.CheckBox();
            this.chkCollapes = new System.Windows.Forms.CheckBox();
            this.chkPageBreaks = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chkComboLocNames = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            this.btnRun = new System.Windows.Forms.Button();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.btnRight = new System.Windows.Forms.Button();
            this.btnLeft = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.chkIncludeRiles = new System.Windows.Forms.CheckBox();
            this.chkActiveOnly = new System.Windows.Forms.CheckBox();
            this.menuStrip1.SuspendLayout();
            this.panelAll.SuspendLayout();
            this.panelBottom.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabDetail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox3)).BeginInit();
            this.tabSummary.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox9)).BeginInit();
            this.tabPrePostRiles.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            this.tabHU.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).BeginInit();
            this.tabJPN.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox4)).BeginInit();
            this.tabNMOC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox5)).BeginInit();
            this.tabCem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox6)).BeginInit();
            this.tabAFA.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox8)).BeginInit();
            this.tabNoContract.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox7)).BeginInit();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboLocNames.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.screenOptionsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1808, 30);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 26);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printPreviewToolStripMenuItem,
            this.printToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(122, 26);
            this.toolStripMenuItem1.Text = "Print";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printPreviewToolStripMenuItem.Text = "Print Preview";
            this.printPreviewToolStripMenuItem.Click += new System.EventHandler(this.printPreviewToolStripMenuItem_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // screenOptionsToolStripMenuItem
            // 
            this.screenOptionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lockScreenFormatToolStripMenuItem,
            this.unlockScreenFormatToolStripMenuItem});
            this.screenOptionsToolStripMenuItem.Name = "screenOptionsToolStripMenuItem";
            this.screenOptionsToolStripMenuItem.Size = new System.Drawing.Size(123, 26);
            this.screenOptionsToolStripMenuItem.Text = "Screen Options";
            // 
            // lockScreenFormatToolStripMenuItem
            // 
            this.lockScreenFormatToolStripMenuItem.Name = "lockScreenFormatToolStripMenuItem";
            this.lockScreenFormatToolStripMenuItem.Size = new System.Drawing.Size(236, 26);
            this.lockScreenFormatToolStripMenuItem.Text = "Lock Screen Format";
            this.lockScreenFormatToolStripMenuItem.Click += new System.EventHandler(this.lockScreenFormatToolStripMenuItem_Click);
            // 
            // unlockScreenFormatToolStripMenuItem
            // 
            this.unlockScreenFormatToolStripMenuItem.Name = "unlockScreenFormatToolStripMenuItem";
            this.unlockScreenFormatToolStripMenuItem.Size = new System.Drawing.Size(236, 26);
            this.unlockScreenFormatToolStripMenuItem.Text = "Unlock Screen Format";
            this.unlockScreenFormatToolStripMenuItem.Click += new System.EventHandler(this.unlockScreenFormatToolStripMenuItem_Click);
            // 
            // panelAll
            // 
            this.panelAll.Controls.Add(this.panelBottom);
            this.panelAll.Controls.Add(this.panelTop);
            this.panelAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAll.Location = new System.Drawing.Point(0, 30);
            this.panelAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelAll.Name = "panelAll";
            this.panelAll.Size = new System.Drawing.Size(1808, 539);
            this.panelAll.TabIndex = 6;
            // 
            // panelBottom
            // 
            this.panelBottom.Controls.Add(this.tabControl1);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBottom.Location = new System.Drawing.Point(0, 78);
            this.panelBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(1808, 461);
            this.panelBottom.TabIndex = 8;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabDetail);
            this.tabControl1.Controls.Add(this.tabSummary);
            this.tabControl1.Controls.Add(this.tabPrePostRiles);
            this.tabControl1.Controls.Add(this.tabHU);
            this.tabControl1.Controls.Add(this.tabJPN);
            this.tabControl1.Controls.Add(this.tabNMOC);
            this.tabControl1.Controls.Add(this.tabCem);
            this.tabControl1.Controls.Add(this.tabAFA);
            this.tabControl1.Controls.Add(this.tabNoContract);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1808, 461);
            this.tabControl1.TabIndex = 5;
            // 
            // tabDetail
            // 
            this.tabDetail.Controls.Add(this.dgv);
            this.tabDetail.Location = new System.Drawing.Point(4, 25);
            this.tabDetail.Name = "tabDetail";
            this.tabDetail.Padding = new System.Windows.Forms.Padding(3);
            this.tabDetail.Size = new System.Drawing.Size(1800, 432);
            this.tabDetail.TabIndex = 0;
            this.tabDetail.Text = "Detail";
            this.tabDetail.UseVisualStyleBackColor = true;
            // 
            // dgv
            // 
            this.dgv.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv.Location = new System.Drawing.Point(3, 3);
            this.dgv.MainView = this.gridMain;
            this.dgv.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv.Name = "dgv";
            this.dgv.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox3});
            this.dgv.Size = new System.Drawing.Size(1794, 426);
            this.dgv.TabIndex = 4;
            this.dgv.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain});
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // gridMain
            // 
            this.gridMain.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain.Appearance.EvenRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.Options.UseBorderColor = true;
            this.gridMain.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.FilterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.gridMain.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.GroupPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(215)))));
            this.gridMain.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain.Appearance.HorzLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain.Appearance.HorzLine.Options.UseBorderColor = true;
            this.gridMain.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain.Appearance.OddRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain.Appearance.OddRow.Options.UseBorderColor = true;
            this.gridMain.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(240)))));
            this.gridMain.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain.Appearance.Preview.Options.UseFont = true;
            this.gridMain.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.Row.Options.UseBackColor = true;
            this.gridMain.Appearance.Row.Options.UseForeColor = true;
            this.gridMain.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(201)))), ((int)(((byte)(207)))));
            this.gridMain.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain.Appearance.VertLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain.Appearance.VertLine.Options.UseBorderColor = true;
            this.gridMain.AppearancePrint.GroupRow.Font = new System.Drawing.Font("Tahoma", 7.8F);
            this.gridMain.AppearancePrint.GroupRow.Options.UseFont = true;
            this.gridMain.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand5});
            this.gridMain.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn1,
            this.bandedGridColumn7,
            this.bandedGridColumn6,
            this.bandedGridColumn4,
            this.bandedGridColumn12,
            this.bandedGridColumn3,
            this.bandedGridColumn2,
            this.bandedGridColumn8,
            this.bandedGridColumn9,
            this.bandedGridColumn11,
            this.bandedGridColumn5,
            this.bandedGridColumn14,
            this.bandedGridColumn13,
            this.bandedGridColumn15,
            this.bandedGridColumn16,
            this.bandedGridColumn17,
            this.bandedGridColumn19,
            this.bandedGridColumn10,
            this.bandedGridColumn95,
            this.bandedGridColumn96,
            this.bandedGridColumn97,
            this.bandedGridColumn102,
            this.bandedGridColumn142,
            this.bandedGridColumn143,
            this.bandedGridColumn179,
            this.bandedGridColumn186,
            this.bandedGridColumn187,
            this.bandedGridColumn188,
            this.bandedGridColumn189,
            this.bandedGridColumn190});
            this.gridMain.DetailHeight = 431;
            this.gridMain.GridControl = this.dgv;
            this.gridMain.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Custom, "downpayment", this.bandedGridColumn2, "", "3")});
            this.gridMain.Name = "gridMain";
            this.gridMain.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain.OptionsPrint.PrintBandHeader = false;
            this.gridMain.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain.OptionsView.ShowFooter = true;
            this.gridMain.OptionsView.ShowGroupPanel = false;
            this.gridMain.PaintStyleName = "Flat";
            this.gridMain.BeforePrintRow += new DevExpress.XtraGrid.Views.Base.BeforePrintRowEventHandler(this.gridMain_BeforePrintRow);
            this.gridMain.AfterPrintRow += new DevExpress.XtraGrid.Views.Base.AfterPrintRowEventHandler(this.gridMain_AfterPrintRow);
            this.gridMain.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMain_CustomDrawCell);
            this.gridMain.RowCellStyle += new DevExpress.XtraGrid.Views.Grid.RowCellStyleEventHandler(this.gridMain_RowCellStyle);
            this.gridMain.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.gridMain_CustomSummaryCalculate);
            this.gridMain.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMain_CellValueChanged);
            this.gridMain.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMain_CustomRowFilter);
            this.gridMain.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain_CustomColumnDisplayText);
            this.gridMain.DoubleClick += new System.EventHandler(this.gMain_DoubleClick);
            // 
            // gridBand5
            // 
            this.gridBand5.Columns.Add(this.bandedGridColumn1);
            this.gridBand5.Columns.Add(this.bandedGridColumn6);
            this.gridBand5.Columns.Add(this.bandedGridColumn4);
            this.gridBand5.Columns.Add(this.bandedGridColumn19);
            this.gridBand5.Columns.Add(this.bandedGridColumn12);
            this.gridBand5.Columns.Add(this.bandedGridColumn3);
            this.gridBand5.Columns.Add(this.bandedGridColumn7);
            this.gridBand5.Columns.Add(this.bandedGridColumn2);
            this.gridBand5.Columns.Add(this.bandedGridColumn179);
            this.gridBand5.Columns.Add(this.bandedGridColumn8);
            this.gridBand5.Columns.Add(this.bandedGridColumn142);
            this.gridBand5.Columns.Add(this.bandedGridColumn9);
            this.gridBand5.Columns.Add(this.bandedGridColumn10);
            this.gridBand5.Columns.Add(this.bandedGridColumn102);
            this.gridBand5.Columns.Add(this.bandedGridColumn95);
            this.gridBand5.Columns.Add(this.bandedGridColumn97);
            this.gridBand5.Columns.Add(this.bandedGridColumn96);
            this.gridBand5.Columns.Add(this.bandedGridColumn11);
            this.gridBand5.Columns.Add(this.bandedGridColumn15);
            this.gridBand5.Columns.Add(this.bandedGridColumn5);
            this.gridBand5.Columns.Add(this.bandedGridColumn14);
            this.gridBand5.Columns.Add(this.bandedGridColumn13);
            this.gridBand5.Columns.Add(this.bandedGridColumn143);
            this.gridBand5.Columns.Add(this.bandedGridColumn186);
            this.gridBand5.Columns.Add(this.bandedGridColumn187);
            this.gridBand5.Columns.Add(this.bandedGridColumn188);
            this.gridBand5.Columns.Add(this.bandedGridColumn189);
            this.gridBand5.Columns.Add(this.bandedGridColumn190);
            this.gridBand5.MinWidth = 22;
            this.gridBand5.Name = "gridBand5";
            this.gridBand5.VisibleIndex = 0;
            this.gridBand5.Width = 2381;
            // 
            // bandedGridColumn1
            // 
            this.bandedGridColumn1.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn1.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn1.Caption = "Num";
            this.bandedGridColumn1.FieldName = "num";
            this.bandedGridColumn1.MinWidth = 42;
            this.bandedGridColumn1.Name = "bandedGridColumn1";
            this.bandedGridColumn1.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn1.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn1.Visible = true;
            this.bandedGridColumn1.Width = 77;
            // 
            // bandedGridColumn6
            // 
            this.bandedGridColumn6.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn6.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn6.Caption = "Date";
            this.bandedGridColumn6.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn6.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn6.FieldName = "issueDate8";
            this.bandedGridColumn6.MinWidth = 42;
            this.bandedGridColumn6.Name = "bandedGridColumn6";
            this.bandedGridColumn6.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn6.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn6.Visible = true;
            this.bandedGridColumn6.Width = 96;
            // 
            // bandedGridColumn4
            // 
            this.bandedGridColumn4.Caption = "Location";
            this.bandedGridColumn4.FieldName = "location";
            this.bandedGridColumn4.MinWidth = 40;
            this.bandedGridColumn4.Name = "bandedGridColumn4";
            this.bandedGridColumn4.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn4.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn4.Visible = true;
            this.bandedGridColumn4.Width = 131;
            // 
            // bandedGridColumn19
            // 
            this.bandedGridColumn19.Caption = "Service Loc";
            this.bandedGridColumn19.FieldName = "serviceLoc";
            this.bandedGridColumn19.MinWidth = 29;
            this.bandedGridColumn19.Name = "bandedGridColumn19";
            this.bandedGridColumn19.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn19.Visible = true;
            this.bandedGridColumn19.Width = 148;
            // 
            // bandedGridColumn12
            // 
            this.bandedGridColumn12.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn12.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn12.Caption = "Contract";
            this.bandedGridColumn12.FieldName = "contractNumber";
            this.bandedGridColumn12.MinWidth = 42;
            this.bandedGridColumn12.Name = "bandedGridColumn12";
            this.bandedGridColumn12.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn12.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn12.Visible = true;
            this.bandedGridColumn12.Width = 154;
            // 
            // bandedGridColumn3
            // 
            this.bandedGridColumn3.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn3.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn3.Caption = "Contract Amount";
            this.bandedGridColumn3.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn3.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn3.FieldName = "paymentCurrMonth";
            this.bandedGridColumn3.MinWidth = 42;
            this.bandedGridColumn3.Name = "bandedGridColumn3";
            this.bandedGridColumn3.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn3.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn3.Visible = true;
            this.bandedGridColumn3.Width = 126;
            // 
            // bandedGridColumn7
            // 
            this.bandedGridColumn7.Caption = "record";
            this.bandedGridColumn7.FieldName = "record";
            this.bandedGridColumn7.MinWidth = 42;
            this.bandedGridColumn7.Name = "bandedGridColumn7";
            this.bandedGridColumn7.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn7.Width = 161;
            // 
            // bandedGridColumn2
            // 
            this.bandedGridColumn2.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn2.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn2.Caption = "Pay Date";
            this.bandedGridColumn2.DisplayFormat.FormatString = "d";
            this.bandedGridColumn2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn2.FieldName = "payDate8";
            this.bandedGridColumn2.MinWidth = 42;
            this.bandedGridColumn2.Name = "bandedGridColumn2";
            this.bandedGridColumn2.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn2.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn2.Visible = true;
            this.bandedGridColumn2.Width = 115;
            // 
            // bandedGridColumn179
            // 
            this.bandedGridColumn179.Caption = "Due Date";
            this.bandedGridColumn179.FieldName = "dueDate8";
            this.bandedGridColumn179.MinWidth = 25;
            this.bandedGridColumn179.Name = "bandedGridColumn179";
            this.bandedGridColumn179.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn179.Visible = true;
            this.bandedGridColumn179.Width = 94;
            // 
            // bandedGridColumn8
            // 
            this.bandedGridColumn8.Caption = "Beginning Balance";
            this.bandedGridColumn8.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn8.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn8.FieldName = "beginningBalance";
            this.bandedGridColumn8.MinWidth = 40;
            this.bandedGridColumn8.Name = "bandedGridColumn8";
            this.bandedGridColumn8.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn8.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn8.Visible = true;
            this.bandedGridColumn8.Width = 149;
            // 
            // bandedGridColumn142
            // 
            this.bandedGridColumn142.Caption = "Trust 50%";
            this.bandedGridColumn142.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn142.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn142.FieldName = "trust50";
            this.bandedGridColumn142.MinWidth = 25;
            this.bandedGridColumn142.Name = "bandedGridColumn142";
            this.bandedGridColumn142.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn142.Visible = true;
            this.bandedGridColumn142.Width = 121;
            // 
            // bandedGridColumn9
            // 
            this.bandedGridColumn9.Caption = "Trust 85%";
            this.bandedGridColumn9.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn9.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn9.FieldName = "trust85";
            this.bandedGridColumn9.MinWidth = 40;
            this.bandedGridColumn9.Name = "bandedGridColumn9";
            this.bandedGridColumn9.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn9.Visible = true;
            this.bandedGridColumn9.Width = 116;
            // 
            // bandedGridColumn10
            // 
            this.bandedGridColumn10.Caption = "Contract Value";
            this.bandedGridColumn10.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn10.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn10.FieldName = "contractValue";
            this.bandedGridColumn10.MinWidth = 25;
            this.bandedGridColumn10.Name = "bandedGridColumn10";
            this.bandedGridColumn10.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn10.Visible = true;
            this.bandedGridColumn10.Width = 94;
            // 
            // bandedGridColumn102
            // 
            this.bandedGridColumn102.Caption = "Remaining Balance";
            this.bandedGridColumn102.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn102.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn102.FieldName = "balanceDue";
            this.bandedGridColumn102.MinWidth = 25;
            this.bandedGridColumn102.Name = "bandedGridColumn102";
            this.bandedGridColumn102.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn102.Visible = true;
            this.bandedGridColumn102.Width = 94;
            // 
            // bandedGridColumn95
            // 
            this.bandedGridColumn95.Caption = "Allow Insurance";
            this.bandedGridColumn95.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn95.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn95.FieldName = "allowInsurance";
            this.bandedGridColumn95.MinWidth = 25;
            this.bandedGridColumn95.Name = "bandedGridColumn95";
            this.bandedGridColumn95.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn95.Visible = true;
            this.bandedGridColumn95.Width = 94;
            // 
            // bandedGridColumn97
            // 
            this.bandedGridColumn97.Caption = "Annuity";
            this.bandedGridColumn97.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn97.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn97.FieldName = "annuity";
            this.bandedGridColumn97.MinWidth = 25;
            this.bandedGridColumn97.Name = "bandedGridColumn97";
            this.bandedGridColumn97.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn97.Visible = true;
            this.bandedGridColumn97.Width = 94;
            // 
            // bandedGridColumn96
            // 
            this.bandedGridColumn96.Caption = "Lapsed";
            this.bandedGridColumn96.FieldName = "lapsed";
            this.bandedGridColumn96.MinWidth = 25;
            this.bandedGridColumn96.Name = "bandedGridColumn96";
            this.bandedGridColumn96.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn96.Visible = true;
            this.bandedGridColumn96.Width = 94;
            // 
            // bandedGridColumn11
            // 
            this.bandedGridColumn11.Caption = "Is2002";
            this.bandedGridColumn11.FieldName = "Is2002";
            this.bandedGridColumn11.MinWidth = 40;
            this.bandedGridColumn11.Name = "bandedGridColumn11";
            this.bandedGridColumn11.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn11.Visible = true;
            this.bandedGridColumn11.Width = 87;
            // 
            // bandedGridColumn15
            // 
            this.bandedGridColumn15.Caption = "riles";
            this.bandedGridColumn15.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.bandedGridColumn15.FieldName = "riles";
            this.bandedGridColumn15.MinWidth = 29;
            this.bandedGridColumn15.Name = "bandedGridColumn15";
            this.bandedGridColumn15.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn15.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn15.Visible = true;
            this.bandedGridColumn15.Width = 77;
            // 
            // bandedGridColumn5
            // 
            this.bandedGridColumn5.MinWidth = 23;
            this.bandedGridColumn5.Name = "bandedGridColumn5";
            this.bandedGridColumn5.Width = 87;
            // 
            // bandedGridColumn14
            // 
            this.bandedGridColumn14.MinWidth = 23;
            this.bandedGridColumn14.Name = "bandedGridColumn14";
            this.bandedGridColumn14.Width = 87;
            // 
            // bandedGridColumn13
            // 
            this.bandedGridColumn13.MinWidth = 23;
            this.bandedGridColumn13.Name = "bandedGridColumn13";
            this.bandedGridColumn13.Width = 87;
            // 
            // bandedGridColumn143
            // 
            this.bandedGridColumn143.Caption = "Issue Date";
            this.bandedGridColumn143.FieldName = "MyIssueDate";
            this.bandedGridColumn143.MinWidth = 25;
            this.bandedGridColumn143.Name = "bandedGridColumn143";
            this.bandedGridColumn143.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn143.Visible = true;
            this.bandedGridColumn143.Width = 94;
            // 
            // bandedGridColumn186
            // 
            this.bandedGridColumn186.Caption = "Trust & ins";
            this.bandedGridColumn186.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn186.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn186.FieldName = "TandI";
            this.bandedGridColumn186.MinWidth = 25;
            this.bandedGridColumn186.Name = "bandedGridColumn186";
            this.bandedGridColumn186.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn186.Visible = true;
            this.bandedGridColumn186.Width = 68;
            // 
            // bandedGridColumn187
            // 
            this.bandedGridColumn187.Caption = "Ins Only";
            this.bandedGridColumn187.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn187.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn187.FieldName = "insOnly";
            this.bandedGridColumn187.MinWidth = 25;
            this.bandedGridColumn187.Name = "bandedGridColumn187";
            this.bandedGridColumn187.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn187.Visible = true;
            this.bandedGridColumn187.Width = 63;
            // 
            // bandedGridColumn188
            // 
            this.bandedGridColumn188.Caption = "Trust Only";
            this.bandedGridColumn188.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn188.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn188.FieldName = "trustOnly";
            this.bandedGridColumn188.MinWidth = 25;
            this.bandedGridColumn188.Name = "bandedGridColumn188";
            this.bandedGridColumn188.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn188.Visible = true;
            this.bandedGridColumn188.Width = 64;
            // 
            // bandedGridColumn189
            // 
            this.bandedGridColumn189.Caption = "Annuity Only";
            this.bandedGridColumn189.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn189.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn189.FieldName = "annOnly";
            this.bandedGridColumn189.MinWidth = 25;
            this.bandedGridColumn189.Name = "bandedGridColumn189";
            this.bandedGridColumn189.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn189.Visible = true;
            this.bandedGridColumn189.Width = 61;
            // 
            // bandedGridColumn190
            // 
            this.bandedGridColumn190.Caption = "Ins and Annuity";
            this.bandedGridColumn190.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn190.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn190.FieldName = "IandA";
            this.bandedGridColumn190.MinWidth = 25;
            this.bandedGridColumn190.Name = "bandedGridColumn190";
            this.bandedGridColumn190.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn190.Visible = true;
            this.bandedGridColumn190.Width = 70;
            // 
            // bandedGridColumn16
            // 
            this.bandedGridColumn16.Caption = "First Name";
            this.bandedGridColumn16.FieldName = "firstName";
            this.bandedGridColumn16.MinWidth = 29;
            this.bandedGridColumn16.Name = "bandedGridColumn16";
            this.bandedGridColumn16.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn16.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn16.Width = 110;
            // 
            // bandedGridColumn17
            // 
            this.bandedGridColumn17.Caption = "Last Name";
            this.bandedGridColumn17.FieldName = "lastName";
            this.bandedGridColumn17.MinWidth = 29;
            this.bandedGridColumn17.Name = "bandedGridColumn17";
            this.bandedGridColumn17.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn17.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn17.Width = 110;
            // 
            // repositoryItemComboBox3
            // 
            this.repositoryItemComboBox3.AutoHeight = false;
            this.repositoryItemComboBox3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox3.Items.AddRange(new object[] {
            "None",
            "Pause"});
            this.repositoryItemComboBox3.Name = "repositoryItemComboBox3";
            // 
            // tabSummary
            // 
            this.tabSummary.Controls.Add(this.dgv9);
            this.tabSummary.Location = new System.Drawing.Point(4, 25);
            this.tabSummary.Name = "tabSummary";
            this.tabSummary.Size = new System.Drawing.Size(1800, 434);
            this.tabSummary.TabIndex = 8;
            this.tabSummary.Text = "Summary";
            this.tabSummary.UseVisualStyleBackColor = true;
            // 
            // dgv9
            // 
            this.dgv9.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv9.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv9.Location = new System.Drawing.Point(0, 0);
            this.dgv9.MainView = this.gridMain9;
            this.dgv9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv9.Name = "dgv9";
            this.dgv9.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox9});
            this.dgv9.Size = new System.Drawing.Size(1800, 434);
            this.dgv9.TabIndex = 6;
            this.dgv9.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain9});
            // 
            // gridMain9
            // 
            this.gridMain9.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain9.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain9.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain9.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain9.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain9.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain9.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain9.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain9.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain9.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain9.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain9.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain9.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain9.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain9.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain9.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain9.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain9.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain9.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain9.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain9.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain9.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain9.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain9.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain9.Appearance.EvenRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain9.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.EvenRow.Options.UseBorderColor = true;
            this.gridMain9.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain9.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain9.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain9.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain9.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain9.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain9.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain9.Appearance.FilterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain9.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain9.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain9.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain9.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain9.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain9.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.gridMain9.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain9.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain9.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain9.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain9.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain9.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain9.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain9.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain9.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain9.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain9.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain9.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain9.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain9.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain9.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain9.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain9.Appearance.GroupPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain9.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain9.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain9.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain9.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain9.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain9.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain9.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain9.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain9.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain9.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain9.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain9.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain9.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(215)))));
            this.gridMain9.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain9.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain9.Appearance.HorzLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain9.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain9.Appearance.HorzLine.Options.UseBorderColor = true;
            this.gridMain9.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain9.Appearance.OddRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain9.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.OddRow.Options.UseBorderColor = true;
            this.gridMain9.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(240)))));
            this.gridMain9.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain9.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain9.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain9.Appearance.Preview.Options.UseFont = true;
            this.gridMain9.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain9.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain9.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.Row.Options.UseBackColor = true;
            this.gridMain9.Appearance.Row.Options.UseForeColor = true;
            this.gridMain9.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain9.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain9.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain9.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(201)))), ((int)(((byte)(207)))));
            this.gridMain9.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain9.Appearance.VertLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain9.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain9.Appearance.VertLine.Options.UseBorderColor = true;
            this.gridMain9.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain9.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain9.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand9});
            this.gridMain9.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn235,
            this.bandedGridColumn226,
            this.bandedGridColumn227,
            this.bandedGridColumn230,
            this.bandedGridColumn228,
            this.bandedGridColumn241,
            this.bandedGridColumn231,
            this.bandedGridColumn232,
            this.bandedGridColumn233,
            this.bandedGridColumn234,
            this.bandedGridColumn229,
            this.bandedGridColumn236,
            this.bandedGridColumn237,
            this.bandedGridColumn238,
            this.bandedGridColumn239,
            this.bandedGridColumn240});
            this.gridMain9.DetailHeight = 431;
            this.gridMain9.GridControl = this.dgv9;
            this.gridMain9.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Custom, "downpayment", null, "", "3")});
            this.gridMain9.Name = "gridMain9";
            this.gridMain9.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain9.OptionsPrint.PrintBandHeader = false;
            this.gridMain9.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain9.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain9.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain9.OptionsView.ShowFooter = true;
            this.gridMain9.OptionsView.ShowGroupPanel = false;
            this.gridMain9.PaintStyleName = "Flat";
            this.gridMain9.DoubleClick += new System.EventHandler(this.gridMain9_DoubleClick);
            // 
            // gridBand9
            // 
            this.gridBand9.Columns.Add(this.bandedGridColumn226);
            this.gridBand9.Columns.Add(this.bandedGridColumn227);
            this.gridBand9.Columns.Add(this.bandedGridColumn228);
            this.gridBand9.Columns.Add(this.bandedGridColumn229);
            this.gridBand9.Columns.Add(this.bandedGridColumn230);
            this.gridBand9.Columns.Add(this.bandedGridColumn241);
            this.gridBand9.Columns.Add(this.bandedGridColumn231);
            this.gridBand9.Columns.Add(this.bandedGridColumn232);
            this.gridBand9.Columns.Add(this.bandedGridColumn233);
            this.gridBand9.Columns.Add(this.bandedGridColumn234);
            this.gridBand9.Columns.Add(this.bandedGridColumn235);
            this.gridBand9.Columns.Add(this.bandedGridColumn236);
            this.gridBand9.Columns.Add(this.bandedGridColumn237);
            this.gridBand9.Columns.Add(this.bandedGridColumn238);
            this.gridBand9.Columns.Add(this.bandedGridColumn239);
            this.gridBand9.Columns.Add(this.bandedGridColumn240);
            this.gridBand9.MinWidth = 41;
            this.gridBand9.Name = "gridBand9";
            this.gridBand9.VisibleIndex = 0;
            this.gridBand9.Width = 1804;
            // 
            // bandedGridColumn226
            // 
            this.bandedGridColumn226.Caption = "Location";
            this.bandedGridColumn226.FieldName = "location";
            this.bandedGridColumn226.MinWidth = 64;
            this.bandedGridColumn226.Name = "bandedGridColumn226";
            this.bandedGridColumn226.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn226.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn226.Visible = true;
            this.bandedGridColumn226.Width = 210;
            // 
            // bandedGridColumn227
            // 
            this.bandedGridColumn227.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn227.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn227.Caption = "Contracts";
            this.bandedGridColumn227.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn227.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn227.FieldName = "contracts";
            this.bandedGridColumn227.MinWidth = 66;
            this.bandedGridColumn227.Name = "bandedGridColumn227";
            this.bandedGridColumn227.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn227.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn227.Visible = true;
            this.bandedGridColumn227.Width = 156;
            // 
            // bandedGridColumn228
            // 
            this.bandedGridColumn228.Caption = "Contract Value";
            this.bandedGridColumn228.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn228.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn228.FieldName = "contractValue";
            this.bandedGridColumn228.MinWidth = 40;
            this.bandedGridColumn228.Name = "bandedGridColumn228";
            this.bandedGridColumn228.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn228.Visible = true;
            this.bandedGridColumn228.Width = 156;
            // 
            // bandedGridColumn229
            // 
            this.bandedGridColumn229.Caption = "Trust 50%";
            this.bandedGridColumn229.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn229.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn229.FieldName = "trust50";
            this.bandedGridColumn229.MinWidth = 29;
            this.bandedGridColumn229.Name = "bandedGridColumn229";
            this.bandedGridColumn229.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn229.Visible = true;
            this.bandedGridColumn229.Width = 128;
            // 
            // bandedGridColumn230
            // 
            this.bandedGridColumn230.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn230.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn230.Caption = "Trust 85%";
            this.bandedGridColumn230.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn230.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn230.FieldName = "total";
            this.bandedGridColumn230.MinWidth = 66;
            this.bandedGridColumn230.Name = "bandedGridColumn230";
            this.bandedGridColumn230.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn230.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn230.Visible = true;
            this.bandedGridColumn230.Width = 156;
            // 
            // bandedGridColumn241
            // 
            this.bandedGridColumn241.Caption = "Active or Paid Off Trust 50% and 85%";
            this.bandedGridColumn241.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn241.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn241.FieldName = "trust5085";
            this.bandedGridColumn241.MinWidth = 40;
            this.bandedGridColumn241.Name = "bandedGridColumn241";
            this.bandedGridColumn241.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn241.Visible = true;
            this.bandedGridColumn241.Width = 156;
            // 
            // bandedGridColumn231
            // 
            this.bandedGridColumn231.Caption = "Allow Insurance";
            this.bandedGridColumn231.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn231.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn231.FieldName = "allowInsurance";
            this.bandedGridColumn231.MinWidth = 40;
            this.bandedGridColumn231.Name = "bandedGridColumn231";
            this.bandedGridColumn231.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn231.Visible = true;
            this.bandedGridColumn231.Width = 152;
            // 
            // bandedGridColumn232
            // 
            this.bandedGridColumn232.Caption = "Annuity";
            this.bandedGridColumn232.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn232.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn232.FieldName = "annuity";
            this.bandedGridColumn232.MinWidth = 40;
            this.bandedGridColumn232.Name = "bandedGridColumn232";
            this.bandedGridColumn232.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn232.Visible = true;
            this.bandedGridColumn232.Width = 126;
            // 
            // bandedGridColumn233
            // 
            this.bandedGridColumn233.Caption = "Total";
            this.bandedGridColumn233.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn233.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn233.FieldName = "totalLoc";
            this.bandedGridColumn233.MinWidth = 34;
            this.bandedGridColumn233.Name = "bandedGridColumn233";
            this.bandedGridColumn233.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn233.Visible = true;
            this.bandedGridColumn233.Width = 135;
            // 
            // bandedGridColumn234
            // 
            this.bandedGridColumn234.Caption = "Remaining Balance";
            this.bandedGridColumn234.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn234.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn234.FieldName = "balanceDue";
            this.bandedGridColumn234.MinWidth = 29;
            this.bandedGridColumn234.Name = "bandedGridColumn234";
            this.bandedGridColumn234.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn234.Visible = true;
            this.bandedGridColumn234.Width = 107;
            // 
            // bandedGridColumn235
            // 
            this.bandedGridColumn235.Caption = "record";
            this.bandedGridColumn235.FieldName = "record";
            this.bandedGridColumn235.MinWidth = 66;
            this.bandedGridColumn235.Name = "bandedGridColumn235";
            this.bandedGridColumn235.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn235.Width = 255;
            // 
            // bandedGridColumn236
            // 
            this.bandedGridColumn236.Caption = "Trust and Ins";
            this.bandedGridColumn236.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn236.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn236.FieldName = "TandI";
            this.bandedGridColumn236.MinWidth = 25;
            this.bandedGridColumn236.Name = "bandedGridColumn236";
            this.bandedGridColumn236.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn236.Visible = true;
            this.bandedGridColumn236.Width = 66;
            // 
            // bandedGridColumn237
            // 
            this.bandedGridColumn237.Caption = "Ins Only";
            this.bandedGridColumn237.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn237.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn237.FieldName = "insOnly";
            this.bandedGridColumn237.MinWidth = 25;
            this.bandedGridColumn237.Name = "bandedGridColumn237";
            this.bandedGridColumn237.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn237.Visible = true;
            this.bandedGridColumn237.Width = 55;
            // 
            // bandedGridColumn238
            // 
            this.bandedGridColumn238.Caption = "Trust Only";
            this.bandedGridColumn238.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn238.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn238.FieldName = "trustOnly";
            this.bandedGridColumn238.MinWidth = 25;
            this.bandedGridColumn238.Name = "bandedGridColumn238";
            this.bandedGridColumn238.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn238.Visible = true;
            this.bandedGridColumn238.Width = 60;
            // 
            // bandedGridColumn239
            // 
            this.bandedGridColumn239.Caption = "Annuity Only";
            this.bandedGridColumn239.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn239.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn239.FieldName = "annOnly";
            this.bandedGridColumn239.MinWidth = 25;
            this.bandedGridColumn239.Name = "bandedGridColumn239";
            this.bandedGridColumn239.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn239.Visible = true;
            this.bandedGridColumn239.Width = 69;
            // 
            // bandedGridColumn240
            // 
            this.bandedGridColumn240.Caption = "Ins and Annuity";
            this.bandedGridColumn240.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn240.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn240.FieldName = "IandA";
            this.bandedGridColumn240.MinWidth = 25;
            this.bandedGridColumn240.Name = "bandedGridColumn240";
            this.bandedGridColumn240.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn240.Visible = true;
            this.bandedGridColumn240.Width = 72;
            // 
            // repositoryItemComboBox9
            // 
            this.repositoryItemComboBox9.AutoHeight = false;
            this.repositoryItemComboBox9.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox9.Items.AddRange(new object[] {
            "None",
            "Pause"});
            this.repositoryItemComboBox9.Name = "repositoryItemComboBox9";
            // 
            // tabPrePostRiles
            // 
            this.tabPrePostRiles.Controls.Add(this.dgv2);
            this.tabPrePostRiles.Location = new System.Drawing.Point(4, 25);
            this.tabPrePostRiles.Name = "tabPrePostRiles";
            this.tabPrePostRiles.Padding = new System.Windows.Forms.Padding(3);
            this.tabPrePostRiles.Size = new System.Drawing.Size(1800, 434);
            this.tabPrePostRiles.TabIndex = 1;
            this.tabPrePostRiles.Text = "Pre/Post/Riles";
            this.tabPrePostRiles.UseVisualStyleBackColor = true;
            // 
            // dgv2
            // 
            this.dgv2.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv2.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Location = new System.Drawing.Point(3, 3);
            this.dgv2.MainView = this.gridMain2;
            this.dgv2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Name = "dgv2";
            this.dgv2.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox1});
            this.dgv2.Size = new System.Drawing.Size(1794, 428);
            this.dgv2.TabIndex = 5;
            this.dgv2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain2});
            // 
            // gridMain2
            // 
            this.gridMain2.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain2.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain2.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain2.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain2.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain2.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain2.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain2.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain2.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain2.Appearance.EvenRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain2.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.Options.UseBorderColor = true;
            this.gridMain2.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain2.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain2.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain2.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.FilterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain2.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain2.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.gridMain2.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain2.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain2.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain2.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain2.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain2.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain2.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain2.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.GroupPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain2.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain2.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain2.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain2.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain2.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(215)))));
            this.gridMain2.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain2.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain2.Appearance.HorzLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain2.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.HorzLine.Options.UseBorderColor = true;
            this.gridMain2.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain2.Appearance.OddRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain2.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.OddRow.Options.UseBorderColor = true;
            this.gridMain2.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(240)))));
            this.gridMain2.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain2.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain2.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain2.Appearance.Preview.Options.UseFont = true;
            this.gridMain2.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain2.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain2.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.Row.Options.UseBackColor = true;
            this.gridMain2.Appearance.Row.Options.UseForeColor = true;
            this.gridMain2.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain2.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(201)))), ((int)(((byte)(207)))));
            this.gridMain2.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain2.Appearance.VertLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain2.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.VertLine.Options.UseBorderColor = true;
            this.gridMain2.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain2.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain2.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand1});
            this.gridMain2.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn24,
            this.bandedGridColumn21,
            this.bandedGridColumn245,
            this.bandedGridColumn243,
            this.bandedGridColumn244,
            this.bandedGridColumn246,
            this.bandedGridColumn247,
            this.bandedGridColumn22,
            this.bandedGridColumn23,
            this.bandedGridColumn242,
            this.bandedGridColumn98,
            this.bandedGridColumn99,
            this.bandedGridColumn100,
            this.bandedGridColumn101,
            this.bandedGridColumn103,
            this.bandedGridColumn144,
            this.bandedGridColumn191,
            this.bandedGridColumn195,
            this.bandedGridColumn194,
            this.bandedGridColumn193,
            this.bandedGridColumn192,
            this.bandedGridColumn248,
            this.bandedGridColumn249});
            this.gridMain2.DetailHeight = 431;
            this.gridMain2.GridControl = this.dgv2;
            this.gridMain2.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Custom, "downpayment", null, "", "3")});
            this.gridMain2.Name = "gridMain2";
            this.gridMain2.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain2.OptionsPrint.PrintBandHeader = false;
            this.gridMain2.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain2.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain2.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain2.OptionsView.ShowFooter = true;
            this.gridMain2.OptionsView.ShowGroupPanel = false;
            this.gridMain2.PaintStyleName = "Flat";
            this.gridMain2.DoubleClick += new System.EventHandler(this.gridMain2_DoubleClick);
            // 
            // gridBand1
            // 
            this.gridBand1.Columns.Add(this.bandedGridColumn21);
            this.gridBand1.Columns.Add(this.bandedGridColumn243);
            this.gridBand1.Columns.Add(this.bandedGridColumn245);
            this.gridBand1.Columns.Add(this.bandedGridColumn244);
            this.gridBand1.Columns.Add(this.bandedGridColumn246);
            this.gridBand1.Columns.Add(this.bandedGridColumn247);
            this.gridBand1.Columns.Add(this.bandedGridColumn22);
            this.gridBand1.Columns.Add(this.bandedGridColumn98);
            this.gridBand1.Columns.Add(this.bandedGridColumn144);
            this.gridBand1.Columns.Add(this.bandedGridColumn23);
            this.gridBand1.Columns.Add(this.bandedGridColumn242);
            this.gridBand1.Columns.Add(this.bandedGridColumn99);
            this.gridBand1.Columns.Add(this.bandedGridColumn101);
            this.gridBand1.Columns.Add(this.bandedGridColumn103);
            this.gridBand1.Columns.Add(this.bandedGridColumn248);
            this.gridBand1.Columns.Add(this.bandedGridColumn249);
            this.gridBand1.Columns.Add(this.bandedGridColumn24);
            this.gridBand1.Columns.Add(this.bandedGridColumn100);
            this.gridBand1.Columns.Add(this.bandedGridColumn191);
            this.gridBand1.Columns.Add(this.bandedGridColumn193);
            this.gridBand1.Columns.Add(this.bandedGridColumn194);
            this.gridBand1.Columns.Add(this.bandedGridColumn192);
            this.gridBand1.Columns.Add(this.bandedGridColumn195);
            this.gridBand1.MinWidth = 41;
            this.gridBand1.Name = "gridBand1";
            this.gridBand1.VisibleIndex = 0;
            this.gridBand1.Width = 1706;
            // 
            // bandedGridColumn21
            // 
            this.bandedGridColumn21.Caption = "Location";
            this.bandedGridColumn21.FieldName = "location";
            this.bandedGridColumn21.MinWidth = 64;
            this.bandedGridColumn21.Name = "bandedGridColumn21";
            this.bandedGridColumn21.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn21.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn21.Visible = true;
            this.bandedGridColumn21.Width = 210;
            // 
            // bandedGridColumn243
            // 
            this.bandedGridColumn243.Caption = "Lapsed Contracts";
            this.bandedGridColumn243.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn243.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn243.FieldName = "L_contracts";
            this.bandedGridColumn243.MinWidth = 25;
            this.bandedGridColumn243.Name = "bandedGridColumn243";
            this.bandedGridColumn243.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn243.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn243.Visible = true;
            this.bandedGridColumn243.Width = 85;
            // 
            // bandedGridColumn245
            // 
            this.bandedGridColumn245.Caption = "Lapsed Contract Value";
            this.bandedGridColumn245.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn245.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn245.FieldName = "L_contractValue";
            this.bandedGridColumn245.MinWidth = 25;
            this.bandedGridColumn245.Name = "bandedGridColumn245";
            this.bandedGridColumn245.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn245.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn245.Visible = true;
            this.bandedGridColumn245.Width = 125;
            // 
            // bandedGridColumn244
            // 
            this.bandedGridColumn244.Caption = "Lapsed 50%";
            this.bandedGridColumn244.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn244.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn244.FieldName = "L_trust50";
            this.bandedGridColumn244.MinWidth = 25;
            this.bandedGridColumn244.Name = "bandedGridColumn244";
            this.bandedGridColumn244.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn244.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn244.Visible = true;
            this.bandedGridColumn244.Width = 100;
            // 
            // bandedGridColumn246
            // 
            this.bandedGridColumn246.Caption = "Lapsed 85%";
            this.bandedGridColumn246.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn246.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn246.FieldName = "L_total";
            this.bandedGridColumn246.MinWidth = 25;
            this.bandedGridColumn246.Name = "bandedGridColumn246";
            this.bandedGridColumn246.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn246.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn246.Visible = true;
            this.bandedGridColumn246.Width = 100;
            // 
            // bandedGridColumn247
            // 
            this.bandedGridColumn247.Caption = "Lapsed Value 50% and 85%";
            this.bandedGridColumn247.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn247.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn247.FieldName = "L_trust5085";
            this.bandedGridColumn247.MinWidth = 25;
            this.bandedGridColumn247.Name = "bandedGridColumn247";
            this.bandedGridColumn247.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn247.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn247.Visible = true;
            this.bandedGridColumn247.Width = 128;
            // 
            // bandedGridColumn22
            // 
            this.bandedGridColumn22.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn22.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn22.Caption = "Contracts";
            this.bandedGridColumn22.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn22.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn22.FieldName = "contracts";
            this.bandedGridColumn22.MinWidth = 66;
            this.bandedGridColumn22.Name = "bandedGridColumn22";
            this.bandedGridColumn22.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn22.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn22.Visible = true;
            this.bandedGridColumn22.Width = 85;
            // 
            // bandedGridColumn98
            // 
            this.bandedGridColumn98.Caption = "Contract Value";
            this.bandedGridColumn98.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn98.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn98.FieldName = "contractValue";
            this.bandedGridColumn98.MinWidth = 40;
            this.bandedGridColumn98.Name = "bandedGridColumn98";
            this.bandedGridColumn98.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn98.Visible = true;
            this.bandedGridColumn98.Width = 125;
            // 
            // bandedGridColumn144
            // 
            this.bandedGridColumn144.Caption = "Trust 50%";
            this.bandedGridColumn144.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn144.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn144.FieldName = "trust50";
            this.bandedGridColumn144.MinWidth = 29;
            this.bandedGridColumn144.Name = "bandedGridColumn144";
            this.bandedGridColumn144.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn144.Visible = true;
            this.bandedGridColumn144.Width = 100;
            // 
            // bandedGridColumn23
            // 
            this.bandedGridColumn23.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn23.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn23.Caption = "Trust 85%";
            this.bandedGridColumn23.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn23.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn23.FieldName = "total";
            this.bandedGridColumn23.MinWidth = 66;
            this.bandedGridColumn23.Name = "bandedGridColumn23";
            this.bandedGridColumn23.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn23.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn23.Visible = true;
            this.bandedGridColumn23.Width = 100;
            // 
            // bandedGridColumn242
            // 
            this.bandedGridColumn242.Caption = "Active or Paid Off Value 50% and 85%";
            this.bandedGridColumn242.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn242.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn242.FieldName = "trust5085";
            this.bandedGridColumn242.MinWidth = 25;
            this.bandedGridColumn242.Name = "bandedGridColumn242";
            this.bandedGridColumn242.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn242.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn242.Visible = true;
            this.bandedGridColumn242.Width = 128;
            // 
            // bandedGridColumn99
            // 
            this.bandedGridColumn99.Caption = "Allow Insurance";
            this.bandedGridColumn99.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn99.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn99.FieldName = "allowInsurance";
            this.bandedGridColumn99.MinWidth = 40;
            this.bandedGridColumn99.Name = "bandedGridColumn99";
            this.bandedGridColumn99.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn99.Width = 152;
            // 
            // bandedGridColumn101
            // 
            this.bandedGridColumn101.Caption = "Total";
            this.bandedGridColumn101.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn101.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn101.FieldName = "totalLoc";
            this.bandedGridColumn101.MinWidth = 34;
            this.bandedGridColumn101.Name = "bandedGridColumn101";
            this.bandedGridColumn101.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn101.Visible = true;
            this.bandedGridColumn101.Width = 125;
            // 
            // bandedGridColumn103
            // 
            this.bandedGridColumn103.Caption = "Remaining Balance";
            this.bandedGridColumn103.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn103.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn103.FieldName = "balanceDue";
            this.bandedGridColumn103.MinWidth = 29;
            this.bandedGridColumn103.Name = "bandedGridColumn103";
            this.bandedGridColumn103.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn103.Visible = true;
            this.bandedGridColumn103.Width = 105;
            // 
            // bandedGridColumn248
            // 
            this.bandedGridColumn248.Caption = "Active Contracts";
            this.bandedGridColumn248.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn248.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn248.FieldName = "A_contracts";
            this.bandedGridColumn248.MinWidth = 65;
            this.bandedGridColumn248.Name = "bandedGridColumn248";
            this.bandedGridColumn248.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn248.Visible = true;
            this.bandedGridColumn248.Width = 85;
            // 
            // bandedGridColumn249
            // 
            this.bandedGridColumn249.Caption = "Active Contracts Remaining Balance";
            this.bandedGridColumn249.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn249.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn249.FieldName = "A_remainingBal";
            this.bandedGridColumn249.MinWidth = 25;
            this.bandedGridColumn249.Name = "bandedGridColumn249";
            this.bandedGridColumn249.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn249.Visible = true;
            this.bandedGridColumn249.Width = 105;
            // 
            // bandedGridColumn24
            // 
            this.bandedGridColumn24.Caption = "record";
            this.bandedGridColumn24.FieldName = "record";
            this.bandedGridColumn24.MinWidth = 66;
            this.bandedGridColumn24.Name = "bandedGridColumn24";
            this.bandedGridColumn24.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn24.Width = 255;
            // 
            // bandedGridColumn100
            // 
            this.bandedGridColumn100.Caption = "Annuity";
            this.bandedGridColumn100.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn100.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn100.FieldName = "annuity";
            this.bandedGridColumn100.MinWidth = 40;
            this.bandedGridColumn100.Name = "bandedGridColumn100";
            this.bandedGridColumn100.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn100.RowIndex = 1;
            this.bandedGridColumn100.Width = 126;
            // 
            // bandedGridColumn191
            // 
            this.bandedGridColumn191.Caption = "Trust and Ins";
            this.bandedGridColumn191.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn191.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn191.FieldName = "TandI";
            this.bandedGridColumn191.MinWidth = 25;
            this.bandedGridColumn191.Name = "bandedGridColumn191";
            this.bandedGridColumn191.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn191.RowIndex = 1;
            this.bandedGridColumn191.Width = 66;
            // 
            // bandedGridColumn193
            // 
            this.bandedGridColumn193.Caption = "Annuity Only";
            this.bandedGridColumn193.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn193.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn193.FieldName = "annOnly";
            this.bandedGridColumn193.MinWidth = 25;
            this.bandedGridColumn193.Name = "bandedGridColumn193";
            this.bandedGridColumn193.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn193.RowIndex = 1;
            this.bandedGridColumn193.Width = 69;
            // 
            // bandedGridColumn194
            // 
            this.bandedGridColumn194.Caption = "Trust Only";
            this.bandedGridColumn194.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn194.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn194.FieldName = "trustOnly";
            this.bandedGridColumn194.MinWidth = 25;
            this.bandedGridColumn194.Name = "bandedGridColumn194";
            this.bandedGridColumn194.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn194.RowIndex = 1;
            this.bandedGridColumn194.Width = 60;
            // 
            // bandedGridColumn192
            // 
            this.bandedGridColumn192.Caption = "Ins and Annuity";
            this.bandedGridColumn192.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn192.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn192.FieldName = "IandA";
            this.bandedGridColumn192.MinWidth = 25;
            this.bandedGridColumn192.Name = "bandedGridColumn192";
            this.bandedGridColumn192.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn192.RowIndex = 1;
            this.bandedGridColumn192.Width = 72;
            // 
            // bandedGridColumn195
            // 
            this.bandedGridColumn195.Caption = "Ins Only";
            this.bandedGridColumn195.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn195.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn195.FieldName = "insOnly";
            this.bandedGridColumn195.MinWidth = 25;
            this.bandedGridColumn195.Name = "bandedGridColumn195";
            this.bandedGridColumn195.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn195.RowIndex = 1;
            this.bandedGridColumn195.Width = 55;
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.AutoHeight = false;
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox1.Items.AddRange(new object[] {
            "None",
            "Pause"});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            // 
            // tabHU
            // 
            this.tabHU.Controls.Add(this.dgv3);
            this.tabHU.Location = new System.Drawing.Point(4, 25);
            this.tabHU.Name = "tabHU";
            this.tabHU.Size = new System.Drawing.Size(1800, 434);
            this.tabHU.TabIndex = 2;
            this.tabHU.Text = "HU";
            this.tabHU.UseVisualStyleBackColor = true;
            // 
            // dgv3
            // 
            this.dgv3.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv3.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Location = new System.Drawing.Point(0, 0);
            this.dgv3.MainView = this.gridMain3;
            this.dgv3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Name = "dgv3";
            this.dgv3.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox2});
            this.dgv3.Size = new System.Drawing.Size(1800, 434);
            this.dgv3.TabIndex = 5;
            this.dgv3.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain3});
            // 
            // gridMain3
            // 
            this.gridMain3.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain3.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain3.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain3.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain3.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain3.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain3.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain3.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain3.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain3.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain3.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain3.Appearance.EvenRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain3.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.EvenRow.Options.UseBorderColor = true;
            this.gridMain3.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain3.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain3.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain3.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.FilterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain3.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain3.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.gridMain3.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain3.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain3.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain3.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain3.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain3.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain3.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain3.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.GroupPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain3.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain3.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain3.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain3.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain3.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain3.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain3.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(215)))));
            this.gridMain3.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain3.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain3.Appearance.HorzLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain3.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain3.Appearance.HorzLine.Options.UseBorderColor = true;
            this.gridMain3.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain3.Appearance.OddRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain3.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.OddRow.Options.UseBorderColor = true;
            this.gridMain3.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(240)))));
            this.gridMain3.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain3.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain3.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain3.Appearance.Preview.Options.UseFont = true;
            this.gridMain3.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain3.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain3.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.Row.Options.UseBackColor = true;
            this.gridMain3.Appearance.Row.Options.UseForeColor = true;
            this.gridMain3.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain3.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain3.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(201)))), ((int)(((byte)(207)))));
            this.gridMain3.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain3.Appearance.VertLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain3.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain3.Appearance.VertLine.Options.UseBorderColor = true;
            this.gridMain3.AppearancePrint.GroupRow.Font = new System.Drawing.Font("Tahoma", 7.8F);
            this.gridMain3.AppearancePrint.GroupRow.Options.UseFont = true;
            this.gridMain3.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain3.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain3.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand2});
            this.gridMain3.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn18,
            this.bandedGridColumn29,
            this.bandedGridColumn20,
            this.bandedGridColumn25,
            this.bandedGridColumn27,
            this.bandedGridColumn28,
            this.bandedGridColumn30,
            this.bandedGridColumn32,
            this.bandedGridColumn34,
            this.bandedGridColumn40,
            this.bandedGridColumn127,
            this.bandedGridColumn128,
            this.bandedGridColumn129,
            this.bandedGridColumn126,
            this.bandedGridColumn199,
            this.bandedGridColumn200,
            this.bandedGridColumn26,
            this.bandedGridColumn35,
            this.bandedGridColumn37,
            this.bandedGridColumn39,
            this.bandedGridColumn38,
            this.bandedGridColumn36,
            this.bandedGridColumn33,
            this.bandedGridColumn145,
            this.bandedGridColumn31,
            this.bandedGridColumn146,
            this.bandedGridColumn180,
            this.bandedGridColumn196,
            this.bandedGridColumn197,
            this.bandedGridColumn198});
            this.gridMain3.DetailHeight = 431;
            this.gridMain3.GridControl = this.dgv3;
            this.gridMain3.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Custom, "downpayment", this.bandedGridColumn30, "", "3")});
            this.gridMain3.Name = "gridMain3";
            this.gridMain3.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain3.OptionsPrint.PrintBandHeader = false;
            this.gridMain3.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain3.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain3.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain3.OptionsView.ShowFooter = true;
            this.gridMain3.OptionsView.ShowGroupPanel = false;
            this.gridMain3.PaintStyleName = "Flat";
            this.gridMain3.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.gridMain_CustomSummaryCalculate);
            this.gridMain3.DoubleClick += new System.EventHandler(this.gMain_DoubleClick);
            // 
            // gridBand2
            // 
            this.gridBand2.Columns.Add(this.bandedGridColumn18);
            this.gridBand2.Columns.Add(this.bandedGridColumn20);
            this.gridBand2.Columns.Add(this.bandedGridColumn25);
            this.gridBand2.Columns.Add(this.bandedGridColumn26);
            this.gridBand2.Columns.Add(this.bandedGridColumn27);
            this.gridBand2.Columns.Add(this.bandedGridColumn28);
            this.gridBand2.Columns.Add(this.bandedGridColumn29);
            this.gridBand2.Columns.Add(this.bandedGridColumn30);
            this.gridBand2.Columns.Add(this.bandedGridColumn31);
            this.gridBand2.Columns.Add(this.bandedGridColumn32);
            this.gridBand2.Columns.Add(this.bandedGridColumn33);
            this.gridBand2.Columns.Add(this.bandedGridColumn34);
            this.gridBand2.Columns.Add(this.bandedGridColumn35);
            this.gridBand2.Columns.Add(this.bandedGridColumn36);
            this.gridBand2.Columns.Add(this.bandedGridColumn37);
            this.gridBand2.Columns.Add(this.bandedGridColumn38);
            this.gridBand2.Columns.Add(this.bandedGridColumn39);
            this.gridBand2.Columns.Add(this.bandedGridColumn40);
            this.gridBand2.Columns.Add(this.bandedGridColumn126);
            this.gridBand2.Columns.Add(this.bandedGridColumn127);
            this.gridBand2.Columns.Add(this.bandedGridColumn128);
            this.gridBand2.Columns.Add(this.bandedGridColumn129);
            this.gridBand2.Columns.Add(this.bandedGridColumn145);
            this.gridBand2.Columns.Add(this.bandedGridColumn146);
            this.gridBand2.Columns.Add(this.bandedGridColumn180);
            this.gridBand2.Columns.Add(this.bandedGridColumn196);
            this.gridBand2.Columns.Add(this.bandedGridColumn197);
            this.gridBand2.Columns.Add(this.bandedGridColumn198);
            this.gridBand2.MinWidth = 22;
            this.gridBand2.Name = "gridBand2";
            this.gridBand2.VisibleIndex = 0;
            this.gridBand2.Width = 2381;
            // 
            // bandedGridColumn18
            // 
            this.bandedGridColumn18.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn18.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn18.Caption = "Num";
            this.bandedGridColumn18.FieldName = "num";
            this.bandedGridColumn18.MinWidth = 42;
            this.bandedGridColumn18.Name = "bandedGridColumn18";
            this.bandedGridColumn18.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn18.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn18.Visible = true;
            this.bandedGridColumn18.Width = 77;
            // 
            // bandedGridColumn20
            // 
            this.bandedGridColumn20.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn20.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn20.Caption = "Date";
            this.bandedGridColumn20.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn20.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn20.FieldName = "issueDate8";
            this.bandedGridColumn20.MinWidth = 42;
            this.bandedGridColumn20.Name = "bandedGridColumn20";
            this.bandedGridColumn20.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn20.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn20.Visible = true;
            this.bandedGridColumn20.Width = 96;
            // 
            // bandedGridColumn25
            // 
            this.bandedGridColumn25.Caption = "Location";
            this.bandedGridColumn25.FieldName = "location";
            this.bandedGridColumn25.MinWidth = 40;
            this.bandedGridColumn25.Name = "bandedGridColumn25";
            this.bandedGridColumn25.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn25.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn25.Visible = true;
            this.bandedGridColumn25.Width = 131;
            // 
            // bandedGridColumn26
            // 
            this.bandedGridColumn26.Caption = "Service Loc";
            this.bandedGridColumn26.FieldName = "serviceLoc";
            this.bandedGridColumn26.MinWidth = 29;
            this.bandedGridColumn26.Name = "bandedGridColumn26";
            this.bandedGridColumn26.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn26.Visible = true;
            this.bandedGridColumn26.Width = 148;
            // 
            // bandedGridColumn27
            // 
            this.bandedGridColumn27.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn27.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn27.Caption = "Contract";
            this.bandedGridColumn27.FieldName = "contractNumber";
            this.bandedGridColumn27.MinWidth = 42;
            this.bandedGridColumn27.Name = "bandedGridColumn27";
            this.bandedGridColumn27.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn27.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn27.Visible = true;
            this.bandedGridColumn27.Width = 154;
            // 
            // bandedGridColumn28
            // 
            this.bandedGridColumn28.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn28.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn28.Caption = "Contract Amount";
            this.bandedGridColumn28.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn28.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn28.FieldName = "paymentCurrMonth";
            this.bandedGridColumn28.MinWidth = 42;
            this.bandedGridColumn28.Name = "bandedGridColumn28";
            this.bandedGridColumn28.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn28.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn28.Visible = true;
            this.bandedGridColumn28.Width = 126;
            // 
            // bandedGridColumn29
            // 
            this.bandedGridColumn29.Caption = "record";
            this.bandedGridColumn29.FieldName = "record";
            this.bandedGridColumn29.MinWidth = 42;
            this.bandedGridColumn29.Name = "bandedGridColumn29";
            this.bandedGridColumn29.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn29.Width = 161;
            // 
            // bandedGridColumn30
            // 
            this.bandedGridColumn30.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn30.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn30.Caption = "Pay Date";
            this.bandedGridColumn30.DisplayFormat.FormatString = "d";
            this.bandedGridColumn30.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn30.FieldName = "payDate8";
            this.bandedGridColumn30.MinWidth = 42;
            this.bandedGridColumn30.Name = "bandedGridColumn30";
            this.bandedGridColumn30.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn30.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn30.Visible = true;
            this.bandedGridColumn30.Width = 115;
            // 
            // bandedGridColumn31
            // 
            this.bandedGridColumn31.Caption = "Due Date";
            this.bandedGridColumn31.FieldName = "dueDate8";
            this.bandedGridColumn31.MinWidth = 25;
            this.bandedGridColumn31.Name = "bandedGridColumn31";
            this.bandedGridColumn31.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn31.Visible = true;
            this.bandedGridColumn31.Width = 94;
            // 
            // bandedGridColumn32
            // 
            this.bandedGridColumn32.Caption = "Beginning Balance";
            this.bandedGridColumn32.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn32.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn32.FieldName = "beginningBalance";
            this.bandedGridColumn32.MinWidth = 40;
            this.bandedGridColumn32.Name = "bandedGridColumn32";
            this.bandedGridColumn32.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn32.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn32.Visible = true;
            this.bandedGridColumn32.Width = 149;
            // 
            // bandedGridColumn33
            // 
            this.bandedGridColumn33.Caption = "Trust 50%";
            this.bandedGridColumn33.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn33.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn33.FieldName = "trust50";
            this.bandedGridColumn33.MinWidth = 25;
            this.bandedGridColumn33.Name = "bandedGridColumn33";
            this.bandedGridColumn33.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn33.Visible = true;
            this.bandedGridColumn33.Width = 121;
            // 
            // bandedGridColumn34
            // 
            this.bandedGridColumn34.Caption = "Trust 85%";
            this.bandedGridColumn34.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn34.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn34.FieldName = "trust85";
            this.bandedGridColumn34.MinWidth = 40;
            this.bandedGridColumn34.Name = "bandedGridColumn34";
            this.bandedGridColumn34.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn34.Visible = true;
            this.bandedGridColumn34.Width = 116;
            // 
            // bandedGridColumn35
            // 
            this.bandedGridColumn35.Caption = "Contract Value";
            this.bandedGridColumn35.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn35.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn35.FieldName = "contractValue";
            this.bandedGridColumn35.MinWidth = 25;
            this.bandedGridColumn35.Name = "bandedGridColumn35";
            this.bandedGridColumn35.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn35.Visible = true;
            this.bandedGridColumn35.Width = 94;
            // 
            // bandedGridColumn36
            // 
            this.bandedGridColumn36.Caption = "Remaining Balance";
            this.bandedGridColumn36.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn36.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn36.FieldName = "balanceDue";
            this.bandedGridColumn36.MinWidth = 25;
            this.bandedGridColumn36.Name = "bandedGridColumn36";
            this.bandedGridColumn36.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn36.Visible = true;
            this.bandedGridColumn36.Width = 94;
            // 
            // bandedGridColumn37
            // 
            this.bandedGridColumn37.Caption = "Allow Insurance";
            this.bandedGridColumn37.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn37.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn37.FieldName = "allowInsurance";
            this.bandedGridColumn37.MinWidth = 25;
            this.bandedGridColumn37.Name = "bandedGridColumn37";
            this.bandedGridColumn37.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn37.Visible = true;
            this.bandedGridColumn37.Width = 94;
            // 
            // bandedGridColumn38
            // 
            this.bandedGridColumn38.Caption = "Annuity";
            this.bandedGridColumn38.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn38.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn38.FieldName = "annuity";
            this.bandedGridColumn38.MinWidth = 25;
            this.bandedGridColumn38.Name = "bandedGridColumn38";
            this.bandedGridColumn38.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn38.Visible = true;
            this.bandedGridColumn38.Width = 94;
            // 
            // bandedGridColumn39
            // 
            this.bandedGridColumn39.Caption = "Lapsed";
            this.bandedGridColumn39.FieldName = "lapsed";
            this.bandedGridColumn39.MinWidth = 25;
            this.bandedGridColumn39.Name = "bandedGridColumn39";
            this.bandedGridColumn39.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn39.Visible = true;
            this.bandedGridColumn39.Width = 94;
            // 
            // bandedGridColumn40
            // 
            this.bandedGridColumn40.Caption = "Is2002";
            this.bandedGridColumn40.FieldName = "Is2002";
            this.bandedGridColumn40.MinWidth = 40;
            this.bandedGridColumn40.Name = "bandedGridColumn40";
            this.bandedGridColumn40.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn40.Visible = true;
            this.bandedGridColumn40.Width = 87;
            // 
            // bandedGridColumn126
            // 
            this.bandedGridColumn126.Caption = "riles";
            this.bandedGridColumn126.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.bandedGridColumn126.FieldName = "riles";
            this.bandedGridColumn126.MinWidth = 29;
            this.bandedGridColumn126.Name = "bandedGridColumn126";
            this.bandedGridColumn126.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn126.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn126.Visible = true;
            this.bandedGridColumn126.Width = 77;
            // 
            // bandedGridColumn127
            // 
            this.bandedGridColumn127.MinWidth = 23;
            this.bandedGridColumn127.Name = "bandedGridColumn127";
            this.bandedGridColumn127.Width = 87;
            // 
            // bandedGridColumn128
            // 
            this.bandedGridColumn128.MinWidth = 23;
            this.bandedGridColumn128.Name = "bandedGridColumn128";
            this.bandedGridColumn128.Width = 87;
            // 
            // bandedGridColumn129
            // 
            this.bandedGridColumn129.MinWidth = 23;
            this.bandedGridColumn129.Name = "bandedGridColumn129";
            this.bandedGridColumn129.Width = 87;
            // 
            // bandedGridColumn145
            // 
            this.bandedGridColumn145.Caption = "Issue Date";
            this.bandedGridColumn145.FieldName = "MyIssueDate";
            this.bandedGridColumn145.MinWidth = 25;
            this.bandedGridColumn145.Name = "bandedGridColumn145";
            this.bandedGridColumn145.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn145.Visible = true;
            this.bandedGridColumn145.Width = 94;
            // 
            // bandedGridColumn146
            // 
            this.bandedGridColumn146.Caption = "Trust & ins";
            this.bandedGridColumn146.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn146.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn146.FieldName = "TandI";
            this.bandedGridColumn146.MinWidth = 25;
            this.bandedGridColumn146.Name = "bandedGridColumn146";
            this.bandedGridColumn146.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn146.Visible = true;
            this.bandedGridColumn146.Width = 68;
            // 
            // bandedGridColumn180
            // 
            this.bandedGridColumn180.Caption = "Ins Only";
            this.bandedGridColumn180.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn180.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn180.FieldName = "insOnly";
            this.bandedGridColumn180.MinWidth = 25;
            this.bandedGridColumn180.Name = "bandedGridColumn180";
            this.bandedGridColumn180.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn180.Visible = true;
            this.bandedGridColumn180.Width = 63;
            // 
            // bandedGridColumn196
            // 
            this.bandedGridColumn196.Caption = "Trust Only";
            this.bandedGridColumn196.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn196.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn196.FieldName = "trustOnly";
            this.bandedGridColumn196.MinWidth = 25;
            this.bandedGridColumn196.Name = "bandedGridColumn196";
            this.bandedGridColumn196.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn196.Visible = true;
            this.bandedGridColumn196.Width = 64;
            // 
            // bandedGridColumn197
            // 
            this.bandedGridColumn197.Caption = "Annuity Only";
            this.bandedGridColumn197.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn197.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn197.FieldName = "annOnly";
            this.bandedGridColumn197.MinWidth = 25;
            this.bandedGridColumn197.Name = "bandedGridColumn197";
            this.bandedGridColumn197.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn197.Visible = true;
            this.bandedGridColumn197.Width = 61;
            // 
            // bandedGridColumn198
            // 
            this.bandedGridColumn198.Caption = "Ins and Annuity";
            this.bandedGridColumn198.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn198.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn198.FieldName = "IandA";
            this.bandedGridColumn198.MinWidth = 25;
            this.bandedGridColumn198.Name = "bandedGridColumn198";
            this.bandedGridColumn198.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn198.Visible = true;
            this.bandedGridColumn198.Width = 70;
            // 
            // bandedGridColumn199
            // 
            this.bandedGridColumn199.Caption = "First Name";
            this.bandedGridColumn199.FieldName = "firstName";
            this.bandedGridColumn199.MinWidth = 29;
            this.bandedGridColumn199.Name = "bandedGridColumn199";
            this.bandedGridColumn199.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn199.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn199.Width = 110;
            // 
            // bandedGridColumn200
            // 
            this.bandedGridColumn200.Caption = "Last Name";
            this.bandedGridColumn200.FieldName = "lastName";
            this.bandedGridColumn200.MinWidth = 29;
            this.bandedGridColumn200.Name = "bandedGridColumn200";
            this.bandedGridColumn200.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn200.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn200.Width = 110;
            // 
            // repositoryItemComboBox2
            // 
            this.repositoryItemComboBox2.AutoHeight = false;
            this.repositoryItemComboBox2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox2.Items.AddRange(new object[] {
            "None",
            "Pause"});
            this.repositoryItemComboBox2.Name = "repositoryItemComboBox2";
            // 
            // tabJPN
            // 
            this.tabJPN.Controls.Add(this.dgv4);
            this.tabJPN.Location = new System.Drawing.Point(4, 25);
            this.tabJPN.Name = "tabJPN";
            this.tabJPN.Size = new System.Drawing.Size(1800, 434);
            this.tabJPN.TabIndex = 3;
            this.tabJPN.Text = "JPN";
            this.tabJPN.UseVisualStyleBackColor = true;
            // 
            // dgv4
            // 
            this.dgv4.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv4.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv4.Location = new System.Drawing.Point(0, 0);
            this.dgv4.MainView = this.gridMain4;
            this.dgv4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv4.Name = "dgv4";
            this.dgv4.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox4});
            this.dgv4.Size = new System.Drawing.Size(1800, 434);
            this.dgv4.TabIndex = 5;
            this.dgv4.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain4});
            // 
            // gridMain4
            // 
            this.gridMain4.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain4.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain4.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain4.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain4.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain4.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain4.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain4.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain4.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain4.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain4.Appearance.EvenRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain4.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.EvenRow.Options.UseBorderColor = true;
            this.gridMain4.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain4.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain4.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain4.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.FilterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain4.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain4.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.gridMain4.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain4.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain4.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain4.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain4.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain4.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain4.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain4.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.GroupPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain4.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain4.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain4.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain4.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain4.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain4.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain4.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(215)))));
            this.gridMain4.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain4.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain4.Appearance.HorzLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain4.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain4.Appearance.HorzLine.Options.UseBorderColor = true;
            this.gridMain4.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain4.Appearance.OddRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain4.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.OddRow.Options.UseBorderColor = true;
            this.gridMain4.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(240)))));
            this.gridMain4.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain4.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain4.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain4.Appearance.Preview.Options.UseFont = true;
            this.gridMain4.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain4.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain4.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.Row.Options.UseBackColor = true;
            this.gridMain4.Appearance.Row.Options.UseForeColor = true;
            this.gridMain4.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain4.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain4.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(201)))), ((int)(((byte)(207)))));
            this.gridMain4.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain4.Appearance.VertLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain4.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain4.Appearance.VertLine.Options.UseBorderColor = true;
            this.gridMain4.AppearancePrint.GroupRow.Font = new System.Drawing.Font("Tahoma", 7.8F);
            this.gridMain4.AppearancePrint.GroupRow.Options.UseFont = true;
            this.gridMain4.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain4.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain4.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand3});
            this.gridMain4.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn41,
            this.bandedGridColumn47,
            this.bandedGridColumn42,
            this.bandedGridColumn43,
            this.bandedGridColumn45,
            this.bandedGridColumn46,
            this.bandedGridColumn48,
            this.bandedGridColumn50,
            this.bandedGridColumn52,
            this.bandedGridColumn58,
            this.bandedGridColumn131,
            this.bandedGridColumn132,
            this.bandedGridColumn133,
            this.bandedGridColumn130,
            this.bandedGridColumn204,
            this.bandedGridColumn205,
            this.bandedGridColumn44,
            this.bandedGridColumn53,
            this.bandedGridColumn55,
            this.bandedGridColumn57,
            this.bandedGridColumn56,
            this.bandedGridColumn54,
            this.bandedGridColumn51,
            this.bandedGridColumn147,
            this.bandedGridColumn49,
            this.bandedGridColumn148,
            this.bandedGridColumn181,
            this.bandedGridColumn201,
            this.bandedGridColumn202,
            this.bandedGridColumn203});
            this.gridMain4.DetailHeight = 431;
            this.gridMain4.GridControl = this.dgv4;
            this.gridMain4.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Custom, "downpayment", this.bandedGridColumn48, "", "3")});
            this.gridMain4.Name = "gridMain4";
            this.gridMain4.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain4.OptionsPrint.PrintBandHeader = false;
            this.gridMain4.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain4.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain4.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain4.OptionsView.ShowFooter = true;
            this.gridMain4.OptionsView.ShowGroupPanel = false;
            this.gridMain4.PaintStyleName = "Flat";
            this.gridMain4.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.gridMain_CustomSummaryCalculate);
            this.gridMain4.DoubleClick += new System.EventHandler(this.gMain_DoubleClick);
            // 
            // gridBand3
            // 
            this.gridBand3.Columns.Add(this.bandedGridColumn41);
            this.gridBand3.Columns.Add(this.bandedGridColumn42);
            this.gridBand3.Columns.Add(this.bandedGridColumn43);
            this.gridBand3.Columns.Add(this.bandedGridColumn44);
            this.gridBand3.Columns.Add(this.bandedGridColumn45);
            this.gridBand3.Columns.Add(this.bandedGridColumn46);
            this.gridBand3.Columns.Add(this.bandedGridColumn47);
            this.gridBand3.Columns.Add(this.bandedGridColumn48);
            this.gridBand3.Columns.Add(this.bandedGridColumn49);
            this.gridBand3.Columns.Add(this.bandedGridColumn50);
            this.gridBand3.Columns.Add(this.bandedGridColumn51);
            this.gridBand3.Columns.Add(this.bandedGridColumn52);
            this.gridBand3.Columns.Add(this.bandedGridColumn53);
            this.gridBand3.Columns.Add(this.bandedGridColumn54);
            this.gridBand3.Columns.Add(this.bandedGridColumn55);
            this.gridBand3.Columns.Add(this.bandedGridColumn56);
            this.gridBand3.Columns.Add(this.bandedGridColumn57);
            this.gridBand3.Columns.Add(this.bandedGridColumn58);
            this.gridBand3.Columns.Add(this.bandedGridColumn130);
            this.gridBand3.Columns.Add(this.bandedGridColumn131);
            this.gridBand3.Columns.Add(this.bandedGridColumn132);
            this.gridBand3.Columns.Add(this.bandedGridColumn133);
            this.gridBand3.Columns.Add(this.bandedGridColumn147);
            this.gridBand3.Columns.Add(this.bandedGridColumn148);
            this.gridBand3.Columns.Add(this.bandedGridColumn181);
            this.gridBand3.Columns.Add(this.bandedGridColumn201);
            this.gridBand3.Columns.Add(this.bandedGridColumn202);
            this.gridBand3.Columns.Add(this.bandedGridColumn203);
            this.gridBand3.MinWidth = 22;
            this.gridBand3.Name = "gridBand3";
            this.gridBand3.VisibleIndex = 0;
            this.gridBand3.Width = 2381;
            // 
            // bandedGridColumn41
            // 
            this.bandedGridColumn41.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn41.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn41.Caption = "Num";
            this.bandedGridColumn41.FieldName = "num";
            this.bandedGridColumn41.MinWidth = 42;
            this.bandedGridColumn41.Name = "bandedGridColumn41";
            this.bandedGridColumn41.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn41.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn41.Visible = true;
            this.bandedGridColumn41.Width = 77;
            // 
            // bandedGridColumn42
            // 
            this.bandedGridColumn42.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn42.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn42.Caption = "Date";
            this.bandedGridColumn42.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn42.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn42.FieldName = "issueDate8";
            this.bandedGridColumn42.MinWidth = 42;
            this.bandedGridColumn42.Name = "bandedGridColumn42";
            this.bandedGridColumn42.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn42.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn42.Visible = true;
            this.bandedGridColumn42.Width = 96;
            // 
            // bandedGridColumn43
            // 
            this.bandedGridColumn43.Caption = "Location";
            this.bandedGridColumn43.FieldName = "location";
            this.bandedGridColumn43.MinWidth = 40;
            this.bandedGridColumn43.Name = "bandedGridColumn43";
            this.bandedGridColumn43.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn43.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn43.Visible = true;
            this.bandedGridColumn43.Width = 131;
            // 
            // bandedGridColumn44
            // 
            this.bandedGridColumn44.Caption = "Service Loc";
            this.bandedGridColumn44.FieldName = "serviceLoc";
            this.bandedGridColumn44.MinWidth = 29;
            this.bandedGridColumn44.Name = "bandedGridColumn44";
            this.bandedGridColumn44.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn44.Visible = true;
            this.bandedGridColumn44.Width = 148;
            // 
            // bandedGridColumn45
            // 
            this.bandedGridColumn45.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn45.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn45.Caption = "Contract";
            this.bandedGridColumn45.FieldName = "contractNumber";
            this.bandedGridColumn45.MinWidth = 42;
            this.bandedGridColumn45.Name = "bandedGridColumn45";
            this.bandedGridColumn45.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn45.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn45.Visible = true;
            this.bandedGridColumn45.Width = 154;
            // 
            // bandedGridColumn46
            // 
            this.bandedGridColumn46.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn46.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn46.Caption = "Contract Amount";
            this.bandedGridColumn46.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn46.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn46.FieldName = "paymentCurrMonth";
            this.bandedGridColumn46.MinWidth = 42;
            this.bandedGridColumn46.Name = "bandedGridColumn46";
            this.bandedGridColumn46.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn46.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn46.Visible = true;
            this.bandedGridColumn46.Width = 126;
            // 
            // bandedGridColumn47
            // 
            this.bandedGridColumn47.Caption = "record";
            this.bandedGridColumn47.FieldName = "record";
            this.bandedGridColumn47.MinWidth = 42;
            this.bandedGridColumn47.Name = "bandedGridColumn47";
            this.bandedGridColumn47.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn47.Width = 161;
            // 
            // bandedGridColumn48
            // 
            this.bandedGridColumn48.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn48.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn48.Caption = "Pay Date";
            this.bandedGridColumn48.DisplayFormat.FormatString = "d";
            this.bandedGridColumn48.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn48.FieldName = "payDate8";
            this.bandedGridColumn48.MinWidth = 42;
            this.bandedGridColumn48.Name = "bandedGridColumn48";
            this.bandedGridColumn48.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn48.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn48.Visible = true;
            this.bandedGridColumn48.Width = 115;
            // 
            // bandedGridColumn49
            // 
            this.bandedGridColumn49.Caption = "Due Date";
            this.bandedGridColumn49.FieldName = "dueDate8";
            this.bandedGridColumn49.MinWidth = 25;
            this.bandedGridColumn49.Name = "bandedGridColumn49";
            this.bandedGridColumn49.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn49.Visible = true;
            this.bandedGridColumn49.Width = 94;
            // 
            // bandedGridColumn50
            // 
            this.bandedGridColumn50.Caption = "Beginning Balance";
            this.bandedGridColumn50.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn50.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn50.FieldName = "beginningBalance";
            this.bandedGridColumn50.MinWidth = 40;
            this.bandedGridColumn50.Name = "bandedGridColumn50";
            this.bandedGridColumn50.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn50.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn50.Visible = true;
            this.bandedGridColumn50.Width = 149;
            // 
            // bandedGridColumn51
            // 
            this.bandedGridColumn51.Caption = "Trust 50%";
            this.bandedGridColumn51.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn51.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn51.FieldName = "trust50";
            this.bandedGridColumn51.MinWidth = 25;
            this.bandedGridColumn51.Name = "bandedGridColumn51";
            this.bandedGridColumn51.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn51.Visible = true;
            this.bandedGridColumn51.Width = 121;
            // 
            // bandedGridColumn52
            // 
            this.bandedGridColumn52.Caption = "Trust 85%";
            this.bandedGridColumn52.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn52.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn52.FieldName = "trust85";
            this.bandedGridColumn52.MinWidth = 40;
            this.bandedGridColumn52.Name = "bandedGridColumn52";
            this.bandedGridColumn52.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn52.Visible = true;
            this.bandedGridColumn52.Width = 116;
            // 
            // bandedGridColumn53
            // 
            this.bandedGridColumn53.Caption = "Contract Value";
            this.bandedGridColumn53.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn53.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn53.FieldName = "contractValue";
            this.bandedGridColumn53.MinWidth = 25;
            this.bandedGridColumn53.Name = "bandedGridColumn53";
            this.bandedGridColumn53.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn53.Visible = true;
            this.bandedGridColumn53.Width = 94;
            // 
            // bandedGridColumn54
            // 
            this.bandedGridColumn54.Caption = "Remaining Balance";
            this.bandedGridColumn54.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn54.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn54.FieldName = "balanceDue";
            this.bandedGridColumn54.MinWidth = 25;
            this.bandedGridColumn54.Name = "bandedGridColumn54";
            this.bandedGridColumn54.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn54.Visible = true;
            this.bandedGridColumn54.Width = 94;
            // 
            // bandedGridColumn55
            // 
            this.bandedGridColumn55.Caption = "Allow Insurance";
            this.bandedGridColumn55.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn55.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn55.FieldName = "allowInsurance";
            this.bandedGridColumn55.MinWidth = 25;
            this.bandedGridColumn55.Name = "bandedGridColumn55";
            this.bandedGridColumn55.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn55.Visible = true;
            this.bandedGridColumn55.Width = 94;
            // 
            // bandedGridColumn56
            // 
            this.bandedGridColumn56.Caption = "Annuity";
            this.bandedGridColumn56.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn56.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn56.FieldName = "annuity";
            this.bandedGridColumn56.MinWidth = 25;
            this.bandedGridColumn56.Name = "bandedGridColumn56";
            this.bandedGridColumn56.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn56.Visible = true;
            this.bandedGridColumn56.Width = 94;
            // 
            // bandedGridColumn57
            // 
            this.bandedGridColumn57.Caption = "Lapsed";
            this.bandedGridColumn57.FieldName = "lapsed";
            this.bandedGridColumn57.MinWidth = 25;
            this.bandedGridColumn57.Name = "bandedGridColumn57";
            this.bandedGridColumn57.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn57.Visible = true;
            this.bandedGridColumn57.Width = 94;
            // 
            // bandedGridColumn58
            // 
            this.bandedGridColumn58.Caption = "Is2002";
            this.bandedGridColumn58.FieldName = "Is2002";
            this.bandedGridColumn58.MinWidth = 40;
            this.bandedGridColumn58.Name = "bandedGridColumn58";
            this.bandedGridColumn58.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn58.Visible = true;
            this.bandedGridColumn58.Width = 87;
            // 
            // bandedGridColumn130
            // 
            this.bandedGridColumn130.Caption = "riles";
            this.bandedGridColumn130.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.bandedGridColumn130.FieldName = "riles";
            this.bandedGridColumn130.MinWidth = 29;
            this.bandedGridColumn130.Name = "bandedGridColumn130";
            this.bandedGridColumn130.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn130.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn130.Visible = true;
            this.bandedGridColumn130.Width = 77;
            // 
            // bandedGridColumn131
            // 
            this.bandedGridColumn131.MinWidth = 23;
            this.bandedGridColumn131.Name = "bandedGridColumn131";
            this.bandedGridColumn131.Width = 87;
            // 
            // bandedGridColumn132
            // 
            this.bandedGridColumn132.MinWidth = 23;
            this.bandedGridColumn132.Name = "bandedGridColumn132";
            this.bandedGridColumn132.Width = 87;
            // 
            // bandedGridColumn133
            // 
            this.bandedGridColumn133.MinWidth = 23;
            this.bandedGridColumn133.Name = "bandedGridColumn133";
            this.bandedGridColumn133.Width = 87;
            // 
            // bandedGridColumn147
            // 
            this.bandedGridColumn147.Caption = "Issue Date";
            this.bandedGridColumn147.FieldName = "MyIssueDate";
            this.bandedGridColumn147.MinWidth = 25;
            this.bandedGridColumn147.Name = "bandedGridColumn147";
            this.bandedGridColumn147.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn147.Visible = true;
            this.bandedGridColumn147.Width = 94;
            // 
            // bandedGridColumn148
            // 
            this.bandedGridColumn148.Caption = "Trust & ins";
            this.bandedGridColumn148.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn148.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn148.FieldName = "TandI";
            this.bandedGridColumn148.MinWidth = 25;
            this.bandedGridColumn148.Name = "bandedGridColumn148";
            this.bandedGridColumn148.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn148.Visible = true;
            this.bandedGridColumn148.Width = 68;
            // 
            // bandedGridColumn181
            // 
            this.bandedGridColumn181.Caption = "Ins Only";
            this.bandedGridColumn181.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn181.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn181.FieldName = "insOnly";
            this.bandedGridColumn181.MinWidth = 25;
            this.bandedGridColumn181.Name = "bandedGridColumn181";
            this.bandedGridColumn181.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn181.Visible = true;
            this.bandedGridColumn181.Width = 63;
            // 
            // bandedGridColumn201
            // 
            this.bandedGridColumn201.Caption = "Trust Only";
            this.bandedGridColumn201.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn201.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn201.FieldName = "trustOnly";
            this.bandedGridColumn201.MinWidth = 25;
            this.bandedGridColumn201.Name = "bandedGridColumn201";
            this.bandedGridColumn201.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn201.Visible = true;
            this.bandedGridColumn201.Width = 64;
            // 
            // bandedGridColumn202
            // 
            this.bandedGridColumn202.Caption = "Annuity Only";
            this.bandedGridColumn202.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn202.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn202.FieldName = "annOnly";
            this.bandedGridColumn202.MinWidth = 25;
            this.bandedGridColumn202.Name = "bandedGridColumn202";
            this.bandedGridColumn202.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn202.Visible = true;
            this.bandedGridColumn202.Width = 61;
            // 
            // bandedGridColumn203
            // 
            this.bandedGridColumn203.Caption = "Ins and Annuity";
            this.bandedGridColumn203.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn203.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn203.FieldName = "IandA";
            this.bandedGridColumn203.MinWidth = 25;
            this.bandedGridColumn203.Name = "bandedGridColumn203";
            this.bandedGridColumn203.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn203.Visible = true;
            this.bandedGridColumn203.Width = 70;
            // 
            // bandedGridColumn204
            // 
            this.bandedGridColumn204.Caption = "First Name";
            this.bandedGridColumn204.FieldName = "firstName";
            this.bandedGridColumn204.MinWidth = 29;
            this.bandedGridColumn204.Name = "bandedGridColumn204";
            this.bandedGridColumn204.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn204.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn204.Width = 110;
            // 
            // bandedGridColumn205
            // 
            this.bandedGridColumn205.Caption = "Last Name";
            this.bandedGridColumn205.FieldName = "lastName";
            this.bandedGridColumn205.MinWidth = 29;
            this.bandedGridColumn205.Name = "bandedGridColumn205";
            this.bandedGridColumn205.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn205.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn205.Width = 110;
            // 
            // repositoryItemComboBox4
            // 
            this.repositoryItemComboBox4.AutoHeight = false;
            this.repositoryItemComboBox4.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox4.Items.AddRange(new object[] {
            "None",
            "Pause"});
            this.repositoryItemComboBox4.Name = "repositoryItemComboBox4";
            // 
            // tabNMOC
            // 
            this.tabNMOC.Controls.Add(this.dgv5);
            this.tabNMOC.Location = new System.Drawing.Point(4, 25);
            this.tabNMOC.Name = "tabNMOC";
            this.tabNMOC.Size = new System.Drawing.Size(1800, 434);
            this.tabNMOC.TabIndex = 4;
            this.tabNMOC.Text = "NMOC";
            this.tabNMOC.UseVisualStyleBackColor = true;
            // 
            // dgv5
            // 
            this.dgv5.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv5.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv5.Location = new System.Drawing.Point(0, 0);
            this.dgv5.MainView = this.gridMain5;
            this.dgv5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv5.Name = "dgv5";
            this.dgv5.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox5});
            this.dgv5.Size = new System.Drawing.Size(1800, 434);
            this.dgv5.TabIndex = 5;
            this.dgv5.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain5});
            // 
            // gridMain5
            // 
            this.gridMain5.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain5.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain5.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain5.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain5.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain5.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain5.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain5.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain5.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain5.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain5.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain5.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain5.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain5.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain5.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain5.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain5.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain5.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain5.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain5.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain5.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain5.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain5.Appearance.EvenRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain5.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.EvenRow.Options.UseBorderColor = true;
            this.gridMain5.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain5.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain5.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain5.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain5.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain5.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain5.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain5.Appearance.FilterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain5.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain5.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain5.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain5.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.gridMain5.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain5.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain5.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain5.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain5.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain5.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain5.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain5.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain5.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain5.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain5.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain5.Appearance.GroupPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain5.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain5.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain5.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain5.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain5.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain5.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain5.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain5.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain5.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain5.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(215)))));
            this.gridMain5.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain5.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain5.Appearance.HorzLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain5.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain5.Appearance.HorzLine.Options.UseBorderColor = true;
            this.gridMain5.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain5.Appearance.OddRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain5.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.OddRow.Options.UseBorderColor = true;
            this.gridMain5.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(240)))));
            this.gridMain5.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain5.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain5.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain5.Appearance.Preview.Options.UseFont = true;
            this.gridMain5.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain5.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain5.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.Row.Options.UseBackColor = true;
            this.gridMain5.Appearance.Row.Options.UseForeColor = true;
            this.gridMain5.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain5.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain5.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain5.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(201)))), ((int)(((byte)(207)))));
            this.gridMain5.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain5.Appearance.VertLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain5.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain5.Appearance.VertLine.Options.UseBorderColor = true;
            this.gridMain5.AppearancePrint.GroupRow.Font = new System.Drawing.Font("Tahoma", 7.8F);
            this.gridMain5.AppearancePrint.GroupRow.Options.UseFont = true;
            this.gridMain5.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain5.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain5.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand4});
            this.gridMain5.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn59,
            this.bandedGridColumn65,
            this.bandedGridColumn60,
            this.bandedGridColumn61,
            this.bandedGridColumn63,
            this.bandedGridColumn64,
            this.bandedGridColumn66,
            this.bandedGridColumn68,
            this.bandedGridColumn70,
            this.bandedGridColumn76,
            this.bandedGridColumn135,
            this.bandedGridColumn136,
            this.bandedGridColumn137,
            this.bandedGridColumn134,
            this.bandedGridColumn209,
            this.bandedGridColumn210,
            this.bandedGridColumn62,
            this.bandedGridColumn71,
            this.bandedGridColumn73,
            this.bandedGridColumn75,
            this.bandedGridColumn74,
            this.bandedGridColumn72,
            this.bandedGridColumn69,
            this.bandedGridColumn149,
            this.bandedGridColumn67,
            this.bandedGridColumn150,
            this.bandedGridColumn182,
            this.bandedGridColumn206,
            this.bandedGridColumn207,
            this.bandedGridColumn208});
            this.gridMain5.DetailHeight = 431;
            this.gridMain5.GridControl = this.dgv5;
            this.gridMain5.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Custom, "downpayment", this.bandedGridColumn66, "", "3")});
            this.gridMain5.Name = "gridMain5";
            this.gridMain5.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain5.OptionsPrint.PrintBandHeader = false;
            this.gridMain5.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain5.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain5.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain5.OptionsView.ShowFooter = true;
            this.gridMain5.OptionsView.ShowGroupPanel = false;
            this.gridMain5.PaintStyleName = "Flat";
            this.gridMain5.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.gridMain_CustomSummaryCalculate);
            this.gridMain5.DoubleClick += new System.EventHandler(this.gMain_DoubleClick);
            // 
            // gridBand4
            // 
            this.gridBand4.Columns.Add(this.bandedGridColumn59);
            this.gridBand4.Columns.Add(this.bandedGridColumn60);
            this.gridBand4.Columns.Add(this.bandedGridColumn61);
            this.gridBand4.Columns.Add(this.bandedGridColumn62);
            this.gridBand4.Columns.Add(this.bandedGridColumn63);
            this.gridBand4.Columns.Add(this.bandedGridColumn64);
            this.gridBand4.Columns.Add(this.bandedGridColumn65);
            this.gridBand4.Columns.Add(this.bandedGridColumn66);
            this.gridBand4.Columns.Add(this.bandedGridColumn67);
            this.gridBand4.Columns.Add(this.bandedGridColumn68);
            this.gridBand4.Columns.Add(this.bandedGridColumn69);
            this.gridBand4.Columns.Add(this.bandedGridColumn70);
            this.gridBand4.Columns.Add(this.bandedGridColumn71);
            this.gridBand4.Columns.Add(this.bandedGridColumn72);
            this.gridBand4.Columns.Add(this.bandedGridColumn73);
            this.gridBand4.Columns.Add(this.bandedGridColumn74);
            this.gridBand4.Columns.Add(this.bandedGridColumn75);
            this.gridBand4.Columns.Add(this.bandedGridColumn76);
            this.gridBand4.Columns.Add(this.bandedGridColumn134);
            this.gridBand4.Columns.Add(this.bandedGridColumn135);
            this.gridBand4.Columns.Add(this.bandedGridColumn136);
            this.gridBand4.Columns.Add(this.bandedGridColumn137);
            this.gridBand4.Columns.Add(this.bandedGridColumn149);
            this.gridBand4.Columns.Add(this.bandedGridColumn150);
            this.gridBand4.Columns.Add(this.bandedGridColumn182);
            this.gridBand4.Columns.Add(this.bandedGridColumn206);
            this.gridBand4.Columns.Add(this.bandedGridColumn207);
            this.gridBand4.Columns.Add(this.bandedGridColumn208);
            this.gridBand4.MinWidth = 22;
            this.gridBand4.Name = "gridBand4";
            this.gridBand4.VisibleIndex = 0;
            this.gridBand4.Width = 2381;
            // 
            // bandedGridColumn59
            // 
            this.bandedGridColumn59.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn59.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn59.Caption = "Num";
            this.bandedGridColumn59.FieldName = "num";
            this.bandedGridColumn59.MinWidth = 42;
            this.bandedGridColumn59.Name = "bandedGridColumn59";
            this.bandedGridColumn59.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn59.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn59.Visible = true;
            this.bandedGridColumn59.Width = 77;
            // 
            // bandedGridColumn60
            // 
            this.bandedGridColumn60.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn60.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn60.Caption = "Date";
            this.bandedGridColumn60.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn60.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn60.FieldName = "issueDate8";
            this.bandedGridColumn60.MinWidth = 42;
            this.bandedGridColumn60.Name = "bandedGridColumn60";
            this.bandedGridColumn60.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn60.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn60.Visible = true;
            this.bandedGridColumn60.Width = 96;
            // 
            // bandedGridColumn61
            // 
            this.bandedGridColumn61.Caption = "Location";
            this.bandedGridColumn61.FieldName = "location";
            this.bandedGridColumn61.MinWidth = 40;
            this.bandedGridColumn61.Name = "bandedGridColumn61";
            this.bandedGridColumn61.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn61.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn61.Visible = true;
            this.bandedGridColumn61.Width = 131;
            // 
            // bandedGridColumn62
            // 
            this.bandedGridColumn62.Caption = "Service Loc";
            this.bandedGridColumn62.FieldName = "serviceLoc";
            this.bandedGridColumn62.MinWidth = 29;
            this.bandedGridColumn62.Name = "bandedGridColumn62";
            this.bandedGridColumn62.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn62.Visible = true;
            this.bandedGridColumn62.Width = 148;
            // 
            // bandedGridColumn63
            // 
            this.bandedGridColumn63.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn63.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn63.Caption = "Contract";
            this.bandedGridColumn63.FieldName = "contractNumber";
            this.bandedGridColumn63.MinWidth = 42;
            this.bandedGridColumn63.Name = "bandedGridColumn63";
            this.bandedGridColumn63.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn63.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn63.Visible = true;
            this.bandedGridColumn63.Width = 154;
            // 
            // bandedGridColumn64
            // 
            this.bandedGridColumn64.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn64.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn64.Caption = "Contract Amount";
            this.bandedGridColumn64.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn64.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn64.FieldName = "paymentCurrMonth";
            this.bandedGridColumn64.MinWidth = 42;
            this.bandedGridColumn64.Name = "bandedGridColumn64";
            this.bandedGridColumn64.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn64.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn64.Visible = true;
            this.bandedGridColumn64.Width = 126;
            // 
            // bandedGridColumn65
            // 
            this.bandedGridColumn65.Caption = "record";
            this.bandedGridColumn65.FieldName = "record";
            this.bandedGridColumn65.MinWidth = 42;
            this.bandedGridColumn65.Name = "bandedGridColumn65";
            this.bandedGridColumn65.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn65.Width = 161;
            // 
            // bandedGridColumn66
            // 
            this.bandedGridColumn66.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn66.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn66.Caption = "Pay Date";
            this.bandedGridColumn66.DisplayFormat.FormatString = "d";
            this.bandedGridColumn66.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn66.FieldName = "payDate8";
            this.bandedGridColumn66.MinWidth = 42;
            this.bandedGridColumn66.Name = "bandedGridColumn66";
            this.bandedGridColumn66.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn66.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn66.Visible = true;
            this.bandedGridColumn66.Width = 115;
            // 
            // bandedGridColumn67
            // 
            this.bandedGridColumn67.Caption = "Due Date";
            this.bandedGridColumn67.FieldName = "dueDate8";
            this.bandedGridColumn67.MinWidth = 25;
            this.bandedGridColumn67.Name = "bandedGridColumn67";
            this.bandedGridColumn67.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn67.Visible = true;
            this.bandedGridColumn67.Width = 94;
            // 
            // bandedGridColumn68
            // 
            this.bandedGridColumn68.Caption = "Beginning Balance";
            this.bandedGridColumn68.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn68.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn68.FieldName = "beginningBalance";
            this.bandedGridColumn68.MinWidth = 40;
            this.bandedGridColumn68.Name = "bandedGridColumn68";
            this.bandedGridColumn68.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn68.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn68.Visible = true;
            this.bandedGridColumn68.Width = 149;
            // 
            // bandedGridColumn69
            // 
            this.bandedGridColumn69.Caption = "Trust 50%";
            this.bandedGridColumn69.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn69.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn69.FieldName = "trust50";
            this.bandedGridColumn69.MinWidth = 25;
            this.bandedGridColumn69.Name = "bandedGridColumn69";
            this.bandedGridColumn69.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn69.Visible = true;
            this.bandedGridColumn69.Width = 121;
            // 
            // bandedGridColumn70
            // 
            this.bandedGridColumn70.Caption = "Trust 85%";
            this.bandedGridColumn70.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn70.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn70.FieldName = "trust85";
            this.bandedGridColumn70.MinWidth = 40;
            this.bandedGridColumn70.Name = "bandedGridColumn70";
            this.bandedGridColumn70.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn70.Visible = true;
            this.bandedGridColumn70.Width = 116;
            // 
            // bandedGridColumn71
            // 
            this.bandedGridColumn71.Caption = "Contract Value";
            this.bandedGridColumn71.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn71.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn71.FieldName = "contractValue";
            this.bandedGridColumn71.MinWidth = 25;
            this.bandedGridColumn71.Name = "bandedGridColumn71";
            this.bandedGridColumn71.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn71.Visible = true;
            this.bandedGridColumn71.Width = 94;
            // 
            // bandedGridColumn72
            // 
            this.bandedGridColumn72.Caption = "Remaining Balance";
            this.bandedGridColumn72.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn72.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn72.FieldName = "balanceDue";
            this.bandedGridColumn72.MinWidth = 25;
            this.bandedGridColumn72.Name = "bandedGridColumn72";
            this.bandedGridColumn72.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn72.Visible = true;
            this.bandedGridColumn72.Width = 94;
            // 
            // bandedGridColumn73
            // 
            this.bandedGridColumn73.Caption = "Allow Insurance";
            this.bandedGridColumn73.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn73.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn73.FieldName = "allowInsurance";
            this.bandedGridColumn73.MinWidth = 25;
            this.bandedGridColumn73.Name = "bandedGridColumn73";
            this.bandedGridColumn73.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn73.Visible = true;
            this.bandedGridColumn73.Width = 94;
            // 
            // bandedGridColumn74
            // 
            this.bandedGridColumn74.Caption = "Annuity";
            this.bandedGridColumn74.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn74.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn74.FieldName = "annuity";
            this.bandedGridColumn74.MinWidth = 25;
            this.bandedGridColumn74.Name = "bandedGridColumn74";
            this.bandedGridColumn74.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn74.Visible = true;
            this.bandedGridColumn74.Width = 94;
            // 
            // bandedGridColumn75
            // 
            this.bandedGridColumn75.Caption = "Lapsed";
            this.bandedGridColumn75.FieldName = "lapsed";
            this.bandedGridColumn75.MinWidth = 25;
            this.bandedGridColumn75.Name = "bandedGridColumn75";
            this.bandedGridColumn75.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn75.Visible = true;
            this.bandedGridColumn75.Width = 94;
            // 
            // bandedGridColumn76
            // 
            this.bandedGridColumn76.Caption = "Is2002";
            this.bandedGridColumn76.FieldName = "Is2002";
            this.bandedGridColumn76.MinWidth = 40;
            this.bandedGridColumn76.Name = "bandedGridColumn76";
            this.bandedGridColumn76.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn76.Visible = true;
            this.bandedGridColumn76.Width = 87;
            // 
            // bandedGridColumn134
            // 
            this.bandedGridColumn134.Caption = "riles";
            this.bandedGridColumn134.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.bandedGridColumn134.FieldName = "riles";
            this.bandedGridColumn134.MinWidth = 29;
            this.bandedGridColumn134.Name = "bandedGridColumn134";
            this.bandedGridColumn134.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn134.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn134.Visible = true;
            this.bandedGridColumn134.Width = 77;
            // 
            // bandedGridColumn135
            // 
            this.bandedGridColumn135.MinWidth = 23;
            this.bandedGridColumn135.Name = "bandedGridColumn135";
            this.bandedGridColumn135.Width = 87;
            // 
            // bandedGridColumn136
            // 
            this.bandedGridColumn136.MinWidth = 23;
            this.bandedGridColumn136.Name = "bandedGridColumn136";
            this.bandedGridColumn136.Width = 87;
            // 
            // bandedGridColumn137
            // 
            this.bandedGridColumn137.MinWidth = 23;
            this.bandedGridColumn137.Name = "bandedGridColumn137";
            this.bandedGridColumn137.Width = 87;
            // 
            // bandedGridColumn149
            // 
            this.bandedGridColumn149.Caption = "Issue Date";
            this.bandedGridColumn149.FieldName = "MyIssueDate";
            this.bandedGridColumn149.MinWidth = 25;
            this.bandedGridColumn149.Name = "bandedGridColumn149";
            this.bandedGridColumn149.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn149.Visible = true;
            this.bandedGridColumn149.Width = 94;
            // 
            // bandedGridColumn150
            // 
            this.bandedGridColumn150.Caption = "Trust & ins";
            this.bandedGridColumn150.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn150.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn150.FieldName = "TandI";
            this.bandedGridColumn150.MinWidth = 25;
            this.bandedGridColumn150.Name = "bandedGridColumn150";
            this.bandedGridColumn150.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn150.Visible = true;
            this.bandedGridColumn150.Width = 68;
            // 
            // bandedGridColumn182
            // 
            this.bandedGridColumn182.Caption = "Ins Only";
            this.bandedGridColumn182.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn182.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn182.FieldName = "insOnly";
            this.bandedGridColumn182.MinWidth = 25;
            this.bandedGridColumn182.Name = "bandedGridColumn182";
            this.bandedGridColumn182.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn182.Visible = true;
            this.bandedGridColumn182.Width = 63;
            // 
            // bandedGridColumn206
            // 
            this.bandedGridColumn206.Caption = "Trust Only";
            this.bandedGridColumn206.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn206.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn206.FieldName = "trustOnly";
            this.bandedGridColumn206.MinWidth = 25;
            this.bandedGridColumn206.Name = "bandedGridColumn206";
            this.bandedGridColumn206.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn206.Visible = true;
            this.bandedGridColumn206.Width = 64;
            // 
            // bandedGridColumn207
            // 
            this.bandedGridColumn207.Caption = "Annuity Only";
            this.bandedGridColumn207.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn207.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn207.FieldName = "annOnly";
            this.bandedGridColumn207.MinWidth = 25;
            this.bandedGridColumn207.Name = "bandedGridColumn207";
            this.bandedGridColumn207.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn207.Visible = true;
            this.bandedGridColumn207.Width = 61;
            // 
            // bandedGridColumn208
            // 
            this.bandedGridColumn208.Caption = "Ins and Annuity";
            this.bandedGridColumn208.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn208.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn208.FieldName = "IandA";
            this.bandedGridColumn208.MinWidth = 25;
            this.bandedGridColumn208.Name = "bandedGridColumn208";
            this.bandedGridColumn208.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn208.Visible = true;
            this.bandedGridColumn208.Width = 70;
            // 
            // bandedGridColumn209
            // 
            this.bandedGridColumn209.Caption = "First Name";
            this.bandedGridColumn209.FieldName = "firstName";
            this.bandedGridColumn209.MinWidth = 29;
            this.bandedGridColumn209.Name = "bandedGridColumn209";
            this.bandedGridColumn209.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn209.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn209.Width = 110;
            // 
            // bandedGridColumn210
            // 
            this.bandedGridColumn210.Caption = "Last Name";
            this.bandedGridColumn210.FieldName = "lastName";
            this.bandedGridColumn210.MinWidth = 29;
            this.bandedGridColumn210.Name = "bandedGridColumn210";
            this.bandedGridColumn210.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn210.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn210.Width = 110;
            // 
            // repositoryItemComboBox5
            // 
            this.repositoryItemComboBox5.AutoHeight = false;
            this.repositoryItemComboBox5.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox5.Items.AddRange(new object[] {
            "None",
            "Pause"});
            this.repositoryItemComboBox5.Name = "repositoryItemComboBox5";
            // 
            // tabCem
            // 
            this.tabCem.Controls.Add(this.dgv6);
            this.tabCem.Location = new System.Drawing.Point(4, 25);
            this.tabCem.Name = "tabCem";
            this.tabCem.Size = new System.Drawing.Size(1800, 434);
            this.tabCem.TabIndex = 5;
            this.tabCem.Text = "cemeteries";
            this.tabCem.UseVisualStyleBackColor = true;
            // 
            // dgv6
            // 
            this.dgv6.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv6.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv6.Location = new System.Drawing.Point(0, 0);
            this.dgv6.MainView = this.gridMain6;
            this.dgv6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv6.Name = "dgv6";
            this.dgv6.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox6});
            this.dgv6.Size = new System.Drawing.Size(1800, 434);
            this.dgv6.TabIndex = 5;
            this.dgv6.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain6});
            // 
            // gridMain6
            // 
            this.gridMain6.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain6.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain6.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain6.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain6.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain6.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain6.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain6.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain6.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain6.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain6.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain6.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain6.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain6.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain6.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain6.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain6.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain6.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain6.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain6.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain6.Appearance.EvenRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain6.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.EvenRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain6.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain6.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain6.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain6.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain6.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain6.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.FilterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain6.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain6.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain6.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain6.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.gridMain6.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain6.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain6.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain6.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain6.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain6.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain6.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain6.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain6.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain6.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain6.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.GroupPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain6.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain6.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain6.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain6.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain6.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain6.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain6.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain6.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(215)))));
            this.gridMain6.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain6.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain6.Appearance.HorzLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain6.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain6.Appearance.HorzLine.Options.UseBorderColor = true;
            this.gridMain6.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain6.Appearance.OddRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain6.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.OddRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(240)))));
            this.gridMain6.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain6.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain6.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain6.Appearance.Preview.Options.UseFont = true;
            this.gridMain6.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain6.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain6.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.Row.Options.UseBackColor = true;
            this.gridMain6.Appearance.Row.Options.UseForeColor = true;
            this.gridMain6.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain6.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain6.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(201)))), ((int)(((byte)(207)))));
            this.gridMain6.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain6.Appearance.VertLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain6.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain6.Appearance.VertLine.Options.UseBorderColor = true;
            this.gridMain6.AppearancePrint.GroupRow.Font = new System.Drawing.Font("Tahoma", 7.8F);
            this.gridMain6.AppearancePrint.GroupRow.Options.UseFont = true;
            this.gridMain6.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain6.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain6.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand6});
            this.gridMain6.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn77,
            this.bandedGridColumn83,
            this.bandedGridColumn78,
            this.bandedGridColumn79,
            this.bandedGridColumn81,
            this.bandedGridColumn82,
            this.bandedGridColumn84,
            this.bandedGridColumn86,
            this.bandedGridColumn88,
            this.bandedGridColumn94,
            this.bandedGridColumn139,
            this.bandedGridColumn140,
            this.bandedGridColumn141,
            this.bandedGridColumn138,
            this.bandedGridColumn214,
            this.bandedGridColumn215,
            this.bandedGridColumn80,
            this.bandedGridColumn89,
            this.bandedGridColumn91,
            this.bandedGridColumn93,
            this.bandedGridColumn92,
            this.bandedGridColumn90,
            this.bandedGridColumn87,
            this.bandedGridColumn151,
            this.bandedGridColumn85,
            this.bandedGridColumn152,
            this.bandedGridColumn183,
            this.bandedGridColumn211,
            this.bandedGridColumn212,
            this.bandedGridColumn213});
            this.gridMain6.DetailHeight = 431;
            this.gridMain6.GridControl = this.dgv6;
            this.gridMain6.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Custom, "downpayment", this.bandedGridColumn84, "", "3")});
            this.gridMain6.Name = "gridMain6";
            this.gridMain6.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain6.OptionsPrint.PrintBandHeader = false;
            this.gridMain6.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain6.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain6.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain6.OptionsView.ShowFooter = true;
            this.gridMain6.OptionsView.ShowGroupPanel = false;
            this.gridMain6.PaintStyleName = "Flat";
            this.gridMain6.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.gridMain_CustomSummaryCalculate);
            this.gridMain6.DoubleClick += new System.EventHandler(this.gMain_DoubleClick);
            // 
            // gridBand6
            // 
            this.gridBand6.Columns.Add(this.bandedGridColumn77);
            this.gridBand6.Columns.Add(this.bandedGridColumn78);
            this.gridBand6.Columns.Add(this.bandedGridColumn79);
            this.gridBand6.Columns.Add(this.bandedGridColumn80);
            this.gridBand6.Columns.Add(this.bandedGridColumn81);
            this.gridBand6.Columns.Add(this.bandedGridColumn82);
            this.gridBand6.Columns.Add(this.bandedGridColumn83);
            this.gridBand6.Columns.Add(this.bandedGridColumn84);
            this.gridBand6.Columns.Add(this.bandedGridColumn85);
            this.gridBand6.Columns.Add(this.bandedGridColumn86);
            this.gridBand6.Columns.Add(this.bandedGridColumn87);
            this.gridBand6.Columns.Add(this.bandedGridColumn88);
            this.gridBand6.Columns.Add(this.bandedGridColumn89);
            this.gridBand6.Columns.Add(this.bandedGridColumn90);
            this.gridBand6.Columns.Add(this.bandedGridColumn91);
            this.gridBand6.Columns.Add(this.bandedGridColumn92);
            this.gridBand6.Columns.Add(this.bandedGridColumn93);
            this.gridBand6.Columns.Add(this.bandedGridColumn94);
            this.gridBand6.Columns.Add(this.bandedGridColumn138);
            this.gridBand6.Columns.Add(this.bandedGridColumn139);
            this.gridBand6.Columns.Add(this.bandedGridColumn140);
            this.gridBand6.Columns.Add(this.bandedGridColumn141);
            this.gridBand6.Columns.Add(this.bandedGridColumn151);
            this.gridBand6.Columns.Add(this.bandedGridColumn152);
            this.gridBand6.Columns.Add(this.bandedGridColumn183);
            this.gridBand6.Columns.Add(this.bandedGridColumn211);
            this.gridBand6.Columns.Add(this.bandedGridColumn212);
            this.gridBand6.Columns.Add(this.bandedGridColumn213);
            this.gridBand6.MinWidth = 22;
            this.gridBand6.Name = "gridBand6";
            this.gridBand6.VisibleIndex = 0;
            this.gridBand6.Width = 2381;
            // 
            // bandedGridColumn77
            // 
            this.bandedGridColumn77.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn77.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn77.Caption = "Num";
            this.bandedGridColumn77.FieldName = "num";
            this.bandedGridColumn77.MinWidth = 42;
            this.bandedGridColumn77.Name = "bandedGridColumn77";
            this.bandedGridColumn77.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn77.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn77.Visible = true;
            this.bandedGridColumn77.Width = 77;
            // 
            // bandedGridColumn78
            // 
            this.bandedGridColumn78.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn78.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn78.Caption = "Date";
            this.bandedGridColumn78.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn78.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn78.FieldName = "issueDate8";
            this.bandedGridColumn78.MinWidth = 42;
            this.bandedGridColumn78.Name = "bandedGridColumn78";
            this.bandedGridColumn78.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn78.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn78.Visible = true;
            this.bandedGridColumn78.Width = 96;
            // 
            // bandedGridColumn79
            // 
            this.bandedGridColumn79.Caption = "Location";
            this.bandedGridColumn79.FieldName = "location";
            this.bandedGridColumn79.MinWidth = 40;
            this.bandedGridColumn79.Name = "bandedGridColumn79";
            this.bandedGridColumn79.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn79.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn79.Visible = true;
            this.bandedGridColumn79.Width = 131;
            // 
            // bandedGridColumn80
            // 
            this.bandedGridColumn80.Caption = "Service Loc";
            this.bandedGridColumn80.FieldName = "serviceLoc";
            this.bandedGridColumn80.MinWidth = 29;
            this.bandedGridColumn80.Name = "bandedGridColumn80";
            this.bandedGridColumn80.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn80.Visible = true;
            this.bandedGridColumn80.Width = 148;
            // 
            // bandedGridColumn81
            // 
            this.bandedGridColumn81.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn81.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn81.Caption = "Contract";
            this.bandedGridColumn81.FieldName = "contractNumber";
            this.bandedGridColumn81.MinWidth = 42;
            this.bandedGridColumn81.Name = "bandedGridColumn81";
            this.bandedGridColumn81.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn81.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn81.Visible = true;
            this.bandedGridColumn81.Width = 154;
            // 
            // bandedGridColumn82
            // 
            this.bandedGridColumn82.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn82.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn82.Caption = "Contract Amount";
            this.bandedGridColumn82.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn82.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn82.FieldName = "paymentCurrMonth";
            this.bandedGridColumn82.MinWidth = 42;
            this.bandedGridColumn82.Name = "bandedGridColumn82";
            this.bandedGridColumn82.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn82.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn82.Visible = true;
            this.bandedGridColumn82.Width = 126;
            // 
            // bandedGridColumn83
            // 
            this.bandedGridColumn83.Caption = "record";
            this.bandedGridColumn83.FieldName = "record";
            this.bandedGridColumn83.MinWidth = 42;
            this.bandedGridColumn83.Name = "bandedGridColumn83";
            this.bandedGridColumn83.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn83.Width = 161;
            // 
            // bandedGridColumn84
            // 
            this.bandedGridColumn84.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn84.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn84.Caption = "Pay Date";
            this.bandedGridColumn84.DisplayFormat.FormatString = "d";
            this.bandedGridColumn84.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn84.FieldName = "payDate8";
            this.bandedGridColumn84.MinWidth = 42;
            this.bandedGridColumn84.Name = "bandedGridColumn84";
            this.bandedGridColumn84.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn84.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn84.Visible = true;
            this.bandedGridColumn84.Width = 115;
            // 
            // bandedGridColumn85
            // 
            this.bandedGridColumn85.Caption = "Due Date";
            this.bandedGridColumn85.FieldName = "dueDate8";
            this.bandedGridColumn85.MinWidth = 25;
            this.bandedGridColumn85.Name = "bandedGridColumn85";
            this.bandedGridColumn85.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn85.Visible = true;
            this.bandedGridColumn85.Width = 94;
            // 
            // bandedGridColumn86
            // 
            this.bandedGridColumn86.Caption = "Beginning Balance";
            this.bandedGridColumn86.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn86.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn86.FieldName = "beginningBalance";
            this.bandedGridColumn86.MinWidth = 40;
            this.bandedGridColumn86.Name = "bandedGridColumn86";
            this.bandedGridColumn86.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn86.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn86.Visible = true;
            this.bandedGridColumn86.Width = 149;
            // 
            // bandedGridColumn87
            // 
            this.bandedGridColumn87.Caption = "Trust 50%";
            this.bandedGridColumn87.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn87.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn87.FieldName = "trust50";
            this.bandedGridColumn87.MinWidth = 25;
            this.bandedGridColumn87.Name = "bandedGridColumn87";
            this.bandedGridColumn87.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn87.Visible = true;
            this.bandedGridColumn87.Width = 121;
            // 
            // bandedGridColumn88
            // 
            this.bandedGridColumn88.Caption = "Trust 85%";
            this.bandedGridColumn88.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn88.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn88.FieldName = "trust85";
            this.bandedGridColumn88.MinWidth = 40;
            this.bandedGridColumn88.Name = "bandedGridColumn88";
            this.bandedGridColumn88.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn88.Visible = true;
            this.bandedGridColumn88.Width = 116;
            // 
            // bandedGridColumn89
            // 
            this.bandedGridColumn89.Caption = "Contract Value";
            this.bandedGridColumn89.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn89.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn89.FieldName = "contractValue";
            this.bandedGridColumn89.MinWidth = 25;
            this.bandedGridColumn89.Name = "bandedGridColumn89";
            this.bandedGridColumn89.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn89.Visible = true;
            this.bandedGridColumn89.Width = 94;
            // 
            // bandedGridColumn90
            // 
            this.bandedGridColumn90.Caption = "Remaining Balance";
            this.bandedGridColumn90.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn90.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn90.FieldName = "balanceDue";
            this.bandedGridColumn90.MinWidth = 25;
            this.bandedGridColumn90.Name = "bandedGridColumn90";
            this.bandedGridColumn90.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn90.Visible = true;
            this.bandedGridColumn90.Width = 94;
            // 
            // bandedGridColumn91
            // 
            this.bandedGridColumn91.Caption = "Allow Insurance";
            this.bandedGridColumn91.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn91.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn91.FieldName = "allowInsurance";
            this.bandedGridColumn91.MinWidth = 25;
            this.bandedGridColumn91.Name = "bandedGridColumn91";
            this.bandedGridColumn91.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn91.Visible = true;
            this.bandedGridColumn91.Width = 94;
            // 
            // bandedGridColumn92
            // 
            this.bandedGridColumn92.Caption = "Annuity";
            this.bandedGridColumn92.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn92.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn92.FieldName = "annuity";
            this.bandedGridColumn92.MinWidth = 25;
            this.bandedGridColumn92.Name = "bandedGridColumn92";
            this.bandedGridColumn92.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn92.Visible = true;
            this.bandedGridColumn92.Width = 94;
            // 
            // bandedGridColumn93
            // 
            this.bandedGridColumn93.Caption = "Lapsed";
            this.bandedGridColumn93.FieldName = "lapsed";
            this.bandedGridColumn93.MinWidth = 25;
            this.bandedGridColumn93.Name = "bandedGridColumn93";
            this.bandedGridColumn93.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn93.Visible = true;
            this.bandedGridColumn93.Width = 94;
            // 
            // bandedGridColumn94
            // 
            this.bandedGridColumn94.Caption = "Is2002";
            this.bandedGridColumn94.FieldName = "Is2002";
            this.bandedGridColumn94.MinWidth = 40;
            this.bandedGridColumn94.Name = "bandedGridColumn94";
            this.bandedGridColumn94.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn94.Visible = true;
            this.bandedGridColumn94.Width = 87;
            // 
            // bandedGridColumn138
            // 
            this.bandedGridColumn138.Caption = "riles";
            this.bandedGridColumn138.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.bandedGridColumn138.FieldName = "riles";
            this.bandedGridColumn138.MinWidth = 29;
            this.bandedGridColumn138.Name = "bandedGridColumn138";
            this.bandedGridColumn138.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn138.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn138.Visible = true;
            this.bandedGridColumn138.Width = 77;
            // 
            // bandedGridColumn139
            // 
            this.bandedGridColumn139.MinWidth = 23;
            this.bandedGridColumn139.Name = "bandedGridColumn139";
            this.bandedGridColumn139.Width = 87;
            // 
            // bandedGridColumn140
            // 
            this.bandedGridColumn140.MinWidth = 23;
            this.bandedGridColumn140.Name = "bandedGridColumn140";
            this.bandedGridColumn140.Width = 87;
            // 
            // bandedGridColumn141
            // 
            this.bandedGridColumn141.MinWidth = 23;
            this.bandedGridColumn141.Name = "bandedGridColumn141";
            this.bandedGridColumn141.Width = 87;
            // 
            // bandedGridColumn151
            // 
            this.bandedGridColumn151.Caption = "Issue Date";
            this.bandedGridColumn151.FieldName = "MyIssueDate";
            this.bandedGridColumn151.MinWidth = 25;
            this.bandedGridColumn151.Name = "bandedGridColumn151";
            this.bandedGridColumn151.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn151.Visible = true;
            this.bandedGridColumn151.Width = 94;
            // 
            // bandedGridColumn152
            // 
            this.bandedGridColumn152.Caption = "Trust & ins";
            this.bandedGridColumn152.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn152.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn152.FieldName = "TandI";
            this.bandedGridColumn152.MinWidth = 25;
            this.bandedGridColumn152.Name = "bandedGridColumn152";
            this.bandedGridColumn152.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn152.Visible = true;
            this.bandedGridColumn152.Width = 68;
            // 
            // bandedGridColumn183
            // 
            this.bandedGridColumn183.Caption = "Ins Only";
            this.bandedGridColumn183.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn183.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn183.FieldName = "insOnly";
            this.bandedGridColumn183.MinWidth = 25;
            this.bandedGridColumn183.Name = "bandedGridColumn183";
            this.bandedGridColumn183.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn183.Visible = true;
            this.bandedGridColumn183.Width = 63;
            // 
            // bandedGridColumn211
            // 
            this.bandedGridColumn211.Caption = "Trust Only";
            this.bandedGridColumn211.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn211.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn211.FieldName = "trustOnly";
            this.bandedGridColumn211.MinWidth = 25;
            this.bandedGridColumn211.Name = "bandedGridColumn211";
            this.bandedGridColumn211.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn211.Visible = true;
            this.bandedGridColumn211.Width = 64;
            // 
            // bandedGridColumn212
            // 
            this.bandedGridColumn212.Caption = "Annuity Only";
            this.bandedGridColumn212.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn212.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn212.FieldName = "annOnly";
            this.bandedGridColumn212.MinWidth = 25;
            this.bandedGridColumn212.Name = "bandedGridColumn212";
            this.bandedGridColumn212.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn212.Visible = true;
            this.bandedGridColumn212.Width = 61;
            // 
            // bandedGridColumn213
            // 
            this.bandedGridColumn213.Caption = "Ins and Annuity";
            this.bandedGridColumn213.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn213.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn213.FieldName = "IandA";
            this.bandedGridColumn213.MinWidth = 25;
            this.bandedGridColumn213.Name = "bandedGridColumn213";
            this.bandedGridColumn213.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn213.Visible = true;
            this.bandedGridColumn213.Width = 70;
            // 
            // bandedGridColumn214
            // 
            this.bandedGridColumn214.Caption = "First Name";
            this.bandedGridColumn214.FieldName = "firstName";
            this.bandedGridColumn214.MinWidth = 29;
            this.bandedGridColumn214.Name = "bandedGridColumn214";
            this.bandedGridColumn214.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn214.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn214.Width = 110;
            // 
            // bandedGridColumn215
            // 
            this.bandedGridColumn215.Caption = "Last Name";
            this.bandedGridColumn215.FieldName = "lastName";
            this.bandedGridColumn215.MinWidth = 29;
            this.bandedGridColumn215.Name = "bandedGridColumn215";
            this.bandedGridColumn215.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn215.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn215.Width = 110;
            // 
            // repositoryItemComboBox6
            // 
            this.repositoryItemComboBox6.AutoHeight = false;
            this.repositoryItemComboBox6.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox6.Items.AddRange(new object[] {
            "None",
            "Pause"});
            this.repositoryItemComboBox6.Name = "repositoryItemComboBox6";
            // 
            // tabAFA
            // 
            this.tabAFA.Controls.Add(this.dgv8);
            this.tabAFA.Location = new System.Drawing.Point(4, 25);
            this.tabAFA.Name = "tabAFA";
            this.tabAFA.Size = new System.Drawing.Size(1800, 434);
            this.tabAFA.TabIndex = 7;
            this.tabAFA.Text = "AFA";
            this.tabAFA.UseVisualStyleBackColor = true;
            // 
            // dgv8
            // 
            this.dgv8.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv8.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv8.Location = new System.Drawing.Point(0, 0);
            this.dgv8.MainView = this.gridMain8;
            this.dgv8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv8.Name = "dgv8";
            this.dgv8.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox8});
            this.dgv8.Size = new System.Drawing.Size(1800, 434);
            this.dgv8.TabIndex = 5;
            this.dgv8.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain8});
            // 
            // gridMain8
            // 
            this.gridMain8.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain8.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain8.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain8.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain8.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain8.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain8.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain8.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain8.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain8.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain8.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain8.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain8.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain8.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain8.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain8.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain8.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain8.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain8.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain8.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain8.Appearance.EvenRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain8.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.EvenRow.Options.UseBorderColor = true;
            this.gridMain8.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain8.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain8.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain8.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain8.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain8.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain8.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.FilterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain8.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain8.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain8.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain8.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain8.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.gridMain8.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain8.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain8.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain8.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain8.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain8.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain8.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain8.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain8.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain8.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain8.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain8.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain8.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.GroupPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain8.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain8.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain8.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain8.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain8.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain8.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain8.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain8.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain8.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(215)))));
            this.gridMain8.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain8.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain8.Appearance.HorzLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain8.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain8.Appearance.HorzLine.Options.UseBorderColor = true;
            this.gridMain8.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain8.Appearance.OddRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain8.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.OddRow.Options.UseBorderColor = true;
            this.gridMain8.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(240)))));
            this.gridMain8.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain8.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain8.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain8.Appearance.Preview.Options.UseFont = true;
            this.gridMain8.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain8.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain8.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.Row.Options.UseBackColor = true;
            this.gridMain8.Appearance.Row.Options.UseForeColor = true;
            this.gridMain8.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain8.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain8.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(201)))), ((int)(((byte)(207)))));
            this.gridMain8.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain8.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain8.Appearance.VertLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain8.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain8.Appearance.VertLine.Options.UseBorderColor = true;
            this.gridMain8.AppearancePrint.GroupRow.Font = new System.Drawing.Font("Tahoma", 7.8F);
            this.gridMain8.AppearancePrint.GroupRow.Options.UseFont = true;
            this.gridMain8.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain8.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain8.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand8});
            this.gridMain8.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn155,
            this.bandedGridColumn161,
            this.bandedGridColumn156,
            this.bandedGridColumn157,
            this.bandedGridColumn159,
            this.bandedGridColumn160,
            this.bandedGridColumn162,
            this.bandedGridColumn164,
            this.bandedGridColumn166,
            this.bandedGridColumn172,
            this.bandedGridColumn174,
            this.bandedGridColumn175,
            this.bandedGridColumn176,
            this.bandedGridColumn173,
            this.bandedGridColumn219,
            this.bandedGridColumn220,
            this.bandedGridColumn158,
            this.bandedGridColumn167,
            this.bandedGridColumn169,
            this.bandedGridColumn171,
            this.bandedGridColumn170,
            this.bandedGridColumn168,
            this.bandedGridColumn165,
            this.bandedGridColumn177,
            this.bandedGridColumn163,
            this.bandedGridColumn178,
            this.bandedGridColumn184,
            this.bandedGridColumn216,
            this.bandedGridColumn217,
            this.bandedGridColumn218});
            this.gridMain8.DetailHeight = 431;
            this.gridMain8.GridControl = this.dgv8;
            this.gridMain8.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Custom, "downpayment", this.bandedGridColumn162, "", "3")});
            this.gridMain8.Name = "gridMain8";
            this.gridMain8.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain8.OptionsPrint.PrintBandHeader = false;
            this.gridMain8.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain8.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain8.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain8.OptionsView.ShowFooter = true;
            this.gridMain8.OptionsView.ShowGroupPanel = false;
            this.gridMain8.PaintStyleName = "Flat";
            this.gridMain8.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.gridMain_CustomSummaryCalculate);
            this.gridMain8.DoubleClick += new System.EventHandler(this.gMain_DoubleClick);
            // 
            // gridBand8
            // 
            this.gridBand8.Columns.Add(this.bandedGridColumn155);
            this.gridBand8.Columns.Add(this.bandedGridColumn156);
            this.gridBand8.Columns.Add(this.bandedGridColumn157);
            this.gridBand8.Columns.Add(this.bandedGridColumn158);
            this.gridBand8.Columns.Add(this.bandedGridColumn159);
            this.gridBand8.Columns.Add(this.bandedGridColumn160);
            this.gridBand8.Columns.Add(this.bandedGridColumn161);
            this.gridBand8.Columns.Add(this.bandedGridColumn162);
            this.gridBand8.Columns.Add(this.bandedGridColumn163);
            this.gridBand8.Columns.Add(this.bandedGridColumn164);
            this.gridBand8.Columns.Add(this.bandedGridColumn165);
            this.gridBand8.Columns.Add(this.bandedGridColumn166);
            this.gridBand8.Columns.Add(this.bandedGridColumn167);
            this.gridBand8.Columns.Add(this.bandedGridColumn168);
            this.gridBand8.Columns.Add(this.bandedGridColumn169);
            this.gridBand8.Columns.Add(this.bandedGridColumn170);
            this.gridBand8.Columns.Add(this.bandedGridColumn171);
            this.gridBand8.Columns.Add(this.bandedGridColumn172);
            this.gridBand8.Columns.Add(this.bandedGridColumn173);
            this.gridBand8.Columns.Add(this.bandedGridColumn174);
            this.gridBand8.Columns.Add(this.bandedGridColumn175);
            this.gridBand8.Columns.Add(this.bandedGridColumn176);
            this.gridBand8.Columns.Add(this.bandedGridColumn177);
            this.gridBand8.Columns.Add(this.bandedGridColumn178);
            this.gridBand8.Columns.Add(this.bandedGridColumn184);
            this.gridBand8.Columns.Add(this.bandedGridColumn216);
            this.gridBand8.Columns.Add(this.bandedGridColumn217);
            this.gridBand8.Columns.Add(this.bandedGridColumn218);
            this.gridBand8.MinWidth = 22;
            this.gridBand8.Name = "gridBand8";
            this.gridBand8.VisibleIndex = 0;
            this.gridBand8.Width = 2381;
            // 
            // bandedGridColumn155
            // 
            this.bandedGridColumn155.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn155.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn155.Caption = "Num";
            this.bandedGridColumn155.FieldName = "num";
            this.bandedGridColumn155.MinWidth = 42;
            this.bandedGridColumn155.Name = "bandedGridColumn155";
            this.bandedGridColumn155.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn155.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn155.Visible = true;
            this.bandedGridColumn155.Width = 77;
            // 
            // bandedGridColumn156
            // 
            this.bandedGridColumn156.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn156.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn156.Caption = "Date";
            this.bandedGridColumn156.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn156.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn156.FieldName = "issueDate8";
            this.bandedGridColumn156.MinWidth = 42;
            this.bandedGridColumn156.Name = "bandedGridColumn156";
            this.bandedGridColumn156.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn156.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn156.Visible = true;
            this.bandedGridColumn156.Width = 96;
            // 
            // bandedGridColumn157
            // 
            this.bandedGridColumn157.Caption = "Location";
            this.bandedGridColumn157.FieldName = "location";
            this.bandedGridColumn157.MinWidth = 40;
            this.bandedGridColumn157.Name = "bandedGridColumn157";
            this.bandedGridColumn157.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn157.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn157.Visible = true;
            this.bandedGridColumn157.Width = 131;
            // 
            // bandedGridColumn158
            // 
            this.bandedGridColumn158.Caption = "Service Loc";
            this.bandedGridColumn158.FieldName = "serviceLoc";
            this.bandedGridColumn158.MinWidth = 29;
            this.bandedGridColumn158.Name = "bandedGridColumn158";
            this.bandedGridColumn158.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn158.Visible = true;
            this.bandedGridColumn158.Width = 148;
            // 
            // bandedGridColumn159
            // 
            this.bandedGridColumn159.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn159.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn159.Caption = "Contract";
            this.bandedGridColumn159.FieldName = "contractNumber";
            this.bandedGridColumn159.MinWidth = 42;
            this.bandedGridColumn159.Name = "bandedGridColumn159";
            this.bandedGridColumn159.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn159.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn159.Visible = true;
            this.bandedGridColumn159.Width = 154;
            // 
            // bandedGridColumn160
            // 
            this.bandedGridColumn160.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn160.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn160.Caption = "Contract Amount";
            this.bandedGridColumn160.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn160.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn160.FieldName = "paymentCurrMonth";
            this.bandedGridColumn160.MinWidth = 42;
            this.bandedGridColumn160.Name = "bandedGridColumn160";
            this.bandedGridColumn160.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn160.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn160.Visible = true;
            this.bandedGridColumn160.Width = 126;
            // 
            // bandedGridColumn161
            // 
            this.bandedGridColumn161.Caption = "record";
            this.bandedGridColumn161.FieldName = "record";
            this.bandedGridColumn161.MinWidth = 42;
            this.bandedGridColumn161.Name = "bandedGridColumn161";
            this.bandedGridColumn161.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn161.Width = 161;
            // 
            // bandedGridColumn162
            // 
            this.bandedGridColumn162.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn162.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn162.Caption = "Pay Date";
            this.bandedGridColumn162.DisplayFormat.FormatString = "d";
            this.bandedGridColumn162.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn162.FieldName = "payDate8";
            this.bandedGridColumn162.MinWidth = 42;
            this.bandedGridColumn162.Name = "bandedGridColumn162";
            this.bandedGridColumn162.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn162.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn162.Visible = true;
            this.bandedGridColumn162.Width = 115;
            // 
            // bandedGridColumn163
            // 
            this.bandedGridColumn163.Caption = "Due Date";
            this.bandedGridColumn163.FieldName = "dueDate8";
            this.bandedGridColumn163.MinWidth = 25;
            this.bandedGridColumn163.Name = "bandedGridColumn163";
            this.bandedGridColumn163.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn163.Visible = true;
            this.bandedGridColumn163.Width = 94;
            // 
            // bandedGridColumn164
            // 
            this.bandedGridColumn164.Caption = "Beginning Balance";
            this.bandedGridColumn164.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn164.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn164.FieldName = "beginningBalance";
            this.bandedGridColumn164.MinWidth = 40;
            this.bandedGridColumn164.Name = "bandedGridColumn164";
            this.bandedGridColumn164.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn164.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn164.Visible = true;
            this.bandedGridColumn164.Width = 149;
            // 
            // bandedGridColumn165
            // 
            this.bandedGridColumn165.Caption = "Trust 50%";
            this.bandedGridColumn165.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn165.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn165.FieldName = "trust50";
            this.bandedGridColumn165.MinWidth = 25;
            this.bandedGridColumn165.Name = "bandedGridColumn165";
            this.bandedGridColumn165.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn165.Visible = true;
            this.bandedGridColumn165.Width = 121;
            // 
            // bandedGridColumn166
            // 
            this.bandedGridColumn166.Caption = "Trust 85%";
            this.bandedGridColumn166.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn166.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn166.FieldName = "trust85";
            this.bandedGridColumn166.MinWidth = 40;
            this.bandedGridColumn166.Name = "bandedGridColumn166";
            this.bandedGridColumn166.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn166.Visible = true;
            this.bandedGridColumn166.Width = 116;
            // 
            // bandedGridColumn167
            // 
            this.bandedGridColumn167.Caption = "Contract Value";
            this.bandedGridColumn167.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn167.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn167.FieldName = "contractValue";
            this.bandedGridColumn167.MinWidth = 25;
            this.bandedGridColumn167.Name = "bandedGridColumn167";
            this.bandedGridColumn167.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn167.Visible = true;
            this.bandedGridColumn167.Width = 94;
            // 
            // bandedGridColumn168
            // 
            this.bandedGridColumn168.Caption = "Remaining Balance";
            this.bandedGridColumn168.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn168.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn168.FieldName = "balanceDue";
            this.bandedGridColumn168.MinWidth = 25;
            this.bandedGridColumn168.Name = "bandedGridColumn168";
            this.bandedGridColumn168.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn168.Visible = true;
            this.bandedGridColumn168.Width = 94;
            // 
            // bandedGridColumn169
            // 
            this.bandedGridColumn169.Caption = "Allow Insurance";
            this.bandedGridColumn169.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn169.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn169.FieldName = "allowInsurance";
            this.bandedGridColumn169.MinWidth = 25;
            this.bandedGridColumn169.Name = "bandedGridColumn169";
            this.bandedGridColumn169.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn169.Visible = true;
            this.bandedGridColumn169.Width = 94;
            // 
            // bandedGridColumn170
            // 
            this.bandedGridColumn170.Caption = "Annuity";
            this.bandedGridColumn170.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn170.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn170.FieldName = "annuity";
            this.bandedGridColumn170.MinWidth = 25;
            this.bandedGridColumn170.Name = "bandedGridColumn170";
            this.bandedGridColumn170.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn170.Visible = true;
            this.bandedGridColumn170.Width = 94;
            // 
            // bandedGridColumn171
            // 
            this.bandedGridColumn171.Caption = "Lapsed";
            this.bandedGridColumn171.FieldName = "lapsed";
            this.bandedGridColumn171.MinWidth = 25;
            this.bandedGridColumn171.Name = "bandedGridColumn171";
            this.bandedGridColumn171.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn171.Visible = true;
            this.bandedGridColumn171.Width = 94;
            // 
            // bandedGridColumn172
            // 
            this.bandedGridColumn172.Caption = "Is2002";
            this.bandedGridColumn172.FieldName = "Is2002";
            this.bandedGridColumn172.MinWidth = 40;
            this.bandedGridColumn172.Name = "bandedGridColumn172";
            this.bandedGridColumn172.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn172.Visible = true;
            this.bandedGridColumn172.Width = 87;
            // 
            // bandedGridColumn173
            // 
            this.bandedGridColumn173.Caption = "riles";
            this.bandedGridColumn173.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.bandedGridColumn173.FieldName = "riles";
            this.bandedGridColumn173.MinWidth = 29;
            this.bandedGridColumn173.Name = "bandedGridColumn173";
            this.bandedGridColumn173.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn173.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn173.Visible = true;
            this.bandedGridColumn173.Width = 77;
            // 
            // bandedGridColumn174
            // 
            this.bandedGridColumn174.MinWidth = 23;
            this.bandedGridColumn174.Name = "bandedGridColumn174";
            this.bandedGridColumn174.Width = 87;
            // 
            // bandedGridColumn175
            // 
            this.bandedGridColumn175.MinWidth = 23;
            this.bandedGridColumn175.Name = "bandedGridColumn175";
            this.bandedGridColumn175.Width = 87;
            // 
            // bandedGridColumn176
            // 
            this.bandedGridColumn176.MinWidth = 23;
            this.bandedGridColumn176.Name = "bandedGridColumn176";
            this.bandedGridColumn176.Width = 87;
            // 
            // bandedGridColumn177
            // 
            this.bandedGridColumn177.Caption = "Issue Date";
            this.bandedGridColumn177.FieldName = "MyIssueDate";
            this.bandedGridColumn177.MinWidth = 25;
            this.bandedGridColumn177.Name = "bandedGridColumn177";
            this.bandedGridColumn177.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn177.Visible = true;
            this.bandedGridColumn177.Width = 94;
            // 
            // bandedGridColumn178
            // 
            this.bandedGridColumn178.Caption = "Trust & ins";
            this.bandedGridColumn178.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn178.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn178.FieldName = "TandI";
            this.bandedGridColumn178.MinWidth = 25;
            this.bandedGridColumn178.Name = "bandedGridColumn178";
            this.bandedGridColumn178.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn178.Visible = true;
            this.bandedGridColumn178.Width = 68;
            // 
            // bandedGridColumn184
            // 
            this.bandedGridColumn184.Caption = "Ins Only";
            this.bandedGridColumn184.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn184.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn184.FieldName = "insOnly";
            this.bandedGridColumn184.MinWidth = 25;
            this.bandedGridColumn184.Name = "bandedGridColumn184";
            this.bandedGridColumn184.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn184.Visible = true;
            this.bandedGridColumn184.Width = 63;
            // 
            // bandedGridColumn216
            // 
            this.bandedGridColumn216.Caption = "Trust Only";
            this.bandedGridColumn216.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn216.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn216.FieldName = "trustOnly";
            this.bandedGridColumn216.MinWidth = 25;
            this.bandedGridColumn216.Name = "bandedGridColumn216";
            this.bandedGridColumn216.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn216.Visible = true;
            this.bandedGridColumn216.Width = 64;
            // 
            // bandedGridColumn217
            // 
            this.bandedGridColumn217.Caption = "Annuity Only";
            this.bandedGridColumn217.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn217.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn217.FieldName = "annOnly";
            this.bandedGridColumn217.MinWidth = 25;
            this.bandedGridColumn217.Name = "bandedGridColumn217";
            this.bandedGridColumn217.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn217.Visible = true;
            this.bandedGridColumn217.Width = 61;
            // 
            // bandedGridColumn218
            // 
            this.bandedGridColumn218.Caption = "Ins and Annuity";
            this.bandedGridColumn218.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn218.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn218.FieldName = "IandA";
            this.bandedGridColumn218.MinWidth = 25;
            this.bandedGridColumn218.Name = "bandedGridColumn218";
            this.bandedGridColumn218.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn218.Visible = true;
            this.bandedGridColumn218.Width = 70;
            // 
            // bandedGridColumn219
            // 
            this.bandedGridColumn219.Caption = "First Name";
            this.bandedGridColumn219.FieldName = "firstName";
            this.bandedGridColumn219.MinWidth = 29;
            this.bandedGridColumn219.Name = "bandedGridColumn219";
            this.bandedGridColumn219.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn219.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn219.Width = 110;
            // 
            // bandedGridColumn220
            // 
            this.bandedGridColumn220.Caption = "Last Name";
            this.bandedGridColumn220.FieldName = "lastName";
            this.bandedGridColumn220.MinWidth = 29;
            this.bandedGridColumn220.Name = "bandedGridColumn220";
            this.bandedGridColumn220.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn220.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn220.Width = 110;
            // 
            // repositoryItemComboBox8
            // 
            this.repositoryItemComboBox8.AutoHeight = false;
            this.repositoryItemComboBox8.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox8.Items.AddRange(new object[] {
            "None",
            "Pause"});
            this.repositoryItemComboBox8.Name = "repositoryItemComboBox8";
            // 
            // tabNoContract
            // 
            this.tabNoContract.Controls.Add(this.dgv7);
            this.tabNoContract.Location = new System.Drawing.Point(4, 25);
            this.tabNoContract.Name = "tabNoContract";
            this.tabNoContract.Size = new System.Drawing.Size(1800, 434);
            this.tabNoContract.TabIndex = 6;
            this.tabNoContract.Text = "No Contract";
            this.tabNoContract.UseVisualStyleBackColor = true;
            // 
            // dgv7
            // 
            this.dgv7.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv7.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv7.Location = new System.Drawing.Point(0, 0);
            this.dgv7.MainView = this.gridMain7;
            this.dgv7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv7.Name = "dgv7";
            this.dgv7.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox7});
            this.dgv7.Size = new System.Drawing.Size(1800, 434);
            this.dgv7.TabIndex = 5;
            this.dgv7.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain7});
            // 
            // gridMain7
            // 
            this.gridMain7.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain7.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain7.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain7.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain7.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain7.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain7.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain7.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain7.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain7.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain7.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain7.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain7.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain7.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain7.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain7.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain7.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain7.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain7.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain7.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain7.Appearance.EvenRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(227)))), ((int)(((byte)(245)))));
            this.gridMain7.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.EvenRow.Options.UseBorderColor = true;
            this.gridMain7.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain7.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain7.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain7.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain7.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain7.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain7.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.FilterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain7.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain7.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain7.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain7.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.gridMain7.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain7.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(221)))), ((int)(((byte)(208)))));
            this.gridMain7.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain7.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain7.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(209)))), ((int)(((byte)(188)))));
            this.gridMain7.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain7.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain7.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain7.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain7.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain7.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.GroupPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain7.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(234)))), ((int)(((byte)(221)))));
            this.gridMain7.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain7.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain7.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain7.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(226)))), ((int)(((byte)(216)))));
            this.gridMain7.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain7.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain7.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain7.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(211)))), ((int)(((byte)(215)))));
            this.gridMain7.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain7.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain7.Appearance.HorzLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain7.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain7.Appearance.HorzLine.Options.UseBorderColor = true;
            this.gridMain7.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain7.Appearance.OddRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain7.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.OddRow.Options.UseBorderColor = true;
            this.gridMain7.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(240)))));
            this.gridMain7.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain7.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(104)))), ((int)(((byte)(130)))), ((int)(((byte)(134)))));
            this.gridMain7.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain7.Appearance.Preview.Options.UseFont = true;
            this.gridMain7.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain7.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain7.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.Row.Options.UseBackColor = true;
            this.gridMain7.Appearance.Row.Options.UseForeColor = true;
            this.gridMain7.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain7.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain7.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(159)))), ((int)(((byte)(201)))), ((int)(((byte)(207)))));
            this.gridMain7.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(197)))), ((int)(((byte)(180)))));
            this.gridMain7.Appearance.VertLine.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(117)))), ((int)(((byte)(136)))), ((int)(((byte)(122)))));
            this.gridMain7.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain7.Appearance.VertLine.Options.UseBorderColor = true;
            this.gridMain7.AppearancePrint.GroupRow.Font = new System.Drawing.Font("Tahoma", 7.8F);
            this.gridMain7.AppearancePrint.GroupRow.Options.UseFont = true;
            this.gridMain7.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain7.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain7.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand7});
            this.gridMain7.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn104,
            this.bandedGridColumn110,
            this.bandedGridColumn105,
            this.bandedGridColumn106,
            this.bandedGridColumn108,
            this.bandedGridColumn109,
            this.bandedGridColumn111,
            this.bandedGridColumn113,
            this.bandedGridColumn115,
            this.bandedGridColumn121,
            this.bandedGridColumn123,
            this.bandedGridColumn124,
            this.bandedGridColumn125,
            this.bandedGridColumn122,
            this.bandedGridColumn224,
            this.bandedGridColumn225,
            this.bandedGridColumn107,
            this.bandedGridColumn116,
            this.bandedGridColumn118,
            this.bandedGridColumn120,
            this.bandedGridColumn119,
            this.bandedGridColumn117,
            this.bandedGridColumn114,
            this.bandedGridColumn153,
            this.bandedGridColumn112,
            this.bandedGridColumn154,
            this.bandedGridColumn185,
            this.bandedGridColumn221,
            this.bandedGridColumn222,
            this.bandedGridColumn223});
            this.gridMain7.DetailHeight = 431;
            this.gridMain7.GridControl = this.dgv7;
            this.gridMain7.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Custom, "downpayment", this.bandedGridColumn111, "", "3")});
            this.gridMain7.Name = "gridMain7";
            this.gridMain7.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain7.OptionsPrint.PrintBandHeader = false;
            this.gridMain7.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain7.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain7.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain7.OptionsView.ShowFooter = true;
            this.gridMain7.OptionsView.ShowGroupPanel = false;
            this.gridMain7.PaintStyleName = "Flat";
            this.gridMain7.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.gridMain_CustomSummaryCalculate);
            this.gridMain7.DoubleClick += new System.EventHandler(this.gMain_DoubleClick);
            // 
            // gridBand7
            // 
            this.gridBand7.Columns.Add(this.bandedGridColumn104);
            this.gridBand7.Columns.Add(this.bandedGridColumn105);
            this.gridBand7.Columns.Add(this.bandedGridColumn106);
            this.gridBand7.Columns.Add(this.bandedGridColumn107);
            this.gridBand7.Columns.Add(this.bandedGridColumn108);
            this.gridBand7.Columns.Add(this.bandedGridColumn109);
            this.gridBand7.Columns.Add(this.bandedGridColumn110);
            this.gridBand7.Columns.Add(this.bandedGridColumn111);
            this.gridBand7.Columns.Add(this.bandedGridColumn112);
            this.gridBand7.Columns.Add(this.bandedGridColumn113);
            this.gridBand7.Columns.Add(this.bandedGridColumn114);
            this.gridBand7.Columns.Add(this.bandedGridColumn115);
            this.gridBand7.Columns.Add(this.bandedGridColumn116);
            this.gridBand7.Columns.Add(this.bandedGridColumn117);
            this.gridBand7.Columns.Add(this.bandedGridColumn118);
            this.gridBand7.Columns.Add(this.bandedGridColumn119);
            this.gridBand7.Columns.Add(this.bandedGridColumn120);
            this.gridBand7.Columns.Add(this.bandedGridColumn121);
            this.gridBand7.Columns.Add(this.bandedGridColumn122);
            this.gridBand7.Columns.Add(this.bandedGridColumn123);
            this.gridBand7.Columns.Add(this.bandedGridColumn124);
            this.gridBand7.Columns.Add(this.bandedGridColumn125);
            this.gridBand7.Columns.Add(this.bandedGridColumn153);
            this.gridBand7.Columns.Add(this.bandedGridColumn154);
            this.gridBand7.Columns.Add(this.bandedGridColumn185);
            this.gridBand7.Columns.Add(this.bandedGridColumn221);
            this.gridBand7.Columns.Add(this.bandedGridColumn222);
            this.gridBand7.Columns.Add(this.bandedGridColumn223);
            this.gridBand7.MinWidth = 22;
            this.gridBand7.Name = "gridBand7";
            this.gridBand7.VisibleIndex = 0;
            this.gridBand7.Width = 2381;
            // 
            // bandedGridColumn104
            // 
            this.bandedGridColumn104.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn104.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn104.Caption = "Num";
            this.bandedGridColumn104.FieldName = "num";
            this.bandedGridColumn104.MinWidth = 42;
            this.bandedGridColumn104.Name = "bandedGridColumn104";
            this.bandedGridColumn104.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn104.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn104.Visible = true;
            this.bandedGridColumn104.Width = 77;
            // 
            // bandedGridColumn105
            // 
            this.bandedGridColumn105.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn105.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn105.Caption = "Date";
            this.bandedGridColumn105.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn105.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn105.FieldName = "issueDate8";
            this.bandedGridColumn105.MinWidth = 42;
            this.bandedGridColumn105.Name = "bandedGridColumn105";
            this.bandedGridColumn105.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn105.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn105.Visible = true;
            this.bandedGridColumn105.Width = 96;
            // 
            // bandedGridColumn106
            // 
            this.bandedGridColumn106.Caption = "Location";
            this.bandedGridColumn106.FieldName = "location";
            this.bandedGridColumn106.MinWidth = 40;
            this.bandedGridColumn106.Name = "bandedGridColumn106";
            this.bandedGridColumn106.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn106.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn106.Visible = true;
            this.bandedGridColumn106.Width = 131;
            // 
            // bandedGridColumn107
            // 
            this.bandedGridColumn107.Caption = "Service Loc";
            this.bandedGridColumn107.FieldName = "serviceLoc";
            this.bandedGridColumn107.MinWidth = 29;
            this.bandedGridColumn107.Name = "bandedGridColumn107";
            this.bandedGridColumn107.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn107.Visible = true;
            this.bandedGridColumn107.Width = 148;
            // 
            // bandedGridColumn108
            // 
            this.bandedGridColumn108.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn108.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn108.Caption = "Contract";
            this.bandedGridColumn108.FieldName = "contractNumber";
            this.bandedGridColumn108.MinWidth = 42;
            this.bandedGridColumn108.Name = "bandedGridColumn108";
            this.bandedGridColumn108.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn108.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn108.Visible = true;
            this.bandedGridColumn108.Width = 154;
            // 
            // bandedGridColumn109
            // 
            this.bandedGridColumn109.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn109.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn109.Caption = "Contract Amount";
            this.bandedGridColumn109.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn109.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn109.FieldName = "paymentCurrMonth";
            this.bandedGridColumn109.MinWidth = 42;
            this.bandedGridColumn109.Name = "bandedGridColumn109";
            this.bandedGridColumn109.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn109.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn109.Visible = true;
            this.bandedGridColumn109.Width = 126;
            // 
            // bandedGridColumn110
            // 
            this.bandedGridColumn110.Caption = "record";
            this.bandedGridColumn110.FieldName = "record";
            this.bandedGridColumn110.MinWidth = 42;
            this.bandedGridColumn110.Name = "bandedGridColumn110";
            this.bandedGridColumn110.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn110.Width = 161;
            // 
            // bandedGridColumn111
            // 
            this.bandedGridColumn111.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn111.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn111.Caption = "Pay Date";
            this.bandedGridColumn111.DisplayFormat.FormatString = "d";
            this.bandedGridColumn111.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn111.FieldName = "payDate8";
            this.bandedGridColumn111.MinWidth = 42;
            this.bandedGridColumn111.Name = "bandedGridColumn111";
            this.bandedGridColumn111.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn111.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn111.Visible = true;
            this.bandedGridColumn111.Width = 115;
            // 
            // bandedGridColumn112
            // 
            this.bandedGridColumn112.Caption = "Due Date";
            this.bandedGridColumn112.FieldName = "dueDate8";
            this.bandedGridColumn112.MinWidth = 25;
            this.bandedGridColumn112.Name = "bandedGridColumn112";
            this.bandedGridColumn112.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn112.Visible = true;
            this.bandedGridColumn112.Width = 94;
            // 
            // bandedGridColumn113
            // 
            this.bandedGridColumn113.Caption = "Beginning Balance";
            this.bandedGridColumn113.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn113.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn113.FieldName = "beginningBalance";
            this.bandedGridColumn113.MinWidth = 40;
            this.bandedGridColumn113.Name = "bandedGridColumn113";
            this.bandedGridColumn113.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn113.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn113.Visible = true;
            this.bandedGridColumn113.Width = 149;
            // 
            // bandedGridColumn114
            // 
            this.bandedGridColumn114.Caption = "Trust 50%";
            this.bandedGridColumn114.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn114.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn114.FieldName = "trust50";
            this.bandedGridColumn114.MinWidth = 25;
            this.bandedGridColumn114.Name = "bandedGridColumn114";
            this.bandedGridColumn114.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn114.Visible = true;
            this.bandedGridColumn114.Width = 121;
            // 
            // bandedGridColumn115
            // 
            this.bandedGridColumn115.Caption = "Trust 85%";
            this.bandedGridColumn115.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn115.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn115.FieldName = "trust85";
            this.bandedGridColumn115.MinWidth = 40;
            this.bandedGridColumn115.Name = "bandedGridColumn115";
            this.bandedGridColumn115.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn115.Visible = true;
            this.bandedGridColumn115.Width = 116;
            // 
            // bandedGridColumn116
            // 
            this.bandedGridColumn116.Caption = "Contract Value";
            this.bandedGridColumn116.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn116.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn116.FieldName = "contractValue";
            this.bandedGridColumn116.MinWidth = 25;
            this.bandedGridColumn116.Name = "bandedGridColumn116";
            this.bandedGridColumn116.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn116.Visible = true;
            this.bandedGridColumn116.Width = 94;
            // 
            // bandedGridColumn117
            // 
            this.bandedGridColumn117.Caption = "Remaining Balance";
            this.bandedGridColumn117.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn117.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn117.FieldName = "balanceDue";
            this.bandedGridColumn117.MinWidth = 25;
            this.bandedGridColumn117.Name = "bandedGridColumn117";
            this.bandedGridColumn117.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn117.Visible = true;
            this.bandedGridColumn117.Width = 94;
            // 
            // bandedGridColumn118
            // 
            this.bandedGridColumn118.Caption = "Allow Insurance";
            this.bandedGridColumn118.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn118.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn118.FieldName = "allowInsurance";
            this.bandedGridColumn118.MinWidth = 25;
            this.bandedGridColumn118.Name = "bandedGridColumn118";
            this.bandedGridColumn118.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn118.Visible = true;
            this.bandedGridColumn118.Width = 94;
            // 
            // bandedGridColumn119
            // 
            this.bandedGridColumn119.Caption = "Annuity";
            this.bandedGridColumn119.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn119.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn119.FieldName = "annuity";
            this.bandedGridColumn119.MinWidth = 25;
            this.bandedGridColumn119.Name = "bandedGridColumn119";
            this.bandedGridColumn119.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn119.Visible = true;
            this.bandedGridColumn119.Width = 94;
            // 
            // bandedGridColumn120
            // 
            this.bandedGridColumn120.Caption = "Lapsed";
            this.bandedGridColumn120.FieldName = "lapsed";
            this.bandedGridColumn120.MinWidth = 25;
            this.bandedGridColumn120.Name = "bandedGridColumn120";
            this.bandedGridColumn120.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn120.Visible = true;
            this.bandedGridColumn120.Width = 94;
            // 
            // bandedGridColumn121
            // 
            this.bandedGridColumn121.Caption = "Is2002";
            this.bandedGridColumn121.FieldName = "Is2002";
            this.bandedGridColumn121.MinWidth = 40;
            this.bandedGridColumn121.Name = "bandedGridColumn121";
            this.bandedGridColumn121.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn121.Visible = true;
            this.bandedGridColumn121.Width = 87;
            // 
            // bandedGridColumn122
            // 
            this.bandedGridColumn122.Caption = "riles";
            this.bandedGridColumn122.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.bandedGridColumn122.FieldName = "riles";
            this.bandedGridColumn122.MinWidth = 29;
            this.bandedGridColumn122.Name = "bandedGridColumn122";
            this.bandedGridColumn122.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn122.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn122.Visible = true;
            this.bandedGridColumn122.Width = 77;
            // 
            // bandedGridColumn123
            // 
            this.bandedGridColumn123.MinWidth = 23;
            this.bandedGridColumn123.Name = "bandedGridColumn123";
            this.bandedGridColumn123.Width = 87;
            // 
            // bandedGridColumn124
            // 
            this.bandedGridColumn124.MinWidth = 23;
            this.bandedGridColumn124.Name = "bandedGridColumn124";
            this.bandedGridColumn124.Width = 87;
            // 
            // bandedGridColumn125
            // 
            this.bandedGridColumn125.MinWidth = 23;
            this.bandedGridColumn125.Name = "bandedGridColumn125";
            this.bandedGridColumn125.Width = 87;
            // 
            // bandedGridColumn153
            // 
            this.bandedGridColumn153.Caption = "Issue Date";
            this.bandedGridColumn153.FieldName = "MyIssueDate";
            this.bandedGridColumn153.MinWidth = 25;
            this.bandedGridColumn153.Name = "bandedGridColumn153";
            this.bandedGridColumn153.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn153.Visible = true;
            this.bandedGridColumn153.Width = 94;
            // 
            // bandedGridColumn154
            // 
            this.bandedGridColumn154.Caption = "Trust & ins";
            this.bandedGridColumn154.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn154.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn154.FieldName = "TandI";
            this.bandedGridColumn154.MinWidth = 25;
            this.bandedGridColumn154.Name = "bandedGridColumn154";
            this.bandedGridColumn154.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn154.Visible = true;
            this.bandedGridColumn154.Width = 68;
            // 
            // bandedGridColumn185
            // 
            this.bandedGridColumn185.Caption = "Ins Only";
            this.bandedGridColumn185.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn185.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn185.FieldName = "insOnly";
            this.bandedGridColumn185.MinWidth = 25;
            this.bandedGridColumn185.Name = "bandedGridColumn185";
            this.bandedGridColumn185.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn185.Visible = true;
            this.bandedGridColumn185.Width = 63;
            // 
            // bandedGridColumn221
            // 
            this.bandedGridColumn221.Caption = "Trust Only";
            this.bandedGridColumn221.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn221.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn221.FieldName = "trustOnly";
            this.bandedGridColumn221.MinWidth = 25;
            this.bandedGridColumn221.Name = "bandedGridColumn221";
            this.bandedGridColumn221.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn221.Visible = true;
            this.bandedGridColumn221.Width = 64;
            // 
            // bandedGridColumn222
            // 
            this.bandedGridColumn222.Caption = "Annuity Only";
            this.bandedGridColumn222.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn222.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn222.FieldName = "annOnly";
            this.bandedGridColumn222.MinWidth = 25;
            this.bandedGridColumn222.Name = "bandedGridColumn222";
            this.bandedGridColumn222.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn222.Visible = true;
            this.bandedGridColumn222.Width = 61;
            // 
            // bandedGridColumn223
            // 
            this.bandedGridColumn223.Caption = "Ins and Annuity";
            this.bandedGridColumn223.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn223.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn223.FieldName = "IandA";
            this.bandedGridColumn223.MinWidth = 25;
            this.bandedGridColumn223.Name = "bandedGridColumn223";
            this.bandedGridColumn223.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn223.Visible = true;
            this.bandedGridColumn223.Width = 70;
            // 
            // bandedGridColumn224
            // 
            this.bandedGridColumn224.Caption = "First Name";
            this.bandedGridColumn224.FieldName = "firstName";
            this.bandedGridColumn224.MinWidth = 29;
            this.bandedGridColumn224.Name = "bandedGridColumn224";
            this.bandedGridColumn224.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn224.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn224.Width = 110;
            // 
            // bandedGridColumn225
            // 
            this.bandedGridColumn225.Caption = "Last Name";
            this.bandedGridColumn225.FieldName = "lastName";
            this.bandedGridColumn225.MinWidth = 29;
            this.bandedGridColumn225.Name = "bandedGridColumn225";
            this.bandedGridColumn225.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn225.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn225.Width = 110;
            // 
            // repositoryItemComboBox7
            // 
            this.repositoryItemComboBox7.AutoHeight = false;
            this.repositoryItemComboBox7.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox7.Items.AddRange(new object[] {
            "None",
            "Pause"});
            this.repositoryItemComboBox7.Name = "repositoryItemComboBox7";
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.chkActiveOnly);
            this.panelTop.Controls.Add(this.chkIncludeRiles);
            this.panelTop.Controls.Add(this.chkRestoreDetail);
            this.panelTop.Controls.Add(this.cmbSelectColumns);
            this.panelTop.Controls.Add(this.btnSelectColumns);
            this.panelTop.Controls.Add(this.chkIncludeSMFS);
            this.panelTop.Controls.Add(this.chkCollapes);
            this.panelTop.Controls.Add(this.chkPageBreaks);
            this.panelTop.Controls.Add(this.label1);
            this.panelTop.Controls.Add(this.chkComboLocNames);
            this.panelTop.Controls.Add(this.btnRun);
            this.panelTop.Controls.Add(this.dateTimePicker2);
            this.panelTop.Controls.Add(this.btnRight);
            this.panelTop.Controls.Add(this.btnLeft);
            this.panelTop.Controls.Add(this.pictureBox1);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1808, 78);
            this.panelTop.TabIndex = 7;
            // 
            // chkRestoreDetail
            // 
            this.chkRestoreDetail.AutoSize = true;
            this.chkRestoreDetail.Location = new System.Drawing.Point(1263, 20);
            this.chkRestoreDetail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkRestoreDetail.Name = "chkRestoreDetail";
            this.chkRestoreDetail.Size = new System.Drawing.Size(114, 21);
            this.chkRestoreDetail.TabIndex = 161;
            this.chkRestoreDetail.Text = "Restore Detail";
            this.chkRestoreDetail.UseVisualStyleBackColor = true;
            this.chkRestoreDetail.CheckedChanged += new System.EventHandler(this.chkRestoreDetail_CheckedChanged);
            // 
            // cmbSelectColumns
            // 
            this.cmbSelectColumns.FormattingEnabled = true;
            this.cmbSelectColumns.Location = new System.Drawing.Point(950, 15);
            this.cmbSelectColumns.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbSelectColumns.Name = "cmbSelectColumns";
            this.cmbSelectColumns.Size = new System.Drawing.Size(179, 24);
            this.cmbSelectColumns.TabIndex = 160;
            this.cmbSelectColumns.SelectedIndexChanged += new System.EventHandler(this.cmbSelectColumns_SelectedIndexChanged);
            // 
            // btnSelectColumns
            // 
            this.btnSelectColumns.BackColor = System.Drawing.Color.PaleGreen;
            this.btnSelectColumns.Location = new System.Drawing.Point(1135, 14);
            this.btnSelectColumns.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSelectColumns.Name = "btnSelectColumns";
            this.btnSelectColumns.Size = new System.Drawing.Size(113, 28);
            this.btnSelectColumns.TabIndex = 159;
            this.btnSelectColumns.Text = "Select Columns";
            this.btnSelectColumns.UseVisualStyleBackColor = false;
            this.btnSelectColumns.Click += new System.EventHandler(this.btnSelectColumns_Click);
            // 
            // chkIncludeSMFS
            // 
            this.chkIncludeSMFS.AutoSize = true;
            this.chkIncludeSMFS.Checked = true;
            this.chkIncludeSMFS.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkIncludeSMFS.Location = new System.Drawing.Point(878, 46);
            this.chkIncludeSMFS.Name = "chkIncludeSMFS";
            this.chkIncludeSMFS.Size = new System.Drawing.Size(194, 21);
            this.chkIncludeSMFS.TabIndex = 158;
            this.chkIncludeSMFS.Text = "Include SMFS Active Trusts";
            this.chkIncludeSMFS.UseVisualStyleBackColor = true;
            // 
            // chkCollapes
            // 
            this.chkCollapes.AutoSize = true;
            this.chkCollapes.Location = new System.Drawing.Point(770, 46);
            this.chkCollapes.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkCollapes.Name = "chkCollapes";
            this.chkCollapes.Size = new System.Drawing.Size(79, 21);
            this.chkCollapes.TabIndex = 157;
            this.chkCollapes.Text = "Collapes";
            this.chkCollapes.UseVisualStyleBackColor = true;
            this.chkCollapes.CheckedChanged += new System.EventHandler(this.chkCollapes_CheckedChanged);
            // 
            // chkPageBreaks
            // 
            this.chkPageBreaks.AutoSize = true;
            this.chkPageBreaks.Checked = true;
            this.chkPageBreaks.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkPageBreaks.Location = new System.Drawing.Point(768, 20);
            this.chkPageBreaks.Name = "chkPageBreaks";
            this.chkPageBreaks.Size = new System.Drawing.Size(176, 21);
            this.chkPageBreaks.TabIndex = 156;
            this.chkPageBreaks.Text = "Page Break at Locations";
            this.chkPageBreaks.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(692, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 17);
            this.label1.TabIndex = 155;
            this.label1.Text = "Location";
            // 
            // chkComboLocNames
            // 
            this.chkComboLocNames.EditValue = "";
            this.chkComboLocNames.Location = new System.Drawing.Point(501, 17);
            this.chkComboLocNames.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkComboLocNames.Name = "chkComboLocNames";
            this.chkComboLocNames.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.chkComboLocNames.Properties.DisplayMember = "LocationCode";
            this.chkComboLocNames.Properties.SeparatorChar = '|';
            this.chkComboLocNames.Size = new System.Drawing.Size(185, 22);
            this.chkComboLocNames.TabIndex = 154;
            this.chkComboLocNames.EditValueChanged += new System.EventHandler(this.chkComboLocNames_EditValueChanged);
            // 
            // btnRun
            // 
            this.btnRun.BackColor = System.Drawing.Color.Honeydew;
            this.btnRun.Font = new System.Drawing.Font("Tahoma", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btnRun.Location = new System.Drawing.Point(394, 10);
            this.btnRun.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(87, 32);
            this.btnRun.TabIndex = 153;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = false;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(108, 14);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker2.TabIndex = 151;
            // 
            // btnRight
            // 
            this.btnRight.BackColor = System.Drawing.Color.Transparent;
            this.btnRight.Image = ((System.Drawing.Image)(resources.GetObject("btnRight.Image")));
            this.btnRight.Location = new System.Drawing.Point(343, 13);
            this.btnRight.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(33, 28);
            this.btnRight.TabIndex = 150;
            this.btnRight.UseVisualStyleBackColor = false;
            this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
            // 
            // btnLeft
            // 
            this.btnLeft.BackColor = System.Drawing.Color.Transparent;
            this.btnLeft.Image = ((System.Drawing.Image)(resources.GetObject("btnLeft.Image")));
            this.btnLeft.Location = new System.Drawing.Point(69, 12);
            this.btnLeft.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(33, 28);
            this.btnLeft.TabIndex = 149;
            this.btnLeft.UseVisualStyleBackColor = false;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 27);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 146;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // chkIncludeRiles
            // 
            this.chkIncludeRiles.AutoSize = true;
            this.chkIncludeRiles.Checked = true;
            this.chkIncludeRiles.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkIncludeRiles.Location = new System.Drawing.Point(1078, 46);
            this.chkIncludeRiles.Name = "chkIncludeRiles";
            this.chkIncludeRiles.Size = new System.Drawing.Size(146, 21);
            this.chkIncludeRiles.TabIndex = 162;
            this.chkIncludeRiles.Text = "Include Riles Trusts";
            this.chkIncludeRiles.UseVisualStyleBackColor = true;
            // 
            // chkActiveOnly
            // 
            this.chkActiveOnly.AutoSize = true;
            this.chkActiveOnly.Location = new System.Drawing.Point(1230, 46);
            this.chkActiveOnly.Name = "chkActiveOnly";
            this.chkActiveOnly.Size = new System.Drawing.Size(170, 21);
            this.chkActiveOnly.TabIndex = 163;
            this.chkActiveOnly.Text = "ShowSMFS Active Only";
            this.chkActiveOnly.UseVisualStyleBackColor = true;
            // 
            // TrustContractEOY
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1808, 569);
            this.Controls.Add(this.panelAll);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "TrustContractEOY";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trust Contract End of Year";
            this.Load += new System.EventHandler(this.TrustContractEOY_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelAll.ResumeLayout(false);
            this.panelBottom.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabDetail.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox3)).EndInit();
            this.tabSummary.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox9)).EndInit();
            this.tabPrePostRiles.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            this.tabHU.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).EndInit();
            this.tabJPN.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox4)).EndInit();
            this.tabNMOC.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox5)).EndInit();
            this.tabCem.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox6)).EndInit();
            this.tabAFA.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox8)).EndInit();
            this.tabNoContract.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox7)).EndInit();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboLocNames.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Panel panelAll;
        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevExpress.XtraGrid.GridControl dgv;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn7;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn12;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn9;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn11;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn14;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn13;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Button btnRight;
        private System.Windows.Forms.Button btnLeft;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraEditors.CheckedComboBoxEdit chkComboLocNames;
        private System.Windows.Forms.CheckBox chkPageBreaks;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn15;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn16;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn17;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabDetail;
        private System.Windows.Forms.TabPage tabPrePostRiles;
        private DevExpress.XtraGrid.GridControl dgv2;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn21;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn22;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn23;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn24;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn19;
        private System.Windows.Forms.TabPage tabHU;
        private System.Windows.Forms.TabPage tabJPN;
        private System.Windows.Forms.TabPage tabNMOC;
        private System.Windows.Forms.TabPage tabCem;
        private System.Windows.Forms.CheckBox chkCollapes;
        private System.Windows.Forms.CheckBox chkIncludeSMFS;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn95;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn96;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn97;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn98;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn99;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn100;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn101;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn102;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn103;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn142;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn143;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn144;
        private System.Windows.Forms.TabPage tabNoContract;
        private System.Windows.Forms.TabPage tabAFA;
        private System.Windows.Forms.ComboBox cmbSelectColumns;
        private System.Windows.Forms.Button btnSelectColumns;
        private System.Windows.Forms.ToolStripMenuItem screenOptionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lockScreenFormatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unlockScreenFormatToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn179;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn186;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn187;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn188;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn189;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn190;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn191;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn195;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn194;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn193;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn192;
        private DevExpress.XtraGrid.GridControl dgv3;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain3;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn18;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn20;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn25;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn26;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn27;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn28;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn29;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn30;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn31;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn32;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn33;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn34;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn35;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn36;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn37;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn38;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn39;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn40;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn126;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn127;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn128;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn129;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn145;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn146;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn180;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn196;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn197;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn198;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn199;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn200;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox2;
        private DevExpress.XtraGrid.GridControl dgv4;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain4;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn41;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn42;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn43;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn44;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn45;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn46;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn47;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn48;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn49;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn50;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn51;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn52;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn53;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn54;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn55;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn56;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn57;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn58;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn130;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn131;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn132;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn133;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn147;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn148;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn181;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn201;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn202;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn203;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn204;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn205;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox4;
        private DevExpress.XtraGrid.GridControl dgv5;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain5;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn59;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn60;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn61;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn62;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn63;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn64;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn65;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn66;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn67;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn68;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn69;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn70;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn71;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn72;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn73;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn74;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn75;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn76;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn134;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn135;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn136;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn137;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn149;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn150;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn182;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn206;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn207;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn208;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn209;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn210;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox5;
        private DevExpress.XtraGrid.GridControl dgv6;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain6;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn77;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn78;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn79;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn80;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn81;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn82;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn83;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn84;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn85;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn86;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn87;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn88;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn89;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn90;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn91;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn92;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn93;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn94;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn138;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn139;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn140;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn141;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn151;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn152;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn183;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn211;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn212;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn213;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn214;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn215;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox6;
        private DevExpress.XtraGrid.GridControl dgv8;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain8;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn155;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn156;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn157;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn158;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn159;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn160;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn161;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn162;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn163;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn164;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn165;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn166;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn167;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn168;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn169;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn170;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn171;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn172;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn173;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn174;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn175;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn176;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn177;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn178;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn184;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn216;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn217;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn218;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn219;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn220;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox8;
        private DevExpress.XtraGrid.GridControl dgv7;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain7;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand7;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn104;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn105;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn106;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn107;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn108;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn109;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn110;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn111;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn112;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn113;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn114;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn115;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn116;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn117;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn118;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn119;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn120;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn121;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn122;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn123;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn124;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn125;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn153;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn154;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn185;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn221;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn222;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn223;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn224;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn225;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox7;
        private System.Windows.Forms.TabPage tabSummary;
        private DevExpress.XtraGrid.GridControl dgv9;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain9;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand9;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn226;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn227;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn228;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn229;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn230;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn231;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn232;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn233;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn234;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn235;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn236;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn237;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn238;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn239;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn240;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox9;
        private System.Windows.Forms.CheckBox chkRestoreDetail;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn241;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn242;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn243;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn244;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn245;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn246;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn247;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn248;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn249;
        private System.Windows.Forms.CheckBox chkIncludeRiles;
        private System.Windows.Forms.CheckBox chkActiveOnly;
    }
}