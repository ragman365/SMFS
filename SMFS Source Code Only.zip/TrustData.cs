﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using GeneralLib;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.Xpo.Helpers;
using System.IO;
using ExcelLibrary.BinaryFileFormat;
using System.Security.Cryptography;
using DevExpress.XtraPrinting;
using DevExpress.Utils;
using MySql.Data.MySqlClient;
/***********************************************************************************************/
namespace SMFS
{
    /***********************************************************************************************/
    public partial class TrustData : DevExpress.XtraEditors.XtraForm
    {
        /***********************************************************************************************/
        private DataTable workDt = null;
        private string workWhat = "";
        private string title = "";
        private string workContract = "";
        private string workPolicy = "";
        /***********************************************************************************************/
        public TrustData( string contractNumber = "", string policyNumber = "" )
        {
            InitializeComponent();
            workContract = contractNumber;
            workPolicy = policyNumber;
            //workDt = dt;
            //workWhat = what;

            SetupTotalsSummary();

            barImport.Hide();

            //LoadMonths();
            //LoadYears();
        }
        /****************************************************************************************/
        private void SetupTotalsSummary()
        {
            AddSummaryColumn("beginningPaymentBalance", null);
            AddSummaryColumn("beginningDeathBenefit", null);
            AddSummaryColumn("endingPaymentBalance", null);
            AddSummaryColumn("endingDeathBenefit", null);
            AddSummaryColumn("downPayments", null);
            AddSummaryColumn("payments", null);
            AddSummaryColumn("growth", null);
            AddSummaryColumn("priorUnappliedCash", null);
            AddSummaryColumn("currentUnappliedCash", null);
            AddSummaryColumn("deathClaimAmount", null);
            AddSummaryColumn("endingBalance", null);
        }
        /****************************************************************************************/
        private void AddSummaryColumn(string columnName, string format = "")
        {
            if (String.IsNullOrWhiteSpace(format))
                format = "{0:0,0.00}";
            gridMain.Columns[columnName].SummaryItem.SummaryType = DevExpress.Data.SummaryItemType.Sum;
            gridMain.Columns[columnName].SummaryItem.DisplayFormat = format;
        }
        /***********************************************************************************************/
        private void TrustData_Load(object sender, EventArgs e)
        {
            btnSave.Hide();
            lblMonth.Hide();
            lblYear.Hide();
            cmbMonth.Hide();
            cmbYear.Hide();

            loadTrustCompanies();

            DateTime now = DateTime.Now;

            int days = DateTime.DaysInMonth(now.Year, now.Month);

            DateTime stop1 = new DateTime(now.Year, now.Month, days - 1);
            this.dateTimePicker1.Value = stop1;

            if (!String.IsNullOrWhiteSpace(workContract))
                LoadContract();
            if (!String.IsNullOrWhiteSpace(workPolicy))
                LoadPolicy();
        }
        /***********************************************************************************************/
        private void LoadContract ()
        {
            string cmd = "Select * from `trust_data` WHERE `contractNumber` = '" + workContract + "';";
            DataTable dx = G1.get_db_data(cmd);
            G1.NumberDataTable(dx);
            //gridMain.Columns["date"].Visible = true;
            dgv.DataSource = dx;
            //gridMain.RefreshData();
            //gridMain.RefreshEditor(true);
            //dgv.Refresh();
        }
        /***********************************************************************************************/
        private void LoadPolicy()
        {
            string cmd = "Select * from `trust_data` WHERE `policyNumber` = '" + workPolicy + "';";
            DataTable dx = G1.get_db_data(cmd);
            G1.NumberDataTable(dx);
            //gridMain.Columns["date"].Visible = true;
            dgv.DataSource = dx;
            //gridMain.RefreshData();
            //gridMain.RefreshEditor(true);
            //dgv.Refresh();
        }
        /***********************************************************************************************/
        private void loadTrustCompanies()
        {
            string cmd = "Select DISTINCT `trustCompany` from `trust_data`;";
            DataTable dt = G1.get_db_data(cmd);

            DataView tempview = dt.DefaultView;
            tempview.Sort = "trustCompany asc";
            dt = tempview.ToTable();

            chkCmbCompany.Properties.DataSource = dt;
        }
        /***********************************************************************************************/
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (dgv.Visible)
                G1.SpyGlass(gridMain);
        }
        /***********************************************************************************************/
        private void gridMain_CustomColumnDisplayText(object sender, DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventArgs e)
        {
            ColumnView view = sender as ColumnView;
            if (e.Column.FieldName.ToUpper().IndexOf("DATE") >= 0 && e.ListSourceRowIndex != DevExpress.XtraGrid.GridControl.InvalidRowHandle)
            {
                if (e.DisplayText.IndexOf("0000") >= 0 || e.DisplayText.IndexOf("0001") >= 0)
                    e.DisplayText = "";
                else
                {
                    DateTime date = e.DisplayText.ObjToString().ObjToDateTime();
                    e.DisplayText = date.ToString("MM/dd/yyyy");
                    if (date.Year < 30)
                        e.DisplayText = "";
                }
            }
        }
        /***********************************************************************************************/
        private void gridMain_DoubleClick(object sender, EventArgs e)
        {
            DataRow dr = gridMain.GetFocusedDataRow();
            string contract = dr["contractNumber"].ObjToString();
            if (!String.IsNullOrWhiteSpace(contract))
            {
                this.Cursor = Cursors.WaitCursor;
                string cmd = "Select * from `contracts` where `contractNumber` = '" + contract + "';";
                DataTable dx = G1.get_db_data(cmd);
                if (dx.Rows.Count <= 0)
                {
                    string cnum = contract.TrimStart('0');
                    cnum = cnum.Replace(" ", "");

                    cmd = "Select * from `icustomers` where `payer` = '" + cnum + "';";
                    dx = G1.get_db_data(cmd);
                    if (dx.Rows.Count > 0)
                        contract = dx.Rows[0]["contractNumber"].ObjToString();
                }
                CustomerDetails clientForm = new CustomerDetails(contract);
                clientForm.Show();
                this.Cursor = Cursors.Default;
            }
        }
        /***********************************************************************************************/
        private int pageMarginLeft = 0;
        private int pageMarginRight = 0;
        private int pageMarginTop = 0;
        private int pageMarginBottom = 0;
        private bool isPrinting = false;
        /***********************************************************************************************/
        private void printPreviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isPrinting = true;
            if (this.components == null)
                this.components = new System.ComponentModel.Container();

            DevExpress.XtraPrinting.PrintingSystem printingSystem1 = new DevExpress.XtraPrinting.PrintingSystem(this.components);
            DevExpress.XtraPrinting.PrintableComponentLink printableComponentLink1 = new DevExpress.XtraPrinting.PrintableComponentLink(this.components);

            printingSystem1.Links.AddRange(new object[] {
            printableComponentLink1});


            printableComponentLink1.Component = dgv;
            if ( dgv2.Visible )
                printableComponentLink1.Component = dgv2;
            else if (dgv3.Visible)
                printableComponentLink1.Component = dgv3;


            printableComponentLink1.PrintingSystemBase = printingSystem1;

            printableComponentLink1.EnablePageDialog = true;

            printableComponentLink1.CreateDetailHeaderArea += new DevExpress.XtraPrinting.CreateAreaEventHandler(this.printableComponentLink1_CreateDetailHeaderArea);
            printableComponentLink1.CreateMarginalHeaderArea += new DevExpress.XtraPrinting.CreateAreaEventHandler(this.printableComponentLink1_CreateMarginalHeaderArea);
            printableComponentLink1.BeforeCreateAreas += new System.EventHandler(this.printableComponentLink1_BeforeCreateAreas);
            printableComponentLink1.AfterCreateAreas += new System.EventHandler(this.printableComponentLink1_AfterCreateAreas);
            printableComponentLink1.Landscape = true;

            Printer.setupPrinterMargins(50, 100, 80, 50);

            pageMarginLeft = Printer.pageMarginLeft;
            pageMarginRight = Printer.pageMarginRight;
            pageMarginTop = Printer.pageMarginTop;
            pageMarginBottom = Printer.pageMarginBottom;

            printableComponentLink1.Margins.Left = pageMarginLeft;
            printableComponentLink1.Margins.Right = pageMarginRight;
            printableComponentLink1.Margins.Top = pageMarginTop;
            printableComponentLink1.Margins.Bottom = pageMarginBottom;

            printableComponentLink1.CreateDocument();
            printableComponentLink1.ShowPreview();
            isPrinting = false;
        }
        /***********************************************************************************************/
        private void printableComponentLink1_BeforeCreateAreas(object sender, EventArgs e)
        {
        }
        /***********************************************************************************************/
        private void printableComponentLink1_AfterCreateAreas(object sender, EventArgs e)
        {
        }
        /***********************************************************************************************/
        private void printableComponentLink1_CreateDetailHeaderArea(object sender, CreateAreaEventArgs e)
        {
        }
        /***********************************************************************************************/
        private void printableComponentLink1_CreateMarginalHeaderArea(object sender, CreateAreaEventArgs e)
        {
            Printer.setupPrinterQuads(e, 2, 3);
            Font font = new Font("Ariel", 16);
            Printer.DrawQuad(1, 1, Printer.xQuads, 2, "South Mississippi Funeral Services, LLC", Color.Black, BorderSide.Top, font, HorizontalAlignment.Center);

            Printer.SetQuadSize(12, 12);

            font = new Font("Ariel", 8);
            Printer.DrawGridDate(2, 3, 2, 3, Color.Black, BorderSide.None, font);
            Printer.DrawGridPage(11, 3, 2, 3, Color.Black, BorderSide.None, font);

            Printer.DrawQuad(1, 9, 2, 3, "User : " + LoginForm.username, Color.Black, BorderSide.None, font, HorizontalAlignment.Left, VertAlignment.Center);

            font = new Font("Ariel", 12);
            string text = this.Text;
            if (dgv2.Visible)
            {
                text = "Trust Data Combined (";
                text += cmbPreOrPost.Text.Trim() + ")";
            }
            else if (dgv3.Visible)
            {
                text = "Trust Data Combined (";
                text += cmbPreOrPost.Text.Trim() + ")";
            }
            Printer.DrawQuad(5, 7, 5, 4, text, Color.Black, BorderSide.None, font, HorizontalAlignment.Left, VertAlignment.Center);

            font = new Font("Ariel", 10, FontStyle.Bold);

            Printer.SetQuadSize(12, 12);
            Printer.DrawQuadBorder(1, 1, 12, 12, BorderSide.All, 1, Color.Black);
            Printer.DrawQuadBorder(12, 1, 1, 12, BorderSide.Right, 1, Color.Black);
        }
        /****************************************************************************************/
        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isPrinting = true;
            if (this.components == null)
                this.components = new System.ComponentModel.Container();

            DevExpress.XtraPrinting.PrintingSystem printingSystem1 = new DevExpress.XtraPrinting.PrintingSystem(this.components);
            DevExpress.XtraPrinting.PrintableComponentLink printableComponentLink1 = new DevExpress.XtraPrinting.PrintableComponentLink(this.components);

            printingSystem1.Links.AddRange(new object[] {
            printableComponentLink1});


            printableComponentLink1.Component = dgv;
            if (dgv2.Visible)
                printableComponentLink1.Component = dgv2;
            else if (dgv3.Visible)
                printableComponentLink1.Component = dgv3;

            printableComponentLink1.PrintingSystemBase = printingSystem1;

            printableComponentLink1.EnablePageDialog = true;

            printableComponentLink1.CreateDetailHeaderArea += new DevExpress.XtraPrinting.CreateAreaEventHandler(this.printableComponentLink1_CreateDetailHeaderArea);
            printableComponentLink1.CreateMarginalHeaderArea += new DevExpress.XtraPrinting.CreateAreaEventHandler(this.printableComponentLink1_CreateMarginalHeaderArea);
            printableComponentLink1.BeforeCreateAreas += new System.EventHandler(this.printableComponentLink1_BeforeCreateAreas);
            printableComponentLink1.AfterCreateAreas += new System.EventHandler(this.printableComponentLink1_AfterCreateAreas);
            printableComponentLink1.Landscape = true;

            Printer.setupPrinterMargins(50, 100, 80, 50);

            pageMarginLeft = Printer.pageMarginLeft;
            pageMarginRight = Printer.pageMarginRight;
            pageMarginTop = Printer.pageMarginTop;
            pageMarginBottom = Printer.pageMarginBottom;

            printableComponentLink1.Margins.Left = pageMarginLeft;
            printableComponentLink1.Margins.Right = pageMarginRight;
            printableComponentLink1.Margins.Top = pageMarginTop;
            printableComponentLink1.Margins.Bottom = pageMarginBottom;

            printableComponentLink1.CreateDocument();
            printableComponentLink1.PrintDlg();
            isPrinting = false;
        }
        /***********************************************************************************************/
        private void gridMain_CellValueChanged(object sender, CellValueChangedEventArgs e)
        {
            DataRow dr = gridMain.GetFocusedDataRow();
            DataTable dt = (DataTable)dgv.DataSource;
            int rowHandle = gridMain.FocusedRowHandle;
            int row = gridMain.GetDataSourceRowIndex(rowHandle);
            if (G1.get_column_number(dt, "mod") < 0)
                dt.Columns.Add("mod");
            dt.Rows[row]["mod"] = "Y";
            btnSave.Show();
            btnSave.Refresh();
        }
        /***********************************************************************************************/
        private void gridMain_CustomDrawCell(object sender, RowCellCustomDrawEventArgs e)
        {
            if (e.RowHandle < 0)
                return;
        }
        /***********************************************************************************************/
        private void btnSave_Click(object sender, EventArgs e)
        {
            DataTable dt = (DataTable)dgv.DataSource;
            DataTable dx = null;
            string record = "";
            string cmd = "";

            string company = workWhat;
            string trustName = "";
            string policyNumber = "";

            string contractNumber = "";
            double premium = 0D;
            double surrender = 0D;
            double faceAmount = 0D;
            double deathBenefit = 0D;
            double downPayments = 0D;
            double payments = 0D;
            double growth = 0D;
            string preOrPost = "";

            string insuredName = "";
            string lastName = "";
            string firstName = "";
            string middleName = "";
            string trustCompany = "";

            DataTable myDt = new DataTable();
            string cName = "";
            string type = "";
            string mod = "";
            DataRow dRow = null;
            DateTime date = DateTime.Now;

            if (G1.get_column_number(dt, "mod") < 0)
                dt.Columns.Add("mod");

            try
            {

                this.Cursor = Cursors.WaitCursor;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    mod = dt.Rows[i]["mod"].ObjToString();
                    if (mod.ToUpper() != "Y")
                        continue;
                    date = dt.Rows[i]["date"].ObjToDateTime();

                    trustName = dt.Rows[i]["trustName"].ObjToString();
                    trustCompany = dt.Rows[i]["trustCompany"].ObjToString();
                    policyNumber = dt.Rows[i]["policyNumber"].ObjToString();
                    preOrPost = dt.Rows[i]["preOrPost"].ObjToString();

                    record = dt.Rows[i]["record"].ObjToString();
                    if ( String.IsNullOrWhiteSpace ( record ))
                        record = G1.create_record("trust_data", "status", "-1");
                    if (G1.BadRecord("trust_data", record))
                        break;

                    contractNumber = dt.Rows[i]["contractNumber"].ObjToString();
                    premium = dt.Rows[i]["beginningPaymentBalance"].ObjToDouble();
                    surrender = dt.Rows[i]["beginningDeathBenefit"].ObjToDouble();
                    faceAmount = dt.Rows[i]["endingPaymentBalance"].ObjToDouble();
                    deathBenefit = dt.Rows[i]["endingDeathBenefit"].ObjToDouble();

                    downPayments = dt.Rows[i]["downPayments"].ObjToDouble();
                    payments = dt.Rows[i]["payments"].ObjToDouble();

                    //growth = deathBenefit - surrender - payments;

                    growth = dt.Rows[i]["growth"].ObjToDouble();

                    insuredName = dt.Rows[i]["insuredName"].ObjToString();
                    firstName = dt.Rows[i]["firstName"].ObjToString();
                    lastName = dt.Rows[i]["lastName"].ObjToString();
                    middleName = dt.Rows[i]["middleName"].ObjToString();

                    G1.update_db_table("trust_data", "record", record, new string[] { "status", "", "trustCompany", trustCompany, "preOrPost", preOrPost, "date", date.ToString("yyyyMMdd"), "trustName", trustName, "contractNumber", contractNumber, "policyNumber", policyNumber, "beginningPaymentBalance", premium.ToString(), "beginningDeathBenefit", surrender.ToString(), "endingPaymentBalance", faceAmount.ToString(), "endingDeathBenefit", deathBenefit.ToString(), "insuredName", insuredName, "lastName", lastName, "firstName", firstName, "middleName", middleName, "downPayments", downPayments.ToString(), "payments", payments.ToString(), "growth", growth.ToString() });

                }
                this.Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
            }
            this.Cursor = Cursors.Default;
        }
        /***********************************************************************************************/
        private void CleanupCommas ( DataTable dt, string column )
        {
            string str = "";
            for ( int i=0; i<dt.Rows.Count; i++)
            {
                str = dt.Rows[i][column].ObjToString();
                if ( str.IndexOf ( "$") >= 0 )
                {
                    str = str.Replace("$", "");
                    dt.Rows[i][column] = str;
                }
                if (String.IsNullOrWhiteSpace(str))
                    dt.Rows[i][column] = "0";
                else if ( str.IndexOf ( ",") > 0 )
                {
                    str = str.Replace(",", "");
                    dt.Rows[i][column] = str;
                }
            }
        }
        /***********************************************************************************************/
        private bool SaveData(DataTable dt, DateTime saveDate )
        {
            this.Cursor = Cursors.WaitCursor;

            DataTable saveDt = dt.Copy();

            if (G1.get_column_number(saveDt, "date") < 0)
                saveDt.Columns.Add("date");
            if (G1.get_column_number(saveDt, "trustCompany") < 0)
                saveDt.Columns.Add("trustCompany");

            if (G1.get_column_number(saveDt, "tmstamp") >= 0)
                saveDt.Columns.Remove("tmstamp");
            if (G1.get_column_number(saveDt, "record") >= 0)
                saveDt.Columns.Remove("record");
            if (G1.get_column_number(saveDt, "num") >= 0)
                saveDt.Columns.Remove("num");

            DataColumn Col = saveDt.Columns.Add("record", System.Type.GetType("System.String"));
            Col.SetOrdinal(0);// to put the column in position 0;
            DataColumn Col1 = saveDt.Columns.Add("tmstamp", System.Type.GetType("System.String"));
            Col1.SetOrdinal(0);// to put the column in position 0;

            double dValue = 0D;
            string str = "";

            for (int i = 0; i < saveDt.Rows.Count; i++)
            {
                //saveDt.Rows[i]["tmstamp"] = "0000-00-00";
                saveDt.Rows[i]["tmstamp"] = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                saveDt.Rows[i]["record"] = "0";
                saveDt.Rows[i]["insuredName"] = G1.try_protect_data(saveDt.Rows[i]["insuredName"].ObjToString());
                saveDt.Rows[i]["firstName"] = G1.try_protect_data(saveDt.Rows[i]["firstName"].ObjToString());
                saveDt.Rows[i]["middleName"] = G1.try_protect_data(saveDt.Rows[i]["middleName"].ObjToString());
                saveDt.Rows[i]["lastName"] = G1.try_protect_data(saveDt.Rows[i]["lastName"].ObjToString());
                saveDt.Rows[i]["firstName"] = G1.Truncate(saveDt.Rows[i]["firstName"].ObjToString(), 80);
                saveDt.Rows[i]["middleName"] = G1.Truncate(saveDt.Rows[i]["middleName"].ObjToString(), 80);
                saveDt.Rows[i]["lastName"] = G1.Truncate(saveDt.Rows[i]["lastName"].ObjToString(), 80);

                saveDt.Rows[i]["trustCompany"] = workWhat;
                saveDt.Rows[i]["date"] = saveDate.ToString("yyyyMMdd");
            }

            DateTime date = saveDate;

            DeletePreviousData(saveDate, workWhat);

            string strFile = "/TrustData/TrustData_P_" + date.ToString("yyyyMMdd") + ".csv";
            string Server = "C:/rag";
            //Create directory if not exist... Make sure directory has required rights..
            if (!Directory.Exists(Server + "/TrustData/"))
                Directory.CreateDirectory(Server + "/TrustData/");

            //If file does not exist then create it and right data into it..
            if (!File.Exists(Server + strFile))
            {
                FileStream fs = new FileStream(Server + strFile, FileMode.Create, FileAccess.Write);
                fs.Close();
                fs.Dispose();
            }

            //Generate csv file from where data read

            try
            {
                //DateTime saveDate = this.dateTimePicker2.Value;
                int days = DateTime.DaysInMonth(saveDate.Year, saveDate.Month);
                //                string mySaveDate = saveDate.Year.ToString("D4") + "-" + saveDate.Month.ToString("D2") + "-" + days.ToString("D2") + " 00:00:00";

                var mySaveDate = G1.DTtoMySQLDT(saveDate);

                //for ( int i=0; i<saveDt.Rows.Count; i++)
                //    saveDt.Rows[i]["payDate8"] = mySaveDate;

                MySQL.CreateCSVfile(saveDt, Server + strFile, false, "~");
            }
            catch (Exception ex)
            {
                MessageBox.Show("***ERROR*** Creating CSV File to load into Database " + ex.Message.ToString());
                this.Cursor = Cursors.Default;
                return false;
            }
            try
            {
                Structures.TieDbTable("trust_data", saveDt);
            }
            catch (Exception ex)
            {
                MessageBox.Show("***ERROR*** Tieing trust_data to DataTable " + ex.Message.ToString());
                this.Cursor = Cursors.Default;
                return false;
            }
            try
            {
                G1.conn1.Open();
                MySqlBulkLoader bcp1 = new MySqlBulkLoader(G1.conn1);
                bcp1.TableName = "trust_data"; //Create table into MYSQL database...
                bcp1.FieldTerminator = ",";

                bcp1.LineTerminator = "\r\n";
                bcp1.FileName = Server + strFile;
                bcp1.NumberOfLinesToSkip = 0;
                bcp1.FieldTerminator = "~";
                bcp1.Load();
            }
            catch (Exception ex)
            {
                MessageBox.Show("***ERROR*** Bulk Loading trust_data to DataTable " + ex.Message.ToString());
            }

            saveDt.Dispose();
            saveDt = null;

//            File.Delete(Server + strFile);

            this.Cursor = Cursors.Default;
            return true;
        }
        /***********************************************************************************************/
        private void DeletePreviousData ( DateTime saveDate, string trustCompany )
        {
            string date1 = saveDate.ToString("yyyy-MM-dd");

            string cmd = "DELETE from `trust_data` where `date` = '" + date1 + "' AND `trustCompany` = '" + trustCompany + "' ";
            cmd += ";";
            try
            {
                G1.get_db_data(cmd);
            }
            catch (Exception ex)
            {
                MessageBox.Show("***ERROR*** Delete Previous Data " + ex.Message.ToString());
            }
        }
        /***********************************************************************************************/
        private void btnLeft_Click(object sender, EventArgs e)
        {
            DateTime now = this.dateTimePicker1.Value;
            now = now.AddMonths(-1);
            int days = DateTime.DaysInMonth(now.Year, now.Month);
            this.dateTimePicker1.Value = new DateTime(now.Year, now.Month, days);
        }
        /***********************************************************************************************/
        private void btnRight_Click(object sender, EventArgs e)
        {
            DateTime now = this.dateTimePicker1.Value;
            now = now.AddMonths(1);
            int days = DateTime.DaysInMonth(now.Year, now.Month);
            this.dateTimePicker1.Value = new DateTime(now.Year, now.Month, days);
        }
        /*******************************************************************************************/
        private string getCompanyQuery()
        {
            string procLoc = "";
            string[] locIDs = chkCmbCompany.EditValue.ToString().Split('|');
            for (int i = 0; i < locIDs.Length; i++)
            {
                if (!String.IsNullOrWhiteSpace(locIDs[i]))
                {
                    if (procLoc.Trim().Length > 0)
                        procLoc += ",";
                    procLoc += "'" + locIDs[i].Trim() + "'";
                }
            }
            return procLoc.Length > 0 ? " `trustCompany` IN (" + procLoc + ") " : "";
        }
        /***********************************************************************************************/
        private void btnRun_Click(object sender, EventArgs e)
        {
            DateTime date = this.dateTimePicker1.Value;
            int days = DateTime.DaysInMonth(date.Year, date.Month);
            DateTime newDate = new DateTime(date.Year, date.Month, days);
            string date1 = newDate.ToString("yyyy-MM-dd");

            barImport.Hide();

            string companies = getCompanyQuery();

            string cmd = "Select * from `trust_data` t LEFT JOIN fcust_extended f ON t.`contractNumber` = f.`contractNumber` LEFT JOIN customers x on t.`contractNumber` = x.`contractNumber` WHERE `date` = '" + date1 + "' ";
            //string cmd = "Select * from `trust_data` WHERE `date` = '" + date1 + "' ";
            if (!String.IsNullOrWhiteSpace(companies))
                cmd += " AND " + companies + " ";
            cmd += ";";

            if (String.IsNullOrWhiteSpace(companies))
                tabPage1.Text = "All Companies";
            else
                tabPage1.Text = chkCmbCompany.Text.Trim();


            DataTable dt = G1.get_db_data(cmd);

            G1.NumberDataTable(dt);
            dgv.DataSource = dt;
        }
        /***********************************************************************************************/
        private void btnRunTotals_Click(object sender, EventArgs e)
        {
            DateTime date1 = this.dateTimePicker2.Value;
            DateTime date2 = this.dateTimePicker3.Value;

            string startDate = date1.ToString("yyyy-MM-dd");
            string stopDate = date2.ToString("yyyy-MM-dd");

            string preOrPost = cmbPreOrPost.Text.Trim();
            if (preOrPost != "Pre" && preOrPost != "Post")
                preOrPost = "Post";

            string cmd = "Select * from `trust_data` WHERE `date` >= '" + startDate + "' AND `date` <= '" + stopDate + "' AND `preOrPost` = '" + preOrPost + "' ORDER by `date`, `trustCompany`;";
            DataTable dt = G1.get_db_data(cmd);

            DataTable dx = new DataTable();
            dx.Columns.Add("month");
            dx.Columns.Add("Security National", Type.GetType("System.Double"));
            dx.Columns.Add("Forethought", Type.GetType("System.Double"));
            dx.Columns.Add("CD", Type.GetType("System.Double"));
            dx.Columns.Add("Unity", Type.GetType("System.Double"));
            dx.Columns.Add("Unity PB", Type.GetType("System.Double"));
            dx.Columns.Add("FDLIC", Type.GetType("System.Double"));
            dx.Columns.Add("FDLIC PB", Type.GetType("System.Double"));
            dx.Columns.Add("total", Type.GetType("System.Double"));

            DateTime date = DateTime.Now;
            string month = "";
            string lastMonth = "";
            string trustCompany = "";
            string type = "";
            double money = 0D;
            double dValue = 0D;

            double total = 0D;

            DataRow dRow = null;
            int col = 0;

            for ( int i=0; i<dt.Rows.Count; i++)
            {
                try
                {
                    date = dt.Rows[i]["date"].ObjToDateTime();
                    month = G1.ToMonthName(date);
                    if (month != lastMonth)
                    {
                        dRow = dx.NewRow();
                        dRow["month"] = month;
                        dx.Rows.Add(dRow);
                        lastMonth = month;
                    }
                    trustCompany = dt.Rows[i]["trustCompany"].ObjToString();
                    col = G1.get_column_number(dx, trustCompany);
                    if (col > 0)
                    {
                        dValue = dt.Rows[i]["endingDeathBenefit"].ObjToDouble();
                        money = dRow[col].ObjToDouble();
                        money += dValue;
                        dRow[col] = money;
                    }
                }
                catch ( Exception ex)
                {
                }
            }

            int col1 = G1.get_column_number(dx, "Security National");
            int col2 = G1.get_column_number(dx, "FDLIC PB");

            for (int i = 0; i < dx.Rows.Count; i++)
            {
                total = 0D;
                for (int j = col1; j <= col2; j++)
                {
                    total += dx.Rows[i][j].ObjToDouble();
                }
                dx.Rows[i]["total"] = total;
            }

            G1.NumberDataTable(dx);
            dgv2.DataSource = dx;
        }
        /***********************************************************************************************/
        private void button2_Click(object sender, EventArgs e)
        {
            DateTime now = this.dateTimePicker2.Value;
            now = now.AddMonths(-1);
            int days = DateTime.DaysInMonth(now.Year, now.Month);
            this.dateTimePicker2.Value = new DateTime(now.Year, now.Month, days);
            this.dateTimePicker3.Value = dateTimePicker2.Value;
        }
        /***********************************************************************************************/
        private void button1_Click(object sender, EventArgs e)
        {
            DateTime now = this.dateTimePicker2.Value;
            now = now.AddMonths(1);
            int days = DateTime.DaysInMonth(now.Year, now.Month);
            this.dateTimePicker2.Value = new DateTime(now.Year, now.Month, days);
            this.dateTimePicker3.Value = dateTimePicker2.Value;
        }
        /***********************************************************************************************/
        private void btnGenerate_Click(object sender, EventArgs e)
        {
            if (dgv == null)
                return;
            DataTable dt = (DataTable)dgv.DataSource;
            if (dt == null)
                return;
            DataRow[] dRows = dt.Select("trustCompany='FDLIC'");
            if (dRows.Length <= 0)
                return;

            DateTime lastPaidDate = DateTime.Now;
            double bBalance = 0D;
            double endingBalance = 0D;

            this.Cursor = Cursors.WaitCursor;

            dt = dRows.CopyToDataTable();

            DataTable dx = new DataTable();
            dx.Columns.Add("month");
            dx.Columns.Add("FDLICTRUST", Type.GetType("System.Double"));
            dx.Columns.Add("DC");
            dx.Columns.Add("description");
            dx.Columns.Add("cadenceDate");
            dx.Columns.Add("contractNumber");
            dx.Columns.Add("funeralNumber");

            dx.Columns.Add("FDLICTRUST2", Type.GetType("System.Double"));
//            dx.Columns.Add("space");
            dx.Columns.Add("DC2");
            dx.Columns.Add("description2");
            dx.Columns.Add("cadenceDate2");
            dx.Columns.Add("contractNumber2");
            dx.Columns.Add("funeralNumber2");

            DateTime date = this.dateTimePicker1.Value;
            DateTime newDate = date.AddMonths(-1);

            double beginningBalance = 14092320.65D;
            double previousDP = 0D;
            double previousPayments = 0D;

            string date1 = newDate.ToString("yyyy-MM-dd");
            string cmd = "Select * from `cashremit_coversheet` where `date` = '" + date1 + "';";
            DataTable ddd = G1.get_db_data(cmd);
            if ( ddd.Rows.Count > 0 )
            {
                beginningBalance = ddd.Rows[0]["beginningBalance"].ObjToDouble();
                previousDP = ddd.Rows[0]["fdlicDownPayments"].ObjToDouble();
                previousPayments = ddd.Rows[0]["fdlicMonthlyPayments"].ObjToDouble();
            }

            double payments = 0D;
            double downPayments = 0D;

            DataRow dR = null;
            string month = G1.ToMonthName(newDate);
            dR = dx.NewRow();
            dR["month"] = month;
            dx.Rows.Add(dR);
            dR = dx.NewRow();
            dR["month"] = "Beginning";
            dx.Rows.Add(dR);
            dR = dx.NewRow();
            dR["month"] = "Balance";
            dR["FDLICTRUST"] = beginningBalance;
            dx.Rows.Add(dR);

            dx = addEmptyRow(dx);
            dx = addEmptyRow(dx);

            string monthName = G1.ToMonthName(newDate);

            dx = addNewRow(dx, previousDP, monthName + " Down Payments");
            dx = addNewRow(dx, previousPayments, monthName + " Monthly Payments");

            dx = addEmptyRow(dx);

            double dTotal = previousPayments + previousDP;
            dx = addNewRow(dx, dTotal, "");

            dx = addEmptyRow(dx);
            dx = addEmptyRow(dx);

            dx = addNewRow(dx, -previousDP, "Sent to FDLIC");
            dx = addNewRow(dx, -previousPayments, "Sent to FDLIC");

            dx = addEmptyRow(dx);

            double fdlicTotal = 0 - previousPayments - previousDP;
            dx = addNewRow(dx, fdlicTotal, "");

            dx = addEmptyRow(dx);

            int pass = 1;

            payments = 0D;
            downPayments = 0D;
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                payments += dt.Rows[i]["payments"].ObjToDouble();
                downPayments += dt.Rows[i]["downPayments"].ObjToDouble();
            }

            string extra = "";
            double diff = downPayments - previousDP;
            if (diff != 0D )
            {
                if (diff > 0D)
                    extra = "Over " + G1.ReformatMoney(diff);
                else if ( diff < 0D )
                    extra = "Under " + G1.ReformatMoney(diff);
            }
            dx = addNewRow(dx, downPayments, "FDLIC DECEMBER DOWN PAYMENTS", extra);

            extra = "";
            diff = payments - previousPayments;
            if (diff != 0D)
            {
                if (diff > 0D)
                    extra = "Over " + G1.ReformatMoney(diff);
                else if ( diff < 0 )
                    extra = "Under " + G1.ReformatMoney(diff);
            }
            dx = addNewRow(dx, payments, "FDLIC DECEMBER MONTHLY PAYMENTS", extra );

            dx = addEmptyRow(dx);

            dTotal = payments + downPayments;
            dx = addNewRow(dx, dTotal, "");

            dx = addEmptyRow(dx);
            dx = addEmptyRow(dx);
            dx = addEmptyRow(dx);


            DateTime dDate = DateTime.Now;
            DataTable ddx = dt.Clone();
            dRows = dt.Select("deathClaimAmount <> '0.00' AND trustCompany='FDLIC'");
            if (dRows.Length > 0)
            {
                ddx = dRows.CopyToDataTable();

                ddx.Columns.Add("tempDate");
                for ( int i=0; i<ddx.Rows.Count; i++)
                {
                    dDate = ddx.Rows[i]["deathPaidDate"].ObjToDateTime();
                    if ( dDate.Year > 1900 )
                        ddx.Rows[i]["tempDate"] = dDate.ToString("yyyyMMdd");
                }
                DataView tempview = ddx.DefaultView;
                tempview.Sort = "tempDate asc";
                ddx = tempview.ToTable();
            }

            dTotal = 0D;
            double deathClaim = 0D;
            string contractNumber = "";
            string funeralNumber = "";
            string deathDate = "";
            string firstName = "";
            string lastName = "";
            string middleName = "";
            string policyNumber = "";
            bool nextMonth = false;

            int firstDcCashRow = -1;
            int firstDcPaidRow = -1;
            int firstXXXRow = -1;

            for ( int i=0; i<ddx.Rows.Count; i++)
            {
                try
                {
                    deathClaim = ddx.Rows[i]["deathClaimAmount"].ObjToDouble();
                    if (deathClaim == 0D)
                        continue;
                    dDate = ddx.Rows[i]["deathPaidDate"].ObjToDateTime();
                    deathDate = dDate.ToString("MM/dd/yyyy");
                    funeralNumber = ddx.Rows[i]["serviceId"].ObjToString();
                    firstName = ddx.Rows[i]["firstName"].ObjToString();
                    middleName = ddx.Rows[i]["middleName"].ObjToString();
                    lastName = ddx.Rows[i]["lastName"].ObjToString();
                    policyNumber = ddx.Rows[i]["policyNumber"].ObjToString();
                    contractNumber = ddx.Rows[i]["contractNumber"].ObjToString();
                    if (!String.IsNullOrWhiteSpace(middleName))
                        firstName += " " + middleName;
                    if (!String.IsNullOrWhiteSpace(lastName))
                        firstName += " " + lastName;

                    if (checkPB(contractNumber))
                        continue;

                    if (!VerifyDate( date, contractNumber, funeralNumber, ref nextMonth ))
                        continue;

                    dx = addNewRow(dx, deathClaim, firstName, deathDate, " DC CASH", contractNumber, funeralNumber );
                    if ( firstDcCashRow < 0 )
                        firstDcCashRow = dx.Rows.Count-1;

                    dTotal += deathClaim;
                }
                catch ( Exception ex )
                {
                }
            }

            dx = addEmptyRow(dx);
            dx = addNewRow(dx, dTotal, "");

            dx = addEmptyRow(dx);

            dx = VerifyFromFunerals(dx, date, pass, ref firstDcPaidRow );

            dx = addEmptyRow(dx);
            dTotal = 0D;

            bool isRemoved = false;
            int row = 0;

            date = this.dateTimePicker1.Value;
            date1 = date.ToString("yyyy-MM-dd");

            double newDeathClaim = 0D;
            double premium = 0D;


            cmd = "Select * from `trust2013r` where `payDate8` = '" + date1 + "' AND ( `deathRemCurrMonth` > '0.00' || `refundRemCurrMonth` > '0.00' ) ;";
            DataTable trustDt = G1.get_db_data(cmd);

            for (int i = 0; i < ddx.Rows.Count; i++)
            {
                try
                {
                    contractNumber = ddx.Rows[i]["contractNumber"].ObjToString();
                    if ( contractNumber.ToUpper() == "P22071L")
                    {
                    }
                    deathClaim = ddx.Rows[i]["beginningPaymentBalance"].ObjToDouble();
                    premium = deathClaim;
                    deathClaim = ddx.Rows[i]["deathClaimAmount"].ObjToDouble();
                    if (deathClaim == 0D)
                        continue;

                    dDate = ddx.Rows[i]["deathPaidDate"].ObjToDateTime();
                    deathDate = dDate.ToString("MM/dd/yyyy");
                    funeralNumber = ddx.Rows[i]["serviceId"].ObjToString();
                    firstName = ddx.Rows[i]["firstName"].ObjToString();
                    middleName = ddx.Rows[i]["middleName"].ObjToString();
                    lastName = ddx.Rows[i]["lastName"].ObjToString();
                    policyNumber = ddx.Rows[i]["policyNumber"].ObjToString();
                    if (!String.IsNullOrWhiteSpace(middleName))
                        firstName += " " + middleName;
                    if (!String.IsNullOrWhiteSpace(lastName))
                        firstName += " " + lastName;

                    if (checkPB(contractNumber))
                        continue;

                    if (contractNumber == "P19003L")
                    {
                    }

                    isRemoved = true;
                    if (!VerifyDate(date, contractNumber, funeralNumber, ref nextMonth))
                    {
                        if (!nextMonth)
                            continue;
                        isRemoved = false;
                        if (CheckRemoved(contractNumber, date))
                            isRemoved = true;
                    }
                    if (!String.IsNullOrWhiteSpace(contractNumber))
                    {
                        if (contractNumber.ToUpper() == "L21146LI")
                        {
                        }
                        deathClaim = 0D;
                        dRows = trustDt.Select("contractNumber='" + contractNumber + "'");
                        if (dRows.Length > 0)
                        {
                            deathClaim = dRows[0]["deathRemCurrMonth"].ObjToDouble();
                            if (deathClaim == 0D)
                                deathClaim = dRows[0]["refundRemCurrMonth"].ObjToDouble();
                        }
                        newDeathClaim = 0D;
                        lastPaidDate = DailyHistory.GetTrustLastPaid(contractNumber, ref bBalance, ref endingBalance);
                        if (endingBalance != 0D)
                            newDeathClaim = endingBalance;
                        else if (bBalance != 0D)
                            newDeathClaim = bBalance;
                        if ( newDeathClaim != deathClaim )
                        {
                            deathClaim = newDeathClaim;
                        }
                        if (deathClaim == 0D)
                            deathClaim = premium;
                    }

                    dx = addNewRow(dx, deathClaim, firstName, deathDate, " DC XXXX", contractNumber, funeralNumber);
                    row = dx.Rows.Count - 1;

                    if (firstXXXRow < 0)
                        firstXXXRow = dx.Rows.Count - 1;

                    if (nextMonth && isRemoved)
                        dx.Rows[row][0] = "BC Paid Next / Is Removed";
                    else if ( nextMonth && !isRemoved )
                        dx.Rows[row][0] = "BC Paid Next / Not Removed";
                    dTotal += deathClaim;
                }
                catch (Exception ex)
                {
                }
            }

            dx = addEmptyRow(dx);
            dx = addNewRow(dx, dTotal, "");

            /***********************************************************************************************/

            pass = 2;
            dTotal = 0D;

            for (int i = 0; i < ddx.Rows.Count; i++)
            {
                try
                {
                    deathClaim = ddx.Rows[i]["deathClaimAmount"].ObjToDouble();
                    if (deathClaim == 0D)
                        continue;
                    dDate = ddx.Rows[i]["deathPaidDate"].ObjToDateTime();
                    deathDate = dDate.ToString("MM/dd/yyyy");
                    funeralNumber = ddx.Rows[i]["serviceId"].ObjToString();
                    firstName = ddx.Rows[i]["firstName"].ObjToString();
                    middleName = ddx.Rows[i]["middleName"].ObjToString();
                    lastName = ddx.Rows[i]["lastName"].ObjToString();
                    policyNumber = ddx.Rows[i]["policyNumber"].ObjToString();
                    contractNumber = ddx.Rows[i]["contractNumber"].ObjToString();
                    if (!String.IsNullOrWhiteSpace(middleName))
                        firstName += " " + middleName;
                    if (!String.IsNullOrWhiteSpace(lastName))
                        firstName += " " + lastName;

                    if (!checkPB(contractNumber))
                    {
                        continue;
                    }

                    if (!VerifyDate(date, contractNumber, funeralNumber, ref nextMonth))
                        continue;

                    //dx = addNewRow(dx, deathClaim, firstName, deathDate, " DC CASH", contractNumber, funeralNumber);

                    dR = dx.Rows[firstDcCashRow];
                    dR["FDLICTRUST2"] = deathClaim;
                    dR["description2"] = firstName;
                    if (!String.IsNullOrWhiteSpace(deathDate))
                        dR["cadenceDate2"] = deathDate;
                    dR["DC2"] = "PB DC CASH";
                    if (!String.IsNullOrWhiteSpace(contractNumber))
                        dR["contractNumber2"] = contractNumber;
                    if (!String.IsNullOrWhiteSpace(funeralNumber))
                        dR["funeralNumber2"] = funeralNumber;
                    firstDcCashRow++;

                    dTotal += deathClaim;
                }
                catch (Exception ex)
                {
                }
            }

            firstDcCashRow++;
            dR = dx.Rows[firstDcCashRow];
            dR["FDLICTRUST2"] = dTotal;

            dx = VerifyFromFunerals(dx, date, pass, ref firstDcPaidRow);

            dTotal = 0D;

            isRemoved = false;
            row = 0;

            date = this.dateTimePicker1.Value;
            date1 = date.ToString("yyyy-MM-dd");

            newDeathClaim = 0D;
            premium = 0D;

            cmd = "Select * from `trust2013r` where `payDate8` = '" + date1 + "' AND ( `deathRemCurrMonth` > '0.00' || `refundRemCurrMonth` > '0.00' ) ;";
            trustDt = G1.get_db_data(cmd);

            for (int i = 0; i < ddx.Rows.Count; i++)
            {
                try
                {
                    contractNumber = ddx.Rows[i]["contractNumber"].ObjToString();
                    if (contractNumber.ToUpper() == "P22071L")
                    {
                    }
                    deathClaim = ddx.Rows[i]["beginningPaymentBalance"].ObjToDouble();
                    premium = deathClaim;
                    deathClaim = ddx.Rows[i]["deathClaimAmount"].ObjToDouble();
                    if (deathClaim == 0D)
                        continue;

                    dDate = ddx.Rows[i]["deathPaidDate"].ObjToDateTime();
                    deathDate = dDate.ToString("MM/dd/yyyy");
                    funeralNumber = ddx.Rows[i]["serviceId"].ObjToString();
                    firstName = ddx.Rows[i]["firstName"].ObjToString();
                    middleName = ddx.Rows[i]["middleName"].ObjToString();
                    lastName = ddx.Rows[i]["lastName"].ObjToString();
                    policyNumber = ddx.Rows[i]["policyNumber"].ObjToString();
                    if (!String.IsNullOrWhiteSpace(middleName))
                        firstName += " " + middleName;
                    if (!String.IsNullOrWhiteSpace(lastName))
                        firstName += " " + lastName;

                    if (!checkPB(contractNumber))
                        continue;

                    isRemoved = true;
                    if (!VerifyDate(date, contractNumber, funeralNumber, ref nextMonth))
                    {
                        if (!nextMonth)
                            continue;
                        isRemoved = false;
                        if (CheckRemoved(contractNumber, date))
                            isRemoved = true;
                    }
                    if (!String.IsNullOrWhiteSpace(contractNumber))
                    {
                        deathClaim = 0D;
                        dRows = trustDt.Select("contractNumber='" + contractNumber + "'");
                        if (dRows.Length > 0)
                        {
                            deathClaim = dRows[0]["deathRemCurrMonth"].ObjToDouble();
                            if (deathClaim == 0D)
                                deathClaim = dRows[0]["refundRemCurrMonth"].ObjToDouble();
                        }
                        newDeathClaim = 0D;
                        lastPaidDate = DailyHistory.GetTrustLastPaid(contractNumber, ref bBalance, ref endingBalance);
                        if (endingBalance != 0D)
                            newDeathClaim = endingBalance;
                        else if (bBalance != 0D)
                            newDeathClaim = bBalance;
                        if (newDeathClaim != deathClaim)
                        {
                            deathClaim = newDeathClaim;
                        }
                        if (deathClaim == 0D)
                            deathClaim = premium;
                    }

                    //dx = addNewRow(dx, deathClaim, firstName, deathDate, " DC XXXX", contractNumber, funeralNumber);
                    //row = dx.Rows.Count - 1;

                    dR = dx.Rows[firstXXXRow];
                    dR["FDLICTRUST2"] = deathClaim;
                    dR["description2"] = firstName;
                    if (!String.IsNullOrWhiteSpace(deathDate))
                        dR["cadenceDate2"] = deathDate;
                    dR["DC2"] = "PB DC XXX";
                    if (!String.IsNullOrWhiteSpace(contractNumber))
                        dR["contractNumber2"] = contractNumber;
                    if (!String.IsNullOrWhiteSpace(funeralNumber))
                        dR["funeralNumber2"] = funeralNumber;
                    firstXXXRow++;

                    //if (nextMonth && isRemoved)
                    //    dx.Rows[row][0] = "BC Paid Next / Is Removed";
                    //else if (nextMonth && !isRemoved)
                    //    dx.Rows[row][0] = "BC Paid Next / Not Removed";
                    dTotal += deathClaim;
                }
                catch (Exception ex)
                {
                }
            }

            firstXXXRow++;
            dR = dx.Rows[firstXXXRow];
            dR["FDLICTRUST2"] = dTotal;

            dgv3.DataSource = dx;

            this.Cursor = Cursors.Default;
        }
        /***********************************************************************************************/
        private bool CheckRemoved ( string contractNumber, DateTime date )
        {
            bool rv = false;
            date = date.AddMonths(1);
            int days = DateTime.DaysInMonth(date.Year, date.Month);
            DateTime newDate = new DateTime(date.Year, date.Month, days);
            string cmd = "Select * from `contracts` WHERE `contractNumber` = '" + contractNumber + "';";
            DataTable dx = G1.get_db_data(cmd);
            if (dx.Rows.Count > 0)
            {
                DateTime dateRemoved = dx.Rows[0]["dateRemoved"].ObjToDateTime();
                if (dateRemoved == newDate)
                    rv = true;
            }
            return rv;
        }
        /***********************************************************************************************/
        private bool checkPB ( string contractNumber )
        {
            bool rv = false;
            string cmd = "Select * from `policytrusts` WHERE `contractNumber` = '" + contractNumber + "';";
            DataTable dx = G1.get_db_data(cmd);
            if ( dx.Rows.Count > 0 )
            {
                if (dx.Rows[0]["type"].ObjToString().ToUpper() == "PB")
                    rv = true;
            }
            return rv;
        }
        /***********************************************************************************************/
        private bool VerifyDate ( DateTime date, string contractNumber, string funeralNumber, ref bool nextMonth )
        {
            bool rv = true;
            if (contractNumber.ToUpper() == "NULL")
                return rv;
            //if (String.IsNullOrWhiteSpace(funeralNumber))
            //    return rv;

            DateTime dateStart = new DateTime(date.Year, date.Month, 1);
            string date1 = date.ToString("yyyy-MM-01");
            int days = DateTime.DaysInMonth(date.Year, date.Month);
            DateTime dateStop = new DateTime(date.Year, date.Month, days);
            string date2 = dateStop.ToString("yyyy-MM-dd");

            DateTime nextStart = dateStart.AddMonths(1);
            days = DateTime.DaysInMonth(nextStart.Year, nextStart.Month);
            DateTime nextStop = new DateTime(nextStart.Year, nextStart.Month, days);

            string cmd = "";
            DataTable dx = null;
            DataTable dt = null;
            bool itsOk = false;
            nextMonth = false;
            if (!String.IsNullOrWhiteSpace(contractNumber))
            {
                cmd = "SELECT * FROM `cust_payments` WHERE `type` = 'TRUST' AND `status` = 'Deposited' ";
                cmd += " AND `trust_policy` LIKE '%" + contractNumber + "%' ";
                cmd += " ORDER BY `dateModified` ";
                cmd += ";";

                dt = G1.get_db_data(cmd);
                if ( dt.Rows.Count <= 0 )
                {
                    cmd = "SELECT * FROM `cust_payments` WHERE `type` = 'TRUST' AND `status` = 'Deposited' ";
                    cmd += " AND `referenceNumber` LIKE '%" + contractNumber + "%' ";
                    cmd += " ORDER BY `dateModified` ";
                    cmd += ";";

                    dt = G1.get_db_data(cmd);
                }
                if (dt.Rows.Count > 0)
                {
                    for (int j = 0; j < dt.Rows.Count; j++)
                    {
                        string paymentRecord = dt.Rows[j]["record"].ObjToString();
                        cmd = "SELECT * FROM `cust_payment_details` WHERE `type` = 'TRUST' AND `status` = 'Deposited' ";
                        cmd += " AND `paymentRecord` = '" + paymentRecord + "' ";
                        cmd += " ORDER BY `dateReceived` ";
                        cmd += ";";

                        dx = G1.get_db_data(cmd);
                        if (dx.Rows.Count > 0)
                        {
                            for (int i = 0; i < dx.Rows.Count; i++)
                            {
                                DateTime dateReceived = dx.Rows[i]["dateReceived"].ObjToDateTime();
                                if (dateReceived >= dateStart && dateReceived <= dateStop)
                                {
                                    itsOk = true;
                                }
                                else if (dateReceived >= nextStart && dateReceived <= nextStop)
                                    nextMonth = true;
                            }
                        }
                    }
                }
            }
            if (!itsOk)
                rv = false;

            return rv;
        }
        /***********************************************************************************************/
        private DataTable VerifyFromFunerals(DataTable ddx, DateTime date, int pass, ref int firstDcPaidRow)
        {
            string date1 = date.ToString("yyyy-MM-01");
            int days = DateTime.DaysInMonth(date.Year, date.Month);
            date = new DateTime(date.Year, date.Month, days);
            string date2 = date.ToString("yyyy-MM-dd");

            double dTotal = 0D;

            string cmd = "SELECT * FROM `cust_payment_details` WHERE `type` = 'TRUST' AND `status` = 'Deposited' AND `dateReceived` >= '" + date1 + "' AND `dateReceived` <= '" + date2 + "' ";
            cmd += " AND ( `contractNumber` LIKE '%L' OR `contractNumber` LIKE '%LI' ) ";
            cmd += " ORDER BY `dateReceived` ";
            cmd += ";";

            cmd = "SELECT * FROM `cust_payments` a JOIN `cust_payment_details` p ON a.`record` = p.`paymentRecord` WHERE a.`type` = 'TRUST' AND a.`status` = 'Deposited' AND p.`dateReceived` >= '" + date1 + "' AND p.`dateReceived` <= '" + date2 + "' ";
            cmd += " AND ( ( `trust_policy` LIKE '%L' OR `trust_policy` LIKE '%LI' )  OR ( `referenceNumber` LIKE '%L' OR `referenceNumber` LIKE '%LI' ) )";
            cmd += " ORDER BY p.`dateReceived` ";
            cmd += ";";

            if ( pass == 2 )
            {
                cmd = "SELECT * FROM `cust_payments` a JOIN `cust_payment_details` p ON a.`record` = p.`paymentRecord` WHERE a.`type` = 'TRUST' AND a.`status` = 'Deposited' AND p.`dateReceived` >= '" + date1 + "' AND p.`dateReceived` <= '" + date2 + "' ";
                //cmd += " AND ( ( `trust_policy` LIKE '%L' OR `trust_policy` LIKE '%LI' )  OR ( `referenceNumber` LIKE '%L' OR `referenceNumber` LIKE '%LI' ) )";
                cmd += " ORDER BY p.`dateReceived` ";
                cmd += ";";
            }

            DataTable dt = G1.get_db_data(cmd);

            if (dt.Rows.Count > 0)
            {
                string contractNumber = "";
                string serviceId = "";
                DataRow[] dRows = null;
                DataRow dR = null;
                DataTable dx = null;
                double deathClaim = 0D;
                string deathDate = "";
                string funeralNumber = "";
                string firstName = "";
                string middleName = "";
                string lastName = "";
                string paidFrom = "";
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    try
                    {
                        contractNumber = dt.Rows[i]["contractNumber"].ObjToString();
                        if (pass == 2)
                        {
                            if (!checkPB(contractNumber))
                                continue;
                        }
                        paidFrom = dt.Rows[i]["paidFrom"].ObjToString();
                        if (paidFrom.ToUpper() != "FDLIC")
                            continue;
                        deathDate = dt.Rows[i]["dateReceived"].ObjToDateTime().ToString("yyyy-MM-dd");
                        deathClaim = dt.Rows[i]["amtActuallyReceived"].ObjToDouble();
                        firstName = "";
                        middleName = "";
                        lastName = "";
                        cmd = "Select * from `customers` where `contractNumber` = '" + contractNumber + "';";
                        dx = G1.get_db_data(cmd);
                        if (dx.Rows.Count > 0)
                        {
                            firstName = dx.Rows[0]["firstName"].ObjToString();
                            middleName = dx.Rows[0]["middleName"].ObjToString();
                            lastName = dx.Rows[0]["lastName"].ObjToString();
                            if (!String.IsNullOrWhiteSpace(middleName))
                                firstName += " " + middleName;
                            if (!String.IsNullOrWhiteSpace(lastName))
                                firstName += " " + lastName;
                        }

                        funeralNumber = "";
                        cmd = "Select * from `fcust_extended` where `contractNumber` = '" + contractNumber + "';";
                        dx = G1.get_db_data(cmd);
                        if (dx.Rows.Count > 0)
                            funeralNumber = dx.Rows[0]["serviceId"].ObjToString();
                        if (pass == 1)
                        {
                            ddx = addNewRow(ddx, deathClaim, firstName, deathDate, " DC PAID", contractNumber, funeralNumber);

                            if (firstDcPaidRow < 0)
                                firstDcPaidRow = ddx.Rows.Count - 1;
                        }
                        else
                        {
                            dR = ddx.Rows[firstDcPaidRow];
                            dR["FDLICTRUST2"] = deathClaim;
                            dR["description2"] = firstName;
                            if (!String.IsNullOrWhiteSpace(deathDate))
                                dR["cadenceDate2"] = deathDate;
                            dR["DC2"] = "PB DC PAID";
                            if (!String.IsNullOrWhiteSpace(contractNumber))
                                dR["contractNumber2"] = contractNumber;
                            if (!String.IsNullOrWhiteSpace(funeralNumber))
                                dR["funeralNumber2"] = funeralNumber;
                            firstDcPaidRow++;
                        }

                        dTotal += deathClaim;
                    }
                    catch (Exception ex)
                    {
                    }
                }
                if (pass == 1)
                {
                    dRows = ddx.Select("contractNumber='NULL'");
                    if (dRows.Length > 0)
                    {
                        dx = dRows.CopyToDataTable();
                        for (int j = 0; j < dx.Rows.Count; j++)
                        {
                            deathClaim = dx.Rows[j]["FDLICTRUST"].ObjToDouble();
                            firstName = dx.Rows[j]["description"].ObjToString();
                            ddx = addNewRow(ddx, deathClaim, firstName, deathDate, " DC PAID", "NULL", "O/S");

                            if (firstDcPaidRow < 0)
                                firstDcPaidRow = ddx.Rows.Count - 1;

                            dTotal += deathClaim;
                        }
                    }
                }

                if (pass == 1)
                {
                    ddx = addEmptyRow(ddx);
                    ddx = addNewRow(ddx, dTotal, "");
                }
                else if (pass == 2)
                {
                    firstDcPaidRow++;
                    dR = ddx.Rows[firstDcPaidRow];
                    dR["FDLICTRUST2"] = dTotal;
                }
            }

            return ddx;
        }
        /***********************************************************************************************/
        private DataTable addEmptyRow ( DataTable dx)
        {
            DataRow dR = dx.NewRow();
            dx.Rows.Add(dR);
            return dx;
        }
        /***********************************************************************************************/
        private DataTable addNewRow(DataTable dx, double value, string desc, string extra = "", string dc = "", string contractNumber = "", string funeralNumber = "" )
        {
            DataRow dR = dx.NewRow();
            dR["FDLICTRUST"] = value;
            dR["description"] = desc;
            if (!String.IsNullOrWhiteSpace(extra))
                dR["cadenceDate"] = extra;
            if (!String.IsNullOrWhiteSpace(dc))
                dR["DC"] = dc;
            if (!String.IsNullOrWhiteSpace(contractNumber))
                dR["contractNumber"] = contractNumber;
            if (!String.IsNullOrWhiteSpace(funeralNumber))
                dR["funeralNumber"] = funeralNumber;
            dx.Rows.Add(dR);
            return dx;
        }
        /***********************************************************************************************/
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (dgv3.Visible)
                G1.SpyGlass(gridMain3);
        }
        /***********************************************************************************************/
        private void gridMain3_DoubleClick(object sender, EventArgs e)
        {
            DataRow dr = gridMain3.GetFocusedDataRow();
            string contract = dr["contractNumber"].ObjToString();
            string funeralNumber = dr["funeralNumber"].ObjToString();
            string dc = dr["DC"].ObjToString();
            if ( dc.ToUpper().IndexOf ( "XXX") > 0 )
            {
                this.Cursor = Cursors.WaitCursor;
                CustomerDetails clientForm = new CustomerDetails(contract);
                clientForm.Show();
                this.Cursor = Cursors.Default;
                return;
            }
            if ( !String.IsNullOrWhiteSpace ( funeralNumber ) && !String.IsNullOrWhiteSpace(contract) && contract != "NULL" )
            {
                this.Cursor = Cursors.WaitCursor;
                FunPayments editFunPayments = new FunPayments(this, contract, "", false, false);
                editFunPayments.TopMost = true;
                editFunPayments.Show();
                this.Cursor = Cursors.Default;
                return;
            }
            if (!String.IsNullOrWhiteSpace(contract) && contract != "NULL" )
            {
                this.Cursor = Cursors.WaitCursor;
                string cmd = "Select * from `contracts` where `contractNumber` = '" + contract + "';";
                DataTable dx = G1.get_db_data(cmd);
                if (dx.Rows.Count <= 0)
                {
                    string cnum = contract.TrimStart('0');
                    cnum = cnum.Replace(" ", "");

                    cmd = "Select * from `icustomers` where `payer` = '" + cnum + "';";
                    dx = G1.get_db_data(cmd);
                    if (dx.Rows.Count > 0)
                        contract = dx.Rows[0]["contractNumber"].ObjToString();
                }
                CustomerDetails clientForm = new CustomerDetails(contract);
                clientForm.Show();
                this.Cursor = Cursors.Default;
            }
        }
        /***********************************************************************************************/
        private void chkGroupContract_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox checkBox = (CheckBox)sender;
            if ( checkBox.Checked )
            {
                gridMain.Columns["contractNumber"].GroupIndex = 0;
                gridMain.ExpandAllGroups();
            }
            else
            {
                gridMain.Columns["contractNumber"].GroupIndex = -1;
                gridMain.CollapseAllDetails();
            }
            gridMain.RefreshData();
            gridMain.RefreshEditor(true);
            dgv.Refresh();
        }
        /***********************************************************************************************/
        private void chkTBB_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox cBox = (CheckBox)sender;
            if ( !cBox.Checked )
            {
                gridMain.Columns["endingBalance"].Visible = false;
                gridMain.RefreshData();
                gridMain.RefreshEditor(true);
                dgv.Refresh();
                barImport.Hide();
                return;
            }
            DataTable dt = (DataTable)dgv.DataSource;
            if (dt == null)
                return;
            if (dt.Rows.Count <= 0)
                return;

            DataView tempview = dt.DefaultView;
            tempview.Sort = "contractNumber";
            dt = tempview.ToTable();

            if ( G1.get_column_number ( dt, "endingBalance") < 0 )
                dt.Columns.Add("endingBalance", Type.GetType("System.Double"));

            string contractNumber = "";
            string oldContract = "";

            double dValue = 0D;

            this.Cursor = Cursors.WaitCursor;

            barImport.Show();
            barImport.Minimum = 0;
            barImport.Maximum = dt.Rows.Count;
            barImport.Value = 0;

            DateTime date = this.dateTimePicker1.Value;
            date = date.AddMonths(-1);
            int days = DateTime.DaysInMonth(date.Year, date.Month);
            DateTime newDate = new DateTime(date.Year, date.Month, days);
            string date1 = newDate.ToString("yyyy-MM-dd");


            string cmd = "Select * from `trust2013r` WHERE `payDate8` = '" + date1 + "';";
            DataTable dx = G1.get_db_data(cmd);
            DataRow[] dRows = null;

            for ( int i=0; i<dt.Rows.Count; i++)
            {
                Application.DoEvents();

                barImport.Value = i;
                barImport.Refresh();

                contractNumber = dt.Rows[i]["contractNumber"].ObjToString();
                if (string.IsNullOrWhiteSpace(contractNumber))
                    continue;
                if (string.IsNullOrWhiteSpace(oldContract))
                    oldContract = contractNumber;
                if ( contractNumber != oldContract )
                {
                    dRows = dx.Select("contractNumber='" + oldContract + "'");
                    if (dRows.Length > 0)
                    {
                        dValue = dRows[0]["endingBalance"].ObjToDouble();
                        dt.Rows[i]["endingBalance"] = dValue;
                    }
                    oldContract = contractNumber;
                }
            }

            dgv.DataSource = dt;
            gridMain.ExpandAllGroups();

            gridMain.RefreshData();
            gridMain.RefreshEditor(true);
            dgv.Refresh();

            this.Cursor = Cursors.Default;
        }
        /***********************************************************************************************/
        private void addToPolicyContractXReferenceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string contractNumber = "";
            string policyNumber = "";
            string trustCompany = "";

            DataRow dr = gridMain.GetFocusedDataRow();
            policyNumber = dr["policyNumber"].ObjToString();
            if (String.IsNullOrWhiteSpace(policyNumber))
            {
                MessageBox.Show("***ERROR*** There is no Policy Number here!!!", "Policy Error Dialog", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly); 
                return;
            }

            trustCompany = dr["trustCompany"].ObjToString();
            contractNumber = dr["contractNumber"].ObjToString();
            if (!String.IsNullOrWhiteSpace(contractNumber))
            {
                DialogResult result = MessageBox.Show("***Warning*** Contract Number (" + contractNumber + ")\n is already assigned here!\nDo you still want to assign a different one?", "Assign Contract Dialog", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1, MessageBoxOptions.DefaultDesktopOnly);
                if (result == DialogResult.No)
                    return;
            }

            FunLookup fastForm = new FunLookup("", "");
            fastForm.SelectDone += FastForm_SelectDone;
            fastForm.Show();


            //using (Ask askForm = new Ask("Enter Contract # to associate with Policy (" + policyNumber + ") ! "))
            //{
            //    askForm.Text = "";
            //    askForm.ShowDialog();
            //    if (askForm.DialogResult != System.Windows.Forms.DialogResult.OK)
            //        return;
            //    contractNumber = askForm.Answer;
            //    if (String.IsNullOrWhiteSpace(contractNumber))
            //        return;
            //}

            //string record = "";
            //string cmd = "Select * from `policyTrusts` WHERE `policyNumber` = '" + policyNumber + "';";
            //DataTable dx = G1.get_db_data(cmd);
            //if (dx.Rows.Count > 0)
            //    record = dx.Rows[0]["record"].ObjToString();
            //else
            //    record = G1.create_record("policyTrusts", "Company", trustCompany);
            //if (G1.BadRecord("policyTrusts", record))
            //    return;
            //G1.update_db_table("policyTrusts", "record", record, new string[] { "policyNumber", policyNumber, "contractNumber", contractNumber, "type", "", "trustCompany", trustCompany });

            //dr["contractNumber"] = contractNumber;

            //gridMain.RefreshData();
            //gridMain.RefreshEditor(true);
            //dgv.Refresh();
        }
        /***********************************************************************************************/
        private void FastForm_SelectDone(DataTable s)
        {
            if (s == null)
                return;
            if (s.Rows.Count <= 0)
                return;
            try
            {
                string contractNumber = s.Rows[0]["contractNumber"].ObjToString();
                if (string.IsNullOrWhiteSpace(contractNumber))
                    return;
                DataRow dr = gridMain.GetFocusedDataRow();
                string policyNumber = dr["policyNumber"].ObjToString();
                string trustCompany = dr["trustCompany"].ObjToString();
                string type = "";
                if ( trustCompany.IndexOf ( "FDLIC") >= 0 )
                {
                    if ( trustCompany.IndexOf ( "PB") > 0 )
                    {
                        trustCompany = "FDLIC";
                        type = "PB";
                    }
                }

                string record = "";
                string cmd = "Select * from `policyTrusts` WHERE `policyNumber` = '" + policyNumber + "';";
                DataTable dx = G1.get_db_data(cmd);
                if (dx.Rows.Count > 0)
                    record = dx.Rows[0]["record"].ObjToString();
                else
                    record = G1.create_record("policyTrusts", "Company", trustCompany);
                if (G1.BadRecord("policyTrusts", record))
                    return;

                G1.update_db_table("policyTrusts", "record", record, new string[] { "policyNumber", policyNumber, "contractNumber", contractNumber, "type", type, "Company", trustCompany });

                dr["contractNumber"] = contractNumber;

                record = dr["record"].ObjToString();
                G1.update_db_table("trust_data", "record", record, new string[] { "contractNumber", contractNumber });

                gridMain.RefreshData();
                gridMain.RefreshEditor(true);
                dgv.Refresh();
            }
            catch ( Exception ex)
            {
            }
        }
        /***********************************************************************************************/
    }
}