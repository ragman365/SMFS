﻿namespace SMFS
{
    partial class FunFamilyNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FunFamilyNew));
            this.repositoryItemComboBox9 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repositoryItemComboBox7 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.panelAll = new System.Windows.Forms.Panel();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabFamily = new System.Windows.Forms.TabPage();
            this.dgvDependent = new DevExpress.XtraGrid.GridControl();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addSignatureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyFromDeceasedAddressToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gridMainDep = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand6 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn45 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn142 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit7 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.bandedGridColumn163 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit12 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.bandedGridColumn143 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn53 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn47 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn48 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn46 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn49 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn9 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn50 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn21 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn138 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit6 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.bandedGridColumn1 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn128 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox15 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn129 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn51 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox2 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn19 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn8 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn20 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn7 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn6 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn120 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn2 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.bandedGridColumn3 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn4 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn160 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn5 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemPictureEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit();
            this.bandedGridColumn10 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn152 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.tabLegal = new System.Windows.Forms.TabPage();
            this.dgvLegal = new DevExpress.XtraGrid.GridControl();
            this.gridMainLegal = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand9 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn99 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn144 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn100 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn101 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn103 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn102 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn104 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn105 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn106 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn107 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn139 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit5 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.bandedGridColumn108 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn126 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn127 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn109 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox13 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn110 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn111 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn112 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn113 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox14 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn114 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn121 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn115 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn116 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn117 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn161 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn119 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn118 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemPictureEdit5 = new DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit();
            this.bandedGridColumn153 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridView6 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.tabFuneralData = new System.Windows.Forms.TabPage();
            this.dgv6 = new DevExpress.XtraGrid.GridControl();
            this.gridMain6 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand5 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn86 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn87 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn88 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn89 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox8 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn90 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn91 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn92 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn93 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn140 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn141 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn94 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn97 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn95 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox10 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn96 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand7 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.gridBand8 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn98 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemPictureEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit();
            this.repositoryItemComboBox11 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repositoryItemComboBox12 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repositoryItemDateEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.tabPallbearers = new System.Windows.Forms.TabPage();
            this.dgv2 = new DevExpress.XtraGrid.GridControl();
            this.gridMain2 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand1 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn11 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn145 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn12 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn13 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn15 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn14 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn16 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn17 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn18 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn22 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn23 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn130 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox16 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn131 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn24 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox3 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn30 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn31 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn32 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox4 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn33 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn122 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn34 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn155 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemPictureEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit();
            this.gridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.tabHonoraryPallBearers = new System.Windows.Forms.TabPage();
            this.dgv3 = new DevExpress.XtraGrid.GridControl();
            this.gridMain3 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand2 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn25 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn146 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn26 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn27 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn29 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn28 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn35 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn36 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn37 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn38 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn39 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn132 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox17 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn133 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn40 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox5 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn41 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn42 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn43 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox6 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn44 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn123 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn52 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn154 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemPictureEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit();
            this.gridView3 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.tabClergy = new System.Windows.Forms.TabPage();
            this.panelClergyStuff = new System.Windows.Forms.Panel();
            this.btnClergyCancel = new System.Windows.Forms.Button();
            this.btnClergyAccept = new System.Windows.Forms.Button();
            this.txtSuffix = new System.Windows.Forms.TextBox();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.txtCity2 = new System.Windows.Forms.TextBox();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtState2 = new System.Windows.Forms.TextBox();
            this.txtMiddleName = new System.Windows.Forms.TextBox();
            this.txtAddress2 = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtZip2 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCounty2 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtPhone2 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dgv4 = new DevExpress.XtraGrid.GridControl();
            this.gridMain4 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand3 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn54 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn150 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn149 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn147 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn55 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn56 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox22 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn58 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn57 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox21 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn151 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn59 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn60 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn61 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn62 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn63 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn135 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox18 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn134 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn64 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn65 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn66 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn67 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn68 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn124 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn69 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox20 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.gridView4 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.tabMusicians = new System.Windows.Forms.TabPage();
            this.dgv5 = new DevExpress.XtraGrid.GridControl();
            this.gridMain5 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand4 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn70 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn148 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn71 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn72 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn74 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn73 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn75 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn76 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn77 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn78 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn79 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn136 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox19 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn137 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn80 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn81 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn82 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn83 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn84 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn125 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn85 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn156 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridView5 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.tabDisclosures = new System.Windows.Forms.TabPage();
            this.dgv7 = new DevExpress.XtraGrid.GridControl();
            this.gridMain7 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand10 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn157 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn162 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit8 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.bandedGridColumn158 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn159 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn167 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit9 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit10 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit11 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.panelFamilyTop = new System.Windows.Forms.Panel();
            this.btnHold = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.picRowDown = new System.Windows.Forms.PictureBox();
            this.picRowUp = new System.Windows.Forms.PictureBox();
            this.btnSaveAll = new System.Windows.Forms.Button();
            this.chkLegal = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            this.lblSelect = new System.Windows.Forms.Label();
            this.lblFamily = new System.Windows.Forms.Label();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox7)).BeginInit();
            this.panelAll.SuspendLayout();
            this.panelBottom.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabFamily.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDependent)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridMainDep)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.tabLegal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLegal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMainLegal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView6)).BeginInit();
            this.tabFuneralData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2.CalendarTimeProperties)).BeginInit();
            this.tabPallbearers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).BeginInit();
            this.tabHonoraryPallBearers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).BeginInit();
            this.tabClergy.SuspendLayout();
            this.panelClergyStuff.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).BeginInit();
            this.tabMusicians.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView5)).BeginInit();
            this.tabDisclosures.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit11)).BeginInit();
            this.panelFamilyTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRowDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRowUp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLegal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.SuspendLayout();
            // 
            // repositoryItemComboBox9
            // 
            this.repositoryItemComboBox9.AutoHeight = false;
            this.repositoryItemComboBox9.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox9.Items.AddRange(new object[] {
            "Spouse",
            "Daughter",
            "Son",
            "Sister",
            "Brother",
            "Grandparent",
            "Grandchild",
            "Great-Grandchild",
            "Granddaughter",
            "Grandson",
            "Great-Granddaughter",
            "Great-Grandson"});
            this.repositoryItemComboBox9.Name = "repositoryItemComboBox9";
            this.repositoryItemComboBox9.PopupFormSize = new System.Drawing.Size(100, 100);
            this.repositoryItemComboBox9.PopupSizeable = true;
            // 
            // repositoryItemComboBox7
            // 
            this.repositoryItemComboBox7.AutoHeight = false;
            this.repositoryItemComboBox7.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox7.Name = "repositoryItemComboBox7";
            // 
            // panelAll
            // 
            this.panelAll.Controls.Add(this.panelBottom);
            this.panelAll.Controls.Add(this.panelFamilyTop);
            this.panelAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAll.Location = new System.Drawing.Point(0, 0);
            this.panelAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelAll.Name = "panelAll";
            this.panelAll.Size = new System.Drawing.Size(1677, 413);
            this.panelAll.TabIndex = 0;
            // 
            // panelBottom
            // 
            this.panelBottom.Controls.Add(this.tabControl1);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBottom.Location = new System.Drawing.Point(0, 37);
            this.panelBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(1677, 376);
            this.panelBottom.TabIndex = 4;
            this.panelBottom.Paint += new System.Windows.Forms.PaintEventHandler(this.panelBottom_Paint);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabFamily);
            this.tabControl1.Controls.Add(this.tabLegal);
            this.tabControl1.Controls.Add(this.tabFuneralData);
            this.tabControl1.Controls.Add(this.tabPallbearers);
            this.tabControl1.Controls.Add(this.tabHonoraryPallBearers);
            this.tabControl1.Controls.Add(this.tabClergy);
            this.tabControl1.Controls.Add(this.tabMusicians);
            this.tabControl1.Controls.Add(this.tabDisclosures);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1677, 376);
            this.tabControl1.TabIndex = 9;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            this.tabControl1.Enter += new System.EventHandler(this.tabControl1_Enter);
            this.tabControl1.Leave += new System.EventHandler(this.tabControl1_Leave);
            // 
            // tabFamily
            // 
            this.tabFamily.Controls.Add(this.dgvDependent);
            this.tabFamily.Location = new System.Drawing.Point(4, 25);
            this.tabFamily.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabFamily.Name = "tabFamily";
            this.tabFamily.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabFamily.Size = new System.Drawing.Size(1669, 347);
            this.tabFamily.TabIndex = 0;
            this.tabFamily.Text = "Family Members";
            this.tabFamily.UseVisualStyleBackColor = true;
            // 
            // dgvDependent
            // 
            this.dgvDependent.ContextMenuStrip = this.contextMenuStrip1;
            this.dgvDependent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDependent.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgvDependent.Location = new System.Drawing.Point(3, 4);
            this.dgvDependent.LookAndFeel.SkinName = "Foggy";
            this.dgvDependent.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgvDependent.MainView = this.gridMainDep;
            this.dgvDependent.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgvDependent.Name = "dgvDependent";
            this.dgvDependent.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox2,
            this.repositoryItemCheckEdit1,
            this.repositoryItemPictureEdit1,
            this.repositoryItemComboBox1,
            this.repositoryItemComboBox15,
            this.repositoryItemCheckEdit6,
            this.repositoryItemCheckEdit7,
            this.repositoryItemDateEdit1,
            this.repositoryItemCheckEdit12});
            this.dgvDependent.Size = new System.Drawing.Size(1663, 339);
            this.dgvDependent.TabIndex = 8;
            this.dgvDependent.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMainDep,
            this.gridView1});
            this.dgvDependent.VisibleChanged += new System.EventHandler(this.dgvDependent_VisibleChanged);
            this.dgvDependent.Enter += new System.EventHandler(this.dgvDependent_Enter);
            this.dgvDependent.Leave += new System.EventHandler(this.dgvDependent_Leave);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addSignatureToolStripMenuItem,
            this.copyFromDeceasedAddressToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(275, 52);
            // 
            // addSignatureToolStripMenuItem
            // 
            this.addSignatureToolStripMenuItem.Name = "addSignatureToolStripMenuItem";
            this.addSignatureToolStripMenuItem.Size = new System.Drawing.Size(274, 24);
            this.addSignatureToolStripMenuItem.Text = "Add Signature";
            this.addSignatureToolStripMenuItem.Click += new System.EventHandler(this.addSignatureToolStripMenuItem_Click);
            // 
            // copyFromDeceasedAddressToolStripMenuItem
            // 
            this.copyFromDeceasedAddressToolStripMenuItem.Name = "copyFromDeceasedAddressToolStripMenuItem";
            this.copyFromDeceasedAddressToolStripMenuItem.Size = new System.Drawing.Size(274, 24);
            this.copyFromDeceasedAddressToolStripMenuItem.Text = "Copy from Deceased Address";
            this.copyFromDeceasedAddressToolStripMenuItem.Click += new System.EventHandler(this.copyFromDeceasedAddressToolStripMenuItem_Click);
            // 
            // gridMainDep
            // 
            this.gridMainDep.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(190)))), ((int)(((byte)(159)))));
            this.gridMainDep.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(190)))), ((int)(((byte)(159)))));
            this.gridMainDep.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMainDep.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMainDep.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMainDep.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMainDep.Appearance.BandPanel.Options.UseFont = true;
            this.gridMainDep.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMainDep.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(93)))), ((int)(((byte)(63)))));
            this.gridMainDep.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMainDep.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainDep.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMainDep.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainDep.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMainDep.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMainDep.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMainDep.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMainDep.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMainDep.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(201)))), ((int)(((byte)(228)))), ((int)(((byte)(206)))));
            this.gridMainDep.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMainDep.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMainDep.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMainDep.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMainDep.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMainDep.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMainDep.Appearance.Empty.Options.UseBackColor = true;
            this.gridMainDep.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainDep.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMainDep.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMainDep.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMainDep.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMainDep.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMainDep.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMainDep.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(123)))), ((int)(((byte)(93)))));
            this.gridMainDep.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMainDep.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMainDep.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMainDep.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMainDep.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMainDep.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMainDep.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(33)))), ((int)(((byte)(3)))));
            this.gridMainDep.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMainDep.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMainDep.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMainDep.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMainDep.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMainDep.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(81)))), ((int)(((byte)(30)))));
            this.gridMainDep.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMainDep.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMainDep.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(201)))), ((int)(((byte)(150)))));
            this.gridMainDep.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMainDep.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMainDep.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMainDep.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainDep.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainDep.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMainDep.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMainDep.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMainDep.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMainDep.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainDep.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainDep.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMainDep.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMainDep.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMainDep.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMainDep.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(210)))), ((int)(((byte)(179)))));
            this.gridMainDep.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(210)))), ((int)(((byte)(179)))));
            this.gridMainDep.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMainDep.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMainDep.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMainDep.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMainDep.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(63)))), ((int)(((byte)(33)))));
            this.gridMainDep.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMainDep.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMainDep.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMainDep.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMainDep.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMainDep.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMainDep.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMainDep.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(227)))), ((int)(((byte)(211)))));
            this.gridMainDep.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMainDep.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMainDep.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainDep.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainDep.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMainDep.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMainDep.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMainDep.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMainDep.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMainDep.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMainDep.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMainDep.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMainDep.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(103)))), ((int)(((byte)(73)))));
            this.gridMainDep.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMainDep.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMainDep.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMainDep.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMainDep.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMainDep.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainDep.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMainDep.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(227)))), ((int)(((byte)(211)))));
            this.gridMainDep.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMainDep.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMainDep.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMainDep.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMainDep.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMainDep.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(255)))), ((int)(((byte)(229)))));
            this.gridMainDep.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMainDep.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMainDep.Appearance.Preview.Options.UseBackColor = true;
            this.gridMainDep.Appearance.Preview.Options.UseForeColor = true;
            this.gridMainDep.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMainDep.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMainDep.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMainDep.Appearance.Row.Options.UseBackColor = true;
            this.gridMainDep.Appearance.Row.Options.UseFont = true;
            this.gridMainDep.Appearance.Row.Options.UseForeColor = true;
            this.gridMainDep.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMainDep.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMainDep.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMainDep.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(161)))), ((int)(((byte)(110)))));
            this.gridMainDep.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMainDep.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMainDep.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMainDep.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainDep.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMainDep.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMainDep.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMainDep.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand6});
            this.gridMainDep.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMainDep.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn45,
            this.bandedGridColumn53,
            this.bandedGridColumn152,
            this.bandedGridColumn143,
            this.bandedGridColumn46,
            this.bandedGridColumn47,
            this.bandedGridColumn48,
            this.bandedGridColumn9,
            this.bandedGridColumn49,
            this.bandedGridColumn50,
            this.bandedGridColumn21,
            this.bandedGridColumn51,
            this.bandedGridColumn19,
            this.bandedGridColumn8,
            this.bandedGridColumn20,
            this.bandedGridColumn7,
            this.bandedGridColumn6,
            this.bandedGridColumn120,
            this.bandedGridColumn1,
            this.bandedGridColumn128,
            this.bandedGridColumn129,
            this.bandedGridColumn2,
            this.bandedGridColumn3,
            this.bandedGridColumn4,
            this.bandedGridColumn160,
            this.bandedGridColumn142,
            this.bandedGridColumn163,
            this.bandedGridColumn5,
            this.bandedGridColumn10,
            this.bandedGridColumn138});
            this.gridMainDep.DetailHeight = 431;
            this.gridMainDep.GridControl = this.dgvDependent;
            this.gridMainDep.Name = "gridMainDep";
            this.gridMainDep.OptionsBehavior.AutoPopulateColumns = false;
            this.gridMainDep.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.MouseDown;
            this.gridMainDep.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridMainDep.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMainDep.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMainDep.OptionsView.EnableAppearanceOddRow = true;
            this.gridMainDep.OptionsView.ShowBands = false;
            this.gridMainDep.OptionsView.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowAlways;
            this.gridMainDep.OptionsView.ShowGroupPanel = false;
            this.gridMainDep.PaintStyleName = "Flat";
            this.gridMainDep.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMainDep_CustomDrawCell);
            this.gridMainDep.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMainDep_CellValueChanged);
            this.gridMainDep.CellValueChanging += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMainDep_CellValueChanging);
            this.gridMainDep.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMainDep_CustomRowFilter);
            this.gridMainDep.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gridMainDep_KeyDown);
            this.gridMainDep.KeyUp += new System.Windows.Forms.KeyEventHandler(this.gridMainDep_KeyUp);
            this.gridMainDep.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.gridMainDep_KeyPress);
            this.gridMainDep.MouseDown += new System.Windows.Forms.MouseEventHandler(this.gridMainDep_MouseDown);
            // 
            // gridBand6
            // 
            this.gridBand6.Caption = "gridBand1";
            this.gridBand6.Columns.Add(this.bandedGridColumn45);
            this.gridBand6.Columns.Add(this.bandedGridColumn142);
            this.gridBand6.Columns.Add(this.bandedGridColumn163);
            this.gridBand6.Columns.Add(this.bandedGridColumn143);
            this.gridBand6.Columns.Add(this.bandedGridColumn53);
            this.gridBand6.Columns.Add(this.bandedGridColumn47);
            this.gridBand6.Columns.Add(this.bandedGridColumn48);
            this.gridBand6.Columns.Add(this.bandedGridColumn46);
            this.gridBand6.Columns.Add(this.bandedGridColumn49);
            this.gridBand6.Columns.Add(this.bandedGridColumn9);
            this.gridBand6.Columns.Add(this.bandedGridColumn50);
            this.gridBand6.Columns.Add(this.bandedGridColumn21);
            this.gridBand6.Columns.Add(this.bandedGridColumn138);
            this.gridBand6.Columns.Add(this.bandedGridColumn1);
            this.gridBand6.Columns.Add(this.bandedGridColumn128);
            this.gridBand6.Columns.Add(this.bandedGridColumn129);
            this.gridBand6.Columns.Add(this.bandedGridColumn51);
            this.gridBand6.Columns.Add(this.bandedGridColumn19);
            this.gridBand6.Columns.Add(this.bandedGridColumn8);
            this.gridBand6.Columns.Add(this.bandedGridColumn20);
            this.gridBand6.Columns.Add(this.bandedGridColumn7);
            this.gridBand6.Columns.Add(this.bandedGridColumn6);
            this.gridBand6.Columns.Add(this.bandedGridColumn120);
            this.gridBand6.Columns.Add(this.bandedGridColumn2);
            this.gridBand6.Columns.Add(this.bandedGridColumn3);
            this.gridBand6.Columns.Add(this.bandedGridColumn4);
            this.gridBand6.Columns.Add(this.bandedGridColumn160);
            this.gridBand6.Columns.Add(this.bandedGridColumn5);
            this.gridBand6.Columns.Add(this.bandedGridColumn10);
            this.gridBand6.MinWidth = 16;
            this.gridBand6.Name = "gridBand6";
            this.gridBand6.VisibleIndex = 0;
            this.gridBand6.Width = 3090;
            // 
            // bandedGridColumn45
            // 
            this.bandedGridColumn45.Caption = "Num";
            this.bandedGridColumn45.FieldName = "num";
            this.bandedGridColumn45.MinWidth = 31;
            this.bandedGridColumn45.Name = "bandedGridColumn45";
            this.bandedGridColumn45.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn45.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn45.Visible = true;
            this.bandedGridColumn45.Width = 84;
            // 
            // bandedGridColumn142
            // 
            this.bandedGridColumn142.Caption = "PB";
            this.bandedGridColumn142.ColumnEdit = this.repositoryItemCheckEdit7;
            this.bandedGridColumn142.FieldName = "pb";
            this.bandedGridColumn142.MinWidth = 31;
            this.bandedGridColumn142.Name = "bandedGridColumn142";
            this.bandedGridColumn142.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn142.ToolTip = "Set as Pall Bearer";
            this.bandedGridColumn142.Visible = true;
            this.bandedGridColumn142.Width = 56;
            // 
            // repositoryItemCheckEdit7
            // 
            this.repositoryItemCheckEdit7.AutoHeight = false;
            this.repositoryItemCheckEdit7.Name = "repositoryItemCheckEdit7";
            this.repositoryItemCheckEdit7.CheckedChanged += new System.EventHandler(this.repositoryItemCheckEdit7_CheckedChanged);
            // 
            // bandedGridColumn163
            // 
            this.bandedGridColumn163.Caption = "HPB";
            this.bandedGridColumn163.ColumnEdit = this.repositoryItemCheckEdit12;
            this.bandedGridColumn163.FieldName = "hpb";
            this.bandedGridColumn163.MinWidth = 29;
            this.bandedGridColumn163.Name = "bandedGridColumn163";
            this.bandedGridColumn163.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn163.ToolTip = "Set as Honorary Pall Bearer";
            this.bandedGridColumn163.Visible = true;
            this.bandedGridColumn163.Width = 58;
            // 
            // repositoryItemCheckEdit12
            // 
            this.repositoryItemCheckEdit12.AutoHeight = false;
            this.repositoryItemCheckEdit12.Name = "repositoryItemCheckEdit12";
            this.repositoryItemCheckEdit12.CheckedChanged += new System.EventHandler(this.repositoryItemCheckEdit12_CheckedChanged);
            // 
            // bandedGridColumn143
            // 
            this.bandedGridColumn143.Caption = "Title";
            this.bandedGridColumn143.FieldName = "depPrefix";
            this.bandedGridColumn143.MinWidth = 31;
            this.bandedGridColumn143.Name = "bandedGridColumn143";
            this.bandedGridColumn143.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn143.Visible = true;
            this.bandedGridColumn143.Width = 64;
            // 
            // bandedGridColumn53
            // 
            this.bandedGridColumn53.Caption = "record";
            this.bandedGridColumn53.FieldName = "record";
            this.bandedGridColumn53.MinWidth = 31;
            this.bandedGridColumn53.Name = "bandedGridColumn53";
            this.bandedGridColumn53.Width = 118;
            // 
            // bandedGridColumn47
            // 
            this.bandedGridColumn47.Caption = "First Name";
            this.bandedGridColumn47.FieldName = "depFirstName";
            this.bandedGridColumn47.MinWidth = 31;
            this.bandedGridColumn47.Name = "bandedGridColumn47";
            this.bandedGridColumn47.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn47.Visible = true;
            this.bandedGridColumn47.Width = 118;
            // 
            // bandedGridColumn48
            // 
            this.bandedGridColumn48.Caption = "Middle Initial";
            this.bandedGridColumn48.FieldName = "depMI";
            this.bandedGridColumn48.MinWidth = 31;
            this.bandedGridColumn48.Name = "bandedGridColumn48";
            this.bandedGridColumn48.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn48.Visible = true;
            this.bandedGridColumn48.Width = 96;
            // 
            // bandedGridColumn46
            // 
            this.bandedGridColumn46.Caption = "Last Name";
            this.bandedGridColumn46.FieldName = "depLastName";
            this.bandedGridColumn46.MinWidth = 31;
            this.bandedGridColumn46.Name = "bandedGridColumn46";
            this.bandedGridColumn46.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn46.Visible = true;
            this.bandedGridColumn46.Width = 118;
            // 
            // bandedGridColumn49
            // 
            this.bandedGridColumn49.Caption = "Suffix";
            this.bandedGridColumn49.FieldName = "depSuffix";
            this.bandedGridColumn49.MinWidth = 31;
            this.bandedGridColumn49.Name = "bandedGridColumn49";
            this.bandedGridColumn49.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn49.Visible = true;
            this.bandedGridColumn49.Width = 79;
            // 
            // bandedGridColumn9
            // 
            this.bandedGridColumn9.Caption = "Maiden Name";
            this.bandedGridColumn9.FieldName = "maidenName";
            this.bandedGridColumn9.MinWidth = 31;
            this.bandedGridColumn9.Name = "bandedGridColumn9";
            this.bandedGridColumn9.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn9.Visible = true;
            this.bandedGridColumn9.Width = 162;
            // 
            // bandedGridColumn50
            // 
            this.bandedGridColumn50.Caption = "DOB";
            this.bandedGridColumn50.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn50.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn50.FieldName = "depDOB";
            this.bandedGridColumn50.MinWidth = 31;
            this.bandedGridColumn50.Name = "bandedGridColumn50";
            this.bandedGridColumn50.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn50.Visible = true;
            this.bandedGridColumn50.Width = 118;
            // 
            // bandedGridColumn21
            // 
            this.bandedGridColumn21.Caption = "DOD";
            this.bandedGridColumn21.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn21.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn21.FieldName = "depDOD";
            this.bandedGridColumn21.MinWidth = 31;
            this.bandedGridColumn21.Name = "bandedGridColumn21";
            this.bandedGridColumn21.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn21.Visible = true;
            this.bandedGridColumn21.Width = 118;
            // 
            // bandedGridColumn138
            // 
            this.bandedGridColumn138.Caption = "Deceased";
            this.bandedGridColumn138.ColumnEdit = this.repositoryItemCheckEdit6;
            this.bandedGridColumn138.FieldName = "deceased";
            this.bandedGridColumn138.MinWidth = 31;
            this.bandedGridColumn138.Name = "bandedGridColumn138";
            this.bandedGridColumn138.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn138.Visible = true;
            this.bandedGridColumn138.Width = 118;
            // 
            // repositoryItemCheckEdit6
            // 
            this.repositoryItemCheckEdit6.AutoHeight = false;
            this.repositoryItemCheckEdit6.Name = "repositoryItemCheckEdit6";
            this.repositoryItemCheckEdit6.Click += new System.EventHandler(this.repositoryItemCheckEdit6_Click);
            // 
            // bandedGridColumn1
            // 
            this.bandedGridColumn1.Caption = "Phone";
            this.bandedGridColumn1.FieldName = "phone";
            this.bandedGridColumn1.MinWidth = 31;
            this.bandedGridColumn1.Name = "bandedGridColumn1";
            this.bandedGridColumn1.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn1.Visible = true;
            this.bandedGridColumn1.Width = 118;
            // 
            // bandedGridColumn128
            // 
            this.bandedGridColumn128.Caption = "Phone Type";
            this.bandedGridColumn128.ColumnEdit = this.repositoryItemComboBox15;
            this.bandedGridColumn128.FieldName = "phoneType";
            this.bandedGridColumn128.MinWidth = 31;
            this.bandedGridColumn128.Name = "bandedGridColumn128";
            this.bandedGridColumn128.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn128.Visible = true;
            this.bandedGridColumn128.Width = 118;
            // 
            // repositoryItemComboBox15
            // 
            this.repositoryItemComboBox15.AutoHeight = false;
            this.repositoryItemComboBox15.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox15.Items.AddRange(new object[] {
            "Home",
            "Cell",
            "Work"});
            this.repositoryItemComboBox15.Name = "repositoryItemComboBox15";
            // 
            // bandedGridColumn129
            // 
            this.bandedGridColumn129.Caption = "Email";
            this.bandedGridColumn129.FieldName = "email";
            this.bandedGridColumn129.MinWidth = 31;
            this.bandedGridColumn129.Name = "bandedGridColumn129";
            this.bandedGridColumn129.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn129.Visible = true;
            this.bandedGridColumn129.Width = 118;
            // 
            // bandedGridColumn51
            // 
            this.bandedGridColumn51.Caption = "RelationShip";
            this.bandedGridColumn51.ColumnEdit = this.repositoryItemComboBox2;
            this.bandedGridColumn51.FieldName = "depRelationship";
            this.bandedGridColumn51.MinWidth = 31;
            this.bandedGridColumn51.Name = "bandedGridColumn51";
            this.bandedGridColumn51.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn51.Visible = true;
            this.bandedGridColumn51.Width = 198;
            // 
            // repositoryItemComboBox2
            // 
            this.repositoryItemComboBox2.AutoHeight = false;
            this.repositoryItemComboBox2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox2.Items.AddRange(new object[] {
            "Spouse",
            "Daughter",
            "Son",
            "Sister",
            "Brother",
            "Grandparent",
            "Grandchild",
            "Great-Grandchild",
            "Granddaughter",
            "Grandson",
            "Great-Granddaughter",
            "Great-Grandson"});
            this.repositoryItemComboBox2.Name = "repositoryItemComboBox2";
            this.repositoryItemComboBox2.PopupFormSize = new System.Drawing.Size(117, 123);
            this.repositoryItemComboBox2.PopupSizeable = true;
            // 
            // bandedGridColumn19
            // 
            this.bandedGridColumn19.Caption = "Spouse First Name";
            this.bandedGridColumn19.FieldName = "spouseFirstName";
            this.bandedGridColumn19.MinWidth = 31;
            this.bandedGridColumn19.Name = "bandedGridColumn19";
            this.bandedGridColumn19.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn19.Visible = true;
            this.bandedGridColumn19.Width = 118;
            // 
            // bandedGridColumn8
            // 
            this.bandedGridColumn8.Caption = "Address";
            this.bandedGridColumn8.FieldName = "address";
            this.bandedGridColumn8.MinWidth = 31;
            this.bandedGridColumn8.Name = "bandedGridColumn8";
            this.bandedGridColumn8.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn8.Visible = true;
            this.bandedGridColumn8.Width = 118;
            // 
            // bandedGridColumn20
            // 
            this.bandedGridColumn20.Caption = "City";
            this.bandedGridColumn20.FieldName = "city";
            this.bandedGridColumn20.MinWidth = 31;
            this.bandedGridColumn20.Name = "bandedGridColumn20";
            this.bandedGridColumn20.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn20.Visible = true;
            this.bandedGridColumn20.Width = 118;
            // 
            // bandedGridColumn7
            // 
            this.bandedGridColumn7.Caption = "State";
            this.bandedGridColumn7.ColumnEdit = this.repositoryItemComboBox1;
            this.bandedGridColumn7.FieldName = "state";
            this.bandedGridColumn7.MinWidth = 31;
            this.bandedGridColumn7.Name = "bandedGridColumn7";
            this.bandedGridColumn7.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn7.Visible = true;
            this.bandedGridColumn7.Width = 79;
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.AutoHeight = false;
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            // 
            // bandedGridColumn6
            // 
            this.bandedGridColumn6.Caption = "Zip";
            this.bandedGridColumn6.FieldName = "zip";
            this.bandedGridColumn6.MinWidth = 31;
            this.bandedGridColumn6.Name = "bandedGridColumn6";
            this.bandedGridColumn6.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn6.Visible = true;
            this.bandedGridColumn6.Width = 96;
            // 
            // bandedGridColumn120
            // 
            this.bandedGridColumn120.Caption = "County";
            this.bandedGridColumn120.FieldName = "county";
            this.bandedGridColumn120.MinWidth = 31;
            this.bandedGridColumn120.Name = "bandedGridColumn120";
            this.bandedGridColumn120.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn120.Visible = true;
            this.bandedGridColumn120.Width = 118;
            // 
            // bandedGridColumn2
            // 
            this.bandedGridColumn2.Caption = "Next of Kin";
            this.bandedGridColumn2.ColumnEdit = this.repositoryItemCheckEdit1;
            this.bandedGridColumn2.FieldName = "nextOfKin";
            this.bandedGridColumn2.MinWidth = 31;
            this.bandedGridColumn2.Name = "bandedGridColumn2";
            this.bandedGridColumn2.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn2.Visible = true;
            this.bandedGridColumn2.Width = 104;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.Click += new System.EventHandler(this.repositoryItemCheckEdit1_Click);
            // 
            // bandedGridColumn3
            // 
            this.bandedGridColumn3.Caption = "Informant";
            this.bandedGridColumn3.ColumnEdit = this.repositoryItemCheckEdit1;
            this.bandedGridColumn3.FieldName = "informant";
            this.bandedGridColumn3.MinWidth = 31;
            this.bandedGridColumn3.Name = "bandedGridColumn3";
            this.bandedGridColumn3.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn3.Visible = true;
            this.bandedGridColumn3.Width = 118;
            // 
            // bandedGridColumn4
            // 
            this.bandedGridColumn4.Caption = "Purchaser";
            this.bandedGridColumn4.ColumnEdit = this.repositoryItemCheckEdit1;
            this.bandedGridColumn4.FieldName = "purchaser";
            this.bandedGridColumn4.MinWidth = 31;
            this.bandedGridColumn4.Name = "bandedGridColumn4";
            this.bandedGridColumn4.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn4.Visible = true;
            this.bandedGridColumn4.Width = 118;
            // 
            // bandedGridColumn160
            // 
            this.bandedGridColumn160.Caption = "Authorize Embalming";
            this.bandedGridColumn160.ColumnEdit = this.repositoryItemCheckEdit1;
            this.bandedGridColumn160.FieldName = "authEmbalming";
            this.bandedGridColumn160.MinWidth = 34;
            this.bandedGridColumn160.Name = "bandedGridColumn160";
            this.bandedGridColumn160.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn160.Visible = true;
            this.bandedGridColumn160.Width = 128;
            // 
            // bandedGridColumn5
            // 
            this.bandedGridColumn5.Caption = "Signature";
            this.bandedGridColumn5.ColumnEdit = this.repositoryItemPictureEdit1;
            this.bandedGridColumn5.FieldName = "sigs";
            this.bandedGridColumn5.MinWidth = 31;
            this.bandedGridColumn5.Name = "bandedGridColumn5";
            this.bandedGridColumn5.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn5.Visible = true;
            this.bandedGridColumn5.Width = 159;
            // 
            // repositoryItemPictureEdit1
            // 
            this.repositoryItemPictureEdit1.Name = "repositoryItemPictureEdit1";
            this.repositoryItemPictureEdit1.PictureAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.repositoryItemPictureEdit1.PictureStoreMode = DevExpress.XtraEditors.Controls.PictureStoreMode.Image;
            this.repositoryItemPictureEdit1.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            // 
            // bandedGridColumn10
            // 
            this.bandedGridColumn10.Caption = "Signature Date";
            this.bandedGridColumn10.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn10.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn10.FieldName = "signatureDate";
            this.bandedGridColumn10.MinWidth = 31;
            this.bandedGridColumn10.Name = "bandedGridColumn10";
            this.bandedGridColumn10.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn10.Visible = true;
            // 
            // bandedGridColumn152
            // 
            this.bandedGridColumn152.Caption = "Full Name";
            this.bandedGridColumn152.FieldName = "fullName";
            this.bandedGridColumn152.MinWidth = 31;
            this.bandedGridColumn152.Name = "bandedGridColumn152";
            this.bandedGridColumn152.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn152.Width = 118;
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            this.repositoryItemDateEdit1.Closed += new DevExpress.XtraEditors.Controls.ClosedEventHandler(this.repositoryItemDateEdit1_Closed);
            // 
            // gridView1
            // 
            this.gridView1.DetailHeight = 431;
            this.gridView1.GridControl = this.dgvDependent;
            this.gridView1.Name = "gridView1";
            // 
            // tabLegal
            // 
            this.tabLegal.Controls.Add(this.dgvLegal);
            this.tabLegal.Location = new System.Drawing.Point(4, 25);
            this.tabLegal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabLegal.Name = "tabLegal";
            this.tabLegal.Size = new System.Drawing.Size(1669, 347);
            this.tabLegal.TabIndex = 6;
            this.tabLegal.Text = "Legal Members";
            this.tabLegal.UseVisualStyleBackColor = true;
            // 
            // dgvLegal
            // 
            this.dgvLegal.ContextMenuStrip = this.contextMenuStrip1;
            this.dgvLegal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvLegal.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgvLegal.Location = new System.Drawing.Point(0, 0);
            this.dgvLegal.LookAndFeel.SkinName = "Foggy";
            this.dgvLegal.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgvLegal.MainView = this.gridMainLegal;
            this.dgvLegal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgvLegal.Name = "dgvLegal";
            this.dgvLegal.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox13,
            this.repositoryItemCheckEdit5,
            this.repositoryItemPictureEdit5,
            this.repositoryItemComboBox14});
            this.dgvLegal.Size = new System.Drawing.Size(1669, 347);
            this.dgvLegal.TabIndex = 9;
            this.dgvLegal.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMainLegal,
            this.gridView6});
            this.dgvLegal.VisibleChanged += new System.EventHandler(this.dgvLegal_VisibleChanged);
            this.dgvLegal.Enter += new System.EventHandler(this.dgvLegal_Enter);
            this.dgvLegal.Leave += new System.EventHandler(this.dgvLegal_Leave);
            // 
            // gridMainLegal
            // 
            this.gridMainLegal.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(190)))), ((int)(((byte)(159)))));
            this.gridMainLegal.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(190)))), ((int)(((byte)(159)))));
            this.gridMainLegal.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMainLegal.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMainLegal.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMainLegal.Appearance.BandPanel.Options.UseFont = true;
            this.gridMainLegal.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(93)))), ((int)(((byte)(63)))));
            this.gridMainLegal.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainLegal.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMainLegal.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainLegal.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMainLegal.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMainLegal.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMainLegal.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(201)))), ((int)(((byte)(228)))), ((int)(((byte)(206)))));
            this.gridMainLegal.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMainLegal.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMainLegal.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMainLegal.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMainLegal.Appearance.Empty.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainLegal.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMainLegal.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMainLegal.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMainLegal.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMainLegal.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(123)))), ((int)(((byte)(93)))));
            this.gridMainLegal.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMainLegal.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMainLegal.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMainLegal.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMainLegal.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(33)))), ((int)(((byte)(3)))));
            this.gridMainLegal.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMainLegal.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMainLegal.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMainLegal.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(81)))), ((int)(((byte)(30)))));
            this.gridMainLegal.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMainLegal.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(201)))), ((int)(((byte)(150)))));
            this.gridMainLegal.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMainLegal.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainLegal.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainLegal.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMainLegal.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMainLegal.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainLegal.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainLegal.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMainLegal.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMainLegal.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(210)))), ((int)(((byte)(179)))));
            this.gridMainLegal.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(210)))), ((int)(((byte)(179)))));
            this.gridMainLegal.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMainLegal.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMainLegal.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(63)))), ((int)(((byte)(33)))));
            this.gridMainLegal.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMainLegal.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMainLegal.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMainLegal.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMainLegal.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMainLegal.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(227)))), ((int)(((byte)(211)))));
            this.gridMainLegal.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainLegal.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainLegal.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMainLegal.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMainLegal.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMainLegal.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMainLegal.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMainLegal.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMainLegal.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(103)))), ((int)(((byte)(73)))));
            this.gridMainLegal.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMainLegal.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMainLegal.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainLegal.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(227)))), ((int)(((byte)(211)))));
            this.gridMainLegal.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMainLegal.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMainLegal.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMainLegal.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(255)))), ((int)(((byte)(229)))));
            this.gridMainLegal.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMainLegal.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMainLegal.Appearance.Preview.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.Preview.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMainLegal.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMainLegal.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMainLegal.Appearance.Row.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.Row.Options.UseFont = true;
            this.gridMainLegal.Appearance.Row.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMainLegal.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMainLegal.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(161)))), ((int)(((byte)(110)))));
            this.gridMainLegal.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMainLegal.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMainLegal.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMainLegal.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMainLegal.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMainLegal.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMainLegal.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMainLegal.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand9});
            this.gridMainLegal.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMainLegal.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn126,
            this.bandedGridColumn99,
            this.bandedGridColumn100,
            this.bandedGridColumn153,
            this.bandedGridColumn144,
            this.bandedGridColumn102,
            this.bandedGridColumn101,
            this.bandedGridColumn103,
            this.bandedGridColumn105,
            this.bandedGridColumn104,
            this.bandedGridColumn106,
            this.bandedGridColumn107,
            this.bandedGridColumn109,
            this.bandedGridColumn110,
            this.bandedGridColumn111,
            this.bandedGridColumn112,
            this.bandedGridColumn113,
            this.bandedGridColumn114,
            this.bandedGridColumn121,
            this.bandedGridColumn108,
            this.bandedGridColumn115,
            this.bandedGridColumn116,
            this.bandedGridColumn117,
            this.bandedGridColumn161,
            this.bandedGridColumn118,
            this.bandedGridColumn119,
            this.bandedGridColumn127,
            this.bandedGridColumn139});
            this.gridMainLegal.DetailHeight = 431;
            this.gridMainLegal.GridControl = this.dgvLegal;
            this.gridMainLegal.Name = "gridMainLegal";
            this.gridMainLegal.OptionsBehavior.AutoPopulateColumns = false;
            this.gridMainLegal.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.MouseDown;
            this.gridMainLegal.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridMainLegal.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMainLegal.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMainLegal.OptionsView.EnableAppearanceOddRow = true;
            this.gridMainLegal.OptionsView.ShowBands = false;
            this.gridMainLegal.OptionsView.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowAlways;
            this.gridMainLegal.OptionsView.ShowGroupPanel = false;
            this.gridMainLegal.PaintStyleName = "Style3D";
            this.gridMainLegal.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMainLegal_CustomDrawCell);
            this.gridMainLegal.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMainLegal_CustomRowFilter);
            this.gridMainLegal.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gridMainDep_KeyDown);
            this.gridMainLegal.MouseDown += new System.Windows.Forms.MouseEventHandler(this.gridMainLegal_MouseDown);
            // 
            // gridBand9
            // 
            this.gridBand9.Caption = "gridBand1";
            this.gridBand9.Columns.Add(this.bandedGridColumn99);
            this.gridBand9.Columns.Add(this.bandedGridColumn144);
            this.gridBand9.Columns.Add(this.bandedGridColumn100);
            this.gridBand9.Columns.Add(this.bandedGridColumn101);
            this.gridBand9.Columns.Add(this.bandedGridColumn103);
            this.gridBand9.Columns.Add(this.bandedGridColumn102);
            this.gridBand9.Columns.Add(this.bandedGridColumn104);
            this.gridBand9.Columns.Add(this.bandedGridColumn105);
            this.gridBand9.Columns.Add(this.bandedGridColumn106);
            this.gridBand9.Columns.Add(this.bandedGridColumn107);
            this.gridBand9.Columns.Add(this.bandedGridColumn139);
            this.gridBand9.Columns.Add(this.bandedGridColumn108);
            this.gridBand9.Columns.Add(this.bandedGridColumn126);
            this.gridBand9.Columns.Add(this.bandedGridColumn127);
            this.gridBand9.Columns.Add(this.bandedGridColumn109);
            this.gridBand9.Columns.Add(this.bandedGridColumn110);
            this.gridBand9.Columns.Add(this.bandedGridColumn111);
            this.gridBand9.Columns.Add(this.bandedGridColumn112);
            this.gridBand9.Columns.Add(this.bandedGridColumn113);
            this.gridBand9.Columns.Add(this.bandedGridColumn114);
            this.gridBand9.Columns.Add(this.bandedGridColumn121);
            this.gridBand9.Columns.Add(this.bandedGridColumn115);
            this.gridBand9.Columns.Add(this.bandedGridColumn116);
            this.gridBand9.Columns.Add(this.bandedGridColumn117);
            this.gridBand9.Columns.Add(this.bandedGridColumn161);
            this.gridBand9.Columns.Add(this.bandedGridColumn119);
            this.gridBand9.Columns.Add(this.bandedGridColumn118);
            this.gridBand9.MinWidth = 22;
            this.gridBand9.Name = "gridBand9";
            this.gridBand9.VisibleIndex = 0;
            this.gridBand9.Width = 3287;
            // 
            // bandedGridColumn99
            // 
            this.bandedGridColumn99.Caption = "Num";
            this.bandedGridColumn99.FieldName = "num";
            this.bandedGridColumn99.MinWidth = 36;
            this.bandedGridColumn99.Name = "bandedGridColumn99";
            this.bandedGridColumn99.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn99.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn99.Visible = true;
            this.bandedGridColumn99.Width = 60;
            // 
            // bandedGridColumn144
            // 
            this.bandedGridColumn144.Caption = "Title";
            this.bandedGridColumn144.FieldName = "depPrefix";
            this.bandedGridColumn144.MinWidth = 36;
            this.bandedGridColumn144.Name = "bandedGridColumn144";
            this.bandedGridColumn144.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn144.Visible = true;
            // 
            // bandedGridColumn100
            // 
            this.bandedGridColumn100.Caption = "record";
            this.bandedGridColumn100.FieldName = "record";
            this.bandedGridColumn100.MinWidth = 36;
            this.bandedGridColumn100.Name = "bandedGridColumn100";
            this.bandedGridColumn100.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn100.Width = 138;
            // 
            // bandedGridColumn101
            // 
            this.bandedGridColumn101.Caption = "First Name";
            this.bandedGridColumn101.FieldName = "depFirstName";
            this.bandedGridColumn101.MinWidth = 36;
            this.bandedGridColumn101.Name = "bandedGridColumn101";
            this.bandedGridColumn101.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn101.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn101.Visible = true;
            this.bandedGridColumn101.Width = 138;
            // 
            // bandedGridColumn103
            // 
            this.bandedGridColumn103.Caption = "Middle Initial";
            this.bandedGridColumn103.FieldName = "depMI";
            this.bandedGridColumn103.MinWidth = 36;
            this.bandedGridColumn103.Name = "bandedGridColumn103";
            this.bandedGridColumn103.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn103.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn103.Visible = true;
            this.bandedGridColumn103.Width = 112;
            // 
            // bandedGridColumn102
            // 
            this.bandedGridColumn102.Caption = "Last Name";
            this.bandedGridColumn102.FieldName = "depLastName";
            this.bandedGridColumn102.MinWidth = 36;
            this.bandedGridColumn102.Name = "bandedGridColumn102";
            this.bandedGridColumn102.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn102.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn102.Visible = true;
            this.bandedGridColumn102.Width = 138;
            // 
            // bandedGridColumn104
            // 
            this.bandedGridColumn104.Caption = "Suffix";
            this.bandedGridColumn104.FieldName = "depSuffix";
            this.bandedGridColumn104.MinWidth = 36;
            this.bandedGridColumn104.Name = "bandedGridColumn104";
            this.bandedGridColumn104.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn104.Visible = true;
            this.bandedGridColumn104.Width = 92;
            // 
            // bandedGridColumn105
            // 
            this.bandedGridColumn105.Caption = "Maiden Name";
            this.bandedGridColumn105.FieldName = "maidenName";
            this.bandedGridColumn105.MinWidth = 36;
            this.bandedGridColumn105.Name = "bandedGridColumn105";
            this.bandedGridColumn105.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn105.Visible = true;
            this.bandedGridColumn105.Width = 189;
            // 
            // bandedGridColumn106
            // 
            this.bandedGridColumn106.Caption = "DOB";
            this.bandedGridColumn106.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn106.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn106.FieldName = "depDOB";
            this.bandedGridColumn106.MinWidth = 36;
            this.bandedGridColumn106.Name = "bandedGridColumn106";
            this.bandedGridColumn106.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn106.Visible = true;
            this.bandedGridColumn106.Width = 101;
            // 
            // bandedGridColumn107
            // 
            this.bandedGridColumn107.Caption = "DOD";
            this.bandedGridColumn107.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn107.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn107.FieldName = "depDOD";
            this.bandedGridColumn107.MinWidth = 36;
            this.bandedGridColumn107.Name = "bandedGridColumn107";
            this.bandedGridColumn107.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn107.Visible = true;
            this.bandedGridColumn107.Width = 96;
            // 
            // bandedGridColumn139
            // 
            this.bandedGridColumn139.Caption = "Deceased";
            this.bandedGridColumn139.ColumnEdit = this.repositoryItemCheckEdit5;
            this.bandedGridColumn139.FieldName = "deceased";
            this.bandedGridColumn139.MinWidth = 42;
            this.bandedGridColumn139.Name = "bandedGridColumn139";
            this.bandedGridColumn139.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn139.Visible = true;
            this.bandedGridColumn139.Width = 125;
            // 
            // repositoryItemCheckEdit5
            // 
            this.repositoryItemCheckEdit5.AutoHeight = false;
            this.repositoryItemCheckEdit5.Name = "repositoryItemCheckEdit5";
            this.repositoryItemCheckEdit5.Click += new System.EventHandler(this.repositoryItemCheckEdit5_Click);
            // 
            // bandedGridColumn108
            // 
            this.bandedGridColumn108.Caption = "Phone";
            this.bandedGridColumn108.FieldName = "phone";
            this.bandedGridColumn108.MinWidth = 36;
            this.bandedGridColumn108.Name = "bandedGridColumn108";
            this.bandedGridColumn108.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn108.Visible = true;
            this.bandedGridColumn108.Width = 122;
            // 
            // bandedGridColumn126
            // 
            this.bandedGridColumn126.Caption = "Phone Type";
            this.bandedGridColumn126.FieldName = "phoneType";
            this.bandedGridColumn126.MinWidth = 36;
            this.bandedGridColumn126.Name = "bandedGridColumn126";
            this.bandedGridColumn126.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn126.Visible = true;
            this.bandedGridColumn126.Width = 138;
            // 
            // bandedGridColumn127
            // 
            this.bandedGridColumn127.Caption = "Email";
            this.bandedGridColumn127.FieldName = "email";
            this.bandedGridColumn127.MinWidth = 36;
            this.bandedGridColumn127.Name = "bandedGridColumn127";
            this.bandedGridColumn127.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn127.Visible = true;
            this.bandedGridColumn127.Width = 138;
            // 
            // bandedGridColumn109
            // 
            this.bandedGridColumn109.Caption = "RelationShip";
            this.bandedGridColumn109.ColumnEdit = this.repositoryItemComboBox13;
            this.bandedGridColumn109.FieldName = "depRelationship";
            this.bandedGridColumn109.MinWidth = 42;
            this.bandedGridColumn109.Name = "bandedGridColumn109";
            this.bandedGridColumn109.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn109.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn109.Visible = true;
            this.bandedGridColumn109.Width = 208;
            // 
            // repositoryItemComboBox13
            // 
            this.repositoryItemComboBox13.AutoHeight = false;
            this.repositoryItemComboBox13.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox13.Items.AddRange(new object[] {
            "Spouse",
            "Daughter",
            "Son",
            "Sister",
            "Brother",
            "Grandparent",
            "Grandchild",
            "Great-Grandchild",
            "Granddaughter",
            "Grandson",
            "Great-Granddaughter",
            "Great-Grandson"});
            this.repositoryItemComboBox13.Name = "repositoryItemComboBox13";
            this.repositoryItemComboBox13.PopupFormSize = new System.Drawing.Size(117, 123);
            this.repositoryItemComboBox13.PopupSizeable = true;
            // 
            // bandedGridColumn110
            // 
            this.bandedGridColumn110.Caption = "Spouse First Name";
            this.bandedGridColumn110.FieldName = "spouseFirstName";
            this.bandedGridColumn110.MinWidth = 36;
            this.bandedGridColumn110.Name = "bandedGridColumn110";
            this.bandedGridColumn110.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn110.Visible = true;
            this.bandedGridColumn110.Width = 138;
            // 
            // bandedGridColumn111
            // 
            this.bandedGridColumn111.Caption = "Address";
            this.bandedGridColumn111.FieldName = "address";
            this.bandedGridColumn111.MinWidth = 36;
            this.bandedGridColumn111.Name = "bandedGridColumn111";
            this.bandedGridColumn111.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn111.Visible = true;
            this.bandedGridColumn111.Width = 138;
            // 
            // bandedGridColumn112
            // 
            this.bandedGridColumn112.Caption = "City";
            this.bandedGridColumn112.FieldName = "city";
            this.bandedGridColumn112.MinWidth = 36;
            this.bandedGridColumn112.Name = "bandedGridColumn112";
            this.bandedGridColumn112.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn112.Visible = true;
            this.bandedGridColumn112.Width = 138;
            // 
            // bandedGridColumn113
            // 
            this.bandedGridColumn113.Caption = "State";
            this.bandedGridColumn113.ColumnEdit = this.repositoryItemComboBox14;
            this.bandedGridColumn113.FieldName = "state";
            this.bandedGridColumn113.MinWidth = 42;
            this.bandedGridColumn113.Name = "bandedGridColumn113";
            this.bandedGridColumn113.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn113.Visible = true;
            this.bandedGridColumn113.Width = 107;
            // 
            // repositoryItemComboBox14
            // 
            this.repositoryItemComboBox14.AutoHeight = false;
            this.repositoryItemComboBox14.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox14.Name = "repositoryItemComboBox14";
            // 
            // bandedGridColumn114
            // 
            this.bandedGridColumn114.Caption = "Zip";
            this.bandedGridColumn114.FieldName = "zip";
            this.bandedGridColumn114.MinWidth = 36;
            this.bandedGridColumn114.Name = "bandedGridColumn114";
            this.bandedGridColumn114.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn114.Visible = true;
            this.bandedGridColumn114.Width = 112;
            // 
            // bandedGridColumn121
            // 
            this.bandedGridColumn121.Caption = "County";
            this.bandedGridColumn121.FieldName = "county";
            this.bandedGridColumn121.MinWidth = 36;
            this.bandedGridColumn121.Name = "bandedGridColumn121";
            this.bandedGridColumn121.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn121.Visible = true;
            this.bandedGridColumn121.Width = 138;
            // 
            // bandedGridColumn115
            // 
            this.bandedGridColumn115.Caption = "Next of Kin";
            this.bandedGridColumn115.ColumnEdit = this.repositoryItemCheckEdit5;
            this.bandedGridColumn115.FieldName = "nextOfKin";
            this.bandedGridColumn115.MinWidth = 42;
            this.bandedGridColumn115.Name = "bandedGridColumn115";
            this.bandedGridColumn115.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn115.Visible = true;
            this.bandedGridColumn115.Width = 100;
            // 
            // bandedGridColumn116
            // 
            this.bandedGridColumn116.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn116.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn116.Caption = "Informant";
            this.bandedGridColumn116.ColumnEdit = this.repositoryItemCheckEdit5;
            this.bandedGridColumn116.FieldName = "informant";
            this.bandedGridColumn116.MinWidth = 42;
            this.bandedGridColumn116.Name = "bandedGridColumn116";
            this.bandedGridColumn116.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn116.Visible = true;
            this.bandedGridColumn116.Width = 110;
            // 
            // bandedGridColumn117
            // 
            this.bandedGridColumn117.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn117.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn117.Caption = "Purchaser";
            this.bandedGridColumn117.ColumnEdit = this.repositoryItemCheckEdit5;
            this.bandedGridColumn117.FieldName = "purchaser";
            this.bandedGridColumn117.MinWidth = 42;
            this.bandedGridColumn117.Name = "bandedGridColumn117";
            this.bandedGridColumn117.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn117.Visible = true;
            this.bandedGridColumn117.Width = 110;
            // 
            // bandedGridColumn161
            // 
            this.bandedGridColumn161.Caption = "Authorize Embalming";
            this.bandedGridColumn161.ColumnEdit = this.repositoryItemCheckEdit5;
            this.bandedGridColumn161.FieldName = "authEmbalming";
            this.bandedGridColumn161.MinWidth = 40;
            this.bandedGridColumn161.Name = "bandedGridColumn161";
            this.bandedGridColumn161.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn161.Visible = true;
            this.bandedGridColumn161.Width = 110;
            // 
            // bandedGridColumn119
            // 
            this.bandedGridColumn119.Caption = "Signature Date";
            this.bandedGridColumn119.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn119.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn119.FieldName = "signatureDate";
            this.bandedGridColumn119.MinWidth = 36;
            this.bandedGridColumn119.Name = "bandedGridColumn119";
            this.bandedGridColumn119.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn119.Visible = true;
            this.bandedGridColumn119.Width = 138;
            // 
            // bandedGridColumn118
            // 
            this.bandedGridColumn118.Caption = "Signature";
            this.bandedGridColumn118.ColumnEdit = this.repositoryItemPictureEdit5;
            this.bandedGridColumn118.FieldName = "sigs";
            this.bandedGridColumn118.MinWidth = 42;
            this.bandedGridColumn118.Name = "bandedGridColumn118";
            this.bandedGridColumn118.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn118.Visible = true;
            this.bandedGridColumn118.Width = 216;
            // 
            // repositoryItemPictureEdit5
            // 
            this.repositoryItemPictureEdit5.Name = "repositoryItemPictureEdit5";
            this.repositoryItemPictureEdit5.PictureAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.repositoryItemPictureEdit5.PictureStoreMode = DevExpress.XtraEditors.Controls.PictureStoreMode.Image;
            this.repositoryItemPictureEdit5.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            // 
            // bandedGridColumn153
            // 
            this.bandedGridColumn153.Caption = "Full Name";
            this.bandedGridColumn153.FieldName = "fullName";
            this.bandedGridColumn153.MinWidth = 36;
            this.bandedGridColumn153.Name = "bandedGridColumn153";
            this.bandedGridColumn153.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn153.Width = 138;
            // 
            // gridView6
            // 
            this.gridView6.DetailHeight = 431;
            this.gridView6.GridControl = this.dgvLegal;
            this.gridView6.Name = "gridView6";
            // 
            // tabFuneralData
            // 
            this.tabFuneralData.Controls.Add(this.dgv6);
            this.tabFuneralData.Location = new System.Drawing.Point(4, 25);
            this.tabFuneralData.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabFuneralData.Name = "tabFuneralData";
            this.tabFuneralData.Size = new System.Drawing.Size(1669, 347);
            this.tabFuneralData.TabIndex = 5;
            this.tabFuneralData.Text = "Other Funeral Information";
            this.tabFuneralData.UseVisualStyleBackColor = true;
            // 
            // dgv6
            // 
            this.dgv6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv6.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv6.Location = new System.Drawing.Point(0, 0);
            this.dgv6.LookAndFeel.SkinMaskColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.dgv6.LookAndFeel.SkinName = "The Asphalt World";
            this.dgv6.LookAndFeel.Style = DevExpress.LookAndFeel.LookAndFeelStyle.Style3D;
            this.dgv6.MainView = this.gridMain6;
            this.dgv6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv6.Name = "dgv6";
            this.dgv6.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit4,
            this.repositoryItemPictureEdit4,
            this.repositoryItemComboBox10,
            this.repositoryItemComboBox8,
            this.repositoryItemComboBox11,
            this.repositoryItemComboBox12,
            this.repositoryItemDateEdit2});
            this.dgv6.Size = new System.Drawing.Size(1669, 347);
            this.dgv6.TabIndex = 8;
            this.dgv6.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain6});
            this.dgv6.Enter += new System.EventHandler(this.dgv6_Enter);
            this.dgv6.Leave += new System.EventHandler(this.dgv6_Leave);
            // 
            // gridMain6
            // 
            this.gridMain6.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain6.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain6.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain6.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain6.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain6.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain6.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain6.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain6.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain6.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain6.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain6.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain6.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain6.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain6.Appearance.EvenRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain6.Appearance.EvenRow.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.gridMain6.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.EvenRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.EvenRow.Options.UseFont = true;
            this.gridMain6.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain6.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain6.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain6.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain6.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain6.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.FilterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(114)))), ((int)(((byte)(113)))));
            this.gridMain6.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain6.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain6.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain6.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(192)))), ((int)(((byte)(157)))));
            this.gridMain6.Appearance.FocusedRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(219)))), ((int)(((byte)(188)))));
            this.gridMain6.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.FocusedRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain6.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain6.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain6.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain6.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain6.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(242)))), ((int)(((byte)(213)))));
            this.gridMain6.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.GroupPanel.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.gridMain6.Appearance.GroupPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain6.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.GroupRow.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.gridMain6.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain6.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.HeaderPanel.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.gridMain6.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain6.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain6.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain6.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(230)))), ((int)(((byte)(203)))));
            this.gridMain6.Appearance.HideSelectionRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(230)))), ((int)(((byte)(203)))));
            this.gridMain6.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.HideSelectionRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain6.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain6.Appearance.OddRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain6.Appearance.OddRow.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.gridMain6.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.OddRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.OddRow.Options.UseFont = true;
            this.gridMain6.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(252)))), ((int)(((byte)(247)))));
            this.gridMain6.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain6.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(148)))), ((int)(((byte)(148)))));
            this.gridMain6.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain6.Appearance.Preview.Options.UseFont = true;
            this.gridMain6.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain6.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain6.Appearance.Row.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.gridMain6.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.Row.Options.UseBackColor = true;
            this.gridMain6.Appearance.Row.Options.UseFont = true;
            this.gridMain6.Appearance.Row.Options.UseForeColor = true;
            this.gridMain6.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain6.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(215)))), ((int)(((byte)(188)))));
            this.gridMain6.Appearance.SelectedRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(230)))), ((int)(((byte)(203)))));
            this.gridMain6.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.SelectedRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain6.AppearancePrint.EvenRow.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.gridMain6.AppearancePrint.EvenRow.Options.UseFont = true;
            this.gridMain6.AppearancePrint.GroupRow.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.gridMain6.AppearancePrint.GroupRow.Options.UseFont = true;
            this.gridMain6.AppearancePrint.HeaderPanel.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.gridMain6.AppearancePrint.HeaderPanel.Options.UseFont = true;
            this.gridMain6.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain6.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain6.AppearancePrint.OddRow.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.gridMain6.AppearancePrint.OddRow.Options.UseFont = true;
            this.gridMain6.AppearancePrint.Row.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.gridMain6.AppearancePrint.Row.Options.UseFont = true;
            this.gridMain6.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand5,
            this.gridBand7,
            this.gridBand8});
            this.gridMain6.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain6.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn86,
            this.bandedGridColumn98,
            this.bandedGridColumn93,
            this.bandedGridColumn92,
            this.bandedGridColumn90,
            this.bandedGridColumn95,
            this.bandedGridColumn96,
            this.bandedGridColumn88,
            this.bandedGridColumn87,
            this.bandedGridColumn91,
            this.bandedGridColumn97,
            this.bandedGridColumn89,
            this.bandedGridColumn94,
            this.bandedGridColumn140,
            this.bandedGridColumn141});
            this.gridMain6.DetailHeight = 431;
            this.gridMain6.GridControl = this.dgv6;
            this.gridMain6.GroupCount = 1;
            this.gridMain6.GroupFormat = "[#image]{1} {2}";
            this.gridMain6.Name = "gridMain6";
            this.gridMain6.OptionsPrint.AllowMultilineHeaders = true;
            this.gridMain6.OptionsPrint.PrintBandHeader = false;
            this.gridMain6.OptionsSelection.MultiSelect = true;
            this.gridMain6.OptionsView.BestFitMode = DevExpress.XtraGrid.Views.Grid.GridBestFitMode.Full;
            this.gridMain6.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain6.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain6.OptionsView.ShowBands = false;
            this.gridMain6.OptionsView.ShowGroupPanel = false;
            this.gridMain6.PaintStyleName = "Style3D";
            this.gridMain6.RowHeight = 4;
            this.gridMain6.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.bandedGridColumn90, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.gridMain6.RowCellStyle += new DevExpress.XtraGrid.Views.Grid.RowCellStyleEventHandler(this.gridMain6_RowCellStyle);
            this.gridMain6.ShownEditor += new System.EventHandler(this.gridMain6_ShownEditor);
            this.gridMain6.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMain6_CellValueChanged);
            this.gridMain6.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMain6_CustomRowFilter);
            this.gridMain6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gridMain6_KeyDown);
            this.gridMain6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.gridMain6_MouseDown);
            this.gridMain6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.gridMain6_MouseMove);
            this.gridMain6.DoubleClick += new System.EventHandler(this.gridMain6_DoubleClick);
            // 
            // gridBand5
            // 
            this.gridBand5.Caption = "gridBand1";
            this.gridBand5.Columns.Add(this.bandedGridColumn86);
            this.gridBand5.Columns.Add(this.bandedGridColumn87);
            this.gridBand5.Columns.Add(this.bandedGridColumn88);
            this.gridBand5.Columns.Add(this.bandedGridColumn89);
            this.gridBand5.Columns.Add(this.bandedGridColumn90);
            this.gridBand5.Columns.Add(this.bandedGridColumn91);
            this.gridBand5.Columns.Add(this.bandedGridColumn92);
            this.gridBand5.Columns.Add(this.bandedGridColumn93);
            this.gridBand5.Columns.Add(this.bandedGridColumn140);
            this.gridBand5.Columns.Add(this.bandedGridColumn141);
            this.gridBand5.Columns.Add(this.bandedGridColumn94);
            this.gridBand5.Columns.Add(this.bandedGridColumn97);
            this.gridBand5.Columns.Add(this.bandedGridColumn95);
            this.gridBand5.Columns.Add(this.bandedGridColumn96);
            this.gridBand5.MinWidth = 12;
            this.gridBand5.Name = "gridBand5";
            this.gridBand5.VisibleIndex = 0;
            this.gridBand5.Width = 1332;
            // 
            // bandedGridColumn86
            // 
            this.bandedGridColumn86.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.bandedGridColumn86.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn86.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.bandedGridColumn86.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn86.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn86.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn86.Caption = "Num";
            this.bandedGridColumn86.FieldName = "num";
            this.bandedGridColumn86.MinWidth = 23;
            this.bandedGridColumn86.Name = "bandedGridColumn86";
            this.bandedGridColumn86.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn86.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn86.Visible = true;
            this.bandedGridColumn86.Width = 69;
            // 
            // bandedGridColumn87
            // 
            this.bandedGridColumn87.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn87.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn87.Caption = "Date Added";
            this.bandedGridColumn87.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn87.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn87.FieldName = "dateAdded";
            this.bandedGridColumn87.MinWidth = 23;
            this.bandedGridColumn87.Name = "bandedGridColumn87";
            this.bandedGridColumn87.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn87.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn87.Width = 87;
            // 
            // bandedGridColumn88
            // 
            this.bandedGridColumn88.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn88.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn88.Caption = "User";
            this.bandedGridColumn88.FieldName = "user";
            this.bandedGridColumn88.MinWidth = 23;
            this.bandedGridColumn88.Name = "bandedGridColumn88";
            this.bandedGridColumn88.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn88.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn88.Width = 87;
            // 
            // bandedGridColumn89
            // 
            this.bandedGridColumn89.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn89.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn89.Caption = "Status";
            this.bandedGridColumn89.ColumnEdit = this.repositoryItemComboBox8;
            this.bandedGridColumn89.FieldName = "status";
            this.bandedGridColumn89.MinWidth = 23;
            this.bandedGridColumn89.Name = "bandedGridColumn89";
            this.bandedGridColumn89.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn89.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn89.Width = 87;
            // 
            // repositoryItemComboBox8
            // 
            this.repositoryItemComboBox8.AutoHeight = false;
            this.repositoryItemComboBox8.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox8.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.repositoryItemComboBox8.Name = "repositoryItemComboBox8";
            this.repositoryItemComboBox8.PopupFormSize = new System.Drawing.Size(117, 62);
            // 
            // bandedGridColumn90
            // 
            this.bandedGridColumn90.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn90.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn90.Caption = "Group";
            this.bandedGridColumn90.FieldName = "group";
            this.bandedGridColumn90.MinWidth = 23;
            this.bandedGridColumn90.Name = "bandedGridColumn90";
            this.bandedGridColumn90.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn90.Width = 146;
            // 
            // bandedGridColumn91
            // 
            this.bandedGridColumn91.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn91.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn91.Caption = "Qualify";
            this.bandedGridColumn91.FieldName = "qualify";
            this.bandedGridColumn91.MinWidth = 23;
            this.bandedGridColumn91.Name = "bandedGridColumn91";
            this.bandedGridColumn91.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn91.Width = 87;
            // 
            // bandedGridColumn92
            // 
            this.bandedGridColumn92.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn92.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn92.Caption = "DB Field";
            this.bandedGridColumn92.FieldName = "dbfield";
            this.bandedGridColumn92.MinWidth = 23;
            this.bandedGridColumn92.Name = "bandedGridColumn92";
            this.bandedGridColumn92.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn92.Width = 146;
            // 
            // bandedGridColumn93
            // 
            this.bandedGridColumn93.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.bandedGridColumn93.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn93.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.bandedGridColumn93.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn93.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn93.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn93.Caption = "Field Name";
            this.bandedGridColumn93.FieldName = "field";
            this.bandedGridColumn93.MinWidth = 23;
            this.bandedGridColumn93.Name = "bandedGridColumn93";
            this.bandedGridColumn93.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn93.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn93.Visible = true;
            this.bandedGridColumn93.Width = 292;
            // 
            // bandedGridColumn140
            // 
            this.bandedGridColumn140.Caption = "A";
            this.bandedGridColumn140.FieldName = "add";
            this.bandedGridColumn140.MinWidth = 23;
            this.bandedGridColumn140.Name = "bandedGridColumn140";
            this.bandedGridColumn140.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn140.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn140.ToolTip = "Add for Tracking if \"+\"  sign is displayed";
            this.bandedGridColumn140.Visible = true;
            this.bandedGridColumn140.Width = 65;
            // 
            // bandedGridColumn141
            // 
            this.bandedGridColumn141.Caption = "E";
            this.bandedGridColumn141.FieldName = "edit";
            this.bandedGridColumn141.MinWidth = 23;
            this.bandedGridColumn141.Name = "bandedGridColumn141";
            this.bandedGridColumn141.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn141.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn141.ToolTip = "Edit Tracking if \"E\"  is displayed";
            this.bandedGridColumn141.Visible = true;
            this.bandedGridColumn141.Width = 65;
            // 
            // bandedGridColumn94
            // 
            this.bandedGridColumn94.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.bandedGridColumn94.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn94.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.bandedGridColumn94.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn94.Caption = "Data";
            this.bandedGridColumn94.FieldName = "data";
            this.bandedGridColumn94.MinWidth = 23;
            this.bandedGridColumn94.Name = "bandedGridColumn94";
            this.bandedGridColumn94.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn94.Visible = true;
            this.bandedGridColumn94.Width = 374;
            // 
            // bandedGridColumn97
            // 
            this.bandedGridColumn97.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn97.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn97.Caption = "Help";
            this.bandedGridColumn97.FieldName = "help";
            this.bandedGridColumn97.MinWidth = 23;
            this.bandedGridColumn97.Name = "bandedGridColumn97";
            this.bandedGridColumn97.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn97.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn97.Visible = true;
            this.bandedGridColumn97.Width = 467;
            // 
            // bandedGridColumn95
            // 
            this.bandedGridColumn95.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn95.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn95.Caption = "Type";
            this.bandedGridColumn95.ColumnEdit = this.repositoryItemComboBox10;
            this.bandedGridColumn95.FieldName = "type";
            this.bandedGridColumn95.MinWidth = 23;
            this.bandedGridColumn95.Name = "bandedGridColumn95";
            this.bandedGridColumn95.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn95.Width = 87;
            // 
            // repositoryItemComboBox10
            // 
            this.repositoryItemComboBox10.AutoHeight = false;
            this.repositoryItemComboBox10.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.repositoryItemComboBox10.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox10.Items.AddRange(new object[] {
            "Text",
            "Numeric",
            "Double",
            "Date"});
            this.repositoryItemComboBox10.Name = "repositoryItemComboBox10";
            this.repositoryItemComboBox10.PopupFormSize = new System.Drawing.Size(117, 123);
            this.repositoryItemComboBox10.PopupSizeable = true;
            // 
            // bandedGridColumn96
            // 
            this.bandedGridColumn96.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn96.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn96.Caption = "Length";
            this.bandedGridColumn96.FieldName = "length";
            this.bandedGridColumn96.MinWidth = 23;
            this.bandedGridColumn96.Name = "bandedGridColumn96";
            this.bandedGridColumn96.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn96.Width = 87;
            // 
            // gridBand7
            // 
            this.gridBand7.Caption = "gridBand2";
            this.gridBand7.MinWidth = 12;
            this.gridBand7.Name = "gridBand7";
            this.gridBand7.Visible = false;
            this.gridBand7.VisibleIndex = -1;
            this.gridBand7.Width = 63;
            // 
            // gridBand8
            // 
            this.gridBand8.Caption = "gridBand3";
            this.gridBand8.MinWidth = 12;
            this.gridBand8.Name = "gridBand8";
            this.gridBand8.Visible = false;
            this.gridBand8.VisibleIndex = -1;
            this.gridBand8.Width = 79;
            // 
            // bandedGridColumn98
            // 
            this.bandedGridColumn98.Caption = "record";
            this.bandedGridColumn98.FieldName = "record";
            this.bandedGridColumn98.MinWidth = 23;
            this.bandedGridColumn98.Name = "bandedGridColumn98";
            this.bandedGridColumn98.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn98.Width = 87;
            // 
            // repositoryItemCheckEdit4
            // 
            this.repositoryItemCheckEdit4.AutoHeight = false;
            this.repositoryItemCheckEdit4.Name = "repositoryItemCheckEdit4";
            // 
            // repositoryItemPictureEdit4
            // 
            this.repositoryItemPictureEdit4.Name = "repositoryItemPictureEdit4";
            this.repositoryItemPictureEdit4.PictureAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.repositoryItemPictureEdit4.PictureStoreMode = DevExpress.XtraEditors.Controls.PictureStoreMode.Image;
            this.repositoryItemPictureEdit4.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            // 
            // repositoryItemComboBox11
            // 
            this.repositoryItemComboBox11.AutoHeight = false;
            this.repositoryItemComboBox11.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox11.Items.AddRange(new object[] {
            "customers",
            "cust_extended",
            "contracts",
            "funeralhomes",
            "relatives"});
            this.repositoryItemComboBox11.Name = "repositoryItemComboBox11";
            // 
            // repositoryItemComboBox12
            // 
            this.repositoryItemComboBox12.AutoHeight = false;
            this.repositoryItemComboBox12.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox12.Name = "repositoryItemComboBox12";
            // 
            // repositoryItemDateEdit2
            // 
            this.repositoryItemDateEdit2.AutoHeight = false;
            this.repositoryItemDateEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit2.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit2.Name = "repositoryItemDateEdit2";
            this.repositoryItemDateEdit2.Closed += new DevExpress.XtraEditors.Controls.ClosedEventHandler(this.repositoryItemDateEdit2_Closed);
            this.repositoryItemDateEdit2.BeforePopup += new System.EventHandler(this.repositoryItemDateEdit2_BeforePopup);
            // 
            // tabPallbearers
            // 
            this.tabPallbearers.Controls.Add(this.dgv2);
            this.tabPallbearers.Location = new System.Drawing.Point(4, 25);
            this.tabPallbearers.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPallbearers.Name = "tabPallbearers";
            this.tabPallbearers.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPallbearers.Size = new System.Drawing.Size(1669, 347);
            this.tabPallbearers.TabIndex = 1;
            this.tabPallbearers.Text = "PallBearers";
            this.tabPallbearers.UseVisualStyleBackColor = true;
            // 
            // dgv2
            // 
            this.dgv2.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv2.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Location = new System.Drawing.Point(3, 4);
            this.dgv2.LookAndFeel.SkinName = "Foggy";
            this.dgv2.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv2.MainView = this.gridMain2;
            this.dgv2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Name = "dgv2";
            this.dgv2.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox3,
            this.repositoryItemCheckEdit2,
            this.repositoryItemPictureEdit2,
            this.repositoryItemComboBox4,
            this.repositoryItemComboBox16});
            this.dgv2.Size = new System.Drawing.Size(1663, 339);
            this.dgv2.TabIndex = 9;
            this.dgv2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain2,
            this.gridView2});
            this.dgv2.VisibleChanged += new System.EventHandler(this.dgv2_VisibleChanged);
            this.dgv2.Enter += new System.EventHandler(this.dgv2_Enter);
            this.dgv2.Leave += new System.EventHandler(this.dgv2_Leave);
            // 
            // gridMain2
            // 
            this.gridMain2.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(190)))), ((int)(((byte)(159)))));
            this.gridMain2.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(190)))), ((int)(((byte)(159)))));
            this.gridMain2.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain2.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(93)))), ((int)(((byte)(63)))));
            this.gridMain2.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain2.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain2.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain2.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(201)))), ((int)(((byte)(228)))), ((int)(((byte)(206)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain2.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain2.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain2.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain2.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain2.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain2.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(123)))), ((int)(((byte)(93)))));
            this.gridMain2.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain2.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(33)))), ((int)(((byte)(3)))));
            this.gridMain2.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain2.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain2.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(81)))), ((int)(((byte)(30)))));
            this.gridMain2.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMain2.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(201)))), ((int)(((byte)(150)))));
            this.gridMain2.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain2.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain2.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain2.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain2.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(210)))), ((int)(((byte)(179)))));
            this.gridMain2.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(210)))), ((int)(((byte)(179)))));
            this.gridMain2.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(63)))), ((int)(((byte)(33)))));
            this.gridMain2.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain2.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMain2.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(227)))), ((int)(((byte)(211)))));
            this.gridMain2.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain2.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain2.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain2.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain2.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(103)))), ((int)(((byte)(73)))));
            this.gridMain2.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain2.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain2.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain2.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(227)))), ((int)(((byte)(211)))));
            this.gridMain2.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain2.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(255)))), ((int)(((byte)(229)))));
            this.gridMain2.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMain2.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain2.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain2.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMain2.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.Row.Options.UseBackColor = true;
            this.gridMain2.Appearance.Row.Options.UseFont = true;
            this.gridMain2.Appearance.Row.Options.UseForeColor = true;
            this.gridMain2.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain2.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(161)))), ((int)(((byte)(110)))));
            this.gridMain2.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain2.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain2.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain2.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain2.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand1});
            this.gridMain2.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain2.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn11,
            this.bandedGridColumn12,
            this.bandedGridColumn155,
            this.bandedGridColumn145,
            this.bandedGridColumn14,
            this.bandedGridColumn13,
            this.bandedGridColumn15,
            this.bandedGridColumn17,
            this.bandedGridColumn16,
            this.bandedGridColumn18,
            this.bandedGridColumn22,
            this.bandedGridColumn24,
            this.bandedGridColumn34,
            this.bandedGridColumn30,
            this.bandedGridColumn31,
            this.bandedGridColumn32,
            this.bandedGridColumn33,
            this.bandedGridColumn122,
            this.bandedGridColumn23,
            this.bandedGridColumn130,
            this.bandedGridColumn131});
            this.gridMain2.DetailHeight = 431;
            this.gridMain2.GridControl = this.dgv2;
            this.gridMain2.Name = "gridMain2";
            this.gridMain2.OptionsBehavior.AutoPopulateColumns = false;
            this.gridMain2.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.MouseDown;
            this.gridMain2.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridMain2.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain2.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain2.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain2.OptionsView.ShowBands = false;
            this.gridMain2.OptionsView.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowAlways;
            this.gridMain2.OptionsView.ShowGroupPanel = false;
            this.gridMain2.PaintStyleName = "Flat";
            this.gridMain2.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMainDep_CustomDrawCell);
            this.gridMain2.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMainDep_CellValueChanged);
            this.gridMain2.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMain2_CustomRowFilter);
            this.gridMain2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gridMainDep_KeyDown);
            // 
            // gridBand1
            // 
            this.gridBand1.Caption = "gridBand1";
            this.gridBand1.Columns.Add(this.bandedGridColumn11);
            this.gridBand1.Columns.Add(this.bandedGridColumn145);
            this.gridBand1.Columns.Add(this.bandedGridColumn12);
            this.gridBand1.Columns.Add(this.bandedGridColumn13);
            this.gridBand1.Columns.Add(this.bandedGridColumn15);
            this.gridBand1.Columns.Add(this.bandedGridColumn14);
            this.gridBand1.Columns.Add(this.bandedGridColumn16);
            this.gridBand1.Columns.Add(this.bandedGridColumn17);
            this.gridBand1.Columns.Add(this.bandedGridColumn18);
            this.gridBand1.Columns.Add(this.bandedGridColumn22);
            this.gridBand1.Columns.Add(this.bandedGridColumn23);
            this.gridBand1.Columns.Add(this.bandedGridColumn130);
            this.gridBand1.Columns.Add(this.bandedGridColumn131);
            this.gridBand1.Columns.Add(this.bandedGridColumn24);
            this.gridBand1.Columns.Add(this.bandedGridColumn30);
            this.gridBand1.Columns.Add(this.bandedGridColumn31);
            this.gridBand1.Columns.Add(this.bandedGridColumn32);
            this.gridBand1.Columns.Add(this.bandedGridColumn33);
            this.gridBand1.Columns.Add(this.bandedGridColumn122);
            this.gridBand1.Columns.Add(this.bandedGridColumn34);
            this.gridBand1.MinWidth = 12;
            this.gridBand1.Name = "gridBand1";
            this.gridBand1.VisibleIndex = 0;
            this.gridBand1.Width = 1382;
            // 
            // bandedGridColumn11
            // 
            this.bandedGridColumn11.Caption = "Num";
            this.bandedGridColumn11.FieldName = "num";
            this.bandedGridColumn11.MinWidth = 23;
            this.bandedGridColumn11.Name = "bandedGridColumn11";
            this.bandedGridColumn11.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn11.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn11.Visible = true;
            this.bandedGridColumn11.Width = 62;
            // 
            // bandedGridColumn145
            // 
            this.bandedGridColumn145.Caption = "Title";
            this.bandedGridColumn145.FieldName = "depPrefix";
            this.bandedGridColumn145.MinWidth = 23;
            this.bandedGridColumn145.Name = "bandedGridColumn145";
            this.bandedGridColumn145.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn145.Visible = true;
            this.bandedGridColumn145.Width = 64;
            // 
            // bandedGridColumn12
            // 
            this.bandedGridColumn12.Caption = "record";
            this.bandedGridColumn12.FieldName = "record";
            this.bandedGridColumn12.MinWidth = 23;
            this.bandedGridColumn12.Name = "bandedGridColumn12";
            this.bandedGridColumn12.Width = 87;
            // 
            // bandedGridColumn13
            // 
            this.bandedGridColumn13.Caption = "First Name";
            this.bandedGridColumn13.FieldName = "depFirstName";
            this.bandedGridColumn13.MinWidth = 23;
            this.bandedGridColumn13.Name = "bandedGridColumn13";
            this.bandedGridColumn13.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn13.Visible = true;
            this.bandedGridColumn13.Width = 87;
            // 
            // bandedGridColumn15
            // 
            this.bandedGridColumn15.Caption = "Middle Initial";
            this.bandedGridColumn15.FieldName = "depMI";
            this.bandedGridColumn15.MinWidth = 23;
            this.bandedGridColumn15.Name = "bandedGridColumn15";
            this.bandedGridColumn15.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn15.Visible = true;
            this.bandedGridColumn15.Width = 70;
            // 
            // bandedGridColumn14
            // 
            this.bandedGridColumn14.Caption = "Last Name";
            this.bandedGridColumn14.FieldName = "depLastName";
            this.bandedGridColumn14.MinWidth = 23;
            this.bandedGridColumn14.Name = "bandedGridColumn14";
            this.bandedGridColumn14.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn14.Visible = true;
            this.bandedGridColumn14.Width = 87;
            // 
            // bandedGridColumn16
            // 
            this.bandedGridColumn16.Caption = "Suffix";
            this.bandedGridColumn16.FieldName = "depSuffix";
            this.bandedGridColumn16.MinWidth = 23;
            this.bandedGridColumn16.Name = "bandedGridColumn16";
            this.bandedGridColumn16.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn16.Visible = true;
            this.bandedGridColumn16.Width = 69;
            // 
            // bandedGridColumn17
            // 
            this.bandedGridColumn17.Caption = "Maiden Name";
            this.bandedGridColumn17.FieldName = "maidenName";
            this.bandedGridColumn17.MinWidth = 23;
            this.bandedGridColumn17.Name = "bandedGridColumn17";
            this.bandedGridColumn17.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn17.Visible = true;
            this.bandedGridColumn17.Width = 119;
            // 
            // bandedGridColumn18
            // 
            this.bandedGridColumn18.Caption = "DOB";
            this.bandedGridColumn18.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn18.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn18.FieldName = "depDOB";
            this.bandedGridColumn18.MinWidth = 23;
            this.bandedGridColumn18.Name = "bandedGridColumn18";
            this.bandedGridColumn18.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn18.Visible = true;
            this.bandedGridColumn18.Width = 87;
            // 
            // bandedGridColumn22
            // 
            this.bandedGridColumn22.Caption = "DOD";
            this.bandedGridColumn22.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn22.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn22.FieldName = "depDOD";
            this.bandedGridColumn22.MinWidth = 23;
            this.bandedGridColumn22.Name = "bandedGridColumn22";
            this.bandedGridColumn22.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn22.Width = 87;
            // 
            // bandedGridColumn23
            // 
            this.bandedGridColumn23.Caption = "Phone";
            this.bandedGridColumn23.FieldName = "phone";
            this.bandedGridColumn23.MinWidth = 23;
            this.bandedGridColumn23.Name = "bandedGridColumn23";
            this.bandedGridColumn23.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn23.Visible = true;
            this.bandedGridColumn23.Width = 87;
            // 
            // bandedGridColumn130
            // 
            this.bandedGridColumn130.Caption = "Phone Type";
            this.bandedGridColumn130.ColumnEdit = this.repositoryItemComboBox16;
            this.bandedGridColumn130.FieldName = "phoneType";
            this.bandedGridColumn130.MinWidth = 23;
            this.bandedGridColumn130.Name = "bandedGridColumn130";
            this.bandedGridColumn130.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn130.Visible = true;
            this.bandedGridColumn130.Width = 87;
            // 
            // repositoryItemComboBox16
            // 
            this.repositoryItemComboBox16.AutoHeight = false;
            this.repositoryItemComboBox16.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox16.Items.AddRange(new object[] {
            "Home",
            "Cell",
            "Work"});
            this.repositoryItemComboBox16.Name = "repositoryItemComboBox16";
            // 
            // bandedGridColumn131
            // 
            this.bandedGridColumn131.Caption = "Email";
            this.bandedGridColumn131.FieldName = "email";
            this.bandedGridColumn131.MinWidth = 23;
            this.bandedGridColumn131.Name = "bandedGridColumn131";
            this.bandedGridColumn131.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn131.Visible = true;
            this.bandedGridColumn131.Width = 87;
            // 
            // bandedGridColumn24
            // 
            this.bandedGridColumn24.Caption = "RelationShip";
            this.bandedGridColumn24.ColumnEdit = this.repositoryItemComboBox3;
            this.bandedGridColumn24.FieldName = "depRelationship";
            this.bandedGridColumn24.MinWidth = 23;
            this.bandedGridColumn24.Name = "bandedGridColumn24";
            this.bandedGridColumn24.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn24.Width = 146;
            // 
            // repositoryItemComboBox3
            // 
            this.repositoryItemComboBox3.AutoHeight = false;
            this.repositoryItemComboBox3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox3.Items.AddRange(new object[] {
            "Spouse",
            "Daughter",
            "Son",
            "Sister",
            "Brother",
            "Grandparent",
            "Grandchild",
            "Great-Grandchild",
            "Granddaughter",
            "Grandson",
            "Great-Granddaughter",
            "Great-Grandson"});
            this.repositoryItemComboBox3.Name = "repositoryItemComboBox3";
            this.repositoryItemComboBox3.PopupFormSize = new System.Drawing.Size(117, 123);
            this.repositoryItemComboBox3.PopupSizeable = true;
            // 
            // bandedGridColumn30
            // 
            this.bandedGridColumn30.Caption = "Address";
            this.bandedGridColumn30.FieldName = "address";
            this.bandedGridColumn30.MinWidth = 23;
            this.bandedGridColumn30.Name = "bandedGridColumn30";
            this.bandedGridColumn30.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn30.Visible = true;
            this.bandedGridColumn30.Width = 87;
            // 
            // bandedGridColumn31
            // 
            this.bandedGridColumn31.Caption = "City";
            this.bandedGridColumn31.FieldName = "city";
            this.bandedGridColumn31.MinWidth = 23;
            this.bandedGridColumn31.Name = "bandedGridColumn31";
            this.bandedGridColumn31.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn31.Visible = true;
            this.bandedGridColumn31.Width = 87;
            // 
            // bandedGridColumn32
            // 
            this.bandedGridColumn32.Caption = "State";
            this.bandedGridColumn32.ColumnEdit = this.repositoryItemComboBox4;
            this.bandedGridColumn32.FieldName = "state";
            this.bandedGridColumn32.MinWidth = 23;
            this.bandedGridColumn32.Name = "bandedGridColumn32";
            this.bandedGridColumn32.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn32.Visible = true;
            this.bandedGridColumn32.Width = 58;
            // 
            // repositoryItemComboBox4
            // 
            this.repositoryItemComboBox4.AutoHeight = false;
            this.repositoryItemComboBox4.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox4.Name = "repositoryItemComboBox4";
            // 
            // bandedGridColumn33
            // 
            this.bandedGridColumn33.Caption = "Zip";
            this.bandedGridColumn33.FieldName = "zip";
            this.bandedGridColumn33.MinWidth = 23;
            this.bandedGridColumn33.Name = "bandedGridColumn33";
            this.bandedGridColumn33.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn33.Visible = true;
            this.bandedGridColumn33.Width = 70;
            // 
            // bandedGridColumn122
            // 
            this.bandedGridColumn122.Caption = "County";
            this.bandedGridColumn122.FieldName = "county";
            this.bandedGridColumn122.MinWidth = 23;
            this.bandedGridColumn122.Name = "bandedGridColumn122";
            this.bandedGridColumn122.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn122.Visible = true;
            this.bandedGridColumn122.Width = 87;
            // 
            // bandedGridColumn34
            // 
            this.bandedGridColumn34.Caption = "Spouse First Name";
            this.bandedGridColumn34.FieldName = "spouseFirstName";
            this.bandedGridColumn34.MinWidth = 23;
            this.bandedGridColumn34.Name = "bandedGridColumn34";
            this.bandedGridColumn34.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn34.Visible = true;
            this.bandedGridColumn34.Width = 87;
            // 
            // bandedGridColumn155
            // 
            this.bandedGridColumn155.Caption = "Full Name";
            this.bandedGridColumn155.FieldName = "fullName";
            this.bandedGridColumn155.MinWidth = 23;
            this.bandedGridColumn155.Name = "bandedGridColumn155";
            this.bandedGridColumn155.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn155.Width = 87;
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            // 
            // repositoryItemPictureEdit2
            // 
            this.repositoryItemPictureEdit2.Name = "repositoryItemPictureEdit2";
            this.repositoryItemPictureEdit2.PictureAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.repositoryItemPictureEdit2.PictureStoreMode = DevExpress.XtraEditors.Controls.PictureStoreMode.Image;
            this.repositoryItemPictureEdit2.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            // 
            // gridView2
            // 
            this.gridView2.DetailHeight = 431;
            this.gridView2.GridControl = this.dgv2;
            this.gridView2.Name = "gridView2";
            // 
            // tabHonoraryPallBearers
            // 
            this.tabHonoraryPallBearers.Controls.Add(this.dgv3);
            this.tabHonoraryPallBearers.Location = new System.Drawing.Point(4, 25);
            this.tabHonoraryPallBearers.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabHonoraryPallBearers.Name = "tabHonoraryPallBearers";
            this.tabHonoraryPallBearers.Size = new System.Drawing.Size(1669, 347);
            this.tabHonoraryPallBearers.TabIndex = 2;
            this.tabHonoraryPallBearers.Text = "Honorary PallBearers";
            this.tabHonoraryPallBearers.UseVisualStyleBackColor = true;
            // 
            // dgv3
            // 
            this.dgv3.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv3.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Location = new System.Drawing.Point(0, 0);
            this.dgv3.LookAndFeel.SkinName = "Foggy";
            this.dgv3.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv3.MainView = this.gridMain3;
            this.dgv3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Name = "dgv3";
            this.dgv3.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox5,
            this.repositoryItemCheckEdit3,
            this.repositoryItemPictureEdit3,
            this.repositoryItemComboBox6,
            this.repositoryItemComboBox17});
            this.dgv3.Size = new System.Drawing.Size(1669, 347);
            this.dgv3.TabIndex = 10;
            this.dgv3.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain3,
            this.gridView3});
            this.dgv3.VisibleChanged += new System.EventHandler(this.dgv3_VisibleChanged);
            this.dgv3.Enter += new System.EventHandler(this.dgv3_Enter);
            this.dgv3.Leave += new System.EventHandler(this.dgv3_Leave);
            // 
            // gridMain3
            // 
            this.gridMain3.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(190)))), ((int)(((byte)(159)))));
            this.gridMain3.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(190)))), ((int)(((byte)(159)))));
            this.gridMain3.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain3.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain3.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(93)))), ((int)(((byte)(63)))));
            this.gridMain3.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain3.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain3.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain3.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(201)))), ((int)(((byte)(228)))), ((int)(((byte)(206)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain3.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain3.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain3.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain3.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain3.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain3.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain3.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(123)))), ((int)(((byte)(93)))));
            this.gridMain3.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain3.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(33)))), ((int)(((byte)(3)))));
            this.gridMain3.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain3.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain3.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(81)))), ((int)(((byte)(30)))));
            this.gridMain3.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMain3.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(201)))), ((int)(((byte)(150)))));
            this.gridMain3.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain3.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain3.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain3.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain3.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(210)))), ((int)(((byte)(179)))));
            this.gridMain3.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(210)))), ((int)(((byte)(179)))));
            this.gridMain3.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(63)))), ((int)(((byte)(33)))));
            this.gridMain3.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain3.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain3.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMain3.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(227)))), ((int)(((byte)(211)))));
            this.gridMain3.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain3.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain3.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain3.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain3.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain3.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(103)))), ((int)(((byte)(73)))));
            this.gridMain3.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain3.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain3.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain3.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain3.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain3.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(227)))), ((int)(((byte)(211)))));
            this.gridMain3.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain3.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(255)))), ((int)(((byte)(229)))));
            this.gridMain3.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMain3.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain3.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain3.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMain3.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.Row.Options.UseBackColor = true;
            this.gridMain3.Appearance.Row.Options.UseFont = true;
            this.gridMain3.Appearance.Row.Options.UseForeColor = true;
            this.gridMain3.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain3.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain3.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(161)))), ((int)(((byte)(110)))));
            this.gridMain3.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain3.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain3.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain3.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain3.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand2});
            this.gridMain3.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain3.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn25,
            this.bandedGridColumn26,
            this.bandedGridColumn154,
            this.bandedGridColumn146,
            this.bandedGridColumn28,
            this.bandedGridColumn27,
            this.bandedGridColumn29,
            this.bandedGridColumn36,
            this.bandedGridColumn35,
            this.bandedGridColumn37,
            this.bandedGridColumn38,
            this.bandedGridColumn40,
            this.bandedGridColumn52,
            this.bandedGridColumn41,
            this.bandedGridColumn42,
            this.bandedGridColumn43,
            this.bandedGridColumn44,
            this.bandedGridColumn123,
            this.bandedGridColumn39,
            this.bandedGridColumn132,
            this.bandedGridColumn133});
            this.gridMain3.DetailHeight = 431;
            this.gridMain3.GridControl = this.dgv3;
            this.gridMain3.Name = "gridMain3";
            this.gridMain3.OptionsBehavior.AutoPopulateColumns = false;
            this.gridMain3.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.MouseDown;
            this.gridMain3.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridMain3.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain3.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain3.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain3.OptionsView.ShowBands = false;
            this.gridMain3.OptionsView.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowAlways;
            this.gridMain3.OptionsView.ShowGroupPanel = false;
            this.gridMain3.PaintStyleName = "Flat";
            this.gridMain3.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMainDep_CustomDrawCell);
            this.gridMain3.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMainDep_CellValueChanged);
            this.gridMain3.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMain3_CustomRowFilter);
            this.gridMain3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gridMainDep_KeyDown);
            // 
            // gridBand2
            // 
            this.gridBand2.Caption = "gridBand1";
            this.gridBand2.Columns.Add(this.bandedGridColumn25);
            this.gridBand2.Columns.Add(this.bandedGridColumn146);
            this.gridBand2.Columns.Add(this.bandedGridColumn26);
            this.gridBand2.Columns.Add(this.bandedGridColumn27);
            this.gridBand2.Columns.Add(this.bandedGridColumn29);
            this.gridBand2.Columns.Add(this.bandedGridColumn28);
            this.gridBand2.Columns.Add(this.bandedGridColumn35);
            this.gridBand2.Columns.Add(this.bandedGridColumn36);
            this.gridBand2.Columns.Add(this.bandedGridColumn37);
            this.gridBand2.Columns.Add(this.bandedGridColumn38);
            this.gridBand2.Columns.Add(this.bandedGridColumn39);
            this.gridBand2.Columns.Add(this.bandedGridColumn132);
            this.gridBand2.Columns.Add(this.bandedGridColumn133);
            this.gridBand2.Columns.Add(this.bandedGridColumn40);
            this.gridBand2.Columns.Add(this.bandedGridColumn41);
            this.gridBand2.Columns.Add(this.bandedGridColumn42);
            this.gridBand2.Columns.Add(this.bandedGridColumn43);
            this.gridBand2.Columns.Add(this.bandedGridColumn44);
            this.gridBand2.Columns.Add(this.bandedGridColumn123);
            this.gridBand2.Columns.Add(this.bandedGridColumn52);
            this.gridBand2.MinWidth = 12;
            this.gridBand2.Name = "gridBand2";
            this.gridBand2.VisibleIndex = 0;
            this.gridBand2.Width = 1382;
            // 
            // bandedGridColumn25
            // 
            this.bandedGridColumn25.Caption = "Num";
            this.bandedGridColumn25.FieldName = "num";
            this.bandedGridColumn25.MinWidth = 23;
            this.bandedGridColumn25.Name = "bandedGridColumn25";
            this.bandedGridColumn25.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn25.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn25.Visible = true;
            this.bandedGridColumn25.Width = 62;
            // 
            // bandedGridColumn146
            // 
            this.bandedGridColumn146.Caption = "Title";
            this.bandedGridColumn146.FieldName = "depPrefix";
            this.bandedGridColumn146.MinWidth = 23;
            this.bandedGridColumn146.Name = "bandedGridColumn146";
            this.bandedGridColumn146.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn146.Visible = true;
            this.bandedGridColumn146.Width = 64;
            // 
            // bandedGridColumn26
            // 
            this.bandedGridColumn26.Caption = "record";
            this.bandedGridColumn26.FieldName = "record";
            this.bandedGridColumn26.MinWidth = 23;
            this.bandedGridColumn26.Name = "bandedGridColumn26";
            this.bandedGridColumn26.Width = 87;
            // 
            // bandedGridColumn27
            // 
            this.bandedGridColumn27.Caption = "First Name";
            this.bandedGridColumn27.FieldName = "depFirstName";
            this.bandedGridColumn27.MinWidth = 23;
            this.bandedGridColumn27.Name = "bandedGridColumn27";
            this.bandedGridColumn27.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn27.Visible = true;
            this.bandedGridColumn27.Width = 87;
            // 
            // bandedGridColumn29
            // 
            this.bandedGridColumn29.Caption = "Middle Initial";
            this.bandedGridColumn29.FieldName = "depMI";
            this.bandedGridColumn29.MinWidth = 23;
            this.bandedGridColumn29.Name = "bandedGridColumn29";
            this.bandedGridColumn29.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn29.Visible = true;
            this.bandedGridColumn29.Width = 70;
            // 
            // bandedGridColumn28
            // 
            this.bandedGridColumn28.Caption = "Last Name";
            this.bandedGridColumn28.FieldName = "depLastName";
            this.bandedGridColumn28.MinWidth = 23;
            this.bandedGridColumn28.Name = "bandedGridColumn28";
            this.bandedGridColumn28.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn28.Visible = true;
            this.bandedGridColumn28.Width = 87;
            // 
            // bandedGridColumn35
            // 
            this.bandedGridColumn35.Caption = "Suffix";
            this.bandedGridColumn35.FieldName = "depSuffix";
            this.bandedGridColumn35.MinWidth = 23;
            this.bandedGridColumn35.Name = "bandedGridColumn35";
            this.bandedGridColumn35.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn35.Visible = true;
            this.bandedGridColumn35.Width = 69;
            // 
            // bandedGridColumn36
            // 
            this.bandedGridColumn36.Caption = "Maiden Name";
            this.bandedGridColumn36.FieldName = "maidenName";
            this.bandedGridColumn36.MinWidth = 23;
            this.bandedGridColumn36.Name = "bandedGridColumn36";
            this.bandedGridColumn36.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn36.Visible = true;
            this.bandedGridColumn36.Width = 119;
            // 
            // bandedGridColumn37
            // 
            this.bandedGridColumn37.Caption = "DOB";
            this.bandedGridColumn37.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn37.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn37.FieldName = "depDOB";
            this.bandedGridColumn37.MinWidth = 23;
            this.bandedGridColumn37.Name = "bandedGridColumn37";
            this.bandedGridColumn37.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn37.Visible = true;
            this.bandedGridColumn37.Width = 87;
            // 
            // bandedGridColumn38
            // 
            this.bandedGridColumn38.Caption = "DOD";
            this.bandedGridColumn38.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn38.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn38.FieldName = "depDOD";
            this.bandedGridColumn38.MinWidth = 23;
            this.bandedGridColumn38.Name = "bandedGridColumn38";
            this.bandedGridColumn38.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn38.Width = 87;
            // 
            // bandedGridColumn39
            // 
            this.bandedGridColumn39.Caption = "Phone";
            this.bandedGridColumn39.FieldName = "phone";
            this.bandedGridColumn39.MinWidth = 23;
            this.bandedGridColumn39.Name = "bandedGridColumn39";
            this.bandedGridColumn39.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn39.Visible = true;
            this.bandedGridColumn39.Width = 87;
            // 
            // bandedGridColumn132
            // 
            this.bandedGridColumn132.Caption = "Phone Type";
            this.bandedGridColumn132.ColumnEdit = this.repositoryItemComboBox17;
            this.bandedGridColumn132.FieldName = "phoneType";
            this.bandedGridColumn132.MinWidth = 23;
            this.bandedGridColumn132.Name = "bandedGridColumn132";
            this.bandedGridColumn132.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn132.Visible = true;
            this.bandedGridColumn132.Width = 87;
            // 
            // repositoryItemComboBox17
            // 
            this.repositoryItemComboBox17.AutoHeight = false;
            this.repositoryItemComboBox17.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox17.Items.AddRange(new object[] {
            "Home",
            "Cell",
            "Work"});
            this.repositoryItemComboBox17.Name = "repositoryItemComboBox17";
            // 
            // bandedGridColumn133
            // 
            this.bandedGridColumn133.Caption = "Email";
            this.bandedGridColumn133.FieldName = "email";
            this.bandedGridColumn133.MinWidth = 23;
            this.bandedGridColumn133.Name = "bandedGridColumn133";
            this.bandedGridColumn133.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn133.Visible = true;
            this.bandedGridColumn133.Width = 87;
            // 
            // bandedGridColumn40
            // 
            this.bandedGridColumn40.Caption = "RelationShip";
            this.bandedGridColumn40.ColumnEdit = this.repositoryItemComboBox5;
            this.bandedGridColumn40.FieldName = "depRelationship";
            this.bandedGridColumn40.MinWidth = 23;
            this.bandedGridColumn40.Name = "bandedGridColumn40";
            this.bandedGridColumn40.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn40.Width = 146;
            // 
            // repositoryItemComboBox5
            // 
            this.repositoryItemComboBox5.AutoHeight = false;
            this.repositoryItemComboBox5.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox5.Items.AddRange(new object[] {
            "Spouse",
            "Daughter",
            "Son",
            "Sister",
            "Brother",
            "Grandparent",
            "Grandchild",
            "Great-Grandchild",
            "Granddaughter",
            "Grandson",
            "Great-Granddaughter",
            "Great-Grandson"});
            this.repositoryItemComboBox5.Name = "repositoryItemComboBox5";
            this.repositoryItemComboBox5.PopupFormSize = new System.Drawing.Size(117, 123);
            this.repositoryItemComboBox5.PopupSizeable = true;
            // 
            // bandedGridColumn41
            // 
            this.bandedGridColumn41.Caption = "Address";
            this.bandedGridColumn41.FieldName = "address";
            this.bandedGridColumn41.MinWidth = 23;
            this.bandedGridColumn41.Name = "bandedGridColumn41";
            this.bandedGridColumn41.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn41.Visible = true;
            this.bandedGridColumn41.Width = 87;
            // 
            // bandedGridColumn42
            // 
            this.bandedGridColumn42.Caption = "City";
            this.bandedGridColumn42.FieldName = "city";
            this.bandedGridColumn42.MinWidth = 23;
            this.bandedGridColumn42.Name = "bandedGridColumn42";
            this.bandedGridColumn42.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn42.Visible = true;
            this.bandedGridColumn42.Width = 87;
            // 
            // bandedGridColumn43
            // 
            this.bandedGridColumn43.Caption = "State";
            this.bandedGridColumn43.ColumnEdit = this.repositoryItemComboBox6;
            this.bandedGridColumn43.FieldName = "state";
            this.bandedGridColumn43.MinWidth = 23;
            this.bandedGridColumn43.Name = "bandedGridColumn43";
            this.bandedGridColumn43.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn43.Visible = true;
            this.bandedGridColumn43.Width = 58;
            // 
            // repositoryItemComboBox6
            // 
            this.repositoryItemComboBox6.AutoHeight = false;
            this.repositoryItemComboBox6.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox6.Name = "repositoryItemComboBox6";
            // 
            // bandedGridColumn44
            // 
            this.bandedGridColumn44.Caption = "Zip";
            this.bandedGridColumn44.FieldName = "zip";
            this.bandedGridColumn44.MinWidth = 23;
            this.bandedGridColumn44.Name = "bandedGridColumn44";
            this.bandedGridColumn44.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn44.Visible = true;
            this.bandedGridColumn44.Width = 70;
            // 
            // bandedGridColumn123
            // 
            this.bandedGridColumn123.Caption = "County";
            this.bandedGridColumn123.FieldName = "county";
            this.bandedGridColumn123.MinWidth = 23;
            this.bandedGridColumn123.Name = "bandedGridColumn123";
            this.bandedGridColumn123.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn123.Visible = true;
            this.bandedGridColumn123.Width = 87;
            // 
            // bandedGridColumn52
            // 
            this.bandedGridColumn52.Caption = "Spouse First Name";
            this.bandedGridColumn52.FieldName = "spouseFirstName";
            this.bandedGridColumn52.MinWidth = 23;
            this.bandedGridColumn52.Name = "bandedGridColumn52";
            this.bandedGridColumn52.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn52.Visible = true;
            this.bandedGridColumn52.Width = 87;
            // 
            // bandedGridColumn154
            // 
            this.bandedGridColumn154.Caption = "Full Name";
            this.bandedGridColumn154.FieldName = "fullName";
            this.bandedGridColumn154.MinWidth = 23;
            this.bandedGridColumn154.Name = "bandedGridColumn154";
            this.bandedGridColumn154.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn154.Width = 87;
            // 
            // repositoryItemCheckEdit3
            // 
            this.repositoryItemCheckEdit3.AutoHeight = false;
            this.repositoryItemCheckEdit3.Name = "repositoryItemCheckEdit3";
            // 
            // repositoryItemPictureEdit3
            // 
            this.repositoryItemPictureEdit3.Name = "repositoryItemPictureEdit3";
            this.repositoryItemPictureEdit3.PictureAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.repositoryItemPictureEdit3.PictureStoreMode = DevExpress.XtraEditors.Controls.PictureStoreMode.Image;
            this.repositoryItemPictureEdit3.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            // 
            // gridView3
            // 
            this.gridView3.DetailHeight = 431;
            this.gridView3.GridControl = this.dgv3;
            this.gridView3.Name = "gridView3";
            // 
            // tabClergy
            // 
            this.tabClergy.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.tabClergy.Controls.Add(this.panelClergyStuff);
            this.tabClergy.Controls.Add(this.dgv4);
            this.tabClergy.Location = new System.Drawing.Point(4, 25);
            this.tabClergy.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabClergy.Name = "tabClergy";
            this.tabClergy.Size = new System.Drawing.Size(1669, 347);
            this.tabClergy.TabIndex = 3;
            this.tabClergy.Text = "Clergy";
            // 
            // panelClergyStuff
            // 
            this.panelClergyStuff.Controls.Add(this.btnClergyCancel);
            this.panelClergyStuff.Controls.Add(this.btnClergyAccept);
            this.panelClergyStuff.Controls.Add(this.txtSuffix);
            this.panelClergyStuff.Controls.Add(this.txtTitle);
            this.panelClergyStuff.Controls.Add(this.txtCity2);
            this.panelClergyStuff.Controls.Add(this.txtFirstName);
            this.panelClergyStuff.Controls.Add(this.txtState2);
            this.panelClergyStuff.Controls.Add(this.txtMiddleName);
            this.panelClergyStuff.Controls.Add(this.txtAddress2);
            this.panelClergyStuff.Controls.Add(this.txtLastName);
            this.panelClergyStuff.Controls.Add(this.txtZip2);
            this.panelClergyStuff.Controls.Add(this.label18);
            this.panelClergyStuff.Controls.Add(this.label14);
            this.panelClergyStuff.Controls.Add(this.label17);
            this.panelClergyStuff.Controls.Add(this.label13);
            this.panelClergyStuff.Controls.Add(this.label16);
            this.panelClergyStuff.Controls.Add(this.label12);
            this.panelClergyStuff.Controls.Add(this.label15);
            this.panelClergyStuff.Controls.Add(this.label11);
            this.panelClergyStuff.Controls.Add(this.txtCounty2);
            this.panelClergyStuff.Controls.Add(this.label10);
            this.panelClergyStuff.Controls.Add(this.txtPhone2);
            this.panelClergyStuff.Controls.Add(this.label9);
            this.panelClergyStuff.Controls.Add(this.label8);
            this.panelClergyStuff.Location = new System.Drawing.Point(1117, 0);
            this.panelClergyStuff.Name = "panelClergyStuff";
            this.panelClergyStuff.Size = new System.Drawing.Size(467, 347);
            this.panelClergyStuff.TabIndex = 61;
            // 
            // btnClergyCancel
            // 
            this.btnClergyCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnClergyCancel.Location = new System.Drawing.Point(363, 310);
            this.btnClergyCancel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnClergyCancel.Name = "btnClergyCancel";
            this.btnClergyCancel.Size = new System.Drawing.Size(87, 28);
            this.btnClergyCancel.TabIndex = 62;
            this.btnClergyCancel.Text = "Cancel";
            this.btnClergyCancel.UseVisualStyleBackColor = false;
            this.btnClergyCancel.Click += new System.EventHandler(this.btnClergyCancel_Click);
            // 
            // btnClergyAccept
            // 
            this.btnClergyAccept.BackColor = System.Drawing.Color.Lime;
            this.btnClergyAccept.Location = new System.Drawing.Point(264, 310);
            this.btnClergyAccept.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnClergyAccept.Name = "btnClergyAccept";
            this.btnClergyAccept.Size = new System.Drawing.Size(87, 28);
            this.btnClergyAccept.TabIndex = 61;
            this.btnClergyAccept.Text = "Accept";
            this.btnClergyAccept.UseVisualStyleBackColor = false;
            this.btnClergyAccept.Click += new System.EventHandler(this.btnClergyAccept_Click);
            // 
            // txtSuffix
            // 
            this.txtSuffix.Location = new System.Drawing.Point(93, 129);
            this.txtSuffix.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSuffix.Name = "txtSuffix";
            this.txtSuffix.ReadOnly = true;
            this.txtSuffix.Size = new System.Drawing.Size(357, 23);
            this.txtSuffix.TabIndex = 44;
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(95, 5);
            this.txtTitle.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.ReadOnly = true;
            this.txtTitle.Size = new System.Drawing.Size(357, 23);
            this.txtTitle.TabIndex = 60;
            // 
            // txtCity2
            // 
            this.txtCity2.Location = new System.Drawing.Point(93, 187);
            this.txtCity2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCity2.Name = "txtCity2";
            this.txtCity2.ReadOnly = true;
            this.txtCity2.Size = new System.Drawing.Size(357, 23);
            this.txtCity2.TabIndex = 46;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(95, 36);
            this.txtFirstName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.ReadOnly = true;
            this.txtFirstName.Size = new System.Drawing.Size(357, 23);
            this.txtFirstName.TabIndex = 59;
            // 
            // txtState2
            // 
            this.txtState2.Location = new System.Drawing.Point(93, 245);
            this.txtState2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtState2.Name = "txtState2";
            this.txtState2.ReadOnly = true;
            this.txtState2.Size = new System.Drawing.Size(357, 23);
            this.txtState2.TabIndex = 48;
            // 
            // txtMiddleName
            // 
            this.txtMiddleName.Location = new System.Drawing.Point(95, 67);
            this.txtMiddleName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMiddleName.Name = "txtMiddleName";
            this.txtMiddleName.ReadOnly = true;
            this.txtMiddleName.Size = new System.Drawing.Size(357, 23);
            this.txtMiddleName.TabIndex = 58;
            // 
            // txtAddress2
            // 
            this.txtAddress2.Location = new System.Drawing.Point(93, 161);
            this.txtAddress2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAddress2.Name = "txtAddress2";
            this.txtAddress2.ReadOnly = true;
            this.txtAddress2.Size = new System.Drawing.Size(357, 23);
            this.txtAddress2.TabIndex = 45;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(93, 98);
            this.txtLastName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.ReadOnly = true;
            this.txtLastName.Size = new System.Drawing.Size(357, 23);
            this.txtLastName.TabIndex = 57;
            // 
            // txtZip2
            // 
            this.txtZip2.Location = new System.Drawing.Point(93, 273);
            this.txtZip2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtZip2.Name = "txtZip2";
            this.txtZip2.ReadOnly = true;
            this.txtZip2.Size = new System.Drawing.Size(82, 23);
            this.txtZip2.TabIndex = 49;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(44, 132);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(42, 17);
            this.label18.TabIndex = 56;
            this.label18.Text = "Suffix";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(66, 278);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(26, 17);
            this.label14.TabIndex = 43;
            this.label14.Text = "Zip";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(17, 101);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(72, 17);
            this.label17.TabIndex = 55;
            this.label17.Text = "Last Name";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(47, 248);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 17);
            this.label13.TabIndex = 42;
            this.label13.Text = "State";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(4, 69);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(84, 17);
            this.label16.TabIndex = 54;
            this.label16.Text = "Middle Name";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(33, 219);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 17);
            this.label12.TabIndex = 51;
            this.label12.Text = "County";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(17, 38);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 17);
            this.label15.TabIndex = 53;
            this.label15.Text = "First Name";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(55, 191);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(32, 17);
            this.label11.TabIndex = 41;
            this.label11.Text = "City";
            // 
            // txtCounty2
            // 
            this.txtCounty2.Location = new System.Drawing.Point(93, 216);
            this.txtCounty2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCounty2.Name = "txtCounty2";
            this.txtCounty2.ReadOnly = true;
            this.txtCounty2.Size = new System.Drawing.Size(357, 23);
            this.txtCounty2.TabIndex = 47;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(32, 161);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 17);
            this.label10.TabIndex = 40;
            this.label10.Text = "Address";
            // 
            // txtPhone2
            // 
            this.txtPhone2.Location = new System.Drawing.Point(91, 299);
            this.txtPhone2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPhone2.Name = "txtPhone2";
            this.txtPhone2.ReadOnly = true;
            this.txtPhone2.Size = new System.Drawing.Size(128, 23);
            this.txtPhone2.TabIndex = 50;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(39, 302);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 17);
            this.label9.TabIndex = 52;
            this.label9.Text = "Phone";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(55, 8);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 17);
            this.label8.TabIndex = 39;
            this.label8.Text = "Title";
            // 
            // dgv4
            // 
            this.dgv4.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv4.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv4.Location = new System.Drawing.Point(0, 0);
            this.dgv4.LookAndFeel.SkinName = "Foggy";
            this.dgv4.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv4.MainView = this.gridMain4;
            this.dgv4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv4.Name = "dgv4";
            this.dgv4.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox18,
            this.repositoryItemComboBox20,
            this.repositoryItemComboBox21,
            this.repositoryItemComboBox22});
            this.dgv4.Size = new System.Drawing.Size(1669, 347);
            this.dgv4.TabIndex = 10;
            this.dgv4.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain4,
            this.gridView4});
            this.dgv4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgv4_KeyUp);
            // 
            // gridMain4
            // 
            this.gridMain4.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(190)))), ((int)(((byte)(159)))));
            this.gridMain4.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(190)))), ((int)(((byte)(159)))));
            this.gridMain4.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain4.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(93)))), ((int)(((byte)(63)))));
            this.gridMain4.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain4.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain4.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain4.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(201)))), ((int)(((byte)(228)))), ((int)(((byte)(206)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain4.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain4.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain4.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain4.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain4.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain4.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain4.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(123)))), ((int)(((byte)(93)))));
            this.gridMain4.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain4.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(33)))), ((int)(((byte)(3)))));
            this.gridMain4.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain4.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain4.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(81)))), ((int)(((byte)(30)))));
            this.gridMain4.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMain4.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(201)))), ((int)(((byte)(150)))));
            this.gridMain4.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain4.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain4.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain4.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain4.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(210)))), ((int)(((byte)(179)))));
            this.gridMain4.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(210)))), ((int)(((byte)(179)))));
            this.gridMain4.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(63)))), ((int)(((byte)(33)))));
            this.gridMain4.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain4.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMain4.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(227)))), ((int)(((byte)(211)))));
            this.gridMain4.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain4.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain4.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain4.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain4.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(103)))), ((int)(((byte)(73)))));
            this.gridMain4.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain4.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain4.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain4.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain4.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain4.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(227)))), ((int)(((byte)(211)))));
            this.gridMain4.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain4.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(255)))), ((int)(((byte)(229)))));
            this.gridMain4.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMain4.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain4.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain4.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMain4.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.Row.Options.UseBackColor = true;
            this.gridMain4.Appearance.Row.Options.UseFont = true;
            this.gridMain4.Appearance.Row.Options.UseForeColor = true;
            this.gridMain4.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain4.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain4.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(161)))), ((int)(((byte)(110)))));
            this.gridMain4.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain4.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain4.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain4.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain4.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand3});
            this.gridMain4.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain4.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn54,
            this.bandedGridColumn55,
            this.bandedGridColumn151,
            this.bandedGridColumn147,
            this.bandedGridColumn57,
            this.bandedGridColumn56,
            this.bandedGridColumn58,
            this.bandedGridColumn60,
            this.bandedGridColumn59,
            this.bandedGridColumn150,
            this.bandedGridColumn149,
            this.bandedGridColumn61,
            this.bandedGridColumn62,
            this.bandedGridColumn64,
            this.bandedGridColumn69,
            this.bandedGridColumn65,
            this.bandedGridColumn66,
            this.bandedGridColumn67,
            this.bandedGridColumn68,
            this.bandedGridColumn124,
            this.bandedGridColumn63,
            this.bandedGridColumn135,
            this.bandedGridColumn134});
            this.gridMain4.DetailHeight = 431;
            this.gridMain4.GridControl = this.dgv4;
            this.gridMain4.Name = "gridMain4";
            this.gridMain4.OptionsBehavior.AutoPopulateColumns = false;
            this.gridMain4.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.MouseDown;
            this.gridMain4.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridMain4.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain4.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain4.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain4.OptionsView.ShowBands = false;
            this.gridMain4.OptionsView.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowAlways;
            this.gridMain4.OptionsView.ShowGroupPanel = false;
            this.gridMain4.PaintStyleName = "Flat";
            this.gridMain4.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMainDep_CustomDrawCell);
            this.gridMain4.ShownEditor += new System.EventHandler(this.gridMain4_ShownEditor);
            this.gridMain4.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.ClergyChanged);
            this.gridMain4.CellValueChanging += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMain4_CellValueChanging);
            this.gridMain4.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMainDep_CustomRowFilter);
            this.gridMain4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gridMainDep_KeyDown);
            this.gridMain4.KeyUp += new System.Windows.Forms.KeyEventHandler(this.gridMain4_KeyUp);
            this.gridMain4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.gridMain4_MouseDown);
            this.gridMain4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.gridMain4_MouseMove);
            this.gridMain4.DoubleClick += new System.EventHandler(this.gridMain4_DoubleClick);
            // 
            // gridBand3
            // 
            this.gridBand3.Caption = "gridBand1";
            this.gridBand3.Columns.Add(this.bandedGridColumn54);
            this.gridBand3.Columns.Add(this.bandedGridColumn150);
            this.gridBand3.Columns.Add(this.bandedGridColumn149);
            this.gridBand3.Columns.Add(this.bandedGridColumn147);
            this.gridBand3.Columns.Add(this.bandedGridColumn55);
            this.gridBand3.Columns.Add(this.bandedGridColumn56);
            this.gridBand3.Columns.Add(this.bandedGridColumn58);
            this.gridBand3.Columns.Add(this.bandedGridColumn57);
            this.gridBand3.Columns.Add(this.bandedGridColumn151);
            this.gridBand3.Columns.Add(this.bandedGridColumn59);
            this.gridBand3.Columns.Add(this.bandedGridColumn60);
            this.gridBand3.Columns.Add(this.bandedGridColumn61);
            this.gridBand3.Columns.Add(this.bandedGridColumn62);
            this.gridBand3.Columns.Add(this.bandedGridColumn63);
            this.gridBand3.Columns.Add(this.bandedGridColumn135);
            this.gridBand3.Columns.Add(this.bandedGridColumn134);
            this.gridBand3.Columns.Add(this.bandedGridColumn64);
            this.gridBand3.Columns.Add(this.bandedGridColumn65);
            this.gridBand3.Columns.Add(this.bandedGridColumn66);
            this.gridBand3.Columns.Add(this.bandedGridColumn67);
            this.gridBand3.Columns.Add(this.bandedGridColumn68);
            this.gridBand3.Columns.Add(this.bandedGridColumn124);
            this.gridBand3.Columns.Add(this.bandedGridColumn69);
            this.gridBand3.MinWidth = 12;
            this.gridBand3.Name = "gridBand3";
            this.gridBand3.VisibleIndex = 0;
            this.gridBand3.Width = 1736;
            // 
            // bandedGridColumn54
            // 
            this.bandedGridColumn54.Caption = "Num";
            this.bandedGridColumn54.FieldName = "num";
            this.bandedGridColumn54.MinWidth = 23;
            this.bandedGridColumn54.Name = "bandedGridColumn54";
            this.bandedGridColumn54.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn54.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn54.Visible = true;
            this.bandedGridColumn54.Width = 62;
            // 
            // bandedGridColumn150
            // 
            this.bandedGridColumn150.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn150.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn150.Caption = "A";
            this.bandedGridColumn150.FieldName = "add";
            this.bandedGridColumn150.MinWidth = 23;
            this.bandedGridColumn150.Name = "bandedGridColumn150";
            this.bandedGridColumn150.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn150.Width = 35;
            // 
            // bandedGridColumn149
            // 
            this.bandedGridColumn149.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn149.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn149.Caption = "E";
            this.bandedGridColumn149.FieldName = "edit";
            this.bandedGridColumn149.MinWidth = 23;
            this.bandedGridColumn149.Name = "bandedGridColumn149";
            this.bandedGridColumn149.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn149.Width = 35;
            // 
            // bandedGridColumn147
            // 
            this.bandedGridColumn147.Caption = "Title";
            this.bandedGridColumn147.FieldName = "depPrefix";
            this.bandedGridColumn147.MinWidth = 23;
            this.bandedGridColumn147.Name = "bandedGridColumn147";
            this.bandedGridColumn147.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn147.Visible = true;
            this.bandedGridColumn147.Width = 58;
            // 
            // bandedGridColumn55
            // 
            this.bandedGridColumn55.Caption = "record";
            this.bandedGridColumn55.FieldName = "record";
            this.bandedGridColumn55.MinWidth = 23;
            this.bandedGridColumn55.Name = "bandedGridColumn55";
            this.bandedGridColumn55.Width = 87;
            // 
            // bandedGridColumn56
            // 
            this.bandedGridColumn56.Caption = "First Name";
            this.bandedGridColumn56.ColumnEdit = this.repositoryItemComboBox22;
            this.bandedGridColumn56.FieldName = "depFirstName";
            this.bandedGridColumn56.MinWidth = 23;
            this.bandedGridColumn56.Name = "bandedGridColumn56";
            this.bandedGridColumn56.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn56.Visible = true;
            this.bandedGridColumn56.Width = 150;
            // 
            // repositoryItemComboBox22
            // 
            this.repositoryItemComboBox22.AutoHeight = false;
            this.repositoryItemComboBox22.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox22.ImmediatePopup = true;
            this.repositoryItemComboBox22.Name = "repositoryItemComboBox22";
            this.repositoryItemComboBox22.ValidateOnEnterKey = true;
            this.repositoryItemComboBox22.SelectedIndexChanged += new System.EventHandler(this.repositoryItemComboBox22_SelectedIndexChanged);
            this.repositoryItemComboBox22.Popup += new System.EventHandler(this.repositoryItemComboBox22_Popup);
            this.repositoryItemComboBox22.Enter += new System.EventHandler(this.repositoryItemComboBox22_Enter);
            this.repositoryItemComboBox22.KeyUp += new System.Windows.Forms.KeyEventHandler(this.repositoryItemComboBox22_KeyUp);
            this.repositoryItemComboBox22.Leave += new System.EventHandler(this.repositoryItemComboBox22_Leave);
            // 
            // bandedGridColumn58
            // 
            this.bandedGridColumn58.Caption = "Middle Initial";
            this.bandedGridColumn58.FieldName = "depMI";
            this.bandedGridColumn58.MinWidth = 23;
            this.bandedGridColumn58.Name = "bandedGridColumn58";
            this.bandedGridColumn58.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn58.Visible = true;
            this.bandedGridColumn58.Width = 70;
            // 
            // bandedGridColumn57
            // 
            this.bandedGridColumn57.Caption = "Last Name";
            this.bandedGridColumn57.ColumnEdit = this.repositoryItemComboBox21;
            this.bandedGridColumn57.FieldName = "depLastName";
            this.bandedGridColumn57.MinWidth = 23;
            this.bandedGridColumn57.Name = "bandedGridColumn57";
            this.bandedGridColumn57.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn57.Visible = true;
            this.bandedGridColumn57.Width = 150;
            // 
            // repositoryItemComboBox21
            // 
            this.repositoryItemComboBox21.AutoHeight = false;
            this.repositoryItemComboBox21.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox21.Name = "repositoryItemComboBox21";
            this.repositoryItemComboBox21.SelectedIndexChanged += new System.EventHandler(this.repositoryItemComboBox21_SelectedIndexChanged);
            this.repositoryItemComboBox21.Popup += new System.EventHandler(this.repositoryItemComboBox21_Popup);
            this.repositoryItemComboBox21.Enter += new System.EventHandler(this.repositoryItemComboBox21_Enter);
            this.repositoryItemComboBox21.KeyUp += new System.Windows.Forms.KeyEventHandler(this.repositoryItemComboBox21_KeyUp);
            this.repositoryItemComboBox21.Leave += new System.EventHandler(this.repositoryItemComboBox21_Leave);
            // 
            // bandedGridColumn151
            // 
            this.bandedGridColumn151.Caption = "Full Name";
            this.bandedGridColumn151.FieldName = "fullName";
            this.bandedGridColumn151.MinWidth = 23;
            this.bandedGridColumn151.Name = "bandedGridColumn151";
            this.bandedGridColumn151.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn151.Visible = true;
            this.bandedGridColumn151.Width = 233;
            // 
            // bandedGridColumn59
            // 
            this.bandedGridColumn59.Caption = "Suffix";
            this.bandedGridColumn59.FieldName = "depSuffix";
            this.bandedGridColumn59.MinWidth = 23;
            this.bandedGridColumn59.Name = "bandedGridColumn59";
            this.bandedGridColumn59.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn59.Visible = true;
            this.bandedGridColumn59.Width = 70;
            // 
            // bandedGridColumn60
            // 
            this.bandedGridColumn60.Caption = "Maiden Name";
            this.bandedGridColumn60.FieldName = "maidenName";
            this.bandedGridColumn60.MinWidth = 23;
            this.bandedGridColumn60.Name = "bandedGridColumn60";
            this.bandedGridColumn60.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn60.Visible = true;
            this.bandedGridColumn60.Width = 119;
            // 
            // bandedGridColumn61
            // 
            this.bandedGridColumn61.Caption = "DOB";
            this.bandedGridColumn61.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn61.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn61.FieldName = "depDOB";
            this.bandedGridColumn61.MinWidth = 23;
            this.bandedGridColumn61.Name = "bandedGridColumn61";
            this.bandedGridColumn61.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn61.Visible = true;
            this.bandedGridColumn61.Width = 87;
            // 
            // bandedGridColumn62
            // 
            this.bandedGridColumn62.Caption = "DOD";
            this.bandedGridColumn62.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn62.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn62.FieldName = "depDOD";
            this.bandedGridColumn62.MinWidth = 23;
            this.bandedGridColumn62.Name = "bandedGridColumn62";
            this.bandedGridColumn62.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn62.Width = 87;
            // 
            // bandedGridColumn63
            // 
            this.bandedGridColumn63.Caption = "Phone";
            this.bandedGridColumn63.FieldName = "phone";
            this.bandedGridColumn63.MinWidth = 23;
            this.bandedGridColumn63.Name = "bandedGridColumn63";
            this.bandedGridColumn63.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn63.Visible = true;
            this.bandedGridColumn63.Width = 87;
            // 
            // bandedGridColumn135
            // 
            this.bandedGridColumn135.Caption = "Phone Type";
            this.bandedGridColumn135.ColumnEdit = this.repositoryItemComboBox18;
            this.bandedGridColumn135.FieldName = "phoneType";
            this.bandedGridColumn135.MinWidth = 23;
            this.bandedGridColumn135.Name = "bandedGridColumn135";
            this.bandedGridColumn135.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn135.Visible = true;
            this.bandedGridColumn135.Width = 87;
            // 
            // repositoryItemComboBox18
            // 
            this.repositoryItemComboBox18.AutoHeight = false;
            this.repositoryItemComboBox18.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox18.Items.AddRange(new object[] {
            "Home",
            "Cell",
            "Work"});
            this.repositoryItemComboBox18.Name = "repositoryItemComboBox18";
            // 
            // bandedGridColumn134
            // 
            this.bandedGridColumn134.Caption = "Email";
            this.bandedGridColumn134.FieldName = "email";
            this.bandedGridColumn134.MinWidth = 23;
            this.bandedGridColumn134.Name = "bandedGridColumn134";
            this.bandedGridColumn134.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn134.Visible = true;
            this.bandedGridColumn134.Width = 87;
            // 
            // bandedGridColumn64
            // 
            this.bandedGridColumn64.Caption = "RelationShip";
            this.bandedGridColumn64.ColumnEdit = this.repositoryItemComboBox9;
            this.bandedGridColumn64.FieldName = "depRelationship";
            this.bandedGridColumn64.MinWidth = 23;
            this.bandedGridColumn64.Name = "bandedGridColumn64";
            this.bandedGridColumn64.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn64.Width = 146;
            // 
            // bandedGridColumn65
            // 
            this.bandedGridColumn65.Caption = "Address";
            this.bandedGridColumn65.FieldName = "address";
            this.bandedGridColumn65.MinWidth = 23;
            this.bandedGridColumn65.Name = "bandedGridColumn65";
            this.bandedGridColumn65.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn65.Visible = true;
            this.bandedGridColumn65.Width = 87;
            // 
            // bandedGridColumn66
            // 
            this.bandedGridColumn66.Caption = "City";
            this.bandedGridColumn66.FieldName = "city";
            this.bandedGridColumn66.MinWidth = 23;
            this.bandedGridColumn66.Name = "bandedGridColumn66";
            this.bandedGridColumn66.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn66.Visible = true;
            this.bandedGridColumn66.Width = 87;
            // 
            // bandedGridColumn67
            // 
            this.bandedGridColumn67.Caption = "State";
            this.bandedGridColumn67.ColumnEdit = this.repositoryItemComboBox7;
            this.bandedGridColumn67.FieldName = "state";
            this.bandedGridColumn67.MinWidth = 23;
            this.bandedGridColumn67.Name = "bandedGridColumn67";
            this.bandedGridColumn67.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn67.Visible = true;
            this.bandedGridColumn67.Width = 58;
            // 
            // bandedGridColumn68
            // 
            this.bandedGridColumn68.Caption = "Zip";
            this.bandedGridColumn68.FieldName = "zip";
            this.bandedGridColumn68.MinWidth = 23;
            this.bandedGridColumn68.Name = "bandedGridColumn68";
            this.bandedGridColumn68.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn68.Visible = true;
            this.bandedGridColumn68.Width = 70;
            // 
            // bandedGridColumn124
            // 
            this.bandedGridColumn124.Caption = "County";
            this.bandedGridColumn124.FieldName = "county";
            this.bandedGridColumn124.MinWidth = 23;
            this.bandedGridColumn124.Name = "bandedGridColumn124";
            this.bandedGridColumn124.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn124.Visible = true;
            this.bandedGridColumn124.Width = 87;
            // 
            // bandedGridColumn69
            // 
            this.bandedGridColumn69.Caption = "Spouse First Name";
            this.bandedGridColumn69.FieldName = "spouseFirstName";
            this.bandedGridColumn69.MinWidth = 23;
            this.bandedGridColumn69.Name = "bandedGridColumn69";
            this.bandedGridColumn69.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn69.Visible = true;
            this.bandedGridColumn69.Width = 87;
            // 
            // repositoryItemComboBox20
            // 
            this.repositoryItemComboBox20.AutoHeight = false;
            this.repositoryItemComboBox20.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox20.Name = "repositoryItemComboBox20";
            // 
            // gridView4
            // 
            this.gridView4.DetailHeight = 431;
            this.gridView4.GridControl = this.dgv4;
            this.gridView4.Name = "gridView4";
            // 
            // tabMusicians
            // 
            this.tabMusicians.Controls.Add(this.dgv5);
            this.tabMusicians.Location = new System.Drawing.Point(4, 25);
            this.tabMusicians.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabMusicians.Name = "tabMusicians";
            this.tabMusicians.Size = new System.Drawing.Size(1669, 347);
            this.tabMusicians.TabIndex = 4;
            this.tabMusicians.Text = "Musicians";
            this.tabMusicians.UseVisualStyleBackColor = true;
            // 
            // dgv5
            // 
            this.dgv5.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv5.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv5.Location = new System.Drawing.Point(0, 0);
            this.dgv5.LookAndFeel.SkinName = "Foggy";
            this.dgv5.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv5.MainView = this.gridMain5;
            this.dgv5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv5.Name = "dgv5";
            this.dgv5.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox19});
            this.dgv5.Size = new System.Drawing.Size(1669, 347);
            this.dgv5.TabIndex = 11;
            this.dgv5.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain5,
            this.gridView5});
            // 
            // gridMain5
            // 
            this.gridMain5.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(190)))), ((int)(((byte)(159)))));
            this.gridMain5.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(190)))), ((int)(((byte)(159)))));
            this.gridMain5.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain5.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain5.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain5.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(63)))), ((int)(((byte)(93)))), ((int)(((byte)(63)))));
            this.gridMain5.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain5.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain5.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain5.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain5.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain5.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain5.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain5.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain5.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain5.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(201)))), ((int)(((byte)(228)))), ((int)(((byte)(206)))));
            this.gridMain5.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain5.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain5.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain5.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain5.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain5.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain5.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain5.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain5.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain5.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain5.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain5.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(123)))), ((int)(((byte)(93)))));
            this.gridMain5.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain5.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain5.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain5.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain5.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain5.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(3)))), ((int)(((byte)(33)))), ((int)(((byte)(3)))));
            this.gridMain5.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain5.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain5.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(81)))), ((int)(((byte)(30)))));
            this.gridMain5.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain5.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMain5.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(201)))), ((int)(((byte)(150)))));
            this.gridMain5.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain5.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain5.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain5.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain5.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain5.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain5.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(210)))), ((int)(((byte)(179)))));
            this.gridMain5.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(172)))), ((int)(((byte)(210)))), ((int)(((byte)(179)))));
            this.gridMain5.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain5.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(63)))), ((int)(((byte)(33)))));
            this.gridMain5.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain5.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain5.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain5.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMain5.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(227)))), ((int)(((byte)(211)))));
            this.gridMain5.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain5.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain5.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.gridMain5.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain5.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain5.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain5.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain5.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(73)))), ((int)(((byte)(103)))), ((int)(((byte)(73)))));
            this.gridMain5.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain5.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain5.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain5.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain5.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain5.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(227)))), ((int)(((byte)(211)))));
            this.gridMain5.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain5.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain5.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(255)))), ((int)(((byte)(229)))));
            this.gridMain5.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain5.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(89)))), ((int)(((byte)(151)))), ((int)(((byte)(100)))));
            this.gridMain5.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain5.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain5.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.Row.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMain5.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.Row.Options.UseBackColor = true;
            this.gridMain5.Appearance.Row.Options.UseFont = true;
            this.gridMain5.Appearance.Row.Options.UseForeColor = true;
            this.gridMain5.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(182)))), ((int)(((byte)(220)))), ((int)(((byte)(189)))));
            this.gridMain5.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain5.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(161)))), ((int)(((byte)(110)))));
            this.gridMain5.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(162)))), ((int)(((byte)(200)))), ((int)(((byte)(169)))));
            this.gridMain5.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain5.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain5.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain5.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand4});
            this.gridMain5.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain5.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn70,
            this.bandedGridColumn71,
            this.bandedGridColumn156,
            this.bandedGridColumn148,
            this.bandedGridColumn73,
            this.bandedGridColumn72,
            this.bandedGridColumn74,
            this.bandedGridColumn76,
            this.bandedGridColumn75,
            this.bandedGridColumn77,
            this.bandedGridColumn78,
            this.bandedGridColumn80,
            this.bandedGridColumn85,
            this.bandedGridColumn81,
            this.bandedGridColumn82,
            this.bandedGridColumn83,
            this.bandedGridColumn84,
            this.bandedGridColumn125,
            this.bandedGridColumn79,
            this.bandedGridColumn136,
            this.bandedGridColumn137});
            this.gridMain5.DetailHeight = 431;
            this.gridMain5.GridControl = this.dgv5;
            this.gridMain5.Name = "gridMain5";
            this.gridMain5.OptionsBehavior.AutoPopulateColumns = false;
            this.gridMain5.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.MouseDown;
            this.gridMain5.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridMain5.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain5.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain5.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain5.OptionsView.ShowBands = false;
            this.gridMain5.OptionsView.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowAlways;
            this.gridMain5.OptionsView.ShowGroupPanel = false;
            this.gridMain5.PaintStyleName = "Flat";
            this.gridMain5.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMainDep_CustomDrawCell);
            this.gridMain5.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMainDep_CellValueChanged);
            this.gridMain5.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMainDep_CustomRowFilter);
            this.gridMain5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gridMainDep_KeyDown);
            // 
            // gridBand4
            // 
            this.gridBand4.Caption = "gridBand1";
            this.gridBand4.Columns.Add(this.bandedGridColumn70);
            this.gridBand4.Columns.Add(this.bandedGridColumn148);
            this.gridBand4.Columns.Add(this.bandedGridColumn71);
            this.gridBand4.Columns.Add(this.bandedGridColumn72);
            this.gridBand4.Columns.Add(this.bandedGridColumn74);
            this.gridBand4.Columns.Add(this.bandedGridColumn73);
            this.gridBand4.Columns.Add(this.bandedGridColumn75);
            this.gridBand4.Columns.Add(this.bandedGridColumn76);
            this.gridBand4.Columns.Add(this.bandedGridColumn77);
            this.gridBand4.Columns.Add(this.bandedGridColumn78);
            this.gridBand4.Columns.Add(this.bandedGridColumn79);
            this.gridBand4.Columns.Add(this.bandedGridColumn136);
            this.gridBand4.Columns.Add(this.bandedGridColumn137);
            this.gridBand4.Columns.Add(this.bandedGridColumn80);
            this.gridBand4.Columns.Add(this.bandedGridColumn81);
            this.gridBand4.Columns.Add(this.bandedGridColumn82);
            this.gridBand4.Columns.Add(this.bandedGridColumn83);
            this.gridBand4.Columns.Add(this.bandedGridColumn84);
            this.gridBand4.Columns.Add(this.bandedGridColumn125);
            this.gridBand4.Columns.Add(this.bandedGridColumn85);
            this.gridBand4.MinWidth = 12;
            this.gridBand4.Name = "gridBand4";
            this.gridBand4.VisibleIndex = 0;
            this.gridBand4.Width = 1383;
            // 
            // bandedGridColumn70
            // 
            this.bandedGridColumn70.Caption = "Num";
            this.bandedGridColumn70.FieldName = "num";
            this.bandedGridColumn70.MinWidth = 23;
            this.bandedGridColumn70.Name = "bandedGridColumn70";
            this.bandedGridColumn70.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn70.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn70.Visible = true;
            this.bandedGridColumn70.Width = 62;
            // 
            // bandedGridColumn148
            // 
            this.bandedGridColumn148.Caption = "Title";
            this.bandedGridColumn148.FieldName = "depPrefix";
            this.bandedGridColumn148.MinWidth = 23;
            this.bandedGridColumn148.Name = "bandedGridColumn148";
            this.bandedGridColumn148.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn148.Visible = true;
            this.bandedGridColumn148.Width = 64;
            // 
            // bandedGridColumn71
            // 
            this.bandedGridColumn71.Caption = "record";
            this.bandedGridColumn71.FieldName = "record";
            this.bandedGridColumn71.MinWidth = 23;
            this.bandedGridColumn71.Name = "bandedGridColumn71";
            this.bandedGridColumn71.Width = 87;
            // 
            // bandedGridColumn72
            // 
            this.bandedGridColumn72.Caption = "First Name";
            this.bandedGridColumn72.FieldName = "depFirstName";
            this.bandedGridColumn72.MinWidth = 23;
            this.bandedGridColumn72.Name = "bandedGridColumn72";
            this.bandedGridColumn72.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn72.Visible = true;
            this.bandedGridColumn72.Width = 87;
            // 
            // bandedGridColumn74
            // 
            this.bandedGridColumn74.Caption = "Middle Initial";
            this.bandedGridColumn74.FieldName = "depMI";
            this.bandedGridColumn74.MinWidth = 23;
            this.bandedGridColumn74.Name = "bandedGridColumn74";
            this.bandedGridColumn74.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn74.Visible = true;
            this.bandedGridColumn74.Width = 70;
            // 
            // bandedGridColumn73
            // 
            this.bandedGridColumn73.Caption = "Last Name";
            this.bandedGridColumn73.FieldName = "depLastName";
            this.bandedGridColumn73.MinWidth = 23;
            this.bandedGridColumn73.Name = "bandedGridColumn73";
            this.bandedGridColumn73.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn73.Visible = true;
            this.bandedGridColumn73.Width = 87;
            // 
            // bandedGridColumn75
            // 
            this.bandedGridColumn75.Caption = "Suffix";
            this.bandedGridColumn75.FieldName = "depSuffix";
            this.bandedGridColumn75.MinWidth = 23;
            this.bandedGridColumn75.Name = "bandedGridColumn75";
            this.bandedGridColumn75.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn75.Visible = true;
            this.bandedGridColumn75.Width = 70;
            // 
            // bandedGridColumn76
            // 
            this.bandedGridColumn76.Caption = "Maiden Name";
            this.bandedGridColumn76.FieldName = "maidenName";
            this.bandedGridColumn76.MinWidth = 23;
            this.bandedGridColumn76.Name = "bandedGridColumn76";
            this.bandedGridColumn76.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn76.Visible = true;
            this.bandedGridColumn76.Width = 119;
            // 
            // bandedGridColumn77
            // 
            this.bandedGridColumn77.Caption = "DOB";
            this.bandedGridColumn77.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn77.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn77.FieldName = "depDOB";
            this.bandedGridColumn77.MinWidth = 23;
            this.bandedGridColumn77.Name = "bandedGridColumn77";
            this.bandedGridColumn77.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn77.Visible = true;
            this.bandedGridColumn77.Width = 87;
            // 
            // bandedGridColumn78
            // 
            this.bandedGridColumn78.Caption = "DOD";
            this.bandedGridColumn78.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn78.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn78.FieldName = "depDOD";
            this.bandedGridColumn78.MinWidth = 23;
            this.bandedGridColumn78.Name = "bandedGridColumn78";
            this.bandedGridColumn78.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn78.Width = 87;
            // 
            // bandedGridColumn79
            // 
            this.bandedGridColumn79.Caption = "Phone";
            this.bandedGridColumn79.FieldName = "phone";
            this.bandedGridColumn79.MinWidth = 23;
            this.bandedGridColumn79.Name = "bandedGridColumn79";
            this.bandedGridColumn79.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn79.Visible = true;
            this.bandedGridColumn79.Width = 87;
            // 
            // bandedGridColumn136
            // 
            this.bandedGridColumn136.Caption = "Phone Type";
            this.bandedGridColumn136.ColumnEdit = this.repositoryItemComboBox19;
            this.bandedGridColumn136.FieldName = "phoneType";
            this.bandedGridColumn136.MinWidth = 23;
            this.bandedGridColumn136.Name = "bandedGridColumn136";
            this.bandedGridColumn136.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn136.Visible = true;
            this.bandedGridColumn136.Width = 87;
            // 
            // repositoryItemComboBox19
            // 
            this.repositoryItemComboBox19.AutoHeight = false;
            this.repositoryItemComboBox19.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox19.Items.AddRange(new object[] {
            "Home",
            "Cell",
            "Work"});
            this.repositoryItemComboBox19.Name = "repositoryItemComboBox19";
            // 
            // bandedGridColumn137
            // 
            this.bandedGridColumn137.Caption = "Email";
            this.bandedGridColumn137.FieldName = "email";
            this.bandedGridColumn137.MinWidth = 23;
            this.bandedGridColumn137.Name = "bandedGridColumn137";
            this.bandedGridColumn137.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn137.Visible = true;
            this.bandedGridColumn137.Width = 87;
            // 
            // bandedGridColumn80
            // 
            this.bandedGridColumn80.Caption = "RelationShip";
            this.bandedGridColumn80.ColumnEdit = this.repositoryItemComboBox9;
            this.bandedGridColumn80.FieldName = "depRelationship";
            this.bandedGridColumn80.MinWidth = 23;
            this.bandedGridColumn80.Name = "bandedGridColumn80";
            this.bandedGridColumn80.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn80.Width = 146;
            // 
            // bandedGridColumn81
            // 
            this.bandedGridColumn81.Caption = "Address";
            this.bandedGridColumn81.FieldName = "address";
            this.bandedGridColumn81.MinWidth = 23;
            this.bandedGridColumn81.Name = "bandedGridColumn81";
            this.bandedGridColumn81.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn81.Visible = true;
            this.bandedGridColumn81.Width = 87;
            // 
            // bandedGridColumn82
            // 
            this.bandedGridColumn82.Caption = "City";
            this.bandedGridColumn82.FieldName = "city";
            this.bandedGridColumn82.MinWidth = 23;
            this.bandedGridColumn82.Name = "bandedGridColumn82";
            this.bandedGridColumn82.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn82.Visible = true;
            this.bandedGridColumn82.Width = 87;
            // 
            // bandedGridColumn83
            // 
            this.bandedGridColumn83.Caption = "State";
            this.bandedGridColumn83.ColumnEdit = this.repositoryItemComboBox7;
            this.bandedGridColumn83.FieldName = "state";
            this.bandedGridColumn83.MinWidth = 23;
            this.bandedGridColumn83.Name = "bandedGridColumn83";
            this.bandedGridColumn83.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn83.Visible = true;
            this.bandedGridColumn83.Width = 58;
            // 
            // bandedGridColumn84
            // 
            this.bandedGridColumn84.Caption = "Zip";
            this.bandedGridColumn84.FieldName = "zip";
            this.bandedGridColumn84.MinWidth = 23;
            this.bandedGridColumn84.Name = "bandedGridColumn84";
            this.bandedGridColumn84.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn84.Visible = true;
            this.bandedGridColumn84.Width = 70;
            // 
            // bandedGridColumn125
            // 
            this.bandedGridColumn125.Caption = "County";
            this.bandedGridColumn125.FieldName = "county";
            this.bandedGridColumn125.MinWidth = 23;
            this.bandedGridColumn125.Name = "bandedGridColumn125";
            this.bandedGridColumn125.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn125.Visible = true;
            this.bandedGridColumn125.Width = 87;
            // 
            // bandedGridColumn85
            // 
            this.bandedGridColumn85.Caption = "Spouse First Name";
            this.bandedGridColumn85.FieldName = "spouseFirstName";
            this.bandedGridColumn85.MinWidth = 23;
            this.bandedGridColumn85.Name = "bandedGridColumn85";
            this.bandedGridColumn85.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn85.Visible = true;
            this.bandedGridColumn85.Width = 87;
            // 
            // bandedGridColumn156
            // 
            this.bandedGridColumn156.Caption = "Full Name";
            this.bandedGridColumn156.FieldName = "fullName";
            this.bandedGridColumn156.MinWidth = 23;
            this.bandedGridColumn156.Name = "bandedGridColumn156";
            this.bandedGridColumn156.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn156.Width = 87;
            // 
            // gridView5
            // 
            this.gridView5.DetailHeight = 431;
            this.gridView5.GridControl = this.dgv5;
            this.gridView5.Name = "gridView5";
            // 
            // tabDisclosures
            // 
            this.tabDisclosures.Controls.Add(this.dgv7);
            this.tabDisclosures.Location = new System.Drawing.Point(4, 25);
            this.tabDisclosures.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabDisclosures.Name = "tabDisclosures";
            this.tabDisclosures.Size = new System.Drawing.Size(1669, 347);
            this.tabDisclosures.TabIndex = 7;
            this.tabDisclosures.Text = "Disclosures";
            this.tabDisclosures.UseVisualStyleBackColor = true;
            // 
            // dgv7
            // 
            this.dgv7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv7.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv7.Location = new System.Drawing.Point(0, 0);
            this.dgv7.LookAndFeel.SkinName = "iMaginary";
            this.dgv7.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv7.MainView = this.gridMain7;
            this.dgv7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv7.Name = "dgv7";
            this.dgv7.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit8,
            this.repositoryItemCheckEdit9,
            this.repositoryItemCheckEdit10,
            this.repositoryItemCheckEdit11});
            this.dgv7.Size = new System.Drawing.Size(1669, 347);
            this.dgv7.TabIndex = 7;
            this.dgv7.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain7});
            // 
            // gridMain7
            // 
            this.gridMain7.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain7.Appearance.BandPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain7.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain7.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain7.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.BandPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain7.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain7.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain7.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain7.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain7.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain7.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain7.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.ColumnFilterButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain7.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain7.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain7.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain7.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(244)))));
            this.gridMain7.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(222)))), ((int)(((byte)(183)))));
            this.gridMain7.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(244)))));
            this.gridMain7.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.ColumnFilterButtonActive.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain7.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain7.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain7.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain7.Appearance.Empty.BackColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain7.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain7.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain7.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain7.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain7.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain7.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain7.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain7.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain7.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(158)))), ((int)(((byte)(126)))));
            this.gridMain7.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(128)))), ((int)(((byte)(88)))));
            this.gridMain7.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain7.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain7.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain7.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain7.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain7.Appearance.FooterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain7.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain7.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FooterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain7.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain7.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain7.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain7.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain7.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain7.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain7.Appearance.GroupFooter.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain7.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain7.Appearance.GroupFooter.Options.UseFont = true;
            this.gridMain7.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(158)))), ((int)(((byte)(126)))));
            this.gridMain7.Appearance.GroupPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain7.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain7.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain7.Appearance.GroupRow.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain7.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain7.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain7.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain7.Appearance.HeaderPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain7.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain7.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.HeaderPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain7.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain7.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain7.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(207)))), ((int)(((byte)(170)))));
            this.gridMain7.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain7.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(168)))), ((int)(((byte)(128)))));
            this.gridMain7.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain7.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.gridMain7.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain7.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain7.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain7.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.Row.Options.UseBackColor = true;
            this.gridMain7.Appearance.Row.Options.UseForeColor = true;
            this.gridMain7.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain7.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(178)))), ((int)(((byte)(133)))));
            this.gridMain7.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(160)))), ((int)(((byte)(188)))));
            this.gridMain7.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain7.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand10});
            this.gridMain7.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain7.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn157,
            this.bandedGridColumn167,
            this.bandedGridColumn162,
            this.bandedGridColumn158,
            this.bandedGridColumn159});
            this.gridMain7.DetailHeight = 431;
            this.gridMain7.GridControl = this.dgv7;
            this.gridMain7.Name = "gridMain7";
            this.gridMain7.OptionsBehavior.AutoPopulateColumns = false;
            this.gridMain7.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.MouseDown;
            this.gridMain7.OptionsPrint.PrintBandHeader = false;
            this.gridMain7.OptionsView.ColumnAutoWidth = true;
            this.gridMain7.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain7.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain7.OptionsView.ShowBands = false;
            this.gridMain7.OptionsView.ShowGroupPanel = false;
            this.gridMain7.PaintStyleName = "Flat";
            this.gridMain7.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMain7_CellValueChanged);
            // 
            // gridBand10
            // 
            this.gridBand10.Caption = "gridBand1";
            this.gridBand10.Columns.Add(this.bandedGridColumn157);
            this.gridBand10.Columns.Add(this.bandedGridColumn162);
            this.gridBand10.Columns.Add(this.bandedGridColumn158);
            this.gridBand10.Columns.Add(this.bandedGridColumn159);
            this.gridBand10.MinWidth = 12;
            this.gridBand10.Name = "gridBand10";
            this.gridBand10.VisibleIndex = 0;
            this.gridBand10.Width = 1562;
            // 
            // bandedGridColumn157
            // 
            this.bandedGridColumn157.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn157.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn157.Caption = "Num";
            this.bandedGridColumn157.FieldName = "num";
            this.bandedGridColumn157.MinWidth = 23;
            this.bandedGridColumn157.Name = "bandedGridColumn157";
            this.bandedGridColumn157.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn157.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn157.Visible = true;
            this.bandedGridColumn157.Width = 58;
            // 
            // bandedGridColumn162
            // 
            this.bandedGridColumn162.Caption = "Select";
            this.bandedGridColumn162.ColumnEdit = this.repositoryItemCheckEdit8;
            this.bandedGridColumn162.FieldName = "nextOfKin";
            this.bandedGridColumn162.MinWidth = 23;
            this.bandedGridColumn162.Name = "bandedGridColumn162";
            this.bandedGridColumn162.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn162.Visible = true;
            this.bandedGridColumn162.Width = 87;
            // 
            // repositoryItemCheckEdit8
            // 
            this.repositoryItemCheckEdit8.AutoHeight = false;
            this.repositoryItemCheckEdit8.Name = "repositoryItemCheckEdit8";
            this.repositoryItemCheckEdit8.Click += new System.EventHandler(this.repositoryItemCheckEdit8_Click);
            // 
            // bandedGridColumn158
            // 
            this.bandedGridColumn158.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn158.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn158.Caption = "Description";
            this.bandedGridColumn158.FieldName = "depFirstName";
            this.bandedGridColumn158.MinWidth = 23;
            this.bandedGridColumn158.Name = "bandedGridColumn158";
            this.bandedGridColumn158.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn158.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn158.Visible = true;
            this.bandedGridColumn158.Width = 233;
            // 
            // bandedGridColumn159
            // 
            this.bandedGridColumn159.Caption = "Disclosure";
            this.bandedGridColumn159.FieldName = "depLastName";
            this.bandedGridColumn159.MinWidth = 23;
            this.bandedGridColumn159.Name = "bandedGridColumn159";
            this.bandedGridColumn159.Visible = true;
            this.bandedGridColumn159.Width = 1184;
            // 
            // bandedGridColumn167
            // 
            this.bandedGridColumn167.Caption = "record";
            this.bandedGridColumn167.FieldName = "record";
            this.bandedGridColumn167.MinWidth = 23;
            this.bandedGridColumn167.Name = "bandedGridColumn167";
            this.bandedGridColumn167.Width = 87;
            // 
            // repositoryItemCheckEdit9
            // 
            this.repositoryItemCheckEdit9.AutoHeight = false;
            this.repositoryItemCheckEdit9.Name = "repositoryItemCheckEdit9";
            // 
            // repositoryItemCheckEdit10
            // 
            this.repositoryItemCheckEdit10.AutoHeight = false;
            this.repositoryItemCheckEdit10.Name = "repositoryItemCheckEdit10";
            // 
            // repositoryItemCheckEdit11
            // 
            this.repositoryItemCheckEdit11.AutoHeight = false;
            this.repositoryItemCheckEdit11.Name = "repositoryItemCheckEdit11";
            // 
            // panelFamilyTop
            // 
            this.panelFamilyTop.BackColor = System.Drawing.Color.Aquamarine;
            this.panelFamilyTop.Controls.Add(this.btnHold);
            this.panelFamilyTop.Controls.Add(this.textBox1);
            this.panelFamilyTop.Controls.Add(this.picRowDown);
            this.panelFamilyTop.Controls.Add(this.picRowUp);
            this.panelFamilyTop.Controls.Add(this.btnSaveAll);
            this.panelFamilyTop.Controls.Add(this.chkLegal);
            this.panelFamilyTop.Controls.Add(this.lblSelect);
            this.panelFamilyTop.Controls.Add(this.lblFamily);
            this.panelFamilyTop.Controls.Add(this.pictureBox12);
            this.panelFamilyTop.Controls.Add(this.pictureBox11);
            this.panelFamilyTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFamilyTop.Location = new System.Drawing.Point(0, 0);
            this.panelFamilyTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelFamilyTop.Name = "panelFamilyTop";
            this.panelFamilyTop.Size = new System.Drawing.Size(1677, 37);
            this.panelFamilyTop.TabIndex = 3;
            this.panelFamilyTop.Paint += new System.Windows.Forms.PaintEventHandler(this.panelFamilyTop_Paint);
            // 
            // btnHold
            // 
            this.btnHold.BackColor = System.Drawing.Color.Lime;
            this.btnHold.Location = new System.Drawing.Point(1516, 5);
            this.btnHold.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnHold.Name = "btnHold";
            this.btnHold.Size = new System.Drawing.Size(87, 28);
            this.btnHold.TabIndex = 33;
            this.btnHold.Text = "Edit";
            this.btnHold.UseVisualStyleBackColor = false;
            this.btnHold.Click += new System.EventHandler(this.btnHold_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(1217, 7);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(293, 23);
            this.textBox1.TabIndex = 32;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // picRowDown
            // 
            this.picRowDown.Image = ((System.Drawing.Image)(resources.GetObject("picRowDown.Image")));
            this.picRowDown.Location = new System.Drawing.Point(296, 5);
            this.picRowDown.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.picRowDown.Name = "picRowDown";
            this.picRowDown.Size = new System.Drawing.Size(36, 28);
            this.picRowDown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picRowDown.TabIndex = 31;
            this.picRowDown.TabStop = false;
            this.picRowDown.Tag = "Add Client";
            this.picRowDown.Click += new System.EventHandler(this.picRowDown_Click);
            // 
            // picRowUp
            // 
            this.picRowUp.Image = ((System.Drawing.Image)(resources.GetObject("picRowUp.Image")));
            this.picRowUp.Location = new System.Drawing.Point(253, 5);
            this.picRowUp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.picRowUp.Name = "picRowUp";
            this.picRowUp.Size = new System.Drawing.Size(36, 28);
            this.picRowUp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picRowUp.TabIndex = 30;
            this.picRowUp.TabStop = false;
            this.picRowUp.Tag = "Add Client";
            this.picRowUp.Click += new System.EventHandler(this.picRowUp_Click);
            // 
            // btnSaveAll
            // 
            this.btnSaveAll.BackColor = System.Drawing.Color.Lime;
            this.btnSaveAll.Location = new System.Drawing.Point(938, 5);
            this.btnSaveAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSaveAll.Name = "btnSaveAll";
            this.btnSaveAll.Size = new System.Drawing.Size(87, 28);
            this.btnSaveAll.TabIndex = 29;
            this.btnSaveAll.Text = "Save All Members";
            this.btnSaveAll.UseVisualStyleBackColor = false;
            this.btnSaveAll.Click += new System.EventHandler(this.btnSaveAll_Click);
            // 
            // chkLegal
            // 
            this.chkLegal.EditValue = "";
            this.chkLegal.Location = new System.Drawing.Point(376, 5);
            this.chkLegal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkLegal.Name = "chkLegal";
            this.chkLegal.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.chkLegal.Properties.DisplayMember = "depRelationship";
            this.chkLegal.Properties.SeparatorChar = '|';
            this.chkLegal.Size = new System.Drawing.Size(324, 22);
            this.chkLegal.TabIndex = 28;
            this.chkLegal.EditValueChanged += new System.EventHandler(this.chkLegal_EditValueChanged);
            // 
            // lblSelect
            // 
            this.lblSelect.AutoSize = true;
            this.lblSelect.Location = new System.Drawing.Point(707, 10);
            this.lblSelect.Name = "lblSelect";
            this.lblSelect.Size = new System.Drawing.Size(208, 17);
            this.lblSelect.TabIndex = 21;
            this.lblSelect.Text = "Select Relationships for Legal Use";
            // 
            // lblFamily
            // 
            this.lblFamily.AutoSize = true;
            this.lblFamily.Location = new System.Drawing.Point(5, 4);
            this.lblFamily.Name = "lblFamily";
            this.lblFamily.Size = new System.Drawing.Size(136, 17);
            this.lblFamily.TabIndex = 19;
            this.lblFamily.Text = "FAMILY RELATIONS :";
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(140, 4);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(36, 28);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 16;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Tag = "Add Site";
            this.pictureBox12.Click += new System.EventHandler(this.pictureBox12_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(195, 4);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(36, 28);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 17;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // FunFamilyNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1677, 413);
            this.Controls.Add(this.panelAll);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FunFamilyNew";
            this.Text = "FunFamily";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FunFamilyNew_FormClosing);
            this.Load += new System.EventHandler(this.FunFamilyNew_Load);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox7)).EndInit();
            this.panelAll.ResumeLayout(false);
            this.panelBottom.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabFamily.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDependent)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridMainDep)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.tabLegal.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLegal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMainLegal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView6)).EndInit();
            this.tabFuneralData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit2)).EndInit();
            this.tabPallbearers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView2)).EndInit();
            this.tabHonoraryPallBearers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView3)).EndInit();
            this.tabClergy.ResumeLayout(false);
            this.panelClergyStuff.ResumeLayout(false);
            this.panelClergyStuff.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView4)).EndInit();
            this.tabMusicians.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView5)).EndInit();
            this.tabDisclosures.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit11)).EndInit();
            this.panelFamilyTop.ResumeLayout(false);
            this.panelFamilyTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picRowDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRowUp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLegal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelAll;
        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.Panel panelFamilyTop;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox11;
        private DevExpress.XtraGrid.GridControl dgvDependent;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMainDep;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn45;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn53;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn47;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn46;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn48;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn49;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn9;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn50;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn21;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn51;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn20;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn19;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private System.Windows.Forms.Label lblFamily;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn1;
        private System.Windows.Forms.Label lblSelect;
        private DevExpress.XtraEditors.CheckedComboBoxEdit chkLegal;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn2;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn5;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addSignatureToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn7;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn6;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn10;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabFamily;
        private System.Windows.Forms.TabPage tabPallbearers;
        private DevExpress.XtraGrid.GridControl dgv2;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn11;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn12;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn13;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn14;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn15;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn16;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn17;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn18;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn22;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn23;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn24;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn30;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn31;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn32;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn33;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn34;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit2;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView2;
        private System.Windows.Forms.TabPage tabHonoraryPallBearers;
        private DevExpress.XtraGrid.GridControl dgv3;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn25;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn26;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn27;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn28;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn29;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn35;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn36;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn37;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn38;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn39;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn40;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn41;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn42;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn43;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn44;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn52;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit3;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit3;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView3;
        private System.Windows.Forms.TabPage tabClergy;
        private DevExpress.XtraGrid.GridControl dgv4;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn54;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn55;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn56;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn57;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn58;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn59;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn60;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn61;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn62;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn63;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn64;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn65;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn66;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn67;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn68;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn69;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView4;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox9;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox7;
        private System.Windows.Forms.Button btnSaveAll;
        private System.Windows.Forms.TabPage tabMusicians;
        private DevExpress.XtraGrid.GridControl dgv5;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn70;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn71;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn72;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn73;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn74;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn75;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn76;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn77;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn78;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn79;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn80;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn81;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn82;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn83;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn84;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn85;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView5;
        private System.Windows.Forms.TabPage tabFuneralData;
        private DevExpress.XtraGrid.GridControl dgv6;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn86;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn87;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn88;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn89;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn90;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn91;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn92;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn93;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn94;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn97;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn95;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn96;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn98;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit4;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit4;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox11;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox12;
        private System.Windows.Forms.TabPage tabLegal;
        private DevExpress.XtraGrid.GridControl dgvLegal;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMainLegal;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn99;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn100;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn101;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn102;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn103;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn104;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn105;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn106;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn107;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn108;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn109;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox13;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn110;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn111;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn112;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn113;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox14;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn114;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn115;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn116;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn117;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn118;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn119;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn120;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn121;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn122;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn123;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn124;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn125;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn126;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn127;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn128;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn129;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn130;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn131;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn132;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn133;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn135;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn134;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn136;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn137;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox15;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox16;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox17;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox18;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox19;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn138;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn139;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn140;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn141;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn142;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit7;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox20;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn143;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn144;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn145;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn146;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn147;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn150;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn149;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn148;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn152;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn153;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn155;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn154;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn151;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn156;
        private System.Windows.Forms.PictureBox picRowDown;
        private System.Windows.Forms.PictureBox picRowUp;
        private System.Windows.Forms.TabPage tabDisclosures;
        private DevExpress.XtraGrid.GridControl dgv7;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain7;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn157;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn162;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn158;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn159;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn167;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit9;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit10;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit11;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand5;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand7;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand8;
        private System.Windows.Forms.ToolStripMenuItem copyFromDeceasedAddressToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn160;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn161;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand9;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn163;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit12;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand6;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox21;
        private System.Windows.Forms.TextBox textBox1;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox22;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtMiddleName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtCounty2;
        private System.Windows.Forms.TextBox txtPhone2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtSuffix;
        private System.Windows.Forms.TextBox txtZip2;
        private System.Windows.Forms.TextBox txtAddress2;
        private System.Windows.Forms.TextBox txtState2;
        private System.Windows.Forms.TextBox txtCity2;
        private System.Windows.Forms.Panel panelClergyStuff;
        private System.Windows.Forms.Button btnHold;
        private System.Windows.Forms.Button btnClergyAccept;
        private System.Windows.Forms.Button btnClergyCancel;
    }
}