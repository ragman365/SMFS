﻿namespace SMFS
{
    partial class Contract1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        /// 
            ///this.gridMain3 = new MinRowHeightXtraGrid.MinRowHeightGridView(dgv3);

        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Contract1));
            this.panelAll = new System.Windows.Forms.Panel();
            this.panelFinale = new System.Windows.Forms.Panel();
            this.rtbSig2 = new EMRControlLib.RichTextBoxEx();
            this.rtbSig1 = new EMRControlLib.RichTextBoxEx();
            this.rtbFinale = new EMRControlLib.RichTextBoxEx();
            this.panelDetail = new System.Windows.Forms.Panel();
            this.panelDetailBottom = new System.Windows.Forms.Panel();
            this.rtbr = new EMRControlLib.RichTextBoxEx();
            this.dgv3 = new MinRowHeightXtraGrid.MinRowHeightGridControl();
            this.gridMain3 = new MinRowHeightXtraGrid.MinRowHeightGridView(dgv3);
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemMemoEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.dgv2 = new DevExpress.XtraGrid.GridControl();
            this.gridMain2 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridView();
            this.gridBand1 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn15 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.bandedGridColumn16 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn5 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn17 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.dgv = new DevExpress.XtraGrid.GridControl();
            this.gridMain = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand2 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn8 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn2 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.bandedGridColumn10 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn4 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn11 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn12 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.price1 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.currentprice5 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn1 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn3 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn14 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelDetailTop = new System.Windows.Forms.Panel();
            this.chkShowSummary = new System.Windows.Forms.CheckBox();
            this.chkZeros = new System.Windows.Forms.CheckBox();
            this.chkCashAdvance = new System.Windows.Forms.CheckBox();
            this.chkMerchandise = new System.Windows.Forms.CheckBox();
            this.chkService = new System.Windows.Forms.CheckBox();
            this.chkAll = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelLegal = new System.Windows.Forms.Panel();
            this.rtbDisclosures = new EMRControlLib.RichTextBoxEx();
            this.rtback = new EMRControlLib.RichTextBoxEx();
            this.rtbDisclaimer = new EMRControlLib.RichTextBoxEx();
            this.panelTop = new System.Windows.Forms.Panel();
            this.rtbStatementOfFuneral = new EMRControlLib.RichTextBoxEx();
            this.rtbAddress = new EMRControlLib.RichTextBoxEx();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.signaturesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enterSignatureOrPurchaserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enterSignatureOfCoPurchaserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnSeparate = new System.Windows.Forms.Button();
            this.panelAll.SuspendLayout();
            this.panelFinale.SuspendLayout();
            this.panelDetail.SuspendLayout();
            this.panelDetailBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            this.panelDetailTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelLegal.SuspendLayout();
            this.panelTop.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelAll
            // 
            this.panelAll.Controls.Add(this.panelFinale);
            this.panelAll.Controls.Add(this.panelDetail);
            this.panelAll.Controls.Add(this.panelLegal);
            this.panelAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAll.Location = new System.Drawing.Point(0, 225);
            this.panelAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelAll.Name = "panelAll";
            this.panelAll.Size = new System.Drawing.Size(1455, 697);
            this.panelAll.TabIndex = 8;
            // 
            // panelFinale
            // 
            this.panelFinale.Controls.Add(this.rtbSig2);
            this.panelFinale.Controls.Add(this.rtbSig1);
            this.panelFinale.Controls.Add(this.rtbFinale);
            this.panelFinale.Location = new System.Drawing.Point(14, 535);
            this.panelFinale.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelFinale.Name = "panelFinale";
            this.panelFinale.Size = new System.Drawing.Size(1067, 320);
            this.panelFinale.TabIndex = 11;
            // 
            // rtbSig2
            // 
            this.rtbSig2.DetectUrls = false;
            this.rtbSig2.HiglightColor = EMRControlLib.RichTextBoxEx.RtfColor.Empty;
            this.rtbSig2.Location = new System.Drawing.Point(596, 4);
            this.rtbSig2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rtbSig2.Name = "rtbSig2";
            this.rtbSig2.Size = new System.Drawing.Size(436, 64);
            this.rtbSig2.TabIndex = 5;
            this.rtbSig2.Text = "";
            this.rtbSig2.TextColor = EMRControlLib.RichTextBoxEx.RtfColor.Black;
            // 
            // rtbSig1
            // 
            this.rtbSig1.DetectUrls = false;
            this.rtbSig1.HiglightColor = EMRControlLib.RichTextBoxEx.RtfColor.Empty;
            this.rtbSig1.Location = new System.Drawing.Point(2, 4);
            this.rtbSig1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rtbSig1.Name = "rtbSig1";
            this.rtbSig1.Size = new System.Drawing.Size(436, 64);
            this.rtbSig1.TabIndex = 4;
            this.rtbSig1.Text = "";
            this.rtbSig1.TextColor = EMRControlLib.RichTextBoxEx.RtfColor.Black;
            // 
            // rtbFinale
            // 
            this.rtbFinale.DetectUrls = false;
            this.rtbFinale.HiglightColor = EMRControlLib.RichTextBoxEx.RtfColor.Empty;
            this.rtbFinale.Location = new System.Drawing.Point(0, 71);
            this.rtbFinale.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rtbFinale.Name = "rtbFinale";
            this.rtbFinale.Size = new System.Drawing.Size(1067, 243);
            this.rtbFinale.TabIndex = 3;
            this.rtbFinale.Text = "";
            this.rtbFinale.TextColor = EMRControlLib.RichTextBoxEx.RtfColor.Black;
            // 
            // panelDetail
            // 
            this.panelDetail.Controls.Add(this.panelDetailBottom);
            this.panelDetail.Controls.Add(this.panelDetailTop);
            this.panelDetail.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDetail.Location = new System.Drawing.Point(0, 0);
            this.panelDetail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelDetail.Name = "panelDetail";
            this.panelDetail.Size = new System.Drawing.Size(1455, 277);
            this.panelDetail.TabIndex = 10;
            // 
            // panelDetailBottom
            // 
            this.panelDetailBottom.Controls.Add(this.rtbr);
            this.panelDetailBottom.Controls.Add(this.dgv3);
            this.panelDetailBottom.Controls.Add(this.dgv2);
            this.panelDetailBottom.Controls.Add(this.dgv);
            this.panelDetailBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDetailBottom.Location = new System.Drawing.Point(0, 48);
            this.panelDetailBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelDetailBottom.Name = "panelDetailBottom";
            this.panelDetailBottom.Size = new System.Drawing.Size(1455, 229);
            this.panelDetailBottom.TabIndex = 9;
            // 
            // rtbr
            // 
            this.rtbr.DetectUrls = false;
            this.rtbr.HiglightColor = EMRControlLib.RichTextBoxEx.RtfColor.Empty;
            this.rtbr.Location = new System.Drawing.Point(1374, 63);
            this.rtbr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rtbr.Name = "rtbr";
            this.rtbr.Size = new System.Drawing.Size(52, 117);
            this.rtbr.TabIndex = 10;
            this.rtbr.Text = "";
            this.rtbr.TextColor = EMRControlLib.RichTextBoxEx.RtfColor.Black;
            // 
            // dgv3
            // 
            this.dgv3.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Location = new System.Drawing.Point(990, 7);
            this.dgv3.MainView = this.gridMain3;
            this.dgv3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Name = "dgv3";
            this.dgv3.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemMemoEdit2});
            this.dgv3.Size = new System.Drawing.Size(348, 203);
            this.dgv3.TabIndex = 9;
            this.dgv3.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain3});
            // 
            // gridMain3
            // 
            this.gridMain3.Appearance.Row.Options.UseTextOptions = true;
            this.gridMain3.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain3.AppearancePrint.Row.Options.UseTextOptions = true;
            this.gridMain3.AppearancePrint.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain3.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4});
            this.gridMain3.DetailHeight = 431;
            this.gridMain3.GridControl = this.dgv3;
            this.gridMain3.Name = "gridMain3";
            this.gridMain3.OptionsBehavior.AutoPopulateColumns = false;
            this.gridMain3.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.MouseDown;
            this.gridMain3.OptionsPrint.PrintFooter = false;
            this.gridMain3.OptionsPrint.PrintGroupFooter = false;
            this.gridMain3.OptionsPrint.PrintHeader = false;
            this.gridMain3.OptionsPrint.PrintHorzLines = false;
            this.gridMain3.OptionsPrint.PrintVertLines = false;
            this.gridMain3.OptionsView.ColumnAutoWidth = false;
            this.gridMain3.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain3.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain3.OptionsView.ShowColumnHeaders = false;
            this.gridMain3.OptionsView.ShowFooter = true;
            this.gridMain3.OptionsView.ShowGroupPanel = false;
            this.gridMain3.BeforePrintRow += new DevExpress.XtraGrid.Views.Base.BeforePrintRowEventHandler(this.gridMain3_BeforePrintRow);
            this.gridMain3.RowCellStyle += new DevExpress.XtraGrid.Views.Grid.RowCellStyleEventHandler(this.gridMain3_RowCellStyle);
            this.gridMain3.CalcRowHeight += new DevExpress.XtraGrid.Views.Grid.RowHeightEventHandler(this.gridMain3_CalcRowHeight);
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn1.Caption = "Description";
            this.gridColumn1.ColumnEdit = this.repositoryItemMemoEdit2;
            this.gridColumn1.FieldName = "description";
            this.gridColumn1.MinWidth = 23;
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.FixedWidth = true;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 408;
            // 
            // repositoryItemMemoEdit2
            // 
            this.repositoryItemMemoEdit2.Name = "repositoryItemMemoEdit2";
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn2.Caption = "Details";
            this.gridColumn2.FieldName = "details";
            this.gridColumn2.MinWidth = 23;
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.FixedWidth = true;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 105;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.NoWrap;
            this.gridColumn3.Caption = "Description2";
            this.gridColumn3.ColumnEdit = this.repositoryItemMemoEdit2;
            this.gridColumn3.FieldName = "description2";
            this.gridColumn3.MinWidth = 23;
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.FixedWidth = true;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 2;
            this.gridColumn3.Width = 408;
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn4.Caption = "Details2";
            this.gridColumn4.FieldName = "details2";
            this.gridColumn4.MinWidth = 23;
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.FixedWidth = true;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 3;
            this.gridColumn4.Width = 105;
            // 
            // dgv2
            // 
            this.dgv2.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Location = new System.Drawing.Point(519, 0);
            this.dgv2.LookAndFeel.SkinName = "iMaginary";
            this.dgv2.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv2.MainView = this.gridMain2;
            this.dgv2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Name = "dgv2";
            this.dgv2.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1,
            this.repositoryItemMemoEdit1});
            this.dgv2.Size = new System.Drawing.Size(434, 229);
            this.dgv2.TabIndex = 8;
            this.dgv2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain2});
            // 
            // gridMain2
            // 
            this.gridMain2.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain2.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain2.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.BandPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain2.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(232)))));
            this.gridMain2.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain2.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain2.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain2.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(232)))));
            this.gridMain2.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(248)))), ((int)(((byte)(236)))));
            this.gridMain2.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.EvenRow.Options.UseTextOptions = true;
            this.gridMain2.Appearance.EvenRow.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.gridMain2.Appearance.EvenRow.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain2.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain2.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain2.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(232)))));
            this.gridMain2.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.FilterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(153)))), ((int)(((byte)(73)))));
            this.gridMain2.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain2.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(154)))), ((int)(((byte)(91)))));
            this.gridMain2.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain2.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain2.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain2.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain2.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain2.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain2.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(232)))));
            this.gridMain2.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.GroupPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain2.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain2.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain2.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain2.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(232)))));
            this.gridMain2.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(183)))), ((int)(((byte)(125)))));
            this.gridMain2.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(232)))));
            this.gridMain2.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain2.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(236)))), ((int)(((byte)(208)))));
            this.gridMain2.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.OddRow.Options.UseTextOptions = true;
            this.gridMain2.Appearance.OddRow.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.gridMain2.Appearance.OddRow.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain2.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(254)))), ((int)(((byte)(249)))));
            this.gridMain2.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain2.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(146)))), ((int)(((byte)(78)))));
            this.gridMain2.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain2.Appearance.Preview.Options.UseFont = true;
            this.gridMain2.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain2.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(248)))), ((int)(((byte)(236)))));
            this.gridMain2.Appearance.Row.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(248)))), ((int)(((byte)(236)))));
            this.gridMain2.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.Row.Options.UseBackColor = true;
            this.gridMain2.Appearance.Row.Options.UseBorderColor = true;
            this.gridMain2.Appearance.Row.Options.UseForeColor = true;
            this.gridMain2.Appearance.Row.Options.UseTextOptions = true;
            this.gridMain2.Appearance.Row.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain2.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(232)))));
            this.gridMain2.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.BackColor = System.Drawing.Color.Gold;
            this.gridMain2.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.SelectedRow.Options.UseTextOptions = true;
            this.gridMain2.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain2.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain2.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand1});
            this.gridMain2.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain2.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn15,
            this.bandedGridColumn16,
            this.bandedGridColumn5,
            this.bandedGridColumn17});
            this.gridMain2.DetailHeight = 431;
            this.gridMain2.GridControl = this.dgv2;
            this.gridMain2.GroupRowHeight = 6;
            this.gridMain2.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "price", this.bandedGridColumn16, "{0:N2})"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "currentprice", this.bandedGridColumn17, "{0:N2})")});
            this.gridMain2.Name = "gridMain2";
            this.gridMain2.OptionsBehavior.AutoPopulateColumns = false;
            this.gridMain2.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.MouseDown;
            this.gridMain2.OptionsCustomization.AllowRowSizing = true;
            this.gridMain2.OptionsPrint.PrintBandHeader = false;
            this.gridMain2.OptionsPrint.PrintHeader = false;
            this.gridMain2.OptionsPrint.PrintHorzLines = false;
            this.gridMain2.OptionsPrint.PrintVertLines = false;
            this.gridMain2.OptionsView.ColumnAutoWidth = false;
            this.gridMain2.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain2.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain2.OptionsView.ShowBands = false;
            this.gridMain2.OptionsView.ShowColumnHeaders = false;
            this.gridMain2.OptionsView.ShowFooter = true;
            this.gridMain2.OptionsView.ShowGroupPanel = false;
            this.gridMain2.RowCellStyle += new DevExpress.XtraGrid.Views.Grid.RowCellStyleEventHandler(this.gridMain2_RowCellStyle);
            this.gridMain2.CalcRowHeight += new DevExpress.XtraGrid.Views.Grid.RowHeightEventHandler(this.gridMain2_CalcRowHeight);
            this.gridMain2.RowCellDefaultAlignment += new DevExpress.XtraGrid.Views.Base.RowCellAlignmentEventHandler(this.gridMain2_RowCellDefaultAlignment);
            // 
            // gridBand1
            // 
            this.gridBand1.Caption = "gridBand1";
            this.gridBand1.Columns.Add(this.bandedGridColumn15);
            this.gridBand1.Columns.Add(this.bandedGridColumn16);
            this.gridBand1.Columns.Add(this.bandedGridColumn5);
            this.gridBand1.Columns.Add(this.bandedGridColumn17);
            this.gridBand1.MinWidth = 12;
            this.gridBand1.Name = "gridBand1";
            this.gridBand1.VisibleIndex = 0;
            this.gridBand1.Width = 1026;
            // 
            // bandedGridColumn15
            // 
            this.bandedGridColumn15.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn15.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.bandedGridColumn15.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.bandedGridColumn15.Caption = "Description";
            this.bandedGridColumn15.ColumnEdit = this.repositoryItemMemoEdit1;
            this.bandedGridColumn15.FieldName = "description";
            this.bandedGridColumn15.MinWidth = 23;
            this.bandedGridColumn15.Name = "bandedGridColumn15";
            this.bandedGridColumn15.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn15.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn15.Visible = true;
            this.bandedGridColumn15.Width = 408;
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Appearance.Options.UseTextOptions = true;
            this.repositoryItemMemoEdit1.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // bandedGridColumn16
            // 
            this.bandedGridColumn16.AppearanceCell.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.bandedGridColumn16.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn16.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn16.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn16.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.bandedGridColumn16.Caption = "Details";
            this.bandedGridColumn16.FieldName = "details";
            this.bandedGridColumn16.MinWidth = 23;
            this.bandedGridColumn16.Name = "bandedGridColumn16";
            this.bandedGridColumn16.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn16.Visible = true;
            this.bandedGridColumn16.Width = 105;
            // 
            // bandedGridColumn5
            // 
            this.bandedGridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn5.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.bandedGridColumn5.Caption = "Description 2";
            this.bandedGridColumn5.ColumnEdit = this.repositoryItemMemoEdit1;
            this.bandedGridColumn5.FieldName = "description2";
            this.bandedGridColumn5.MinWidth = 23;
            this.bandedGridColumn5.Name = "bandedGridColumn5";
            this.bandedGridColumn5.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn5.Visible = true;
            this.bandedGridColumn5.Width = 408;
            // 
            // bandedGridColumn17
            // 
            this.bandedGridColumn17.AppearanceCell.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.bandedGridColumn17.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn17.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn17.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn17.AppearanceCell.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.bandedGridColumn17.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.bandedGridColumn17.Caption = "Details 2";
            this.bandedGridColumn17.FieldName = "details2";
            this.bandedGridColumn17.MinWidth = 23;
            this.bandedGridColumn17.Name = "bandedGridColumn17";
            this.bandedGridColumn17.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn17.Visible = true;
            this.bandedGridColumn17.Width = 105;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // dgv
            // 
            this.dgv.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv.Location = new System.Drawing.Point(0, 0);
            this.dgv.LookAndFeel.SkinName = "iMaginary";
            this.dgv.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv.MainView = this.gridMain;
            this.dgv.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv.Name = "dgv";
            this.dgv.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit2});
            this.dgv.Size = new System.Drawing.Size(434, 229);
            this.dgv.TabIndex = 7;
            this.dgv.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain});
            // 
            // gridMain
            // 
            this.gridMain.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.BandPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(232)))));
            this.gridMain.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(232)))));
            this.gridMain.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(248)))), ((int)(((byte)(236)))));
            this.gridMain.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(232)))));
            this.gridMain.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.FilterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(153)))), ((int)(((byte)(73)))));
            this.gridMain.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(154)))), ((int)(((byte)(91)))));
            this.gridMain.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(232)))));
            this.gridMain.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.GroupPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(204)))), ((int)(((byte)(124)))));
            this.gridMain.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(232)))));
            this.gridMain.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(225)))), ((int)(((byte)(183)))), ((int)(((byte)(125)))));
            this.gridMain.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(232)))));
            this.gridMain.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(236)))), ((int)(((byte)(208)))));
            this.gridMain.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(254)))), ((int)(((byte)(249)))));
            this.gridMain.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(146)))), ((int)(((byte)(78)))));
            this.gridMain.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain.Appearance.Preview.Options.UseFont = true;
            this.gridMain.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(248)))), ((int)(((byte)(236)))));
            this.gridMain.Appearance.Row.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(248)))), ((int)(((byte)(236)))));
            this.gridMain.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.Row.Options.UseBackColor = true;
            this.gridMain.Appearance.Row.Options.UseBorderColor = true;
            this.gridMain.Appearance.Row.Options.UseForeColor = true;
            this.gridMain.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(244)))), ((int)(((byte)(232)))));
            this.gridMain.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.BackColor = System.Drawing.Color.Gold;
            this.gridMain.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.SelectedRow.Options.UseTextOptions = true;
            this.gridMain.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(177)))), ((int)(((byte)(94)))));
            this.gridMain.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand2});
            this.gridMain.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn8,
            this.bandedGridColumn14,
            this.bandedGridColumn11,
            this.bandedGridColumn10,
            this.bandedGridColumn12,
            this.price1,
            this.bandedGridColumn3,
            this.bandedGridColumn4,
            this.bandedGridColumn2,
            this.currentprice5,
            this.bandedGridColumn1});
            this.gridMain.DetailHeight = 431;
            this.gridMain.GridControl = this.dgv;
            this.gridMain.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "price", this.price1, "{0:N2})"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "currentprice", this.currentprice5, "{0:N2})")});
            this.gridMain.Name = "gridMain";
            this.gridMain.OptionsBehavior.AutoPopulateColumns = false;
            this.gridMain.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.MouseDown;
            this.gridMain.OptionsPrint.PrintBandHeader = false;
            this.gridMain.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain.OptionsView.ShowBands = false;
            this.gridMain.OptionsView.ShowFooter = true;
            this.gridMain.OptionsView.ShowGroupPanel = false;
            this.gridMain.PaintStyleName = "Style3D";
            // 
            // gridBand2
            // 
            this.gridBand2.Caption = "gridBand1";
            this.gridBand2.Columns.Add(this.bandedGridColumn8);
            this.gridBand2.Columns.Add(this.bandedGridColumn2);
            this.gridBand2.Columns.Add(this.bandedGridColumn10);
            this.gridBand2.Columns.Add(this.bandedGridColumn4);
            this.gridBand2.Columns.Add(this.bandedGridColumn11);
            this.gridBand2.Columns.Add(this.bandedGridColumn12);
            this.gridBand2.Columns.Add(this.price1);
            this.gridBand2.Columns.Add(this.currentprice5);
            this.gridBand2.Columns.Add(this.bandedGridColumn1);
            this.gridBand2.Columns.Add(this.bandedGridColumn3);
            this.gridBand2.MinWidth = 12;
            this.gridBand2.Name = "gridBand2";
            this.gridBand2.VisibleIndex = 0;
            this.gridBand2.Width = 853;
            // 
            // bandedGridColumn8
            // 
            this.bandedGridColumn8.Caption = "Num";
            this.bandedGridColumn8.FieldName = "num";
            this.bandedGridColumn8.MinWidth = 23;
            this.bandedGridColumn8.Name = "bandedGridColumn8";
            this.bandedGridColumn8.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn8.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn8.Visible = true;
            this.bandedGridColumn8.Width = 43;
            // 
            // bandedGridColumn2
            // 
            this.bandedGridColumn2.Caption = "Select";
            this.bandedGridColumn2.ColumnEdit = this.repositoryItemCheckEdit2;
            this.bandedGridColumn2.FieldName = "select";
            this.bandedGridColumn2.MinWidth = 23;
            this.bandedGridColumn2.Name = "bandedGridColumn2";
            this.bandedGridColumn2.Width = 52;
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            // 
            // bandedGridColumn10
            // 
            this.bandedGridColumn10.Caption = "Status";
            this.bandedGridColumn10.FieldName = "status";
            this.bandedGridColumn10.MinWidth = 23;
            this.bandedGridColumn10.Name = "bandedGridColumn10";
            this.bandedGridColumn10.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn10.Width = 77;
            // 
            // bandedGridColumn4
            // 
            this.bandedGridColumn4.Caption = "Type";
            this.bandedGridColumn4.FieldName = "type";
            this.bandedGridColumn4.MinWidth = 23;
            this.bandedGridColumn4.Name = "bandedGridColumn4";
            this.bandedGridColumn4.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn4.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn4.Visible = true;
            this.bandedGridColumn4.Width = 87;
            // 
            // bandedGridColumn11
            // 
            this.bandedGridColumn11.Caption = "ServiceRecord";
            this.bandedGridColumn11.FieldName = "!ServiceRecord";
            this.bandedGridColumn11.MinWidth = 23;
            this.bandedGridColumn11.Name = "bandedGridColumn11";
            this.bandedGridColumn11.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn11.Width = 87;
            // 
            // bandedGridColumn12
            // 
            this.bandedGridColumn12.Caption = "Description";
            this.bandedGridColumn12.FieldName = "service";
            this.bandedGridColumn12.MinWidth = 23;
            this.bandedGridColumn12.Name = "bandedGridColumn12";
            this.bandedGridColumn12.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn12.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn12.Visible = true;
            this.bandedGridColumn12.Width = 408;
            // 
            // price1
            // 
            this.price1.Caption = "Customer Price";
            this.price1.DisplayFormat.FormatString = "N2";
            this.price1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.price1.FieldName = "price";
            this.price1.MinWidth = 23;
            this.price1.Name = "price1";
            this.price1.OptionsColumn.FixedWidth = true;
            this.price1.Visible = true;
            this.price1.Width = 105;
            // 
            // currentprice5
            // 
            this.currentprice5.Caption = "Current Price";
            this.currentprice5.DisplayFormat.FormatString = "N2";
            this.currentprice5.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.currentprice5.FieldName = "currentprice";
            this.currentprice5.MinWidth = 23;
            this.currentprice5.Name = "currentprice5";
            this.currentprice5.OptionsColumn.FixedWidth = true;
            this.currentprice5.Visible = true;
            this.currentprice5.Width = 105;
            // 
            // bandedGridColumn1
            // 
            this.bandedGridColumn1.Caption = "Savings";
            this.bandedGridColumn1.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn1.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn1.FieldName = "difference";
            this.bandedGridColumn1.MinWidth = 23;
            this.bandedGridColumn1.Name = "bandedGridColumn1";
            this.bandedGridColumn1.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn1.Visible = true;
            this.bandedGridColumn1.Width = 105;
            // 
            // bandedGridColumn3
            // 
            this.bandedGridColumn3.Caption = "Data";
            this.bandedGridColumn3.FieldName = "data";
            this.bandedGridColumn3.MinWidth = 23;
            this.bandedGridColumn3.Name = "bandedGridColumn3";
            this.bandedGridColumn3.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn3.Width = 292;
            // 
            // bandedGridColumn14
            // 
            this.bandedGridColumn14.Caption = "record";
            this.bandedGridColumn14.FieldName = "record";
            this.bandedGridColumn14.MinWidth = 23;
            this.bandedGridColumn14.Name = "bandedGridColumn14";
            this.bandedGridColumn14.Width = 87;
            // 
            // panelDetailTop
            // 
            this.panelDetailTop.Controls.Add(this.chkShowSummary);
            this.panelDetailTop.Controls.Add(this.chkZeros);
            this.panelDetailTop.Controls.Add(this.chkCashAdvance);
            this.panelDetailTop.Controls.Add(this.chkMerchandise);
            this.panelDetailTop.Controls.Add(this.chkService);
            this.panelDetailTop.Controls.Add(this.chkAll);
            this.panelDetailTop.Controls.Add(this.label1);
            this.panelDetailTop.Controls.Add(this.pictureBox1);
            this.panelDetailTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDetailTop.Location = new System.Drawing.Point(0, 0);
            this.panelDetailTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelDetailTop.Name = "panelDetailTop";
            this.panelDetailTop.Size = new System.Drawing.Size(1455, 48);
            this.panelDetailTop.TabIndex = 8;
            // 
            // chkShowSummary
            // 
            this.chkShowSummary.AutoSize = true;
            this.chkShowSummary.Checked = true;
            this.chkShowSummary.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShowSummary.Location = new System.Drawing.Point(726, 14);
            this.chkShowSummary.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkShowSummary.Name = "chkShowSummary";
            this.chkShowSummary.Size = new System.Drawing.Size(128, 21);
            this.chkShowSummary.TabIndex = 36;
            this.chkShowSummary.Text = "Show Summary";
            this.chkShowSummary.UseVisualStyleBackColor = true;
            this.chkShowSummary.CheckedChanged += new System.EventHandler(this.chkShowSummary_CheckedChanged);
            // 
            // chkZeros
            // 
            this.chkZeros.AutoSize = true;
            this.chkZeros.Checked = true;
            this.chkZeros.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkZeros.Location = new System.Drawing.Point(467, 15);
            this.chkZeros.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkZeros.Name = "chkZeros";
            this.chkZeros.Size = new System.Drawing.Size(127, 21);
            this.chkZeros.TabIndex = 35;
            this.chkZeros.Text = "Filter All Zero $\'s";
            this.chkZeros.UseVisualStyleBackColor = true;
            this.chkZeros.CheckedChanged += new System.EventHandler(this.chkZeros_CheckedChanged);
            // 
            // chkCashAdvance
            // 
            this.chkCashAdvance.AutoSize = true;
            this.chkCashAdvance.Location = new System.Drawing.Point(336, 15);
            this.chkCashAdvance.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkCashAdvance.Name = "chkCashAdvance";
            this.chkCashAdvance.Size = new System.Drawing.Size(117, 21);
            this.chkCashAdvance.TabIndex = 34;
            this.chkCashAdvance.Text = "Cash Advance";
            this.chkCashAdvance.UseVisualStyleBackColor = true;
            this.chkCashAdvance.CheckedChanged += new System.EventHandler(this.Filter_CheckedChanged);
            // 
            // chkMerchandise
            // 
            this.chkMerchandise.AutoSize = true;
            this.chkMerchandise.Location = new System.Drawing.Point(226, 15);
            this.chkMerchandise.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkMerchandise.Name = "chkMerchandise";
            this.chkMerchandise.Size = new System.Drawing.Size(105, 21);
            this.chkMerchandise.TabIndex = 33;
            this.chkMerchandise.Text = "Merchandise";
            this.chkMerchandise.UseVisualStyleBackColor = true;
            this.chkMerchandise.CheckedChanged += new System.EventHandler(this.Filter_CheckedChanged);
            // 
            // chkService
            // 
            this.chkService.AutoSize = true;
            this.chkService.Location = new System.Drawing.Point(148, 15);
            this.chkService.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkService.Name = "chkService";
            this.chkService.Size = new System.Drawing.Size(74, 21);
            this.chkService.TabIndex = 32;
            this.chkService.Text = "Service";
            this.chkService.UseVisualStyleBackColor = true;
            this.chkService.CheckedChanged += new System.EventHandler(this.Filter_CheckedChanged);
            // 
            // chkAll
            // 
            this.chkAll.AutoSize = true;
            this.chkAll.Checked = true;
            this.chkAll.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkAll.Location = new System.Drawing.Point(100, 15);
            this.chkAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkAll.Name = "chkAll";
            this.chkAll.Size = new System.Drawing.Size(42, 21);
            this.chkAll.TabIndex = 31;
            this.chkAll.Text = "All";
            this.chkAll.UseVisualStyleBackColor = true;
            this.chkAll.CheckedChanged += new System.EventHandler(this.Filter_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 17);
            this.label1.TabIndex = 30;
            this.label1.Text = "Filter";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 7);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 27);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // panelLegal
            // 
            this.panelLegal.Controls.Add(this.rtbDisclosures);
            this.panelLegal.Controls.Add(this.rtback);
            this.panelLegal.Controls.Add(this.rtbDisclaimer);
            this.panelLegal.Location = new System.Drawing.Point(14, 306);
            this.panelLegal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelLegal.Name = "panelLegal";
            this.panelLegal.Size = new System.Drawing.Size(1067, 222);
            this.panelLegal.TabIndex = 9;
            // 
            // rtbDisclosures
            // 
            this.rtbDisclosures.DetectUrls = false;
            this.rtbDisclosures.Dock = System.Windows.Forms.DockStyle.Left;
            this.rtbDisclosures.HiglightColor = EMRControlLib.RichTextBoxEx.RtfColor.Empty;
            this.rtbDisclosures.Location = new System.Drawing.Point(710, 0);
            this.rtbDisclosures.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rtbDisclosures.Name = "rtbDisclosures";
            this.rtbDisclosures.Size = new System.Drawing.Size(350, 222);
            this.rtbDisclosures.TabIndex = 2;
            this.rtbDisclosures.Text = "";
            this.rtbDisclosures.TextColor = EMRControlLib.RichTextBoxEx.RtfColor.Black;
            // 
            // rtback
            // 
            this.rtback.DetectUrls = false;
            this.rtback.Dock = System.Windows.Forms.DockStyle.Left;
            this.rtback.HiglightColor = EMRControlLib.RichTextBoxEx.RtfColor.Empty;
            this.rtback.Location = new System.Drawing.Point(360, 0);
            this.rtback.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rtback.Name = "rtback";
            this.rtback.Size = new System.Drawing.Size(350, 222);
            this.rtback.TabIndex = 1;
            this.rtback.Text = "";
            this.rtback.TextColor = EMRControlLib.RichTextBoxEx.RtfColor.Black;
            // 
            // rtbDisclaimer
            // 
            this.rtbDisclaimer.DetectUrls = false;
            this.rtbDisclaimer.Dock = System.Windows.Forms.DockStyle.Left;
            this.rtbDisclaimer.HiglightColor = EMRControlLib.RichTextBoxEx.RtfColor.Empty;
            this.rtbDisclaimer.Location = new System.Drawing.Point(0, 0);
            this.rtbDisclaimer.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rtbDisclaimer.Name = "rtbDisclaimer";
            this.rtbDisclaimer.Size = new System.Drawing.Size(360, 222);
            this.rtbDisclaimer.TabIndex = 0;
            this.rtbDisclaimer.Text = "";
            this.rtbDisclaimer.TextColor = EMRControlLib.RichTextBoxEx.RtfColor.Black;
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.rtbStatementOfFuneral);
            this.panelTop.Controls.Add(this.rtbAddress);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 28);
            this.panelTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1455, 197);
            this.panelTop.TabIndex = 9;
            // 
            // rtbStatementOfFuneral
            // 
            this.rtbStatementOfFuneral.DetectUrls = false;
            this.rtbStatementOfFuneral.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbStatementOfFuneral.HiglightColor = EMRControlLib.RichTextBoxEx.RtfColor.Empty;
            this.rtbStatementOfFuneral.Location = new System.Drawing.Point(0, 66);
            this.rtbStatementOfFuneral.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rtbStatementOfFuneral.Name = "rtbStatementOfFuneral";
            this.rtbStatementOfFuneral.Size = new System.Drawing.Size(1455, 131);
            this.rtbStatementOfFuneral.TabIndex = 1;
            this.rtbStatementOfFuneral.Text = "";
            this.rtbStatementOfFuneral.TextColor = EMRControlLib.RichTextBoxEx.RtfColor.Black;
            // 
            // rtbAddress
            // 
            this.rtbAddress.DetectUrls = false;
            this.rtbAddress.Dock = System.Windows.Forms.DockStyle.Top;
            this.rtbAddress.HiglightColor = EMRControlLib.RichTextBoxEx.RtfColor.Empty;
            this.rtbAddress.Location = new System.Drawing.Point(0, 0);
            this.rtbAddress.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rtbAddress.Name = "rtbAddress";
            this.rtbAddress.Size = new System.Drawing.Size(1455, 66);
            this.rtbAddress.TabIndex = 2;
            this.rtbAddress.Text = "";
            this.rtbAddress.TextColor = EMRControlLib.RichTextBoxEx.RtfColor.Black;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Bisque;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.signaturesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1455, 28);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printPreviewToolStripMenuItem,
            this.printToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(122, 26);
            this.toolStripMenuItem1.Text = "Print";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printPreviewToolStripMenuItem.Text = "Print Preview";
            this.printPreviewToolStripMenuItem.Click += new System.EventHandler(this.printPreviewToolStripMenuItem_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // signaturesToolStripMenuItem
            // 
            this.signaturesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.enterSignatureOrPurchaserToolStripMenuItem,
            this.enterSignatureOfCoPurchaserToolStripMenuItem});
            this.signaturesToolStripMenuItem.Name = "signaturesToolStripMenuItem";
            this.signaturesToolStripMenuItem.Size = new System.Drawing.Size(92, 24);
            this.signaturesToolStripMenuItem.Text = "Signatures";
            // 
            // enterSignatureOrPurchaserToolStripMenuItem
            // 
            this.enterSignatureOrPurchaserToolStripMenuItem.Name = "enterSignatureOrPurchaserToolStripMenuItem";
            this.enterSignatureOrPurchaserToolStripMenuItem.Size = new System.Drawing.Size(302, 26);
            this.enterSignatureOrPurchaserToolStripMenuItem.Text = "Enter Signature of Purchaser";
            this.enterSignatureOrPurchaserToolStripMenuItem.Click += new System.EventHandler(this.enterSignatureOrPurchaserToolStripMenuItem_Click);
            // 
            // enterSignatureOfCoPurchaserToolStripMenuItem
            // 
            this.enterSignatureOfCoPurchaserToolStripMenuItem.Name = "enterSignatureOfCoPurchaserToolStripMenuItem";
            this.enterSignatureOfCoPurchaserToolStripMenuItem.Size = new System.Drawing.Size(302, 26);
            this.enterSignatureOfCoPurchaserToolStripMenuItem.Text = "Enter Signature of Co-Purchaser";
            this.enterSignatureOfCoPurchaserToolStripMenuItem.Click += new System.EventHandler(this.enterSignatureOfCoPurchaserToolStripMenuItem_Click);
            // 
            // btnSeparate
            // 
            this.btnSeparate.BackColor = System.Drawing.Color.Gray;
            this.btnSeparate.ForeColor = System.Drawing.Color.Yellow;
            this.btnSeparate.Location = new System.Drawing.Point(854, 1);
            this.btnSeparate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSeparate.Name = "btnSeparate";
            this.btnSeparate.Size = new System.Drawing.Size(87, 26);
            this.btnSeparate.TabIndex = 10;
            this.btnSeparate.Text = "Separate";
            this.btnSeparate.UseVisualStyleBackColor = false;
            this.btnSeparate.Click += new System.EventHandler(this.btnSeparate_Click);
            // 
            // Contract1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1455, 922);
            this.Controls.Add(this.btnSeparate);
            this.Controls.Add(this.panelAll);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Contract1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Contract1";
            this.Load += new System.EventHandler(this.Contract1_Load);
            this.panelAll.ResumeLayout(false);
            this.panelFinale.ResumeLayout(false);
            this.panelDetail.ResumeLayout(false);
            this.panelDetailBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            this.panelDetailTop.ResumeLayout(false);
            this.panelDetailTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelLegal.ResumeLayout(false);
            this.panelTop.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private EMRControlLib.RichTextBoxEx rtbStatementOfFuneral;
        private System.Windows.Forms.Panel panelAll;
        private System.Windows.Forms.Panel panelLegal;
        private EMRControlLib.RichTextBoxEx rtback;
        private EMRControlLib.RichTextBoxEx rtbDisclaimer;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private EMRControlLib.RichTextBoxEx rtbDisclosures;
        private System.Windows.Forms.Panel panelDetail;
        private DevExpress.XtraGrid.GridControl dgv;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn2;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn11;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn12;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn price1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn currentprice5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn14;
        private System.Windows.Forms.Panel panelDetailBottom;
        private System.Windows.Forms.Panel panelDetailTop;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkCashAdvance;
        private System.Windows.Forms.CheckBox chkMerchandise;
        private System.Windows.Forms.CheckBox chkService;
        private System.Windows.Forms.CheckBox chkAll;
        private EMRControlLib.RichTextBoxEx rtbAddress;
        private System.Windows.Forms.CheckBox chkZeros;
        private System.Windows.Forms.Panel panelFinale;
        private System.Windows.Forms.ToolStripMenuItem signaturesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enterSignatureOrPurchaserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enterSignatureOfCoPurchaserToolStripMenuItem;
        private EMRControlLib.RichTextBoxEx rtbFinale;
        private EMRControlLib.RichTextBoxEx rtbSig2;
        private EMRControlLib.RichTextBoxEx rtbSig1;
        private DevExpress.XtraGrid.GridControl dgv2;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private System.Windows.Forms.CheckBox chkShowSummary;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridView gridMain2;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn15;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn16;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn17;
        private System.Windows.Forms.Button btnSeparate;
        private MinRowHeightXtraGrid.MinRowHeightGridControl dgv3;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit2;
        private MinRowHeightXtraGrid.MinRowHeightGridView gridMain3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private EMRControlLib.RichTextBoxEx rtbr;
    }
}