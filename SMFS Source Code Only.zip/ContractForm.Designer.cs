﻿namespace SMFS
{
    partial class ContractForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ContractForm));
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener1 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener2 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener3 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener4 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener5 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener6 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener7 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            DevExpress.XtraReports.UserDesigner.XRDesignPanelListener xrDesignPanelListener8 = new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener();
            this.xrDesignBarManager1 = new DevExpress.XtraReports.UserDesigner.XRDesignBarManager(this.components);
            this.pageSetupBar1 = new DevExpress.XtraRichEdit.UI.PageSetupBar();
            this.rtb = new DevExpress.XtraRichEdit.RichEditControl();
            this.changeSectionPageMarginsItem1 = new DevExpress.XtraRichEdit.UI.ChangeSectionPageMarginsItem();
            this.setNormalSectionPageMarginsItem1 = new DevExpress.XtraRichEdit.UI.SetNormalSectionPageMarginsItem();
            this.setNarrowSectionPageMarginsItem1 = new DevExpress.XtraRichEdit.UI.SetNarrowSectionPageMarginsItem();
            this.setModerateSectionPageMarginsItem1 = new DevExpress.XtraRichEdit.UI.SetModerateSectionPageMarginsItem();
            this.setWideSectionPageMarginsItem1 = new DevExpress.XtraRichEdit.UI.SetWideSectionPageMarginsItem();
            this.showPageMarginsSetupFormItem1 = new DevExpress.XtraRichEdit.UI.ShowPageMarginsSetupFormItem();
            this.changeSectionPaperKindItem1 = new DevExpress.XtraRichEdit.UI.ChangeSectionPaperKindItem();
            this.pageBackgroundBar1 = new DevExpress.XtraRichEdit.UI.PageBackgroundBar();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.xrDesignDockManager1 = new DevExpress.XtraReports.UserDesigner.XRDesignDockManager(this.components);
            this.propertyGridDockPanel1 = new DevExpress.XtraReports.UserDesigner.PropertyGridDockPanel();
            this.propertyGridDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            this.reportGalleryDockPanel1 = new DevExpress.XtraReports.UserDesigner.ReportGalleryDockPanel();
            this.reportGalleryDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            this.fieldListDockPanel1 = new DevExpress.XtraReports.UserDesigner.FieldListDockPanel();
            this.fieldListDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            this.reportExplorerDockPanel1 = new DevExpress.XtraReports.UserDesigner.ReportExplorerDockPanel();
            this.reportExplorerDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            this.groupAndSortDockPanel1 = new DevExpress.XtraReports.UserDesigner.GroupAndSortDockPanel();
            this.groupAndSortDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            this.errorListDockPanel1 = new DevExpress.XtraReports.UserDesigner.ErrorListDockPanel();
            this.errorListDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            this.recentlyUsedItemsComboBox1 = new DevExpress.XtraReports.UserDesigner.RecentlyUsedItemsComboBox();
            this.beiFontName = new DevExpress.XtraBars.BarEditItem();
            this.designRepositoryItemComboBox1 = new DevExpress.XtraReports.UserDesigner.DesignRepositoryItemComboBox();
            this.beiFontSize = new DevExpress.XtraBars.BarEditItem();
            this.bsiHint = new DevExpress.XtraBars.BarStaticItem();
            this.bbiFontBold = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiFontItalic = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiFontUnderline = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiForeColor = new DevExpress.XtraReports.UserDesigner.CommandColorBarItem();
            this.bbiBackColor = new DevExpress.XtraReports.UserDesigner.CommandColorBarItem();
            this.bbiJustifyLeft = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiJustifyCenter = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiJustifyRight = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiJustifyJustify = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiAlignToGrid = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiAlignLeft = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiAlignVerticalCenters = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiAlignRight = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiAlignTop = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiAlignHorizontalCenters = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiAlignBottom = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiSizeToControlWidth = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiSizeToGrid = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiSizeToControlHeight = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiSizeToControl = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiHorizSpaceMakeEqual = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiHorizSpaceIncrease = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiHorizSpaceDecrease = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiHorizSpaceConcatenate = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiVertSpaceMakeEqual = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiVertSpaceIncrease = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiVertSpaceDecrease = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiVertSpaceConcatenate = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiCenterHorizontally = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiCenterVertically = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiBringToFront = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiSendToBack = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem1 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiOpenFile = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiSaveFile = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiCut = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiCopy = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiPaste = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiUndo = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiRedo = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.msiFile = new DevExpress.XtraBars.BarSubItem();
            this.commandBarItem2 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem3 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem7 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem11 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem4 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.msiEdit = new DevExpress.XtraBars.BarSubItem();
            this.commandBarItem5 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem6 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.msiTabButtons = new DevExpress.XtraBars.BarSubItem();
            this.barReportTabButtonsListItem1 = new DevExpress.XtraReports.UserDesigner.BarReportTabButtonsListItem();
            this.barSubItem1 = new DevExpress.XtraBars.BarSubItem();
            this.xrBarToolbarsListItem1 = new DevExpress.XtraReports.UserDesigner.XRBarToolbarsListItem();
            this.barSubItem2 = new DevExpress.XtraBars.BarSubItem();
            this.barDockPanelsListItem1 = new DevExpress.XtraReports.UserDesigner.BarDockPanelsListItem();
            this.msiFormat = new DevExpress.XtraBars.BarSubItem();
            this.msiFont = new DevExpress.XtraBars.BarSubItem();
            this.msiJustify = new DevExpress.XtraBars.BarSubItem();
            this.msiAlign = new DevExpress.XtraBars.BarSubItem();
            this.msiSameSize = new DevExpress.XtraBars.BarSubItem();
            this.msiHorizontalSpacing = new DevExpress.XtraBars.BarSubItem();
            this.msiVerticalSpacing = new DevExpress.XtraBars.BarSubItem();
            this.bsiCenter = new DevExpress.XtraBars.BarSubItem();
            this.msiOrder = new DevExpress.XtraBars.BarSubItem();
            this.msiWindow = new DevExpress.XtraBars.BarSubItem();
            this.msiWindowInterface = new DevExpress.XtraReports.UserDesigner.CommandBarCheckItem();
            this.commandBarItem8 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem9 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem10 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.msiWindows = new DevExpress.XtraBars.BarMdiChildrenListItem();
            this.bbiZoomOut = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.bbiZoom = new DevExpress.XtraReports.UserDesigner.XRZoomBarEditItem();
            this.designRepositoryItemComboBox2 = new DevExpress.XtraReports.UserDesigner.DesignRepositoryItemComboBox();
            this.bbiZoomIn = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.changeSectionPageOrientationItem1 = new DevExpress.XtraRichEdit.UI.ChangeSectionPageOrientationItem();
            this.setPortraitPageOrientationItem1 = new DevExpress.XtraRichEdit.UI.SetPortraitPageOrientationItem();
            this.setLandscapePageOrientationItem1 = new DevExpress.XtraRichEdit.UI.SetLandscapePageOrientationItem();
            this.changeSectionColumnsItem1 = new DevExpress.XtraRichEdit.UI.ChangeSectionColumnsItem();
            this.setSectionOneColumnItem1 = new DevExpress.XtraRichEdit.UI.SetSectionOneColumnItem();
            this.setSectionTwoColumnsItem1 = new DevExpress.XtraRichEdit.UI.SetSectionTwoColumnsItem();
            this.setSectionThreeColumnsItem1 = new DevExpress.XtraRichEdit.UI.SetSectionThreeColumnsItem();
            this.showColumnsSetupFormItem1 = new DevExpress.XtraRichEdit.UI.ShowColumnsSetupFormItem();
            this.insertBreakItem1 = new DevExpress.XtraRichEdit.UI.InsertBreakItem();
            this.insertPageBreakItem1 = new DevExpress.XtraRichEdit.UI.InsertPageBreakItem();
            this.insertColumnBreakItem1 = new DevExpress.XtraRichEdit.UI.InsertColumnBreakItem();
            this.insertSectionBreakNextPageItem1 = new DevExpress.XtraRichEdit.UI.InsertSectionBreakNextPageItem();
            this.insertSectionBreakContinuousItem1 = new DevExpress.XtraRichEdit.UI.InsertSectionBreakContinuousItem();
            this.insertSectionBreakEvenPageItem1 = new DevExpress.XtraRichEdit.UI.InsertSectionBreakEvenPageItem();
            this.insertSectionBreakOddPageItem1 = new DevExpress.XtraRichEdit.UI.InsertSectionBreakOddPageItem();
            this.changeSectionLineNumberingItem1 = new DevExpress.XtraRichEdit.UI.ChangeSectionLineNumberingItem();
            this.setSectionLineNumberingNoneItem1 = new DevExpress.XtraRichEdit.UI.SetSectionLineNumberingNoneItem();
            this.setSectionLineNumberingContinuousItem1 = new DevExpress.XtraRichEdit.UI.SetSectionLineNumberingContinuousItem();
            this.setSectionLineNumberingRestartNewPageItem1 = new DevExpress.XtraRichEdit.UI.SetSectionLineNumberingRestartNewPageItem();
            this.setSectionLineNumberingRestartNewSectionItem1 = new DevExpress.XtraRichEdit.UI.SetSectionLineNumberingRestartNewSectionItem();
            this.toggleParagraphSuppressLineNumbersItem1 = new DevExpress.XtraRichEdit.UI.ToggleParagraphSuppressLineNumbersItem();
            this.showLineNumberingFormItem1 = new DevExpress.XtraRichEdit.UI.ShowLineNumberingFormItem();
            this.changeHyphenationOptionsItem1 = new DevExpress.XtraRichEdit.UI.ChangeHyphenationOptionsItem();
            this.setHyphenateDocumentNoneItem1 = new DevExpress.XtraRichEdit.UI.SetHyphenateDocumentNoneItem();
            this.setHyphenateDocumentAutomaticItem1 = new DevExpress.XtraRichEdit.UI.SetHyphenateDocumentAutomaticItem();
            this.showHyphenationOptionsFormItem1 = new DevExpress.XtraRichEdit.UI.ShowHyphenationOptionsFormItem();
            this.changePageColorItem1 = new DevExpress.XtraRichEdit.UI.ChangePageColorItem();
            this.repositoryItemMemoEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.repositoryItemMemoEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.repositoryItemMemoEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.reportDesigner1 = new DevExpress.XtraReports.UserDesigner.XRDesignMdiController(this.components);
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelAll = new System.Windows.Forms.Panel();
            this.rtbAddress = new EMRControlLib.RichTextBoxEx();
            this.richEditBarController1 = new DevExpress.XtraRichEdit.UI.RichEditBarController(this.components);
            this.rtbStatementOfFuneral = new DevExpress.XtraRichEdit.RichEditControl();
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignBarManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignDockManager1)).BeginInit();
            this.propertyGridDockPanel1.SuspendLayout();
            this.reportGalleryDockPanel1.SuspendLayout();
            this.fieldListDockPanel1.SuspendLayout();
            this.reportExplorerDockPanel1.SuspendLayout();
            this.groupAndSortDockPanel1.SuspendLayout();
            this.errorListDockPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.recentlyUsedItemsComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.designRepositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.designRepositoryItemComboBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.reportDesigner1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panelAll.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.richEditBarController1)).BeginInit();
            this.SuspendLayout();
            // 
            // xrDesignBarManager1
            // 
            this.xrDesignBarManager1.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.pageSetupBar1,
            this.pageBackgroundBar1});
            this.xrDesignBarManager1.DockControls.Add(this.barDockControlTop);
            this.xrDesignBarManager1.DockControls.Add(this.barDockControlBottom);
            this.xrDesignBarManager1.DockControls.Add(this.barDockControlLeft);
            this.xrDesignBarManager1.DockControls.Add(this.barDockControlRight);
            this.xrDesignBarManager1.DockManager = this.xrDesignDockManager1;
            this.xrDesignBarManager1.FontNameBox = this.recentlyUsedItemsComboBox1;
            this.xrDesignBarManager1.FontNameEdit = this.beiFontName;
            this.xrDesignBarManager1.FontSizeBox = this.designRepositoryItemComboBox1;
            this.xrDesignBarManager1.FontSizeEdit = this.beiFontSize;
            this.xrDesignBarManager1.Form = this;
            this.xrDesignBarManager1.FormattingToolbar = null;
            this.xrDesignBarManager1.HintStaticItem = this.bsiHint;
            this.xrDesignBarManager1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("xrDesignBarManager1.ImageStream")));
            this.xrDesignBarManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.beiFontName,
            this.beiFontSize,
            this.bbiFontBold,
            this.bbiFontItalic,
            this.bbiFontUnderline,
            this.bbiForeColor,
            this.bbiBackColor,
            this.bbiJustifyLeft,
            this.bbiJustifyCenter,
            this.bbiJustifyRight,
            this.bbiJustifyJustify,
            this.bbiAlignToGrid,
            this.bbiAlignLeft,
            this.bbiAlignVerticalCenters,
            this.bbiAlignRight,
            this.bbiAlignTop,
            this.bbiAlignHorizontalCenters,
            this.bbiAlignBottom,
            this.bbiSizeToControlWidth,
            this.bbiSizeToGrid,
            this.bbiSizeToControlHeight,
            this.bbiSizeToControl,
            this.bbiHorizSpaceMakeEqual,
            this.bbiHorizSpaceIncrease,
            this.bbiHorizSpaceDecrease,
            this.bbiHorizSpaceConcatenate,
            this.bbiVertSpaceMakeEqual,
            this.bbiVertSpaceIncrease,
            this.bbiVertSpaceDecrease,
            this.bbiVertSpaceConcatenate,
            this.bbiCenterHorizontally,
            this.bbiCenterVertically,
            this.bbiBringToFront,
            this.bbiSendToBack,
            this.commandBarItem1,
            this.bbiOpenFile,
            this.bbiSaveFile,
            this.bbiCut,
            this.bbiCopy,
            this.bbiPaste,
            this.bbiUndo,
            this.bbiRedo,
            this.bsiHint,
            this.msiFile,
            this.msiEdit,
            this.msiTabButtons,
            this.barReportTabButtonsListItem1,
            this.barSubItem1,
            this.xrBarToolbarsListItem1,
            this.barSubItem2,
            this.barDockPanelsListItem1,
            this.msiFormat,
            this.msiFont,
            this.msiJustify,
            this.msiAlign,
            this.msiSameSize,
            this.msiHorizontalSpacing,
            this.msiVerticalSpacing,
            this.bsiCenter,
            this.msiOrder,
            this.commandBarItem2,
            this.commandBarItem3,
            this.commandBarItem4,
            this.commandBarItem5,
            this.commandBarItem6,
            this.commandBarItem7,
            this.msiWindow,
            this.msiWindowInterface,
            this.commandBarItem8,
            this.commandBarItem9,
            this.commandBarItem10,
            this.msiWindows,
            this.commandBarItem11,
            this.bbiZoomOut,
            this.bbiZoom,
            this.bbiZoomIn,
            this.changeSectionPageMarginsItem1,
            this.setNormalSectionPageMarginsItem1,
            this.setNarrowSectionPageMarginsItem1,
            this.setModerateSectionPageMarginsItem1,
            this.setWideSectionPageMarginsItem1,
            this.showPageMarginsSetupFormItem1,
            this.changeSectionPageOrientationItem1,
            this.setPortraitPageOrientationItem1,
            this.setLandscapePageOrientationItem1,
            this.changeSectionPaperKindItem1,
            this.changeSectionColumnsItem1,
            this.setSectionOneColumnItem1,
            this.setSectionTwoColumnsItem1,
            this.setSectionThreeColumnsItem1,
            this.showColumnsSetupFormItem1,
            this.insertBreakItem1,
            this.insertPageBreakItem1,
            this.insertColumnBreakItem1,
            this.insertSectionBreakNextPageItem1,
            this.insertSectionBreakContinuousItem1,
            this.insertSectionBreakEvenPageItem1,
            this.insertSectionBreakOddPageItem1,
            this.changeSectionLineNumberingItem1,
            this.setSectionLineNumberingNoneItem1,
            this.setSectionLineNumberingContinuousItem1,
            this.setSectionLineNumberingRestartNewPageItem1,
            this.setSectionLineNumberingRestartNewSectionItem1,
            this.toggleParagraphSuppressLineNumbersItem1,
            this.showLineNumberingFormItem1,
            this.changeHyphenationOptionsItem1,
            this.setHyphenateDocumentNoneItem1,
            this.setHyphenateDocumentAutomaticItem1,
            this.showHyphenationOptionsFormItem1,
            this.changePageColorItem1});
            this.xrDesignBarManager1.LayoutToolbar = null;
            this.xrDesignBarManager1.MaxItemId = 343;
            this.xrDesignBarManager1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.recentlyUsedItemsComboBox1,
            this.designRepositoryItemComboBox1,
            this.designRepositoryItemComboBox2});
            this.xrDesignBarManager1.Toolbar = null;
            this.xrDesignBarManager1.TransparentEditorsMode = DevExpress.Utils.DefaultBoolean.True;
            this.xrDesignBarManager1.Updates.AddRange(new string[] {
            "Toolbox"});
            this.xrDesignBarManager1.ZoomItem = this.bbiZoom;
            // 
            // pageSetupBar1
            // 
            this.pageSetupBar1.Control = this.rtb;
            this.pageSetupBar1.DockCol = 0;
            this.pageSetupBar1.DockRow = 0;
            this.pageSetupBar1.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.pageSetupBar1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.KeyTip, this.changeSectionPageMarginsItem1, "", false, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.Standard, "M", ""),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.KeyTip, this.changeSectionPaperKindItem1, "", false, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.Standard, "SZ", "")});
            // 
            // rtb
            // 
            this.rtb.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtb.Location = new System.Drawing.Point(0, 0);
            this.rtb.MenuManager = this.xrDesignBarManager1;
            this.rtb.Name = "rtb";
            this.rtb.Options.Printing.PrintPreviewFormKind = DevExpress.XtraRichEdit.PrintPreviewFormKind.Bars;
            this.rtb.Size = new System.Drawing.Size(1190, 598);
            this.rtb.TabIndex = 0;
            // 
            // changeSectionPageMarginsItem1
            // 
            this.changeSectionPageMarginsItem1.Id = 81;
            this.changeSectionPageMarginsItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setNormalSectionPageMarginsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setNarrowSectionPageMarginsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setModerateSectionPageMarginsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setWideSectionPageMarginsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.showPageMarginsSetupFormItem1)});
            this.changeSectionPageMarginsItem1.Name = "changeSectionPageMarginsItem1";
            // 
            // setNormalSectionPageMarginsItem1
            // 
            this.setNormalSectionPageMarginsItem1.Id = 76;
            this.setNormalSectionPageMarginsItem1.Name = "setNormalSectionPageMarginsItem1";
            // 
            // setNarrowSectionPageMarginsItem1
            // 
            this.setNarrowSectionPageMarginsItem1.Id = 77;
            this.setNarrowSectionPageMarginsItem1.Name = "setNarrowSectionPageMarginsItem1";
            // 
            // setModerateSectionPageMarginsItem1
            // 
            this.setModerateSectionPageMarginsItem1.Id = 78;
            this.setModerateSectionPageMarginsItem1.Name = "setModerateSectionPageMarginsItem1";
            // 
            // setWideSectionPageMarginsItem1
            // 
            this.setWideSectionPageMarginsItem1.Id = 79;
            this.setWideSectionPageMarginsItem1.Name = "setWideSectionPageMarginsItem1";
            // 
            // showPageMarginsSetupFormItem1
            // 
            this.showPageMarginsSetupFormItem1.Id = 80;
            this.showPageMarginsSetupFormItem1.Name = "showPageMarginsSetupFormItem1";
            // 
            // changeSectionPaperKindItem1
            // 
            this.changeSectionPaperKindItem1.Id = 85;
            this.changeSectionPaperKindItem1.Name = "changeSectionPaperKindItem1";
            // 
            // pageBackgroundBar1
            // 
            this.pageBackgroundBar1.BarName = "";
            this.pageBackgroundBar1.Control = this.rtb;
            this.pageBackgroundBar1.DockCol = 0;
            this.pageBackgroundBar1.DockRow = 1;
            this.pageBackgroundBar1.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.pageBackgroundBar1.Text = "";
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Manager = this.xrDesignBarManager1;
            this.barDockControlTop.Size = new System.Drawing.Size(1190, 46);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 668);
            this.barDockControlBottom.Manager = this.xrDesignBarManager1;
            this.barDockControlBottom.Size = new System.Drawing.Size(1190, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 46);
            this.barDockControlLeft.Manager = this.xrDesignBarManager1;
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 622);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1190, 46);
            this.barDockControlRight.Manager = this.xrDesignBarManager1;
            this.barDockControlRight.Size = new System.Drawing.Size(0, 622);
            // 
            // xrDesignDockManager1
            // 
            this.xrDesignDockManager1.Form = this;
            this.xrDesignDockManager1.HiddenPanels.AddRange(new DevExpress.XtraBars.Docking.DockPanel[] {
            this.propertyGridDockPanel1,
            this.reportExplorerDockPanel1,
            this.reportGalleryDockPanel1,
            this.fieldListDockPanel1,
            this.groupAndSortDockPanel1,
            this.errorListDockPanel1});
            this.xrDesignDockManager1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("xrDesignDockManager1.ImageStream")));
            this.xrDesignDockManager1.MenuManager = this.xrDesignBarManager1;
            this.xrDesignDockManager1.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "DevExpress.XtraBars.StandaloneBarDockControl",
            "System.Windows.Forms.StatusBar",
            "System.Windows.Forms.MenuStrip",
            "System.Windows.Forms.StatusStrip",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl",
            "DevExpress.XtraBars.Navigation.OfficeNavigationBar",
            "DevExpress.XtraBars.Navigation.TileNavPane",
            "DevExpress.XtraBars.TabFormControl",
            "DevExpress.XtraBars.FluentDesignSystem.FluentDesignFormControl",
            "DevExpress.XtraBars.ToolbarForm.ToolbarFormControl"});
            // 
            // propertyGridDockPanel1
            // 
            this.propertyGridDockPanel1.Controls.Add(this.propertyGridDockPanel1_Container);
            this.propertyGridDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.propertyGridDockPanel1.ID = new System.Guid("b38d12c3-cd06-4dec-b93d-63a0088e495a");
            this.propertyGridDockPanel1.Location = new System.Drawing.Point(1, 24);
            this.propertyGridDockPanel1.Name = "propertyGridDockPanel1";
            this.propertyGridDockPanel1.OriginalSize = new System.Drawing.Size(200, 200);
            this.propertyGridDockPanel1.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.propertyGridDockPanel1.SavedIndex = 0;
            this.propertyGridDockPanel1.SavedParent = this.reportGalleryDockPanel1;
            this.propertyGridDockPanel1.SavedTabbed = true;
            this.propertyGridDockPanel1.Size = new System.Drawing.Size(374, 95);
            this.propertyGridDockPanel1.Text = "Properties";
            this.propertyGridDockPanel1.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Hidden;
            // 
            // propertyGridDockPanel1_Container
            // 
            this.propertyGridDockPanel1_Container.Location = new System.Drawing.Point(0, 0);
            this.propertyGridDockPanel1_Container.Name = "propertyGridDockPanel1_Container";
            this.propertyGridDockPanel1_Container.Size = new System.Drawing.Size(374, 95);
            this.propertyGridDockPanel1_Container.TabIndex = 0;
            // 
            // reportGalleryDockPanel1
            // 
            this.reportGalleryDockPanel1.Controls.Add(this.reportGalleryDockPanel1_Container);
            this.reportGalleryDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.reportGalleryDockPanel1.ID = new System.Guid("7cd5b1e8-63bb-46f7-af65-af61eb851a38");
            this.reportGalleryDockPanel1.Location = new System.Drawing.Point(0, 146);
            this.reportGalleryDockPanel1.Name = "reportGalleryDockPanel1";
            this.reportGalleryDockPanel1.OriginalSize = new System.Drawing.Size(200, 200);
            this.reportGalleryDockPanel1.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.reportGalleryDockPanel1.SavedIndex = 1;
            this.reportGalleryDockPanel1.SavedParent = this.fieldListDockPanel1;
            this.reportGalleryDockPanel1.Size = new System.Drawing.Size(375, 146);
            this.reportGalleryDockPanel1.Text = "Report Gallery";
            this.reportGalleryDockPanel1.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Hidden;
            // 
            // reportGalleryDockPanel1_Container
            // 
            this.reportGalleryDockPanel1_Container.Location = new System.Drawing.Point(1, 24);
            this.reportGalleryDockPanel1_Container.Name = "reportGalleryDockPanel1_Container";
            this.reportGalleryDockPanel1_Container.Size = new System.Drawing.Size(374, 122);
            this.reportGalleryDockPanel1_Container.TabIndex = 0;
            // 
            // fieldListDockPanel1
            // 
            this.fieldListDockPanel1.Controls.Add(this.fieldListDockPanel1_Container);
            this.fieldListDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Right;
            this.fieldListDockPanel1.ID = new System.Guid("faf69838-a93f-4114-83e8-d0d09cc5ce95");
            this.fieldListDockPanel1.Location = new System.Drawing.Point(815, 71);
            this.fieldListDockPanel1.Name = "fieldListDockPanel1";
            this.fieldListDockPanel1.OriginalSize = new System.Drawing.Size(375, 200);
            this.fieldListDockPanel1.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Right;
            this.fieldListDockPanel1.SavedIndex = 0;
            this.fieldListDockPanel1.Size = new System.Drawing.Size(375, 292);
            this.fieldListDockPanel1.Text = "Field List";
            this.fieldListDockPanel1.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Hidden;
            // 
            // fieldListDockPanel1_Container
            // 
            this.fieldListDockPanel1_Container.Location = new System.Drawing.Point(1, 23);
            this.fieldListDockPanel1_Container.Name = "fieldListDockPanel1_Container";
            this.fieldListDockPanel1_Container.Size = new System.Drawing.Size(374, 269);
            this.fieldListDockPanel1_Container.TabIndex = 0;
            // 
            // reportExplorerDockPanel1
            // 
            this.reportExplorerDockPanel1.Controls.Add(this.reportExplorerDockPanel1_Container);
            this.reportExplorerDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.reportExplorerDockPanel1.ID = new System.Guid("fb3ec6cc-3b9b-4b9c-91cf-cff78c1edbf1");
            this.reportExplorerDockPanel1.Location = new System.Drawing.Point(1, 23);
            this.reportExplorerDockPanel1.Name = "reportExplorerDockPanel1";
            this.reportExplorerDockPanel1.OriginalSize = new System.Drawing.Size(200, 200);
            this.reportExplorerDockPanel1.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.reportExplorerDockPanel1.SavedIndex = 0;
            this.reportExplorerDockPanel1.SavedParent = this.fieldListDockPanel1;
            this.reportExplorerDockPanel1.SavedTabbed = true;
            this.reportExplorerDockPanel1.Size = new System.Drawing.Size(374, 96);
            this.reportExplorerDockPanel1.Text = "Report Explorer";
            this.reportExplorerDockPanel1.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Hidden;
            // 
            // reportExplorerDockPanel1_Container
            // 
            this.reportExplorerDockPanel1_Container.Location = new System.Drawing.Point(0, 0);
            this.reportExplorerDockPanel1_Container.Name = "reportExplorerDockPanel1_Container";
            this.reportExplorerDockPanel1_Container.Size = new System.Drawing.Size(374, 96);
            this.reportExplorerDockPanel1_Container.TabIndex = 0;
            // 
            // groupAndSortDockPanel1
            // 
            this.groupAndSortDockPanel1.Controls.Add(this.groupAndSortDockPanel1_Container);
            this.groupAndSortDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.groupAndSortDockPanel1.ID = new System.Guid("4bab159e-c495-4d67-87dc-f4e895da443e");
            this.groupAndSortDockPanel1.Location = new System.Drawing.Point(0, 24);
            this.groupAndSortDockPanel1.Name = "groupAndSortDockPanel1";
            this.groupAndSortDockPanel1.OriginalSize = new System.Drawing.Size(200, 200);
            this.groupAndSortDockPanel1.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.groupAndSortDockPanel1.SavedIndex = 0;
            this.groupAndSortDockPanel1.SavedParent = this.errorListDockPanel1;
            this.groupAndSortDockPanel1.SavedTabbed = true;
            this.groupAndSortDockPanel1.Size = new System.Drawing.Size(1190, 149);
            this.groupAndSortDockPanel1.Text = "Group and Sort";
            this.groupAndSortDockPanel1.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Hidden;
            // 
            // groupAndSortDockPanel1_Container
            // 
            this.groupAndSortDockPanel1_Container.Location = new System.Drawing.Point(0, 0);
            this.groupAndSortDockPanel1_Container.Name = "groupAndSortDockPanel1_Container";
            this.groupAndSortDockPanel1_Container.Size = new System.Drawing.Size(1190, 149);
            this.groupAndSortDockPanel1_Container.TabIndex = 0;
            // 
            // errorListDockPanel1
            // 
            this.errorListDockPanel1.Controls.Add(this.errorListDockPanel1_Container);
            this.errorListDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Bottom;
            this.errorListDockPanel1.ID = new System.Guid("5a9a01fd-6e95-4e81-a8c4-ac63153d7488");
            this.errorListDockPanel1.Location = new System.Drawing.Point(0, 185);
            this.errorListDockPanel1.Name = "errorListDockPanel1";
            this.errorListDockPanel1.OriginalSize = new System.Drawing.Size(200, 200);
            this.errorListDockPanel1.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Bottom;
            this.errorListDockPanel1.SavedIndex = 0;
            this.errorListDockPanel1.Size = new System.Drawing.Size(1190, 200);
            this.errorListDockPanel1.Text = "Scripts Errors";
            this.errorListDockPanel1.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Hidden;
            // 
            // errorListDockPanel1_Container
            // 
            this.errorListDockPanel1_Container.Location = new System.Drawing.Point(0, 24);
            this.errorListDockPanel1_Container.Name = "errorListDockPanel1_Container";
            this.errorListDockPanel1_Container.Size = new System.Drawing.Size(1190, 176);
            this.errorListDockPanel1_Container.TabIndex = 0;
            // 
            // recentlyUsedItemsComboBox1
            // 
            this.recentlyUsedItemsComboBox1.AppearanceDropDown.Font = new System.Drawing.Font("Tahoma", 11.25F);
            this.recentlyUsedItemsComboBox1.AppearanceDropDown.Options.UseFont = true;
            this.recentlyUsedItemsComboBox1.AutoHeight = false;
            this.recentlyUsedItemsComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.recentlyUsedItemsComboBox1.Name = "recentlyUsedItemsComboBox1";
            // 
            // beiFontName
            // 
            this.beiFontName.Caption = "Font Name";
            this.beiFontName.Edit = this.recentlyUsedItemsComboBox1;
            this.beiFontName.EditWidth = 120;
            this.beiFontName.Hint = "Font Name";
            this.beiFontName.Id = 0;
            this.beiFontName.Name = "beiFontName";
            // 
            // designRepositoryItemComboBox1
            // 
            this.designRepositoryItemComboBox1.AutoHeight = false;
            this.designRepositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.designRepositoryItemComboBox1.Name = "designRepositoryItemComboBox1";
            // 
            // beiFontSize
            // 
            this.beiFontSize.Caption = "Font Size";
            this.beiFontSize.Edit = this.designRepositoryItemComboBox1;
            this.beiFontSize.EditWidth = 55;
            this.beiFontSize.Hint = "Font Size";
            this.beiFontSize.Id = 1;
            this.beiFontSize.Name = "beiFontSize";
            // 
            // bsiHint
            // 
            this.bsiHint.AutoSize = DevExpress.XtraBars.BarStaticItemSize.Spring;
            this.bsiHint.Border = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.bsiHint.Id = 42;
            this.bsiHint.Name = "bsiHint";
            // 
            // bbiFontBold
            // 
            this.bbiFontBold.Caption = "&Bold";
            this.bbiFontBold.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FontBold;
            this.bbiFontBold.Enabled = false;
            this.bbiFontBold.Hint = "Make the font bold";
            this.bbiFontBold.Id = 2;
            this.bbiFontBold.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B));
            this.bbiFontBold.Name = "bbiFontBold";
            // 
            // bbiFontItalic
            // 
            this.bbiFontItalic.Caption = "&Italic";
            this.bbiFontItalic.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FontItalic;
            this.bbiFontItalic.Enabled = false;
            this.bbiFontItalic.Hint = "Make the font italic";
            this.bbiFontItalic.Id = 3;
            this.bbiFontItalic.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I));
            this.bbiFontItalic.Name = "bbiFontItalic";
            // 
            // bbiFontUnderline
            // 
            this.bbiFontUnderline.Caption = "&Underline";
            this.bbiFontUnderline.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FontUnderline;
            this.bbiFontUnderline.Enabled = false;
            this.bbiFontUnderline.Hint = "Underline the font";
            this.bbiFontUnderline.Id = 4;
            this.bbiFontUnderline.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.U));
            this.bbiFontUnderline.Name = "bbiFontUnderline";
            // 
            // bbiForeColor
            // 
            this.bbiForeColor.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.bbiForeColor.Caption = "For&eground Color";
            this.bbiForeColor.CloseSubMenuOnClickMode = DevExpress.Utils.DefaultBoolean.False;
            this.bbiForeColor.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ForeColor;
            this.bbiForeColor.Enabled = false;
            this.bbiForeColor.Hint = "Set the foreground color of the control";
            this.bbiForeColor.Id = 5;
            this.bbiForeColor.Name = "bbiForeColor";
            // 
            // bbiBackColor
            // 
            this.bbiBackColor.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.bbiBackColor.Caption = "Bac&kground Color";
            this.bbiBackColor.CloseSubMenuOnClickMode = DevExpress.Utils.DefaultBoolean.False;
            this.bbiBackColor.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BackColor;
            this.bbiBackColor.Enabled = false;
            this.bbiBackColor.Hint = "Set the background color of the control";
            this.bbiBackColor.Id = 6;
            this.bbiBackColor.Name = "bbiBackColor";
            // 
            // bbiJustifyLeft
            // 
            this.bbiJustifyLeft.Caption = "&Left";
            this.bbiJustifyLeft.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyLeft;
            this.bbiJustifyLeft.Enabled = false;
            this.bbiJustifyLeft.Hint = "Align the control\'s text to the left";
            this.bbiJustifyLeft.Id = 7;
            this.bbiJustifyLeft.Name = "bbiJustifyLeft";
            // 
            // bbiJustifyCenter
            // 
            this.bbiJustifyCenter.Caption = "&Center";
            this.bbiJustifyCenter.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyCenter;
            this.bbiJustifyCenter.Enabled = false;
            this.bbiJustifyCenter.Hint = "Align the control\'s text to the center";
            this.bbiJustifyCenter.Id = 8;
            this.bbiJustifyCenter.Name = "bbiJustifyCenter";
            // 
            // bbiJustifyRight
            // 
            this.bbiJustifyRight.Caption = "&Rights";
            this.bbiJustifyRight.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyRight;
            this.bbiJustifyRight.Enabled = false;
            this.bbiJustifyRight.Hint = "Align the control\'s text to the right";
            this.bbiJustifyRight.Id = 9;
            this.bbiJustifyRight.Name = "bbiJustifyRight";
            // 
            // bbiJustifyJustify
            // 
            this.bbiJustifyJustify.Caption = "&Justify";
            this.bbiJustifyJustify.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyJustify;
            this.bbiJustifyJustify.Enabled = false;
            this.bbiJustifyJustify.Hint = "Justify the control\'s text";
            this.bbiJustifyJustify.Id = 10;
            this.bbiJustifyJustify.Name = "bbiJustifyJustify";
            // 
            // bbiAlignToGrid
            // 
            this.bbiAlignToGrid.Caption = "to &Grid";
            this.bbiAlignToGrid.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignToGrid;
            this.bbiAlignToGrid.Enabled = false;
            this.bbiAlignToGrid.Hint = "Align the positions of the selected controls to the grid";
            this.bbiAlignToGrid.Id = 11;
            this.bbiAlignToGrid.Name = "bbiAlignToGrid";
            // 
            // bbiAlignLeft
            // 
            this.bbiAlignLeft.Caption = "&Lefts";
            this.bbiAlignLeft.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignLeft;
            this.bbiAlignLeft.Enabled = false;
            this.bbiAlignLeft.Hint = "Left align the selected controls";
            this.bbiAlignLeft.Id = 12;
            this.bbiAlignLeft.Name = "bbiAlignLeft";
            // 
            // bbiAlignVerticalCenters
            // 
            this.bbiAlignVerticalCenters.Caption = "&Centers";
            this.bbiAlignVerticalCenters.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignVerticalCenters;
            this.bbiAlignVerticalCenters.Enabled = false;
            this.bbiAlignVerticalCenters.Hint = "Align the centers of the selected controls vertically";
            this.bbiAlignVerticalCenters.Id = 13;
            this.bbiAlignVerticalCenters.Name = "bbiAlignVerticalCenters";
            // 
            // bbiAlignRight
            // 
            this.bbiAlignRight.Caption = "&Rights";
            this.bbiAlignRight.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignRight;
            this.bbiAlignRight.Enabled = false;
            this.bbiAlignRight.Hint = "Right align the selected controls";
            this.bbiAlignRight.Id = 14;
            this.bbiAlignRight.Name = "bbiAlignRight";
            // 
            // bbiAlignTop
            // 
            this.bbiAlignTop.Caption = "&Tops";
            this.bbiAlignTop.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignTop;
            this.bbiAlignTop.Enabled = false;
            this.bbiAlignTop.Hint = "Align the tops of the selected controls";
            this.bbiAlignTop.Id = 15;
            this.bbiAlignTop.Name = "bbiAlignTop";
            // 
            // bbiAlignHorizontalCenters
            // 
            this.bbiAlignHorizontalCenters.Caption = "&Middles";
            this.bbiAlignHorizontalCenters.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignHorizontalCenters;
            this.bbiAlignHorizontalCenters.Enabled = false;
            this.bbiAlignHorizontalCenters.Hint = "Align the centers of the selected controls horizontally";
            this.bbiAlignHorizontalCenters.Id = 16;
            this.bbiAlignHorizontalCenters.Name = "bbiAlignHorizontalCenters";
            // 
            // bbiAlignBottom
            // 
            this.bbiAlignBottom.Caption = "&Bottoms";
            this.bbiAlignBottom.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignBottom;
            this.bbiAlignBottom.Enabled = false;
            this.bbiAlignBottom.Hint = "Align the bottoms of the selected controls";
            this.bbiAlignBottom.Id = 17;
            this.bbiAlignBottom.Name = "bbiAlignBottom";
            // 
            // bbiSizeToControlWidth
            // 
            this.bbiSizeToControlWidth.Caption = "&Width";
            this.bbiSizeToControlWidth.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToControlWidth;
            this.bbiSizeToControlWidth.Enabled = false;
            this.bbiSizeToControlWidth.Hint = "Make the selected controls have the same width";
            this.bbiSizeToControlWidth.Id = 18;
            this.bbiSizeToControlWidth.Name = "bbiSizeToControlWidth";
            // 
            // bbiSizeToGrid
            // 
            this.bbiSizeToGrid.Caption = "Size to Gri&d";
            this.bbiSizeToGrid.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToGrid;
            this.bbiSizeToGrid.Enabled = false;
            this.bbiSizeToGrid.Hint = "Size the selected controls to the grid";
            this.bbiSizeToGrid.Id = 19;
            this.bbiSizeToGrid.Name = "bbiSizeToGrid";
            // 
            // bbiSizeToControlHeight
            // 
            this.bbiSizeToControlHeight.Caption = "&Height";
            this.bbiSizeToControlHeight.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToControlHeight;
            this.bbiSizeToControlHeight.Enabled = false;
            this.bbiSizeToControlHeight.Hint = "Make the selected controls have the same height";
            this.bbiSizeToControlHeight.Id = 20;
            this.bbiSizeToControlHeight.Name = "bbiSizeToControlHeight";
            // 
            // bbiSizeToControl
            // 
            this.bbiSizeToControl.Caption = "&Both";
            this.bbiSizeToControl.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToControl;
            this.bbiSizeToControl.Enabled = false;
            this.bbiSizeToControl.Hint = "Make the selected controls the same size";
            this.bbiSizeToControl.Id = 21;
            this.bbiSizeToControl.Name = "bbiSizeToControl";
            // 
            // bbiHorizSpaceMakeEqual
            // 
            this.bbiHorizSpaceMakeEqual.Caption = "Make &Equal";
            this.bbiHorizSpaceMakeEqual.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceMakeEqual;
            this.bbiHorizSpaceMakeEqual.Enabled = false;
            this.bbiHorizSpaceMakeEqual.Hint = "Make the spacing between the selected controls equal";
            this.bbiHorizSpaceMakeEqual.Id = 22;
            this.bbiHorizSpaceMakeEqual.Name = "bbiHorizSpaceMakeEqual";
            // 
            // bbiHorizSpaceIncrease
            // 
            this.bbiHorizSpaceIncrease.Caption = "&Increase";
            this.bbiHorizSpaceIncrease.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceIncrease;
            this.bbiHorizSpaceIncrease.Enabled = false;
            this.bbiHorizSpaceIncrease.Hint = "Increase the spacing between the selected controls";
            this.bbiHorizSpaceIncrease.Id = 23;
            this.bbiHorizSpaceIncrease.Name = "bbiHorizSpaceIncrease";
            // 
            // bbiHorizSpaceDecrease
            // 
            this.bbiHorizSpaceDecrease.Caption = "&Decrease";
            this.bbiHorizSpaceDecrease.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceDecrease;
            this.bbiHorizSpaceDecrease.Enabled = false;
            this.bbiHorizSpaceDecrease.Hint = "Decrease the spacing between the selected controls";
            this.bbiHorizSpaceDecrease.Id = 24;
            this.bbiHorizSpaceDecrease.Name = "bbiHorizSpaceDecrease";
            // 
            // bbiHorizSpaceConcatenate
            // 
            this.bbiHorizSpaceConcatenate.Caption = "&Remove";
            this.bbiHorizSpaceConcatenate.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceConcatenate;
            this.bbiHorizSpaceConcatenate.Enabled = false;
            this.bbiHorizSpaceConcatenate.Hint = "Remove the spacing between the selected controls";
            this.bbiHorizSpaceConcatenate.Id = 25;
            this.bbiHorizSpaceConcatenate.Name = "bbiHorizSpaceConcatenate";
            // 
            // bbiVertSpaceMakeEqual
            // 
            this.bbiVertSpaceMakeEqual.Caption = "Make &Equal";
            this.bbiVertSpaceMakeEqual.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceMakeEqual;
            this.bbiVertSpaceMakeEqual.Enabled = false;
            this.bbiVertSpaceMakeEqual.Hint = "Make the spacing between the selected controls equal";
            this.bbiVertSpaceMakeEqual.Id = 26;
            this.bbiVertSpaceMakeEqual.Name = "bbiVertSpaceMakeEqual";
            // 
            // bbiVertSpaceIncrease
            // 
            this.bbiVertSpaceIncrease.Caption = "&Increase";
            this.bbiVertSpaceIncrease.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceIncrease;
            this.bbiVertSpaceIncrease.Enabled = false;
            this.bbiVertSpaceIncrease.Hint = "Increase the spacing between the selected controls";
            this.bbiVertSpaceIncrease.Id = 27;
            this.bbiVertSpaceIncrease.Name = "bbiVertSpaceIncrease";
            // 
            // bbiVertSpaceDecrease
            // 
            this.bbiVertSpaceDecrease.Caption = "&Decrease";
            this.bbiVertSpaceDecrease.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceDecrease;
            this.bbiVertSpaceDecrease.Enabled = false;
            this.bbiVertSpaceDecrease.Hint = "Decrease the spacing between the selected controls";
            this.bbiVertSpaceDecrease.Id = 28;
            this.bbiVertSpaceDecrease.Name = "bbiVertSpaceDecrease";
            // 
            // bbiVertSpaceConcatenate
            // 
            this.bbiVertSpaceConcatenate.Caption = "&Remove";
            this.bbiVertSpaceConcatenate.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceConcatenate;
            this.bbiVertSpaceConcatenate.Enabled = false;
            this.bbiVertSpaceConcatenate.Hint = "Remove the spacing between the selected controls";
            this.bbiVertSpaceConcatenate.Id = 29;
            this.bbiVertSpaceConcatenate.Name = "bbiVertSpaceConcatenate";
            // 
            // bbiCenterHorizontally
            // 
            this.bbiCenterHorizontally.Caption = "&Horizontally";
            this.bbiCenterHorizontally.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.CenterHorizontally;
            this.bbiCenterHorizontally.Enabled = false;
            this.bbiCenterHorizontally.Hint = "Horizontally center the selected controls within a band";
            this.bbiCenterHorizontally.Id = 30;
            this.bbiCenterHorizontally.Name = "bbiCenterHorizontally";
            // 
            // bbiCenterVertically
            // 
            this.bbiCenterVertically.Caption = "&Vertically";
            this.bbiCenterVertically.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.CenterVertically;
            this.bbiCenterVertically.Enabled = false;
            this.bbiCenterVertically.Hint = "Vertically center the selected controls within a band";
            this.bbiCenterVertically.Id = 31;
            this.bbiCenterVertically.Name = "bbiCenterVertically";
            // 
            // bbiBringToFront
            // 
            this.bbiBringToFront.Caption = "&Bring to Front";
            this.bbiBringToFront.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BringToFront;
            this.bbiBringToFront.Enabled = false;
            this.bbiBringToFront.Hint = "Bring the selected controls to the front";
            this.bbiBringToFront.Id = 32;
            this.bbiBringToFront.Name = "bbiBringToFront";
            // 
            // bbiSendToBack
            // 
            this.bbiSendToBack.Caption = "&Send to Back";
            this.bbiSendToBack.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SendToBack;
            this.bbiSendToBack.Enabled = false;
            this.bbiSendToBack.Hint = "Move the selected controls to the back";
            this.bbiSendToBack.Id = 33;
            this.bbiSendToBack.Name = "bbiSendToBack";
            // 
            // commandBarItem1
            // 
            this.commandBarItem1.Caption = "&New";
            this.commandBarItem1.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.NewReport;
            this.commandBarItem1.Enabled = false;
            this.commandBarItem1.Hint = "Create a new blank report";
            this.commandBarItem1.Id = 34;
            this.commandBarItem1.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N));
            this.commandBarItem1.Name = "commandBarItem1";
            // 
            // bbiOpenFile
            // 
            this.bbiOpenFile.Caption = "&Open...";
            this.bbiOpenFile.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.OpenFile;
            this.bbiOpenFile.Enabled = false;
            this.bbiOpenFile.Hint = "Open a report";
            this.bbiOpenFile.Id = 35;
            this.bbiOpenFile.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O));
            this.bbiOpenFile.Name = "bbiOpenFile";
            // 
            // bbiSaveFile
            // 
            this.bbiSaveFile.Caption = "&Save";
            this.bbiSaveFile.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SaveFile;
            this.bbiSaveFile.Enabled = false;
            this.bbiSaveFile.Hint = "Save the report";
            this.bbiSaveFile.Id = 36;
            this.bbiSaveFile.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S));
            this.bbiSaveFile.Name = "bbiSaveFile";
            // 
            // bbiCut
            // 
            this.bbiCut.Caption = "Cu&t";
            this.bbiCut.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Cut;
            this.bbiCut.Enabled = false;
            this.bbiCut.Hint = "Delete the control and copy it to the clipboard";
            this.bbiCut.Id = 37;
            this.bbiCut.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X));
            this.bbiCut.Name = "bbiCut";
            // 
            // bbiCopy
            // 
            this.bbiCopy.Caption = "&Copy";
            this.bbiCopy.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Copy;
            this.bbiCopy.Enabled = false;
            this.bbiCopy.Hint = "Copy the control to the clipboard";
            this.bbiCopy.Id = 38;
            this.bbiCopy.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C));
            this.bbiCopy.Name = "bbiCopy";
            // 
            // bbiPaste
            // 
            this.bbiPaste.Caption = "&Paste";
            this.bbiPaste.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Paste;
            this.bbiPaste.Enabled = false;
            this.bbiPaste.Hint = "Add the control from the clipboard";
            this.bbiPaste.Id = 39;
            this.bbiPaste.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V));
            this.bbiPaste.Name = "bbiPaste";
            // 
            // bbiUndo
            // 
            this.bbiUndo.Caption = "&Undo";
            this.bbiUndo.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Undo;
            this.bbiUndo.Enabled = false;
            this.bbiUndo.Hint = "Undo the last operation";
            this.bbiUndo.Id = 40;
            this.bbiUndo.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z));
            this.bbiUndo.Name = "bbiUndo";
            // 
            // bbiRedo
            // 
            this.bbiRedo.Caption = "&Redo";
            this.bbiRedo.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Redo;
            this.bbiRedo.Enabled = false;
            this.bbiRedo.Hint = "Redo the last operation";
            this.bbiRedo.Id = 41;
            this.bbiRedo.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y));
            this.bbiRedo.Name = "bbiRedo";
            // 
            // msiFile
            // 
            this.msiFile.Caption = "&File";
            this.msiFile.Id = 43;
            this.msiFile.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem2),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiOpenFile),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiSaveFile, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem3),
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem7),
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem11),
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem4, true)});
            this.msiFile.Name = "msiFile";
            // 
            // commandBarItem2
            // 
            this.commandBarItem2.Caption = "New via &Wizard...";
            this.commandBarItem2.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.NewReportWizard;
            this.commandBarItem2.Enabled = false;
            this.commandBarItem2.Hint = "Create a new report using the Wizard";
            this.commandBarItem2.Id = 60;
            this.commandBarItem2.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.W));
            this.commandBarItem2.Name = "commandBarItem2";
            // 
            // commandBarItem3
            // 
            this.commandBarItem3.Caption = "Save &As...";
            this.commandBarItem3.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SaveFileAs;
            this.commandBarItem3.Enabled = false;
            this.commandBarItem3.Hint = "Save the report with a new name";
            this.commandBarItem3.Id = 61;
            this.commandBarItem3.Name = "commandBarItem3";
            // 
            // commandBarItem7
            // 
            this.commandBarItem7.Caption = "Save A&ll";
            this.commandBarItem7.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SaveAll;
            this.commandBarItem7.Enabled = false;
            this.commandBarItem7.Hint = "Save all reports";
            this.commandBarItem7.Id = 65;
            this.commandBarItem7.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L));
            this.commandBarItem7.Name = "commandBarItem7";
            // 
            // commandBarItem11
            // 
            this.commandBarItem11.Caption = "&Close";
            this.commandBarItem11.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Close;
            this.commandBarItem11.Enabled = false;
            this.commandBarItem11.Hint = "Close the report";
            this.commandBarItem11.Id = 72;
            this.commandBarItem11.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F4));
            this.commandBarItem11.Name = "commandBarItem11";
            // 
            // commandBarItem4
            // 
            this.commandBarItem4.Caption = "E&xit";
            this.commandBarItem4.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Exit;
            this.commandBarItem4.Enabled = false;
            this.commandBarItem4.Hint = "Close the designer";
            this.commandBarItem4.Id = 62;
            this.commandBarItem4.Name = "commandBarItem4";
            // 
            // msiEdit
            // 
            this.msiEdit.Caption = "&Edit";
            this.msiEdit.Id = 44;
            this.msiEdit.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiUndo, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiRedo),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiCut, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiCopy),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiPaste),
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem5),
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem6, true)});
            this.msiEdit.Name = "msiEdit";
            // 
            // commandBarItem5
            // 
            this.commandBarItem5.Caption = "&Delete";
            this.commandBarItem5.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Delete;
            this.commandBarItem5.Enabled = false;
            this.commandBarItem5.Hint = "Delete the control";
            this.commandBarItem5.Id = 63;
            this.commandBarItem5.Name = "commandBarItem5";
            // 
            // commandBarItem6
            // 
            this.commandBarItem6.Caption = "Select &All";
            this.commandBarItem6.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SelectAll;
            this.commandBarItem6.Enabled = false;
            this.commandBarItem6.Hint = "Select all the controls in the document";
            this.commandBarItem6.Id = 64;
            this.commandBarItem6.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A));
            this.commandBarItem6.Name = "commandBarItem6";
            // 
            // msiTabButtons
            // 
            this.msiTabButtons.Caption = "&View";
            this.msiTabButtons.Id = 45;
            this.msiTabButtons.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barReportTabButtonsListItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem1, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem2, true)});
            this.msiTabButtons.Name = "msiTabButtons";
            // 
            // barReportTabButtonsListItem1
            // 
            this.barReportTabButtonsListItem1.Caption = "Tab Buttons";
            this.barReportTabButtonsListItem1.Id = 46;
            this.barReportTabButtonsListItem1.Name = "barReportTabButtonsListItem1";
            // 
            // barSubItem1
            // 
            this.barSubItem1.Caption = "&Toolbars";
            this.barSubItem1.Id = 47;
            this.barSubItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.xrBarToolbarsListItem1)});
            this.barSubItem1.Name = "barSubItem1";
            // 
            // xrBarToolbarsListItem1
            // 
            this.xrBarToolbarsListItem1.Caption = "&Toolbars";
            this.xrBarToolbarsListItem1.Id = 48;
            this.xrBarToolbarsListItem1.Name = "xrBarToolbarsListItem1";
            // 
            // barSubItem2
            // 
            this.barSubItem2.Caption = "&Windows";
            this.barSubItem2.Id = 49;
            this.barSubItem2.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barDockPanelsListItem1)});
            this.barSubItem2.Name = "barSubItem2";
            // 
            // barDockPanelsListItem1
            // 
            this.barDockPanelsListItem1.Caption = "&Windows";
            this.barDockPanelsListItem1.DockManager = null;
            this.barDockPanelsListItem1.Id = 50;
            this.barDockPanelsListItem1.Name = "barDockPanelsListItem1";
            this.barDockPanelsListItem1.ShowCustomizationItem = false;
            this.barDockPanelsListItem1.ShowDockPanels = true;
            this.barDockPanelsListItem1.ShowToolbars = false;
            // 
            // msiFormat
            // 
            this.msiFormat.Caption = "Fo&rmat";
            this.msiFormat.Id = 51;
            this.msiFormat.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiForeColor),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiBackColor),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiFont, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiJustify),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiAlign, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiSameSize),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiHorizontalSpacing, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiVerticalSpacing),
            new DevExpress.XtraBars.LinkPersistInfo(this.bsiCenter, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiOrder, true)});
            this.msiFormat.Name = "msiFormat";
            // 
            // msiFont
            // 
            this.msiFont.Caption = "&Font";
            this.msiFont.Id = 52;
            this.msiFont.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiFontBold, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiFontItalic),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiFontUnderline)});
            this.msiFont.Name = "msiFont";
            // 
            // msiJustify
            // 
            this.msiJustify.Caption = "&Justify";
            this.msiJustify.Id = 53;
            this.msiJustify.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiJustifyLeft, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiJustifyCenter),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiJustifyRight),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiJustifyJustify)});
            this.msiJustify.Name = "msiJustify";
            // 
            // msiAlign
            // 
            this.msiAlign.Caption = "&Align";
            this.msiAlign.Id = 54;
            this.msiAlign.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiAlignLeft, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiAlignVerticalCenters),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiAlignRight),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiAlignTop, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiAlignHorizontalCenters),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiAlignBottom),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiAlignToGrid, true)});
            this.msiAlign.Name = "msiAlign";
            // 
            // msiSameSize
            // 
            this.msiSameSize.Caption = "&Make Same Size";
            this.msiSameSize.Id = 55;
            this.msiSameSize.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiSizeToControlWidth, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiSizeToGrid),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiSizeToControlHeight),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiSizeToControl)});
            this.msiSameSize.Name = "msiSameSize";
            // 
            // msiHorizontalSpacing
            // 
            this.msiHorizontalSpacing.Caption = "&Horizontal Spacing";
            this.msiHorizontalSpacing.Id = 56;
            this.msiHorizontalSpacing.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiHorizSpaceMakeEqual, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiHorizSpaceIncrease),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiHorizSpaceDecrease),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiHorizSpaceConcatenate)});
            this.msiHorizontalSpacing.Name = "msiHorizontalSpacing";
            // 
            // msiVerticalSpacing
            // 
            this.msiVerticalSpacing.Caption = "&Vertical Spacing";
            this.msiVerticalSpacing.Id = 57;
            this.msiVerticalSpacing.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiVertSpaceMakeEqual, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiVertSpaceIncrease),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiVertSpaceDecrease),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiVertSpaceConcatenate)});
            this.msiVerticalSpacing.Name = "msiVerticalSpacing";
            // 
            // bsiCenter
            // 
            this.bsiCenter.Caption = "&Center in Form";
            this.bsiCenter.Id = 58;
            this.bsiCenter.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiCenterHorizontally, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiCenterVertically)});
            this.bsiCenter.Name = "bsiCenter";
            // 
            // msiOrder
            // 
            this.msiOrder.Caption = "&Order";
            this.msiOrder.Id = 59;
            this.msiOrder.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiBringToFront, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbiSendToBack)});
            this.msiOrder.Name = "msiOrder";
            // 
            // msiWindow
            // 
            this.msiWindow.Caption = "&Window";
            this.msiWindow.Id = 66;
            this.msiWindow.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.msiWindowInterface, true),
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem8),
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem9),
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem10),
            new DevExpress.XtraBars.LinkPersistInfo(this.msiWindows, true)});
            this.msiWindow.Name = "msiWindow";
            // 
            // msiWindowInterface
            // 
            this.msiWindowInterface.BindableChecked = true;
            this.msiWindowInterface.Caption = "&Tabbed Interface";
            this.msiWindowInterface.Checked = true;
            this.msiWindowInterface.CheckedCommand = DevExpress.XtraReports.UserDesigner.ReportCommand.ShowTabbedInterface;
            this.msiWindowInterface.Enabled = false;
            this.msiWindowInterface.Hint = "Switch between tabbed and window MDI layout modes";
            this.msiWindowInterface.Id = 67;
            this.msiWindowInterface.Name = "msiWindowInterface";
            this.msiWindowInterface.UncheckedCommand = DevExpress.XtraReports.UserDesigner.ReportCommand.ShowWindowInterface;
            // 
            // commandBarItem8
            // 
            this.commandBarItem8.Caption = "&Cascade";
            this.commandBarItem8.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.MdiCascade;
            this.commandBarItem8.Enabled = false;
            this.commandBarItem8.Hint = "Arrange all open documents cascaded, so that they overlap each other";
            this.commandBarItem8.Id = 68;
            this.commandBarItem8.Name = "commandBarItem8";
            // 
            // commandBarItem9
            // 
            this.commandBarItem9.Caption = "Tile &Horizontal";
            this.commandBarItem9.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.MdiTileHorizontal;
            this.commandBarItem9.Enabled = false;
            this.commandBarItem9.Hint = "Arrange all open documents from top to bottom";
            this.commandBarItem9.Id = 69;
            this.commandBarItem9.Name = "commandBarItem9";
            // 
            // commandBarItem10
            // 
            this.commandBarItem10.Caption = "Tile &Vertical";
            this.commandBarItem10.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.MdiTileVertical;
            this.commandBarItem10.Enabled = false;
            this.commandBarItem10.Hint = "Arrange all open documents from left to right";
            this.commandBarItem10.Id = 70;
            this.commandBarItem10.Name = "commandBarItem10";
            // 
            // msiWindows
            // 
            this.msiWindows.Caption = "Windows";
            this.msiWindows.Id = 71;
            this.msiWindows.Name = "msiWindows";
            // 
            // bbiZoomOut
            // 
            this.bbiZoomOut.Caption = "Zoom Out";
            this.bbiZoomOut.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ZoomOut;
            this.bbiZoomOut.Enabled = false;
            this.bbiZoomOut.Hint = "Zoom out the design surface";
            this.bbiZoomOut.Id = 73;
            this.bbiZoomOut.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Subtract));
            this.bbiZoomOut.Name = "bbiZoomOut";
            // 
            // bbiZoom
            // 
            this.bbiZoom.Caption = "Zoom";
            this.bbiZoom.Edit = this.designRepositoryItemComboBox2;
            this.bbiZoom.EditWidth = 70;
            this.bbiZoom.Enabled = false;
            this.bbiZoom.Hint = "Select or input the zoom factor";
            this.bbiZoom.Id = 74;
            this.bbiZoom.Name = "bbiZoom";
            // 
            // designRepositoryItemComboBox2
            // 
            this.designRepositoryItemComboBox2.AutoComplete = false;
            this.designRepositoryItemComboBox2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.designRepositoryItemComboBox2.Name = "designRepositoryItemComboBox2";
            // 
            // bbiZoomIn
            // 
            this.bbiZoomIn.Caption = "Zoom In";
            this.bbiZoomIn.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ZoomIn;
            this.bbiZoomIn.Enabled = false;
            this.bbiZoomIn.Hint = "Zoom in the design surface";
            this.bbiZoomIn.Id = 75;
            this.bbiZoomIn.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Add));
            this.bbiZoomIn.Name = "bbiZoomIn";
            // 
            // changeSectionPageOrientationItem1
            // 
            this.changeSectionPageOrientationItem1.Id = 84;
            this.changeSectionPageOrientationItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setPortraitPageOrientationItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setLandscapePageOrientationItem1)});
            this.changeSectionPageOrientationItem1.Name = "changeSectionPageOrientationItem1";
            // 
            // setPortraitPageOrientationItem1
            // 
            this.setPortraitPageOrientationItem1.Id = 82;
            this.setPortraitPageOrientationItem1.Name = "setPortraitPageOrientationItem1";
            // 
            // setLandscapePageOrientationItem1
            // 
            this.setLandscapePageOrientationItem1.Id = 83;
            this.setLandscapePageOrientationItem1.Name = "setLandscapePageOrientationItem1";
            // 
            // changeSectionColumnsItem1
            // 
            this.changeSectionColumnsItem1.Id = 90;
            this.changeSectionColumnsItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setSectionOneColumnItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setSectionTwoColumnsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setSectionThreeColumnsItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.showColumnsSetupFormItem1)});
            this.changeSectionColumnsItem1.Name = "changeSectionColumnsItem1";
            // 
            // setSectionOneColumnItem1
            // 
            this.setSectionOneColumnItem1.Id = 86;
            this.setSectionOneColumnItem1.Name = "setSectionOneColumnItem1";
            // 
            // setSectionTwoColumnsItem1
            // 
            this.setSectionTwoColumnsItem1.Id = 87;
            this.setSectionTwoColumnsItem1.Name = "setSectionTwoColumnsItem1";
            // 
            // setSectionThreeColumnsItem1
            // 
            this.setSectionThreeColumnsItem1.Id = 88;
            this.setSectionThreeColumnsItem1.Name = "setSectionThreeColumnsItem1";
            // 
            // showColumnsSetupFormItem1
            // 
            this.showColumnsSetupFormItem1.Id = 89;
            this.showColumnsSetupFormItem1.Name = "showColumnsSetupFormItem1";
            // 
            // insertBreakItem1
            // 
            this.insertBreakItem1.Id = 97;
            this.insertBreakItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.KeyTip, this.insertPageBreakItem1, "", false, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.Standard, "B", ""),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertColumnBreakItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertSectionBreakNextPageItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertSectionBreakContinuousItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertSectionBreakEvenPageItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.insertSectionBreakOddPageItem1)});
            this.insertBreakItem1.Name = "insertBreakItem1";
            // 
            // insertPageBreakItem1
            // 
            this.insertPageBreakItem1.Id = 91;
            this.insertPageBreakItem1.Name = "insertPageBreakItem1";
            // 
            // insertColumnBreakItem1
            // 
            this.insertColumnBreakItem1.Id = 92;
            this.insertColumnBreakItem1.Name = "insertColumnBreakItem1";
            // 
            // insertSectionBreakNextPageItem1
            // 
            this.insertSectionBreakNextPageItem1.Id = 93;
            this.insertSectionBreakNextPageItem1.Name = "insertSectionBreakNextPageItem1";
            // 
            // insertSectionBreakContinuousItem1
            // 
            this.insertSectionBreakContinuousItem1.Id = 94;
            this.insertSectionBreakContinuousItem1.Name = "insertSectionBreakContinuousItem1";
            // 
            // insertSectionBreakEvenPageItem1
            // 
            this.insertSectionBreakEvenPageItem1.Id = 95;
            this.insertSectionBreakEvenPageItem1.Name = "insertSectionBreakEvenPageItem1";
            // 
            // insertSectionBreakOddPageItem1
            // 
            this.insertSectionBreakOddPageItem1.Id = 96;
            this.insertSectionBreakOddPageItem1.Name = "insertSectionBreakOddPageItem1";
            // 
            // changeSectionLineNumberingItem1
            // 
            this.changeSectionLineNumberingItem1.Id = 104;
            this.changeSectionLineNumberingItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setSectionLineNumberingNoneItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setSectionLineNumberingContinuousItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setSectionLineNumberingRestartNewPageItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setSectionLineNumberingRestartNewSectionItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.toggleParagraphSuppressLineNumbersItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.showLineNumberingFormItem1)});
            this.changeSectionLineNumberingItem1.Name = "changeSectionLineNumberingItem1";
            // 
            // setSectionLineNumberingNoneItem1
            // 
            this.setSectionLineNumberingNoneItem1.Id = 98;
            this.setSectionLineNumberingNoneItem1.Name = "setSectionLineNumberingNoneItem1";
            // 
            // setSectionLineNumberingContinuousItem1
            // 
            this.setSectionLineNumberingContinuousItem1.Id = 99;
            this.setSectionLineNumberingContinuousItem1.Name = "setSectionLineNumberingContinuousItem1";
            // 
            // setSectionLineNumberingRestartNewPageItem1
            // 
            this.setSectionLineNumberingRestartNewPageItem1.Id = 100;
            this.setSectionLineNumberingRestartNewPageItem1.Name = "setSectionLineNumberingRestartNewPageItem1";
            // 
            // setSectionLineNumberingRestartNewSectionItem1
            // 
            this.setSectionLineNumberingRestartNewSectionItem1.Id = 101;
            this.setSectionLineNumberingRestartNewSectionItem1.Name = "setSectionLineNumberingRestartNewSectionItem1";
            // 
            // toggleParagraphSuppressLineNumbersItem1
            // 
            this.toggleParagraphSuppressLineNumbersItem1.Id = 102;
            this.toggleParagraphSuppressLineNumbersItem1.Name = "toggleParagraphSuppressLineNumbersItem1";
            // 
            // showLineNumberingFormItem1
            // 
            this.showLineNumberingFormItem1.Id = 103;
            this.showLineNumberingFormItem1.Name = "showLineNumberingFormItem1";
            // 
            // changeHyphenationOptionsItem1
            // 
            this.changeHyphenationOptionsItem1.Id = 108;
            this.changeHyphenationOptionsItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.setHyphenateDocumentNoneItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.setHyphenateDocumentAutomaticItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.showHyphenationOptionsFormItem1)});
            this.changeHyphenationOptionsItem1.Name = "changeHyphenationOptionsItem1";
            // 
            // setHyphenateDocumentNoneItem1
            // 
            this.setHyphenateDocumentNoneItem1.Id = 105;
            this.setHyphenateDocumentNoneItem1.Name = "setHyphenateDocumentNoneItem1";
            // 
            // setHyphenateDocumentAutomaticItem1
            // 
            this.setHyphenateDocumentAutomaticItem1.Id = 106;
            this.setHyphenateDocumentAutomaticItem1.Name = "setHyphenateDocumentAutomaticItem1";
            // 
            // showHyphenationOptionsFormItem1
            // 
            this.showHyphenationOptionsFormItem1.Id = 107;
            this.showHyphenationOptionsFormItem1.Name = "showHyphenationOptionsFormItem1";
            // 
            // changePageColorItem1
            // 
            this.changePageColorItem1.Id = 109;
            this.changePageColorItem1.Name = "changePageColorItem1";
            // 
            // repositoryItemMemoEdit3
            // 
            this.repositoryItemMemoEdit3.Name = "repositoryItemMemoEdit3";
            // 
            // repositoryItemMemoEdit1
            // 
            this.repositoryItemMemoEdit1.Name = "repositoryItemMemoEdit1";
            // 
            // repositoryItemMemoEdit2
            // 
            this.repositoryItemMemoEdit2.Name = "repositoryItemMemoEdit2";
            // 
            // gridColumn1
            // 
            this.gridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn1.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn1.Caption = "Description";
            this.gridColumn1.ColumnEdit = this.repositoryItemMemoEdit2;
            this.gridColumn1.FieldName = "description";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.FixedWidth = true;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 350;
            // 
            // gridColumn2
            // 
            this.gridColumn2.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn2.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn2.Caption = "Details";
            this.gridColumn2.FieldName = "details";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.FixedWidth = true;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 90;
            // 
            // gridColumn3
            // 
            this.gridColumn3.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn3.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.NoWrap;
            this.gridColumn3.Caption = "Description2";
            this.gridColumn3.ColumnEdit = this.repositoryItemMemoEdit2;
            this.gridColumn3.FieldName = "description2";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.FixedWidth = true;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 2;
            this.gridColumn3.Width = 350;
            // 
            // gridColumn4
            // 
            this.gridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn4.Caption = "Details2";
            this.gridColumn4.FieldName = "details2";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.OptionsColumn.FixedWidth = true;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 3;
            this.gridColumn4.Width = 90;
            // 
            // gridColumn5
            // 
            this.gridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn5.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn5.Caption = "Description";
            this.gridColumn5.ColumnEdit = this.repositoryItemMemoEdit1;
            this.gridColumn5.FieldName = "description";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.FixedWidth = true;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 0;
            this.gridColumn5.Width = 350;
            // 
            // gridColumn6
            // 
            this.gridColumn6.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn6.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn6.Caption = "Details";
            this.gridColumn6.FieldName = "details";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.FixedWidth = true;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 1;
            this.gridColumn6.Width = 90;
            // 
            // gridColumn7
            // 
            this.gridColumn7.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn7.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.NoWrap;
            this.gridColumn7.Caption = "Description2";
            this.gridColumn7.ColumnEdit = this.repositoryItemMemoEdit1;
            this.gridColumn7.FieldName = "description2";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.FixedWidth = true;
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 2;
            this.gridColumn7.Width = 350;
            // 
            // gridColumn8
            // 
            this.gridColumn8.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn8.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn8.Caption = "Details2";
            this.gridColumn8.FieldName = "details2";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.FixedWidth = true;
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 3;
            this.gridColumn8.Width = 90;
            // 
            // reportDesigner1
            // 
            this.reportDesigner1.ContainerControl = null;
            xrDesignPanelListener1.DesignControl = this.xrDesignBarManager1;
            xrDesignPanelListener2.DesignControl = this.xrDesignDockManager1;
            xrDesignPanelListener3.DesignControl = this.fieldListDockPanel1;
            xrDesignPanelListener4.DesignControl = this.propertyGridDockPanel1;
            xrDesignPanelListener5.DesignControl = this.reportExplorerDockPanel1;
            xrDesignPanelListener6.DesignControl = this.reportGalleryDockPanel1;
            xrDesignPanelListener7.DesignControl = this.groupAndSortDockPanel1;
            xrDesignPanelListener8.DesignControl = this.errorListDockPanel1;
            this.reportDesigner1.DesignPanelListeners.AddRange(new DevExpress.XtraReports.UserDesigner.XRDesignPanelListener[] {
            xrDesignPanelListener1,
            xrDesignPanelListener2,
            xrDesignPanelListener3,
            xrDesignPanelListener4,
            xrDesignPanelListener5,
            xrDesignPanelListener6,
            xrDesignPanelListener7,
            xrDesignPanelListener8});
            this.reportDesigner1.Form = this;
            // 
            // gridColumn9
            // 
            this.gridColumn9.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn9.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridColumn9.Caption = "Description";
            this.gridColumn9.ColumnEdit = this.repositoryItemMemoEdit3;
            this.gridColumn9.FieldName = "description";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.FixedWidth = true;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 0;
            this.gridColumn9.Width = 350;
            // 
            // gridColumn10
            // 
            this.gridColumn10.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn10.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn10.Caption = "Details";
            this.gridColumn10.FieldName = "details";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.OptionsColumn.FixedWidth = true;
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 1;
            this.gridColumn10.Width = 90;
            // 
            // gridColumn11
            // 
            this.gridColumn11.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn11.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.NoWrap;
            this.gridColumn11.Caption = "Description2";
            this.gridColumn11.ColumnEdit = this.repositoryItemMemoEdit3;
            this.gridColumn11.FieldName = "description2";
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.OptionsColumn.FixedWidth = true;
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 2;
            this.gridColumn11.Width = 350;
            // 
            // gridColumn12
            // 
            this.gridColumn12.AppearanceCell.Options.UseTextOptions = true;
            this.gridColumn12.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.gridColumn12.Caption = "Details2";
            this.gridColumn12.FieldName = "details2";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.OptionsColumn.FixedWidth = true;
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 3;
            this.gridColumn12.Width = 90;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 46);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1190, 24);
            this.menuStrip1.TabIndex = 27;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printPreviewToolStripMenuItem,
            this.printToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(99, 22);
            this.toolStripMenuItem1.Text = "Print";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.printPreviewToolStripMenuItem.Text = "Print Preview";
            this.printPreviewToolStripMenuItem.Click += new System.EventHandler(this.printPreviewToolStripMenuItem_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(99, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // panelAll
            // 
            this.panelAll.Controls.Add(this.rtbStatementOfFuneral);
            this.panelAll.Controls.Add(this.rtbAddress);
            this.panelAll.Controls.Add(this.rtb);
            this.panelAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAll.Location = new System.Drawing.Point(0, 70);
            this.panelAll.Name = "panelAll";
            this.panelAll.Size = new System.Drawing.Size(1190, 598);
            this.panelAll.TabIndex = 32;
            // 
            // rtbAddress
            // 
            this.rtbAddress.DetectUrls = false;
            this.rtbAddress.HiglightColor = EMRControlLib.RichTextBoxEx.RtfColor.Empty;
            this.rtbAddress.Location = new System.Drawing.Point(193, 32);
            this.rtbAddress.Name = "rtbAddress";
            this.rtbAddress.Size = new System.Drawing.Size(811, 80);
            this.rtbAddress.TabIndex = 1;
            this.rtbAddress.Text = "";
            this.rtbAddress.TextColor = EMRControlLib.RichTextBoxEx.RtfColor.Black;
            // 
            // richEditBarController1
            // 
            this.richEditBarController1.BarItems.Add(this.setNormalSectionPageMarginsItem1);
            this.richEditBarController1.BarItems.Add(this.setNarrowSectionPageMarginsItem1);
            this.richEditBarController1.BarItems.Add(this.setModerateSectionPageMarginsItem1);
            this.richEditBarController1.BarItems.Add(this.setWideSectionPageMarginsItem1);
            this.richEditBarController1.BarItems.Add(this.showPageMarginsSetupFormItem1);
            this.richEditBarController1.BarItems.Add(this.changeSectionPageMarginsItem1);
            this.richEditBarController1.BarItems.Add(this.setPortraitPageOrientationItem1);
            this.richEditBarController1.BarItems.Add(this.setLandscapePageOrientationItem1);
            this.richEditBarController1.BarItems.Add(this.changeSectionPageOrientationItem1);
            this.richEditBarController1.BarItems.Add(this.changeSectionPaperKindItem1);
            this.richEditBarController1.BarItems.Add(this.setSectionOneColumnItem1);
            this.richEditBarController1.BarItems.Add(this.setSectionTwoColumnsItem1);
            this.richEditBarController1.BarItems.Add(this.setSectionThreeColumnsItem1);
            this.richEditBarController1.BarItems.Add(this.showColumnsSetupFormItem1);
            this.richEditBarController1.BarItems.Add(this.changeSectionColumnsItem1);
            this.richEditBarController1.BarItems.Add(this.insertPageBreakItem1);
            this.richEditBarController1.BarItems.Add(this.insertColumnBreakItem1);
            this.richEditBarController1.BarItems.Add(this.insertSectionBreakNextPageItem1);
            this.richEditBarController1.BarItems.Add(this.insertSectionBreakContinuousItem1);
            this.richEditBarController1.BarItems.Add(this.insertSectionBreakEvenPageItem1);
            this.richEditBarController1.BarItems.Add(this.insertSectionBreakOddPageItem1);
            this.richEditBarController1.BarItems.Add(this.insertBreakItem1);
            this.richEditBarController1.BarItems.Add(this.setSectionLineNumberingNoneItem1);
            this.richEditBarController1.BarItems.Add(this.setSectionLineNumberingContinuousItem1);
            this.richEditBarController1.BarItems.Add(this.setSectionLineNumberingRestartNewPageItem1);
            this.richEditBarController1.BarItems.Add(this.setSectionLineNumberingRestartNewSectionItem1);
            this.richEditBarController1.BarItems.Add(this.toggleParagraphSuppressLineNumbersItem1);
            this.richEditBarController1.BarItems.Add(this.showLineNumberingFormItem1);
            this.richEditBarController1.BarItems.Add(this.changeSectionLineNumberingItem1);
            this.richEditBarController1.BarItems.Add(this.setHyphenateDocumentNoneItem1);
            this.richEditBarController1.BarItems.Add(this.setHyphenateDocumentAutomaticItem1);
            this.richEditBarController1.BarItems.Add(this.showHyphenationOptionsFormItem1);
            this.richEditBarController1.BarItems.Add(this.changeHyphenationOptionsItem1);
            this.richEditBarController1.BarItems.Add(this.changePageColorItem1);
            this.richEditBarController1.Control = this.rtb;
            // 
            // rtbStatementOfFuneral
            // 
            this.rtbStatementOfFuneral.Location = new System.Drawing.Point(314, 97);
            this.rtbStatementOfFuneral.MenuManager = this.xrDesignBarManager1;
            this.rtbStatementOfFuneral.Name = "rtbStatementOfFuneral";
            this.rtbStatementOfFuneral.Size = new System.Drawing.Size(400, 200);
            this.rtbStatementOfFuneral.TabIndex = 2;
            // 
            // ContractForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1190, 668);
            this.Controls.Add(this.panelAll);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.Name = "ContractForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ContractForm";
            this.Load += new System.EventHandler(this.ContractForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignBarManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignDockManager1)).EndInit();
            this.propertyGridDockPanel1.ResumeLayout(false);
            this.reportGalleryDockPanel1.ResumeLayout(false);
            this.fieldListDockPanel1.ResumeLayout(false);
            this.reportExplorerDockPanel1.ResumeLayout(false);
            this.groupAndSortDockPanel1.ResumeLayout(false);
            this.errorListDockPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.recentlyUsedItemsComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.designRepositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.designRepositoryItemComboBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemMemoEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.reportDesigner1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelAll.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.richEditBarController1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit1;
        private DevExpress.XtraReports.UserDesigner.XRDesignMdiController reportDesigner1;
        private DevExpress.XtraReports.UserDesigner.XRDesignBarManager xrDesignBarManager1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraReports.UserDesigner.XRDesignDockManager xrDesignDockManager1;
        private DevExpress.XtraReports.UserDesigner.PropertyGridDockPanel propertyGridDockPanel1;
        private DevExpress.XtraReports.UserDesigner.DesignControlContainer propertyGridDockPanel1_Container;
        private DevExpress.XtraReports.UserDesigner.ReportGalleryDockPanel reportGalleryDockPanel1;
        private DevExpress.XtraReports.UserDesigner.DesignControlContainer reportGalleryDockPanel1_Container;
        private DevExpress.XtraReports.UserDesigner.FieldListDockPanel fieldListDockPanel1;
        private DevExpress.XtraReports.UserDesigner.DesignControlContainer fieldListDockPanel1_Container;
        private DevExpress.XtraReports.UserDesigner.ReportExplorerDockPanel reportExplorerDockPanel1;
        private DevExpress.XtraReports.UserDesigner.DesignControlContainer reportExplorerDockPanel1_Container;
        private DevExpress.XtraReports.UserDesigner.GroupAndSortDockPanel groupAndSortDockPanel1;
        private DevExpress.XtraReports.UserDesigner.DesignControlContainer groupAndSortDockPanel1_Container;
        private DevExpress.XtraReports.UserDesigner.ErrorListDockPanel errorListDockPanel1;
        private DevExpress.XtraReports.UserDesigner.DesignControlContainer errorListDockPanel1_Container;
        private DevExpress.XtraReports.UserDesigner.RecentlyUsedItemsComboBox recentlyUsedItemsComboBox1;
        private DevExpress.XtraBars.BarEditItem beiFontName;
        private DevExpress.XtraReports.UserDesigner.DesignRepositoryItemComboBox designRepositoryItemComboBox1;
        private DevExpress.XtraBars.BarEditItem beiFontSize;
        private DevExpress.XtraBars.BarStaticItem bsiHint;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiFontBold;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiFontItalic;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiFontUnderline;
        private DevExpress.XtraReports.UserDesigner.CommandColorBarItem bbiForeColor;
        private DevExpress.XtraReports.UserDesigner.CommandColorBarItem bbiBackColor;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiJustifyLeft;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiJustifyCenter;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiJustifyRight;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiJustifyJustify;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiAlignToGrid;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiAlignLeft;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiAlignVerticalCenters;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiAlignRight;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiAlignTop;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiAlignHorizontalCenters;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiAlignBottom;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiSizeToControlWidth;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiSizeToGrid;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiSizeToControlHeight;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiSizeToControl;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiHorizSpaceMakeEqual;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiHorizSpaceIncrease;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiHorizSpaceDecrease;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiHorizSpaceConcatenate;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiVertSpaceMakeEqual;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiVertSpaceIncrease;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiVertSpaceDecrease;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiVertSpaceConcatenate;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiCenterHorizontally;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiCenterVertically;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiBringToFront;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiSendToBack;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem1;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiOpenFile;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiSaveFile;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiCut;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiCopy;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiPaste;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiUndo;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiRedo;
        private DevExpress.XtraBars.BarSubItem msiFile;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem2;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem3;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem7;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem11;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem4;
        private DevExpress.XtraBars.BarSubItem msiEdit;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem5;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem6;
        private DevExpress.XtraBars.BarSubItem msiTabButtons;
        private DevExpress.XtraReports.UserDesigner.BarReportTabButtonsListItem barReportTabButtonsListItem1;
        private DevExpress.XtraBars.BarSubItem barSubItem1;
        private DevExpress.XtraReports.UserDesigner.XRBarToolbarsListItem xrBarToolbarsListItem1;
        private DevExpress.XtraBars.BarSubItem barSubItem2;
        private DevExpress.XtraReports.UserDesigner.BarDockPanelsListItem barDockPanelsListItem1;
        private DevExpress.XtraBars.BarSubItem msiFormat;
        private DevExpress.XtraBars.BarSubItem msiFont;
        private DevExpress.XtraBars.BarSubItem msiJustify;
        private DevExpress.XtraBars.BarSubItem msiAlign;
        private DevExpress.XtraBars.BarSubItem msiSameSize;
        private DevExpress.XtraBars.BarSubItem msiHorizontalSpacing;
        private DevExpress.XtraBars.BarSubItem msiVerticalSpacing;
        private DevExpress.XtraBars.BarSubItem bsiCenter;
        private DevExpress.XtraBars.BarSubItem msiOrder;
        private DevExpress.XtraBars.BarSubItem msiWindow;
        private DevExpress.XtraReports.UserDesigner.CommandBarCheckItem msiWindowInterface;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem8;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem9;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem10;
        private DevExpress.XtraBars.BarMdiChildrenListItem msiWindows;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiZoomOut;
        private DevExpress.XtraReports.UserDesigner.XRZoomBarEditItem bbiZoom;
        private DevExpress.XtraReports.UserDesigner.DesignRepositoryItemComboBox designRepositoryItemComboBox2;
        private DevExpress.XtraReports.UserDesigner.CommandBarItem bbiZoomIn;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraEditors.Repository.RepositoryItemMemoEdit repositoryItemMemoEdit3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private DevExpress.XtraRichEdit.UI.PageSetupBar pageSetupBar1;
        private DevExpress.XtraRichEdit.UI.ChangeSectionPageMarginsItem changeSectionPageMarginsItem1;
        private DevExpress.XtraRichEdit.UI.SetNormalSectionPageMarginsItem setNormalSectionPageMarginsItem1;
        private DevExpress.XtraRichEdit.UI.SetNarrowSectionPageMarginsItem setNarrowSectionPageMarginsItem1;
        private DevExpress.XtraRichEdit.UI.SetModerateSectionPageMarginsItem setModerateSectionPageMarginsItem1;
        private DevExpress.XtraRichEdit.UI.SetWideSectionPageMarginsItem setWideSectionPageMarginsItem1;
        private DevExpress.XtraRichEdit.UI.ShowPageMarginsSetupFormItem showPageMarginsSetupFormItem1;
        private DevExpress.XtraRichEdit.UI.ChangeSectionPageOrientationItem changeSectionPageOrientationItem1;
        private DevExpress.XtraRichEdit.UI.SetPortraitPageOrientationItem setPortraitPageOrientationItem1;
        private DevExpress.XtraRichEdit.UI.SetLandscapePageOrientationItem setLandscapePageOrientationItem1;
        private DevExpress.XtraRichEdit.UI.ChangeSectionPaperKindItem changeSectionPaperKindItem1;
        private DevExpress.XtraRichEdit.UI.ChangeSectionColumnsItem changeSectionColumnsItem1;
        private DevExpress.XtraRichEdit.UI.SetSectionOneColumnItem setSectionOneColumnItem1;
        private DevExpress.XtraRichEdit.UI.SetSectionTwoColumnsItem setSectionTwoColumnsItem1;
        private DevExpress.XtraRichEdit.UI.SetSectionThreeColumnsItem setSectionThreeColumnsItem1;
        private DevExpress.XtraRichEdit.UI.ShowColumnsSetupFormItem showColumnsSetupFormItem1;
        private DevExpress.XtraRichEdit.UI.InsertBreakItem insertBreakItem1;
        private DevExpress.XtraRichEdit.UI.InsertPageBreakItem insertPageBreakItem1;
        private DevExpress.XtraRichEdit.UI.InsertColumnBreakItem insertColumnBreakItem1;
        private DevExpress.XtraRichEdit.UI.InsertSectionBreakNextPageItem insertSectionBreakNextPageItem1;
        private DevExpress.XtraRichEdit.UI.InsertSectionBreakContinuousItem insertSectionBreakContinuousItem1;
        private DevExpress.XtraRichEdit.UI.InsertSectionBreakEvenPageItem insertSectionBreakEvenPageItem1;
        private DevExpress.XtraRichEdit.UI.InsertSectionBreakOddPageItem insertSectionBreakOddPageItem1;
        private DevExpress.XtraRichEdit.UI.ChangeSectionLineNumberingItem changeSectionLineNumberingItem1;
        private DevExpress.XtraRichEdit.UI.SetSectionLineNumberingNoneItem setSectionLineNumberingNoneItem1;
        private DevExpress.XtraRichEdit.UI.SetSectionLineNumberingContinuousItem setSectionLineNumberingContinuousItem1;
        private DevExpress.XtraRichEdit.UI.SetSectionLineNumberingRestartNewPageItem setSectionLineNumberingRestartNewPageItem1;
        private DevExpress.XtraRichEdit.UI.SetSectionLineNumberingRestartNewSectionItem setSectionLineNumberingRestartNewSectionItem1;
        private DevExpress.XtraRichEdit.UI.ToggleParagraphSuppressLineNumbersItem toggleParagraphSuppressLineNumbersItem1;
        private DevExpress.XtraRichEdit.UI.ShowLineNumberingFormItem showLineNumberingFormItem1;
        private DevExpress.XtraRichEdit.UI.ChangeHyphenationOptionsItem changeHyphenationOptionsItem1;
        private DevExpress.XtraRichEdit.UI.SetHyphenateDocumentNoneItem setHyphenateDocumentNoneItem1;
        private DevExpress.XtraRichEdit.UI.SetHyphenateDocumentAutomaticItem setHyphenateDocumentAutomaticItem1;
        private DevExpress.XtraRichEdit.UI.ShowHyphenationOptionsFormItem showHyphenationOptionsFormItem1;
        private DevExpress.XtraRichEdit.UI.PageBackgroundBar pageBackgroundBar1;
        private DevExpress.XtraRichEdit.UI.ChangePageColorItem changePageColorItem1;
        private System.Windows.Forms.Panel panelAll;
        private DevExpress.XtraRichEdit.UI.RichEditBarController richEditBarController1;
        private DevExpress.XtraRichEdit.RichEditControl rtb;
        private EMRControlLib.RichTextBoxEx rtbAddress;
        private DevExpress.XtraRichEdit.RichEditControl rtbStatementOfFuneral;
    }
}