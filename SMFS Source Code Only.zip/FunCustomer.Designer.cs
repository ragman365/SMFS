﻿namespace SMFS
{
    partial class FunCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelAll = new System.Windows.Forms.Panel();
            this.panelVitals = new System.Windows.Forms.Panel();
            this.dgv6 = new DevExpress.XtraGrid.GridControl();
            this.gridMain6 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand5 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn86 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn87 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn88 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn89 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox8 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn90 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn91 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn92 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn93 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn3 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn1 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn2 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn94 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn97 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn95 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox10 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn96 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand7 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.gridBand8 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn98 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemPictureEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit();
            this.repositoryItemComboBox11 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repositoryItemComboBox12 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.panelTop = new System.Windows.Forms.Panel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.changeSSNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txtArrangementTime = new System.Windows.Forms.TextBox();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.txtFirstPayDate = new System.Windows.Forms.TextBox();
            this.lblFirstPayDate = new DevExpress.XtraEditors.LabelControl();
            this.txtArrangementDate = new System.Windows.Forms.TextBox();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnSaveAll = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtServiceDate = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.labelControl_namePrefix = new DevExpress.XtraEditors.LabelControl();
            this.labelControl_nameFirst = new DevExpress.XtraEditors.LabelControl();
            this.cmbPhoneQualifier2 = new System.Windows.Forms.ComboBox();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.txtPhone2 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl_nameMiddle = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl_nameLast = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl_nameSuffix = new DevExpress.XtraEditors.LabelControl();
            this.cmbPhoneQualifier1 = new System.Windows.Forms.ComboBox();
            this.txtBday = new System.Windows.Forms.TextBox();
            this.labelControl31 = new DevExpress.XtraEditors.LabelControl();
            this.txtPrefix = new System.Windows.Forms.TextBox();
            this.txtPhone1 = new DevExpress.XtraEditors.TextEdit();
            this.txtDOD = new System.Windows.Forms.TextBox();
            this.labelControl32 = new DevExpress.XtraEditors.LabelControl();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.cmbDelivery = new System.Windows.Forms.ComboBox();
            this.txtServiceId = new DevExpress.XtraEditors.TextEdit();
            this.lblDelivery = new DevExpress.XtraEditors.LabelControl();
            this.txtMiddleName = new System.Windows.Forms.TextBox();
            this.txtEmail = new DevExpress.XtraEditors.TextEdit();
            this.lblServiceId = new DevExpress.XtraEditors.LabelControl();
            this.lblEmail = new DevExpress.XtraEditors.LabelControl();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.groupBoxMailing = new System.Windows.Forms.GroupBox();
            this.chkSameAsHome = new System.Windows.Forms.CheckBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textEdit1 = new DevExpress.XtraEditors.TextEdit();
            this.textEdit2 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit3 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit4 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.txtSuffix = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbInsideCity = new System.Windows.Forms.ComboBox();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.txtCounty = new DevExpress.XtraEditors.TextEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.comboStates = new System.Windows.Forms.ComboBox();
            this.textEdit_patientZipCode = new DevExpress.XtraEditors.TextEdit();
            this.textEdit_patientAddressLine1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit_patientAddressLine2 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.textEdit_patientCity = new DevExpress.XtraEditors.TextEdit();
            this.labelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.dateDeceased = new DevExpress.XtraEditors.DateEdit();
            this.picDec = new System.Windows.Forms.PictureBox();
            this.dateDOB = new DevExpress.XtraEditors.DateEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.txtPreferedName = new System.Windows.Forms.TextBox();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.txtMaidenName = new System.Windows.Forms.TextBox();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.txtFullLegalName = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioFemale = new System.Windows.Forms.RadioButton();
            this.radioMale = new System.Windows.Forms.RadioButton();
            this.lblAge = new DevExpress.XtraEditors.LabelControl();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.labelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.txtSSN = new DevExpress.XtraEditors.TextEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.panelAll.SuspendLayout();
            this.panelVitals.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox12)).BeginInit();
            this.panelTop.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPhone2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPhone1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtServiceId.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmail.Properties)).BeginInit();
            this.groupBoxMailing.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit4.Properties)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtCounty.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit_patientZipCode.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit_patientAddressLine1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit_patientAddressLine2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit_patientCity.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDeceased.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDeceased.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDec)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDOB.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDOB.Properties)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSSN.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // panelAll
            // 
            this.panelAll.Controls.Add(this.panelVitals);
            this.panelAll.Controls.Add(this.panelTop);
            this.panelAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAll.Location = new System.Drawing.Point(0, 0);
            this.panelAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelAll.Name = "panelAll";
            this.panelAll.Size = new System.Drawing.Size(1554, 811);
            this.panelAll.TabIndex = 0;
            this.panelAll.Paint += new System.Windows.Forms.PaintEventHandler(this.panelAll_Paint);
            // 
            // panelVitals
            // 
            this.panelVitals.Controls.Add(this.dgv6);
            this.panelVitals.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelVitals.Location = new System.Drawing.Point(0, 398);
            this.panelVitals.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelVitals.Name = "panelVitals";
            this.panelVitals.Size = new System.Drawing.Size(1554, 413);
            this.panelVitals.TabIndex = 171;
            // 
            // dgv6
            // 
            this.dgv6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv6.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv6.Location = new System.Drawing.Point(0, 0);
            this.dgv6.LookAndFeel.SkinMaskColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.dgv6.LookAndFeel.SkinName = "The Asphalt World";
            this.dgv6.LookAndFeel.Style = DevExpress.LookAndFeel.LookAndFeelStyle.Style3D;
            this.dgv6.MainView = this.gridMain6;
            this.dgv6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv6.Name = "dgv6";
            this.dgv6.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit4,
            this.repositoryItemPictureEdit4,
            this.repositoryItemComboBox10,
            this.repositoryItemComboBox8,
            this.repositoryItemComboBox11,
            this.repositoryItemComboBox12});
            this.dgv6.Size = new System.Drawing.Size(1554, 413);
            this.dgv6.TabIndex = 9;
            this.dgv6.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain6});
            // 
            // gridMain6
            // 
            this.gridMain6.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain6.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain6.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain6.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain6.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain6.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain6.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain6.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain6.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain6.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain6.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain6.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain6.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain6.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain6.Appearance.EvenRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(231)))), ((int)(((byte)(234)))));
            this.gridMain6.Appearance.EvenRow.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMain6.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.EvenRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.EvenRow.Options.UseFont = true;
            this.gridMain6.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain6.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain6.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain6.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain6.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain6.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.FilterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(114)))), ((int)(((byte)(113)))));
            this.gridMain6.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain6.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain6.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain6.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(192)))), ((int)(((byte)(157)))));
            this.gridMain6.Appearance.FocusedRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(219)))), ((int)(((byte)(188)))));
            this.gridMain6.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.FocusedRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain6.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain6.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(179)))));
            this.gridMain6.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain6.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain6.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(242)))), ((int)(((byte)(213)))));
            this.gridMain6.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.GroupPanel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMain6.Appearance.GroupPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain6.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.GroupRow.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMain6.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain6.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.HeaderPanel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMain6.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain6.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain6.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain6.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(230)))), ((int)(((byte)(203)))));
            this.gridMain6.Appearance.HideSelectionRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(230)))), ((int)(((byte)(203)))));
            this.gridMain6.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.HideSelectionRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain6.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain6.Appearance.OddRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain6.Appearance.OddRow.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMain6.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.OddRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.OddRow.Options.UseFont = true;
            this.gridMain6.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(252)))), ((int)(((byte)(247)))));
            this.gridMain6.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain6.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(148)))), ((int)(((byte)(148)))));
            this.gridMain6.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain6.Appearance.Preview.Options.UseFont = true;
            this.gridMain6.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain6.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(244)))), ((int)(((byte)(236)))));
            this.gridMain6.Appearance.Row.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMain6.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.Row.Options.UseBackColor = true;
            this.gridMain6.Appearance.Row.Options.UseFont = true;
            this.gridMain6.Appearance.Row.Options.UseForeColor = true;
            this.gridMain6.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(232)))), ((int)(((byte)(201)))));
            this.gridMain6.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain6.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(215)))), ((int)(((byte)(188)))));
            this.gridMain6.Appearance.SelectedRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(230)))), ((int)(((byte)(203)))));
            this.gridMain6.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.SelectedRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(209)))), ((int)(((byte)(170)))));
            this.gridMain6.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain6.AppearancePrint.EvenRow.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMain6.AppearancePrint.EvenRow.Options.UseFont = true;
            this.gridMain6.AppearancePrint.GroupRow.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMain6.AppearancePrint.GroupRow.Options.UseFont = true;
            this.gridMain6.AppearancePrint.HeaderPanel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMain6.AppearancePrint.HeaderPanel.Options.UseFont = true;
            this.gridMain6.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain6.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain6.AppearancePrint.OddRow.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMain6.AppearancePrint.OddRow.Options.UseFont = true;
            this.gridMain6.AppearancePrint.Row.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridMain6.AppearancePrint.Row.Options.UseFont = true;
            this.gridMain6.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand5,
            this.gridBand7,
            this.gridBand8});
            this.gridMain6.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain6.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn86,
            this.bandedGridColumn98,
            this.bandedGridColumn93,
            this.bandedGridColumn92,
            this.bandedGridColumn90,
            this.bandedGridColumn95,
            this.bandedGridColumn96,
            this.bandedGridColumn88,
            this.bandedGridColumn87,
            this.bandedGridColumn91,
            this.bandedGridColumn97,
            this.bandedGridColumn89,
            this.bandedGridColumn94,
            this.bandedGridColumn1,
            this.bandedGridColumn2,
            this.bandedGridColumn3});
            this.gridMain6.DetailHeight = 431;
            this.gridMain6.GridControl = this.dgv6;
            this.gridMain6.GroupFormat = "[#image]{1} {2}";
            this.gridMain6.Name = "gridMain6";
            this.gridMain6.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain6.OptionsPrint.AllowMultilineHeaders = true;
            this.gridMain6.OptionsPrint.PrintBandHeader = false;
            this.gridMain6.OptionsView.ColumnAutoWidth = true;
            this.gridMain6.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain6.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain6.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain6.OptionsView.ShowBands = false;
            this.gridMain6.OptionsView.ShowGroupPanel = false;
            this.gridMain6.PaintStyleName = "Style3D";
            this.gridMain6.RowHeight = 4;
            this.gridMain6.ShownEditor += new System.EventHandler(this.gridMain6_ShownEditor);
            this.gridMain6.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMain6_CellValueChanged);
            this.gridMain6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gridMain6_KeyDown);
            this.gridMain6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.gridMain6_MouseDown);
            this.gridMain6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.gridMain6_MouseMove);
            this.gridMain6.DoubleClick += new System.EventHandler(this.gridMain6_DoubleClick);
            this.gridMain6.ValidatingEditor += new DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventHandler(this.gridMain6_ValidatingEditor);
            // 
            // gridBand5
            // 
            this.gridBand5.Caption = "gridBand1";
            this.gridBand5.Columns.Add(this.bandedGridColumn86);
            this.gridBand5.Columns.Add(this.bandedGridColumn87);
            this.gridBand5.Columns.Add(this.bandedGridColumn88);
            this.gridBand5.Columns.Add(this.bandedGridColumn89);
            this.gridBand5.Columns.Add(this.bandedGridColumn90);
            this.gridBand5.Columns.Add(this.bandedGridColumn91);
            this.gridBand5.Columns.Add(this.bandedGridColumn92);
            this.gridBand5.Columns.Add(this.bandedGridColumn93);
            this.gridBand5.Columns.Add(this.bandedGridColumn3);
            this.gridBand5.Columns.Add(this.bandedGridColumn1);
            this.gridBand5.Columns.Add(this.bandedGridColumn2);
            this.gridBand5.Columns.Add(this.bandedGridColumn94);
            this.gridBand5.Columns.Add(this.bandedGridColumn97);
            this.gridBand5.Columns.Add(this.bandedGridColumn95);
            this.gridBand5.Columns.Add(this.bandedGridColumn96);
            this.gridBand5.MinWidth = 16;
            this.gridBand5.Name = "gridBand5";
            this.gridBand5.VisibleIndex = 0;
            this.gridBand5.Width = 1620;
            // 
            // bandedGridColumn86
            // 
            this.bandedGridColumn86.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bandedGridColumn86.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn86.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bandedGridColumn86.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn86.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn86.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn86.Caption = "Num";
            this.bandedGridColumn86.FieldName = "num";
            this.bandedGridColumn86.MinWidth = 31;
            this.bandedGridColumn86.Name = "bandedGridColumn86";
            this.bandedGridColumn86.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn86.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn86.Visible = true;
            this.bandedGridColumn86.Width = 93;
            // 
            // bandedGridColumn87
            // 
            this.bandedGridColumn87.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn87.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn87.Caption = "Date Added";
            this.bandedGridColumn87.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn87.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn87.FieldName = "dateAdded";
            this.bandedGridColumn87.MinWidth = 31;
            this.bandedGridColumn87.Name = "bandedGridColumn87";
            this.bandedGridColumn87.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn87.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn87.Width = 118;
            // 
            // bandedGridColumn88
            // 
            this.bandedGridColumn88.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn88.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn88.Caption = "User";
            this.bandedGridColumn88.FieldName = "user";
            this.bandedGridColumn88.MinWidth = 31;
            this.bandedGridColumn88.Name = "bandedGridColumn88";
            this.bandedGridColumn88.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn88.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn88.Width = 118;
            // 
            // bandedGridColumn89
            // 
            this.bandedGridColumn89.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn89.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn89.Caption = "Status";
            this.bandedGridColumn89.ColumnEdit = this.repositoryItemComboBox8;
            this.bandedGridColumn89.FieldName = "status";
            this.bandedGridColumn89.MinWidth = 31;
            this.bandedGridColumn89.Name = "bandedGridColumn89";
            this.bandedGridColumn89.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn89.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn89.Width = 118;
            // 
            // repositoryItemComboBox8
            // 
            this.repositoryItemComboBox8.AutoHeight = false;
            this.repositoryItemComboBox8.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox8.Items.AddRange(new object[] {
            "Active",
            "Inactive"});
            this.repositoryItemComboBox8.Name = "repositoryItemComboBox8";
            this.repositoryItemComboBox8.PopupFormSize = new System.Drawing.Size(117, 62);
            // 
            // bandedGridColumn90
            // 
            this.bandedGridColumn90.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn90.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn90.Caption = "Group";
            this.bandedGridColumn90.FieldName = "group";
            this.bandedGridColumn90.MinWidth = 31;
            this.bandedGridColumn90.Name = "bandedGridColumn90";
            this.bandedGridColumn90.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn90.Width = 198;
            // 
            // bandedGridColumn91
            // 
            this.bandedGridColumn91.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn91.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn91.Caption = "Qualify";
            this.bandedGridColumn91.FieldName = "qualify";
            this.bandedGridColumn91.MinWidth = 31;
            this.bandedGridColumn91.Name = "bandedGridColumn91";
            this.bandedGridColumn91.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn91.Width = 118;
            // 
            // bandedGridColumn92
            // 
            this.bandedGridColumn92.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn92.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn92.Caption = "DB Field";
            this.bandedGridColumn92.FieldName = "dbfield";
            this.bandedGridColumn92.MinWidth = 31;
            this.bandedGridColumn92.Name = "bandedGridColumn92";
            this.bandedGridColumn92.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn92.Width = 198;
            // 
            // bandedGridColumn93
            // 
            this.bandedGridColumn93.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bandedGridColumn93.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn93.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bandedGridColumn93.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn93.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn93.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn93.Caption = "Field Name";
            this.bandedGridColumn93.FieldName = "field";
            this.bandedGridColumn93.MinWidth = 31;
            this.bandedGridColumn93.Name = "bandedGridColumn93";
            this.bandedGridColumn93.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn93.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn93.Visible = true;
            this.bandedGridColumn93.Width = 430;
            // 
            // bandedGridColumn3
            // 
            this.bandedGridColumn3.Caption = "T";
            this.bandedGridColumn3.FieldName = "tracking";
            this.bandedGridColumn3.MinWidth = 31;
            this.bandedGridColumn3.Name = "bandedGridColumn3";
            this.bandedGridColumn3.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn3.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn3.Visible = true;
            this.bandedGridColumn3.Width = 48;
            // 
            // bandedGridColumn1
            // 
            this.bandedGridColumn1.Caption = "A";
            this.bandedGridColumn1.FieldName = "add";
            this.bandedGridColumn1.MinWidth = 31;
            this.bandedGridColumn1.Name = "bandedGridColumn1";
            this.bandedGridColumn1.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn1.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn1.Visible = true;
            this.bandedGridColumn1.Width = 48;
            // 
            // bandedGridColumn2
            // 
            this.bandedGridColumn2.Caption = "E";
            this.bandedGridColumn2.FieldName = "edit";
            this.bandedGridColumn2.MinWidth = 31;
            this.bandedGridColumn2.Name = "bandedGridColumn2";
            this.bandedGridColumn2.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn2.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn2.Visible = true;
            this.bandedGridColumn2.Width = 48;
            // 
            // bandedGridColumn94
            // 
            this.bandedGridColumn94.AppearanceCell.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bandedGridColumn94.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn94.AppearanceHeader.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bandedGridColumn94.AppearanceHeader.Options.UseFont = true;
            this.bandedGridColumn94.Caption = "Data";
            this.bandedGridColumn94.FieldName = "data";
            this.bandedGridColumn94.MinWidth = 31;
            this.bandedGridColumn94.Name = "bandedGridColumn94";
            this.bandedGridColumn94.Visible = true;
            this.bandedGridColumn94.Width = 553;
            // 
            // bandedGridColumn97
            // 
            this.bandedGridColumn97.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn97.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn97.Caption = "Help";
            this.bandedGridColumn97.FieldName = "help";
            this.bandedGridColumn97.MinWidth = 31;
            this.bandedGridColumn97.Name = "bandedGridColumn97";
            this.bandedGridColumn97.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn97.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn97.Visible = true;
            this.bandedGridColumn97.Width = 400;
            // 
            // bandedGridColumn95
            // 
            this.bandedGridColumn95.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn95.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn95.Caption = "Type";
            this.bandedGridColumn95.ColumnEdit = this.repositoryItemComboBox10;
            this.bandedGridColumn95.FieldName = "type";
            this.bandedGridColumn95.MinWidth = 31;
            this.bandedGridColumn95.Name = "bandedGridColumn95";
            this.bandedGridColumn95.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn95.Width = 118;
            // 
            // repositoryItemComboBox10
            // 
            this.repositoryItemComboBox10.AutoHeight = false;
            this.repositoryItemComboBox10.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.repositoryItemComboBox10.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox10.Items.AddRange(new object[] {
            "Text",
            "Numeric",
            "Double",
            "Date"});
            this.repositoryItemComboBox10.Name = "repositoryItemComboBox10";
            this.repositoryItemComboBox10.PopupFormSize = new System.Drawing.Size(117, 123);
            this.repositoryItemComboBox10.PopupSizeable = true;
            // 
            // bandedGridColumn96
            // 
            this.bandedGridColumn96.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn96.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn96.Caption = "Length";
            this.bandedGridColumn96.FieldName = "length";
            this.bandedGridColumn96.MinWidth = 31;
            this.bandedGridColumn96.Name = "bandedGridColumn96";
            this.bandedGridColumn96.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn96.Width = 118;
            // 
            // gridBand7
            // 
            this.gridBand7.Caption = "gridBand2";
            this.gridBand7.MinWidth = 16;
            this.gridBand7.Name = "gridBand7";
            this.gridBand7.Visible = false;
            this.gridBand7.VisibleIndex = -1;
            this.gridBand7.Width = 85;
            // 
            // gridBand8
            // 
            this.gridBand8.Caption = "gridBand3";
            this.gridBand8.MinWidth = 16;
            this.gridBand8.Name = "gridBand8";
            this.gridBand8.Visible = false;
            this.gridBand8.VisibleIndex = -1;
            this.gridBand8.Width = 107;
            // 
            // bandedGridColumn98
            // 
            this.bandedGridColumn98.Caption = "record";
            this.bandedGridColumn98.FieldName = "record";
            this.bandedGridColumn98.MinWidth = 31;
            this.bandedGridColumn98.Name = "bandedGridColumn98";
            this.bandedGridColumn98.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn98.Width = 118;
            // 
            // repositoryItemCheckEdit4
            // 
            this.repositoryItemCheckEdit4.AutoHeight = false;
            this.repositoryItemCheckEdit4.Name = "repositoryItemCheckEdit4";
            // 
            // repositoryItemPictureEdit4
            // 
            this.repositoryItemPictureEdit4.Name = "repositoryItemPictureEdit4";
            this.repositoryItemPictureEdit4.PictureAlignment = System.Drawing.ContentAlignment.TopCenter;
            this.repositoryItemPictureEdit4.PictureStoreMode = DevExpress.XtraEditors.Controls.PictureStoreMode.Image;
            this.repositoryItemPictureEdit4.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch;
            // 
            // repositoryItemComboBox11
            // 
            this.repositoryItemComboBox11.AutoHeight = false;
            this.repositoryItemComboBox11.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox11.Items.AddRange(new object[] {
            "customers",
            "cust_extended",
            "contracts",
            "funeralhomes",
            "relatives"});
            this.repositoryItemComboBox11.Name = "repositoryItemComboBox11";
            // 
            // repositoryItemComboBox12
            // 
            this.repositoryItemComboBox12.AutoHeight = false;
            this.repositoryItemComboBox12.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox12.Name = "repositoryItemComboBox12";
            // 
            // panelTop
            // 
            this.panelTop.ContextMenuStrip = this.contextMenuStrip1;
            this.panelTop.Controls.Add(this.textBox1);
            this.panelTop.Controls.Add(this.txtArrangementTime);
            this.panelTop.Controls.Add(this.labelControl17);
            this.panelTop.Controls.Add(this.txtFirstPayDate);
            this.panelTop.Controls.Add(this.lblFirstPayDate);
            this.panelTop.Controls.Add(this.txtArrangementDate);
            this.panelTop.Controls.Add(this.labelControl15);
            this.panelTop.Controls.Add(this.pictureBox1);
            this.panelTop.Controls.Add(this.btnSaveAll);
            this.panelTop.Controls.Add(this.label1);
            this.panelTop.Controls.Add(this.txtServiceDate);
            this.panelTop.Controls.Add(this.label2);
            this.panelTop.Controls.Add(this.labelControl_namePrefix);
            this.panelTop.Controls.Add(this.labelControl_nameFirst);
            this.panelTop.Controls.Add(this.cmbPhoneQualifier2);
            this.panelTop.Controls.Add(this.labelControl9);
            this.panelTop.Controls.Add(this.txtPhone2);
            this.panelTop.Controls.Add(this.labelControl_nameMiddle);
            this.panelTop.Controls.Add(this.labelControl12);
            this.panelTop.Controls.Add(this.labelControl_nameLast);
            this.panelTop.Controls.Add(this.labelControl11);
            this.panelTop.Controls.Add(this.labelControl_nameSuffix);
            this.panelTop.Controls.Add(this.cmbPhoneQualifier1);
            this.panelTop.Controls.Add(this.txtBday);
            this.panelTop.Controls.Add(this.labelControl31);
            this.panelTop.Controls.Add(this.txtPrefix);
            this.panelTop.Controls.Add(this.txtPhone1);
            this.panelTop.Controls.Add(this.txtDOD);
            this.panelTop.Controls.Add(this.labelControl32);
            this.panelTop.Controls.Add(this.txtFirstName);
            this.panelTop.Controls.Add(this.cmbDelivery);
            this.panelTop.Controls.Add(this.txtServiceId);
            this.panelTop.Controls.Add(this.lblDelivery);
            this.panelTop.Controls.Add(this.txtMiddleName);
            this.panelTop.Controls.Add(this.txtEmail);
            this.panelTop.Controls.Add(this.lblServiceId);
            this.panelTop.Controls.Add(this.lblEmail);
            this.panelTop.Controls.Add(this.txtLastName);
            this.panelTop.Controls.Add(this.groupBoxMailing);
            this.panelTop.Controls.Add(this.txtSuffix);
            this.panelTop.Controls.Add(this.groupBox2);
            this.panelTop.Controls.Add(this.dateDeceased);
            this.panelTop.Controls.Add(this.picDec);
            this.panelTop.Controls.Add(this.dateDOB);
            this.panelTop.Controls.Add(this.labelControl1);
            this.panelTop.Controls.Add(this.txtPreferedName);
            this.panelTop.Controls.Add(this.labelControl3);
            this.panelTop.Controls.Add(this.txtMaidenName);
            this.panelTop.Controls.Add(this.labelControl2);
            this.panelTop.Controls.Add(this.txtFullLegalName);
            this.panelTop.Controls.Add(this.groupBox1);
            this.panelTop.Controls.Add(this.lblAge);
            this.panelTop.Controls.Add(this.txtAge);
            this.panelTop.Controls.Add(this.labelControl21);
            this.panelTop.Controls.Add(this.txtSSN);
            this.panelTop.Controls.Add(this.labelControl16);
            this.panelTop.Controls.Add(this.labelControl14);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1554, 398);
            this.panelTop.TabIndex = 178;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changeSSNToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(160, 28);
            // 
            // changeSSNToolStripMenuItem
            // 
            this.changeSSNToolStripMenuItem.Name = "changeSSNToolStripMenuItem";
            this.changeSSNToolStripMenuItem.Size = new System.Drawing.Size(159, 24);
            this.changeSSNToolStripMenuItem.Text = "Change SSN";
            this.changeSSNToolStripMenuItem.Click += new System.EventHandler(this.changeSSNToolStripMenuItem_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(1106, 358);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(199, 23);
            this.textBox1.TabIndex = 185;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtArrangementTime
            // 
            this.txtArrangementTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtArrangementTime.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArrangementTime.Location = new System.Drawing.Point(1381, 231);
            this.txtArrangementTime.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtArrangementTime.Name = "txtArrangementTime";
            this.txtArrangementTime.Size = new System.Drawing.Size(138, 25);
            this.txtArrangementTime.TabIndex = 184;
            this.txtArrangementTime.TextChanged += new System.EventHandler(this.txtArrangementTime_TextChanged);
            this.txtArrangementTime.Leave += new System.EventHandler(this.txtArrangementTime_Leave);
            // 
            // labelControl17
            // 
            this.labelControl17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControl17.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl17.Appearance.Options.UseFont = true;
            this.labelControl17.Location = new System.Drawing.Point(1381, 208);
            this.labelControl17.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(135, 19);
            this.labelControl17.TabIndex = 183;
            this.labelControl17.Text = "Time of Arrangement :";
            this.labelControl17.ToolTip = "Enter Time of Arrangement";
            // 
            // txtFirstPayDate
            // 
            this.txtFirstPayDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFirstPayDate.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFirstPayDate.Location = new System.Drawing.Point(1381, 287);
            this.txtFirstPayDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtFirstPayDate.Name = "txtFirstPayDate";
            this.txtFirstPayDate.Size = new System.Drawing.Size(138, 25);
            this.txtFirstPayDate.TabIndex = 182;
            this.txtFirstPayDate.TextChanged += new System.EventHandler(this.somethingChanged);
            this.txtFirstPayDate.Enter += new System.EventHandler(this.txtFirstPayDate_Enter);
            this.txtFirstPayDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtFirstPayDate_KeyDown);
            this.txtFirstPayDate.Leave += new System.EventHandler(this.txtFirstPayDate_Leave);
            // 
            // lblFirstPayDate
            // 
            this.lblFirstPayDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFirstPayDate.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstPayDate.Appearance.Options.UseFont = true;
            this.lblFirstPayDate.Location = new System.Drawing.Point(1381, 263);
            this.lblFirstPayDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.lblFirstPayDate.Name = "lblFirstPayDate";
            this.lblFirstPayDate.Size = new System.Drawing.Size(94, 19);
            this.lblFirstPayDate.TabIndex = 181;
            this.lblFirstPayDate.Text = "First Pay Date :";
            this.lblFirstPayDate.ToolTip = "Enter Date First Payment Was Made";
            // 
            // txtArrangementDate
            // 
            this.txtArrangementDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtArrangementDate.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArrangementDate.Location = new System.Drawing.Point(1381, 177);
            this.txtArrangementDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtArrangementDate.Name = "txtArrangementDate";
            this.txtArrangementDate.Size = new System.Drawing.Size(138, 25);
            this.txtArrangementDate.TabIndex = 180;
            this.txtArrangementDate.TextChanged += new System.EventHandler(this.somethingChanged);
            this.txtArrangementDate.Enter += new System.EventHandler(this.txtArrangementDate_Enter);
            this.txtArrangementDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtArrangementDate_KeyDown);
            this.txtArrangementDate.Leave += new System.EventHandler(this.txtArrangementDate_Leave);
            // 
            // labelControl15
            // 
            this.labelControl15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControl15.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl15.Appearance.Options.UseFont = true;
            this.labelControl15.Location = new System.Drawing.Point(1381, 154);
            this.labelControl15.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(134, 19);
            this.labelControl15.TabIndex = 179;
            this.labelControl15.Text = "Date of Arrangement :";
            this.labelControl15.ToolTip = "Enter Date of Arrangement";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SMFS.Properties.Resources.eyeball1;
            this.pictureBox1.Location = new System.Drawing.Point(622, 103);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(31, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 178;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btnSaveAll
            // 
            this.btnSaveAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSaveAll.BackColor = System.Drawing.Color.Lime;
            this.btnSaveAll.Location = new System.Drawing.Point(1350, 6);
            this.btnSaveAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSaveAll.Name = "btnSaveAll";
            this.btnSaveAll.Size = new System.Drawing.Size(87, 28);
            this.btnSaveAll.TabIndex = 172;
            this.btnSaveAll.Text = "Save All Members";
            this.btnSaveAll.UseVisualStyleBackColor = false;
            this.btnSaveAll.Click += new System.EventHandler(this.btnSaveAll_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 372);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(344, 17);
            this.label1.TabIndex = 174;
            this.label1.Text = "Extra Information i.e. 3rd Party Info : (250 Characters)";
            // 
            // txtServiceDate
            // 
            this.txtServiceDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtServiceDate.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtServiceDate.Location = new System.Drawing.Point(1381, 123);
            this.txtServiceDate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtServiceDate.Name = "txtServiceDate";
            this.txtServiceDate.Size = new System.Drawing.Size(138, 25);
            this.txtServiceDate.TabIndex = 176;
            this.txtServiceDate.TextChanged += new System.EventHandler(this.somethingChanged);
            this.txtServiceDate.Enter += new System.EventHandler(this.txtServiceDate_Enter);
            this.txtServiceDate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtServiceDate_KeyDown);
            this.txtServiceDate.Leave += new System.EventHandler(this.txtServiceDate_Leave);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1347, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 17);
            this.label2.TabIndex = 177;
            this.label2.Text = "<----Click to Add Picture";
            // 
            // labelControl_namePrefix
            // 
            this.labelControl_namePrefix.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl_namePrefix.Appearance.Options.UseFont = true;
            this.labelControl_namePrefix.Location = new System.Drawing.Point(9, 6);
            this.labelControl_namePrefix.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl_namePrefix.Name = "labelControl_namePrefix";
            this.labelControl_namePrefix.Size = new System.Drawing.Size(42, 19);
            this.labelControl_namePrefix.TabIndex = 127;
            this.labelControl_namePrefix.Text = "Prefix :";
            // 
            // labelControl_nameFirst
            // 
            this.labelControl_nameFirst.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl_nameFirst.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl_nameFirst.Appearance.Options.UseFont = true;
            this.labelControl_nameFirst.Appearance.Options.UseForeColor = true;
            this.labelControl_nameFirst.Location = new System.Drawing.Point(71, 6);
            this.labelControl_nameFirst.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl_nameFirst.Name = "labelControl_nameFirst";
            this.labelControl_nameFirst.Size = new System.Drawing.Size(75, 19);
            this.labelControl_nameFirst.TabIndex = 128;
            this.labelControl_nameFirst.Text = "First Name :";
            // 
            // cmbPhoneQualifier2
            // 
            this.cmbPhoneQualifier2.FormattingEnabled = true;
            this.cmbPhoneQualifier2.Items.AddRange(new object[] {
            "Cell",
            "Home",
            "Work"});
            this.cmbPhoneQualifier2.Location = new System.Drawing.Point(1003, 306);
            this.cmbPhoneQualifier2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbPhoneQualifier2.Name = "cmbPhoneQualifier2";
            this.cmbPhoneQualifier2.Size = new System.Drawing.Size(89, 24);
            this.cmbPhoneQualifier2.TabIndex = 166;
            this.cmbPhoneQualifier2.SelectedIndexChanged += new System.EventHandler(this.somethingChanged);
            // 
            // labelControl9
            // 
            this.labelControl9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControl9.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl9.Appearance.Options.UseFont = true;
            this.labelControl9.Location = new System.Drawing.Point(1381, 102);
            this.labelControl9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(85, 19);
            this.labelControl9.TabIndex = 175;
            this.labelControl9.Text = "Service Date :";
            this.labelControl9.ToolTip = "Enter Service Date";
            // 
            // txtPhone2
            // 
            this.txtPhone2.Location = new System.Drawing.Point(871, 306);
            this.txtPhone2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPhone2.Name = "txtPhone2";
            this.txtPhone2.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhone2.Properties.Appearance.Options.UseFont = true;
            this.txtPhone2.Properties.Mask.EditMask = "\\((\\d{3})\\)(\\d{3})-(\\d{4}) (x(\\d*))?";
            this.txtPhone2.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
            this.txtPhone2.Size = new System.Drawing.Size(119, 26);
            this.txtPhone2.TabIndex = 165;
            this.txtPhone2.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // labelControl_nameMiddle
            // 
            this.labelControl_nameMiddle.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl_nameMiddle.Appearance.Options.UseFont = true;
            this.labelControl_nameMiddle.Location = new System.Drawing.Point(253, 6);
            this.labelControl_nameMiddle.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl_nameMiddle.Name = "labelControl_nameMiddle";
            this.labelControl_nameMiddle.Size = new System.Drawing.Size(91, 19);
            this.labelControl_nameMiddle.TabIndex = 129;
            this.labelControl_nameMiddle.Text = "Middle Name :";
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl12.Appearance.Options.UseFont = true;
            this.labelControl12.Location = new System.Drawing.Point(1003, 289);
            this.labelControl12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(80, 19);
            this.labelControl12.TabIndex = 164;
            this.labelControl12.Text = "Phone Type :";
            // 
            // labelControl_nameLast
            // 
            this.labelControl_nameLast.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl_nameLast.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl_nameLast.Appearance.Options.UseFont = true;
            this.labelControl_nameLast.Appearance.Options.UseForeColor = true;
            this.labelControl_nameLast.Location = new System.Drawing.Point(405, 6);
            this.labelControl_nameLast.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl_nameLast.Name = "labelControl_nameLast";
            this.labelControl_nameLast.Size = new System.Drawing.Size(74, 19);
            this.labelControl_nameLast.TabIndex = 130;
            this.labelControl_nameLast.Text = "Last Name :";
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl11.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl11.Appearance.Options.UseFont = true;
            this.labelControl11.Appearance.Options.UseForeColor = true;
            this.labelControl11.Location = new System.Drawing.Point(871, 288);
            this.labelControl11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(114, 19);
            this.labelControl11.TabIndex = 163;
            this.labelControl11.Text = "Secondary Phone :";
            // 
            // labelControl_nameSuffix
            // 
            this.labelControl_nameSuffix.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl_nameSuffix.Appearance.Options.UseFont = true;
            this.labelControl_nameSuffix.Location = new System.Drawing.Point(608, 6);
            this.labelControl_nameSuffix.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl_nameSuffix.Name = "labelControl_nameSuffix";
            this.labelControl_nameSuffix.Size = new System.Drawing.Size(41, 19);
            this.labelControl_nameSuffix.TabIndex = 131;
            this.labelControl_nameSuffix.Text = "Suffix :";
            // 
            // cmbPhoneQualifier1
            // 
            this.cmbPhoneQualifier1.FormattingEnabled = true;
            this.cmbPhoneQualifier1.Items.AddRange(new object[] {
            "Cell",
            "Home",
            "Work"});
            this.cmbPhoneQualifier1.Location = new System.Drawing.Point(1003, 258);
            this.cmbPhoneQualifier1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbPhoneQualifier1.Name = "cmbPhoneQualifier1";
            this.cmbPhoneQualifier1.Size = new System.Drawing.Size(89, 24);
            this.cmbPhoneQualifier1.TabIndex = 162;
            this.cmbPhoneQualifier1.SelectedIndexChanged += new System.EventHandler(this.somethingChanged);
            // 
            // txtBday
            // 
            this.txtBday.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBday.Location = new System.Drawing.Point(661, 76);
            this.txtBday.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBday.Name = "txtBday";
            this.txtBday.Size = new System.Drawing.Size(129, 25);
            this.txtBday.TabIndex = 170;
            this.txtBday.Enter += new System.EventHandler(this.txtBday_Enter);
            this.txtBday.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBday_KeyDown);
            this.txtBday.Leave += new System.EventHandler(this.txtBday_Leave);
            // 
            // labelControl31
            // 
            this.labelControl31.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl31.Appearance.Options.UseFont = true;
            this.labelControl31.Location = new System.Drawing.Point(1003, 238);
            this.labelControl31.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl31.Name = "labelControl31";
            this.labelControl31.Size = new System.Drawing.Size(80, 19);
            this.labelControl31.TabIndex = 161;
            this.labelControl31.Text = "Phone Type :";
            // 
            // txtPrefix
            // 
            this.txtPrefix.Location = new System.Drawing.Point(9, 30);
            this.txtPrefix.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPrefix.Name = "txtPrefix";
            this.txtPrefix.Size = new System.Drawing.Size(54, 23);
            this.txtPrefix.TabIndex = 132;
            this.txtPrefix.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // txtPhone1
            // 
            this.txtPhone1.Location = new System.Drawing.Point(871, 258);
            this.txtPhone1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPhone1.Name = "txtPhone1";
            this.txtPhone1.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhone1.Properties.Appearance.Options.UseFont = true;
            this.txtPhone1.Properties.Mask.EditMask = "\\((\\d{3})\\)(\\d{3})-(\\d{4}) (x(\\d*))?";
            this.txtPhone1.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx;
            this.txtPhone1.Size = new System.Drawing.Size(119, 26);
            this.txtPhone1.TabIndex = 160;
            this.txtPhone1.EditValueChanged += new System.EventHandler(this.somethingChanged);
            // 
            // txtDOD
            // 
            this.txtDOD.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDOD.Location = new System.Drawing.Point(799, 76);
            this.txtDOD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtDOD.Name = "txtDOD";
            this.txtDOD.Size = new System.Drawing.Size(138, 25);
            this.txtDOD.TabIndex = 169;
            this.txtDOD.TextChanged += new System.EventHandler(this.somethingChanged);
            this.txtDOD.Enter += new System.EventHandler(this.txtDOD_Enter);
            this.txtDOD.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtDOD_KeyDown);
            this.txtDOD.Leave += new System.EventHandler(this.txtDOD_Leave);
            // 
            // labelControl32
            // 
            this.labelControl32.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl32.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl32.Appearance.Options.UseFont = true;
            this.labelControl32.Appearance.Options.UseForeColor = true;
            this.labelControl32.Location = new System.Drawing.Point(876, 238);
            this.labelControl32.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl32.Name = "labelControl32";
            this.labelControl32.Size = new System.Drawing.Size(96, 19);
            this.labelControl32.TabIndex = 159;
            this.labelControl32.Text = "Primary Phone :";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(69, 30);
            this.txtFirstName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(175, 23);
            this.txtFirstName.TabIndex = 133;
            this.txtFirstName.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // cmbDelivery
            // 
            this.cmbDelivery.FormattingEnabled = true;
            this.cmbDelivery.Items.AddRange(new object[] {
            "Mail",
            "Email"});
            this.cmbDelivery.Location = new System.Drawing.Point(871, 206);
            this.cmbDelivery.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbDelivery.Name = "cmbDelivery";
            this.cmbDelivery.Size = new System.Drawing.Size(118, 24);
            this.cmbDelivery.TabIndex = 158;
            this.cmbDelivery.Text = "Mail";
            this.cmbDelivery.SelectedIndexChanged += new System.EventHandler(this.somethingChanged);
            // 
            // txtServiceId
            // 
            this.txtServiceId.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtServiceId.Location = new System.Drawing.Point(1381, 75);
            this.txtServiceId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtServiceId.Name = "txtServiceId";
            this.txtServiceId.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtServiceId.Properties.Appearance.Options.UseFont = true;
            this.txtServiceId.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtServiceId.Size = new System.Drawing.Size(142, 26);
            this.txtServiceId.TabIndex = 168;
            this.txtServiceId.TextChanged += new System.EventHandler(this.somethingChanged);
            this.txtServiceId.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtServiceId_KeyDown);
            // 
            // lblDelivery
            // 
            this.lblDelivery.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDelivery.Appearance.Options.UseFont = true;
            this.lblDelivery.Location = new System.Drawing.Point(871, 183);
            this.lblDelivery.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.lblDelivery.Name = "lblDelivery";
            this.lblDelivery.Size = new System.Drawing.Size(118, 19);
            this.lblDelivery.TabIndex = 157;
            this.lblDelivery.Text = "Delivery Preferred :";
            // 
            // txtMiddleName
            // 
            this.txtMiddleName.Location = new System.Drawing.Point(253, 30);
            this.txtMiddleName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMiddleName.Name = "txtMiddleName";
            this.txtMiddleName.Size = new System.Drawing.Size(140, 23);
            this.txtMiddleName.TabIndex = 134;
            this.txtMiddleName.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(871, 149);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Properties.Appearance.Options.UseFont = true;
            this.txtEmail.Size = new System.Drawing.Size(204, 26);
            this.txtEmail.TabIndex = 155;
            this.txtEmail.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // lblServiceId
            // 
            this.lblServiceId.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblServiceId.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServiceId.Appearance.Options.UseFont = true;
            this.lblServiceId.Location = new System.Drawing.Point(1381, 57);
            this.lblServiceId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.lblServiceId.Name = "lblServiceId";
            this.lblServiceId.Size = new System.Drawing.Size(143, 19);
            this.lblServiceId.TabIndex = 167;
            this.lblServiceId.Text = "Service ID (Funeral #) :";
            this.lblServiceId.ToolTip = "Enter Service ID";
            // 
            // lblEmail
            // 
            this.lblEmail.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Appearance.Options.UseFont = true;
            this.lblEmail.Location = new System.Drawing.Point(871, 130);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(95, 19);
            this.lblEmail.TabIndex = 156;
            this.lblEmail.Text = "Email Address :";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(401, 30);
            this.txtLastName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(199, 23);
            this.txtLastName.TabIndex = 135;
            this.txtLastName.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // groupBoxMailing
            // 
            this.groupBoxMailing.Controls.Add(this.chkSameAsHome);
            this.groupBoxMailing.Controls.Add(this.comboBox1);
            this.groupBoxMailing.Controls.Add(this.textEdit1);
            this.groupBoxMailing.Controls.Add(this.textEdit2);
            this.groupBoxMailing.Controls.Add(this.labelControl4);
            this.groupBoxMailing.Controls.Add(this.textEdit3);
            this.groupBoxMailing.Controls.Add(this.labelControl5);
            this.groupBoxMailing.Controls.Add(this.labelControl6);
            this.groupBoxMailing.Controls.Add(this.textEdit4);
            this.groupBoxMailing.Controls.Add(this.labelControl7);
            this.groupBoxMailing.Controls.Add(this.labelControl8);
            this.groupBoxMailing.Location = new System.Drawing.Point(449, 130);
            this.groupBoxMailing.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxMailing.Name = "groupBoxMailing";
            this.groupBoxMailing.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxMailing.Size = new System.Drawing.Size(409, 201);
            this.groupBoxMailing.TabIndex = 154;
            this.groupBoxMailing.TabStop = false;
            this.groupBoxMailing.Text = "Mailing Address";
            // 
            // chkSameAsHome
            // 
            this.chkSameAsHome.AutoSize = true;
            this.chkSameAsHome.Location = new System.Drawing.Point(122, 25);
            this.chkSameAsHome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkSameAsHome.Name = "chkSameAsHome";
            this.chkSameAsHome.Size = new System.Drawing.Size(173, 21);
            this.chkSameAsHome.TabIndex = 136;
            this.chkSameAsHome.Text = "Same as Home Address";
            this.chkSameAsHome.UseVisualStyleBackColor = true;
            this.chkSameAsHome.Click += new System.EventHandler(this.somethingChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(131, 154);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(53, 24);
            this.comboBox1.TabIndex = 135;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.somethingChanged);
            // 
            // textEdit1
            // 
            this.textEdit1.Location = new System.Drawing.Point(198, 153);
            this.textEdit1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textEdit1.Name = "textEdit1";
            this.textEdit1.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEdit1.Properties.Appearance.Options.UseFont = true;
            this.textEdit1.Size = new System.Drawing.Size(125, 26);
            this.textEdit1.TabIndex = 134;
            this.textEdit1.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // textEdit2
            // 
            this.textEdit2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textEdit2.Location = new System.Drawing.Point(9, 49);
            this.textEdit2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textEdit2.Name = "textEdit2";
            this.textEdit2.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEdit2.Properties.Appearance.Options.UseFont = true;
            this.textEdit2.Properties.MaxLength = 35;
            this.textEdit2.Size = new System.Drawing.Size(376, 26);
            this.textEdit2.TabIndex = 131;
            this.textEdit2.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl4.Appearance.Options.UseFont = true;
            this.labelControl4.Location = new System.Drawing.Point(9, 28);
            this.labelControl4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(96, 19);
            this.labelControl4.TabIndex = 126;
            this.labelControl4.Text = "Address Line1 :";
            // 
            // textEdit3
            // 
            this.textEdit3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textEdit3.Location = new System.Drawing.Point(9, 103);
            this.textEdit3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textEdit3.Name = "textEdit3";
            this.textEdit3.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEdit3.Properties.Appearance.Options.UseFont = true;
            this.textEdit3.Properties.MaxLength = 35;
            this.textEdit3.Size = new System.Drawing.Size(376, 26);
            this.textEdit3.TabIndex = 132;
            this.textEdit3.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl5.Appearance.Options.UseFont = true;
            this.labelControl5.Location = new System.Drawing.Point(9, 82);
            this.labelControl5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(96, 19);
            this.labelControl5.TabIndex = 127;
            this.labelControl5.Text = "Address Line2 :";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl6.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl6.Appearance.Options.UseFont = true;
            this.labelControl6.Appearance.Options.UseForeColor = true;
            this.labelControl6.Location = new System.Drawing.Point(198, 135);
            this.labelControl6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(61, 19);
            this.labelControl6.TabIndex = 130;
            this.labelControl6.Text = "ZipCode :";
            // 
            // textEdit4
            // 
            this.textEdit4.Location = new System.Drawing.Point(9, 154);
            this.textEdit4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textEdit4.Name = "textEdit4";
            this.textEdit4.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEdit4.Properties.Appearance.Options.UseFont = true;
            this.textEdit4.Properties.MaxLength = 35;
            this.textEdit4.Size = new System.Drawing.Size(110, 26);
            this.textEdit4.TabIndex = 133;
            this.textEdit4.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl7.Appearance.Options.UseFont = true;
            this.labelControl7.Location = new System.Drawing.Point(9, 133);
            this.labelControl7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(32, 19);
            this.labelControl7.TabIndex = 128;
            this.labelControl7.Text = "City :";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl8.Appearance.Options.UseFont = true;
            this.labelControl8.Location = new System.Drawing.Point(131, 135);
            this.labelControl8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(38, 19);
            this.labelControl8.TabIndex = 129;
            this.labelControl8.Text = "State :";
            // 
            // txtSuffix
            // 
            this.txtSuffix.Location = new System.Drawing.Point(605, 30);
            this.txtSuffix.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSuffix.Name = "txtSuffix";
            this.txtSuffix.Size = new System.Drawing.Size(54, 23);
            this.txtSuffix.TabIndex = 136;
            this.txtSuffix.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cmbInsideCity);
            this.groupBox2.Controls.Add(this.labelControl13);
            this.groupBox2.Controls.Add(this.txtCounty);
            this.groupBox2.Controls.Add(this.labelControl10);
            this.groupBox2.Controls.Add(this.comboStates);
            this.groupBox2.Controls.Add(this.textEdit_patientZipCode);
            this.groupBox2.Controls.Add(this.textEdit_patientAddressLine1);
            this.groupBox2.Controls.Add(this.labelControl26);
            this.groupBox2.Controls.Add(this.textEdit_patientAddressLine2);
            this.groupBox2.Controls.Add(this.labelControl25);
            this.groupBox2.Controls.Add(this.labelControl22);
            this.groupBox2.Controls.Add(this.textEdit_patientCity);
            this.groupBox2.Controls.Add(this.labelControl24);
            this.groupBox2.Controls.Add(this.labelControl23);
            this.groupBox2.Location = new System.Drawing.Point(9, 130);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(409, 238);
            this.groupBox2.TabIndex = 153;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Home (Physical) Address";
            // 
            // cmbInsideCity
            // 
            this.cmbInsideCity.FormattingEnabled = true;
            this.cmbInsideCity.Items.AddRange(new object[] {
            "Yes",
            "No"});
            this.cmbInsideCity.Location = new System.Drawing.Point(241, 203);
            this.cmbInsideCity.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbInsideCity.Name = "cmbInsideCity";
            this.cmbInsideCity.Size = new System.Drawing.Size(61, 24);
            this.cmbInsideCity.TabIndex = 159;
            this.cmbInsideCity.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl13.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl13.Appearance.Options.UseFont = true;
            this.labelControl13.Appearance.Options.UseForeColor = true;
            this.labelControl13.Location = new System.Drawing.Point(198, 182);
            this.labelControl13.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(174, 19);
            this.labelControl13.TabIndex = 138;
            this.labelControl13.Text = "Inside City Limits (Yes/No) :";
            // 
            // txtCounty
            // 
            this.txtCounty.Location = new System.Drawing.Point(9, 203);
            this.txtCounty.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCounty.Name = "txtCounty";
            this.txtCounty.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCounty.Properties.Appearance.Options.UseFont = true;
            this.txtCounty.Properties.MaxLength = 35;
            this.txtCounty.Size = new System.Drawing.Size(175, 26);
            this.txtCounty.TabIndex = 137;
            this.txtCounty.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl10.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl10.Appearance.Options.UseFont = true;
            this.labelControl10.Appearance.Options.UseForeColor = true;
            this.labelControl10.Location = new System.Drawing.Point(9, 182);
            this.labelControl10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(51, 19);
            this.labelControl10.TabIndex = 136;
            this.labelControl10.Text = "County :";
            // 
            // comboStates
            // 
            this.comboStates.FormattingEnabled = true;
            this.comboStates.Location = new System.Drawing.Point(131, 154);
            this.comboStates.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.comboStates.Name = "comboStates";
            this.comboStates.Size = new System.Drawing.Size(53, 24);
            this.comboStates.TabIndex = 135;
            this.comboStates.SelectedIndexChanged += new System.EventHandler(this.somethingChanged);
            // 
            // textEdit_patientZipCode
            // 
            this.textEdit_patientZipCode.Location = new System.Drawing.Point(198, 153);
            this.textEdit_patientZipCode.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textEdit_patientZipCode.Name = "textEdit_patientZipCode";
            this.textEdit_patientZipCode.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEdit_patientZipCode.Properties.Appearance.Options.UseFont = true;
            this.textEdit_patientZipCode.Size = new System.Drawing.Size(125, 26);
            this.textEdit_patientZipCode.TabIndex = 134;
            this.textEdit_patientZipCode.EditValueChanged += new System.EventHandler(this.textEdit_patientZipCode_EditValueChanged);
            this.textEdit_patientZipCode.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // textEdit_patientAddressLine1
            // 
            this.textEdit_patientAddressLine1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textEdit_patientAddressLine1.Location = new System.Drawing.Point(8, 47);
            this.textEdit_patientAddressLine1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textEdit_patientAddressLine1.Name = "textEdit_patientAddressLine1";
            this.textEdit_patientAddressLine1.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEdit_patientAddressLine1.Properties.Appearance.Options.UseFont = true;
            this.textEdit_patientAddressLine1.Properties.MaxLength = 35;
            this.textEdit_patientAddressLine1.Size = new System.Drawing.Size(376, 26);
            this.textEdit_patientAddressLine1.TabIndex = 131;
            this.textEdit_patientAddressLine1.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // labelControl26
            // 
            this.labelControl26.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl26.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl26.Appearance.Options.UseFont = true;
            this.labelControl26.Appearance.Options.UseForeColor = true;
            this.labelControl26.Location = new System.Drawing.Point(9, 25);
            this.labelControl26.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl26.Name = "labelControl26";
            this.labelControl26.Size = new System.Drawing.Size(96, 19);
            this.labelControl26.TabIndex = 126;
            this.labelControl26.Text = "Address Line1 :";
            // 
            // textEdit_patientAddressLine2
            // 
            this.textEdit_patientAddressLine2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textEdit_patientAddressLine2.Location = new System.Drawing.Point(8, 102);
            this.textEdit_patientAddressLine2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textEdit_patientAddressLine2.Name = "textEdit_patientAddressLine2";
            this.textEdit_patientAddressLine2.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEdit_patientAddressLine2.Properties.Appearance.Options.UseFont = true;
            this.textEdit_patientAddressLine2.Properties.MaxLength = 35;
            this.textEdit_patientAddressLine2.Size = new System.Drawing.Size(376, 26);
            this.textEdit_patientAddressLine2.TabIndex = 132;
            this.textEdit_patientAddressLine2.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // labelControl25
            // 
            this.labelControl25.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl25.Appearance.Options.UseFont = true;
            this.labelControl25.Location = new System.Drawing.Point(9, 82);
            this.labelControl25.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl25.Name = "labelControl25";
            this.labelControl25.Size = new System.Drawing.Size(96, 19);
            this.labelControl25.TabIndex = 127;
            this.labelControl25.Text = "Address Line2 :";
            // 
            // labelControl22
            // 
            this.labelControl22.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl22.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl22.Appearance.Options.UseFont = true;
            this.labelControl22.Appearance.Options.UseForeColor = true;
            this.labelControl22.Location = new System.Drawing.Point(198, 135);
            this.labelControl22.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl22.Name = "labelControl22";
            this.labelControl22.Size = new System.Drawing.Size(61, 19);
            this.labelControl22.TabIndex = 130;
            this.labelControl22.Text = "ZipCode :";
            // 
            // textEdit_patientCity
            // 
            this.textEdit_patientCity.Location = new System.Drawing.Point(9, 154);
            this.textEdit_patientCity.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textEdit_patientCity.Name = "textEdit_patientCity";
            this.textEdit_patientCity.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textEdit_patientCity.Properties.Appearance.Options.UseFont = true;
            this.textEdit_patientCity.Properties.MaxLength = 35;
            this.textEdit_patientCity.Size = new System.Drawing.Size(110, 26);
            this.textEdit_patientCity.TabIndex = 133;
            this.textEdit_patientCity.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // labelControl24
            // 
            this.labelControl24.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl24.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl24.Appearance.Options.UseFont = true;
            this.labelControl24.Appearance.Options.UseForeColor = true;
            this.labelControl24.Location = new System.Drawing.Point(9, 133);
            this.labelControl24.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl24.Name = "labelControl24";
            this.labelControl24.Size = new System.Drawing.Size(32, 19);
            this.labelControl24.TabIndex = 128;
            this.labelControl24.Text = "City :";
            // 
            // labelControl23
            // 
            this.labelControl23.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl23.Appearance.ForeColor = System.Drawing.Color.Red;
            this.labelControl23.Appearance.Options.UseFont = true;
            this.labelControl23.Appearance.Options.UseForeColor = true;
            this.labelControl23.Location = new System.Drawing.Point(131, 135);
            this.labelControl23.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl23.Name = "labelControl23";
            this.labelControl23.Size = new System.Drawing.Size(38, 19);
            this.labelControl23.TabIndex = 129;
            this.labelControl23.Text = "State :";
            // 
            // dateDeceased
            // 
            this.dateDeceased.EditValue = null;
            this.dateDeceased.Location = new System.Drawing.Point(1143, 284);
            this.dateDeceased.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateDeceased.Name = "dateDeceased";
            this.dateDeceased.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateDeceased.Properties.Appearance.Options.UseFont = true;
            this.dateDeceased.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateDeceased.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateDeceased.Properties.Mask.EditMask = "mm/dd/yyyy";
            this.dateDeceased.Properties.MinValue = new System.DateTime(1, 1, 1, 0, 1, 0, 0);
            this.dateDeceased.Properties.NullDate = "01/01/0001 12:01 AM";
            this.dateDeceased.Properties.NullDateCalendarValue = new System.DateTime(1, 1, 1, 0, 1, 0, 0);
            this.dateDeceased.Size = new System.Drawing.Size(141, 26);
            this.dateDeceased.TabIndex = 151;
            this.dateDeceased.EditValueChanged += new System.EventHandler(this.dateDeceased_EditValueChanged);
            this.dateDeceased.TextChanged += new System.EventHandler(this.dateDeceased_TextChanged);
            this.dateDeceased.Enter += new System.EventHandler(this.dateDeceased_Enter);
            this.dateDeceased.Leave += new System.EventHandler(this.dateDeceased_Leave);
            // 
            // picDec
            // 
            this.picDec.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picDec.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picDec.Location = new System.Drawing.Point(1226, 4);
            this.picDec.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.picDec.Name = "picDec";
            this.picDec.Size = new System.Drawing.Size(105, 95);
            this.picDec.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picDec.TabIndex = 137;
            this.picDec.TabStop = false;
            this.picDec.Click += new System.EventHandler(this.picDec_Click);
            // 
            // dateDOB
            // 
            this.dateDOB.EditValue = null;
            this.dateDOB.Location = new System.Drawing.Point(1150, 318);
            this.dateDOB.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateDOB.Name = "dateDOB";
            this.dateDOB.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateDOB.Properties.Appearance.Options.UseFont = true;
            this.dateDOB.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.dateDOB.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.dateDOB.Properties.Mask.EditMask = "mm/dd/yyyy";
            this.dateDOB.Size = new System.Drawing.Size(132, 26);
            this.dateDOB.TabIndex = 149;
            this.dateDOB.EditValueChanged += new System.EventHandler(this.dateDOB_EditValueChanged);
            this.dateDOB.Enter += new System.EventHandler(this.dateDOB_Enter);
            this.dateDOB.Leave += new System.EventHandler(this.dateDOB_Leave);
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Appearance.Options.UseFont = true;
            this.labelControl1.Location = new System.Drawing.Point(712, 6);
            this.labelControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(105, 19);
            this.labelControl1.TabIndex = 138;
            this.labelControl1.Text = "Preferred Name :";
            // 
            // txtPreferedName
            // 
            this.txtPreferedName.Location = new System.Drawing.Point(712, 30);
            this.txtPreferedName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtPreferedName.Name = "txtPreferedName";
            this.txtPreferedName.Size = new System.Drawing.Size(140, 23);
            this.txtPreferedName.TabIndex = 139;
            this.txtPreferedName.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Appearance.Options.UseFont = true;
            this.labelControl3.Location = new System.Drawing.Point(871, 6);
            this.labelControl3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(94, 19);
            this.labelControl3.TabIndex = 147;
            this.labelControl3.Text = "Maiden Name :";
            // 
            // txtMaidenName
            // 
            this.txtMaidenName.Location = new System.Drawing.Point(871, 30);
            this.txtMaidenName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtMaidenName.Name = "txtMaidenName";
            this.txtMaidenName.Size = new System.Drawing.Size(140, 23);
            this.txtMaidenName.TabIndex = 148;
            this.txtMaidenName.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl2.Appearance.Options.UseFont = true;
            this.labelControl2.Location = new System.Drawing.Point(9, 62);
            this.labelControl2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(107, 19);
            this.labelControl2.TabIndex = 140;
            this.labelControl2.Text = "Full Legal Name :";
            // 
            // txtFullLegalName
            // 
            this.txtFullLegalName.Location = new System.Drawing.Point(9, 86);
            this.txtFullLegalName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtFullLegalName.Name = "txtFullLegalName";
            this.txtFullLegalName.Size = new System.Drawing.Size(322, 23);
            this.txtFullLegalName.TabIndex = 141;
            this.txtFullLegalName.TextChanged += new System.EventHandler(this.somethingChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioFemale);
            this.groupBox1.Controls.Add(this.radioMale);
            this.groupBox1.ForeColor = System.Drawing.Color.Red;
            this.groupBox1.Location = new System.Drawing.Point(341, 58);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(103, 71);
            this.groupBox1.TabIndex = 142;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Gender";
            // 
            // radioFemale
            // 
            this.radioFemale.AutoSize = true;
            this.radioFemale.ForeColor = System.Drawing.Color.Black;
            this.radioFemale.Location = new System.Drawing.Point(22, 43);
            this.radioFemale.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioFemale.Name = "radioFemale";
            this.radioFemale.Size = new System.Drawing.Size(71, 21);
            this.radioFemale.TabIndex = 1;
            this.radioFemale.TabStop = true;
            this.radioFemale.Text = "Female";
            this.radioFemale.UseVisualStyleBackColor = true;
            this.radioFemale.CheckedChanged += new System.EventHandler(this.somethingChanged);
            // 
            // radioMale
            // 
            this.radioMale.AutoSize = true;
            this.radioMale.ForeColor = System.Drawing.Color.Black;
            this.radioMale.Location = new System.Drawing.Point(22, 20);
            this.radioMale.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioMale.Name = "radioMale";
            this.radioMale.Size = new System.Drawing.Size(55, 21);
            this.radioMale.TabIndex = 0;
            this.radioMale.TabStop = true;
            this.radioMale.Text = "Male";
            this.radioMale.UseVisualStyleBackColor = true;
            this.radioMale.Click += new System.EventHandler(this.somethingChanged);
            // 
            // lblAge
            // 
            this.lblAge.Location = new System.Drawing.Point(946, 59);
            this.lblAge.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(31, 16);
            this.lblAge.TabIndex = 143;
            this.lblAge.Text = "Age :";
            // 
            // txtAge
            // 
            this.txtAge.Enabled = false;
            this.txtAge.Location = new System.Drawing.Point(944, 76);
            this.txtAge.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(38, 23);
            this.txtAge.TabIndex = 144;
            // 
            // labelControl21
            // 
            this.labelControl21.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl21.Appearance.Options.UseFont = true;
            this.labelControl21.Location = new System.Drawing.Point(449, 58);
            this.labelControl21.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl21.Name = "labelControl21";
            this.labelControl21.Size = new System.Drawing.Size(109, 19);
            this.labelControl21.TabIndex = 146;
            this.labelControl21.Text = "Social Security # :";
            // 
            // txtSSN
            // 
            this.txtSSN.Location = new System.Drawing.Point(449, 76);
            this.txtSSN.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSSN.Name = "txtSSN";
            this.txtSSN.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSSN.Properties.Appearance.Options.UseFont = true;
            this.txtSSN.Size = new System.Drawing.Size(204, 26);
            this.txtSSN.TabIndex = 145;
            this.txtSSN.EditValueChanged += new System.EventHandler(this.ssnChanged);
            this.txtSSN.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSSN_KeyUp);
            this.txtSSN.Leave += new System.EventHandler(this.txtSSN_Leave);
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl16.Appearance.ForeColor = System.Drawing.Color.Black;
            this.labelControl16.Appearance.Options.UseFont = true;
            this.labelControl16.Appearance.Options.UseForeColor = true;
            this.labelControl16.Location = new System.Drawing.Point(660, 59);
            this.labelControl16.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(69, 19);
            this.labelControl16.TabIndex = 150;
            this.labelControl16.Text = "Birth Date :";
            // 
            // labelControl14
            // 
            this.labelControl14.Appearance.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl14.Appearance.Options.UseFont = true;
            this.labelControl14.Location = new System.Drawing.Point(797, 59);
            this.labelControl14.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(100, 19);
            this.labelControl14.TabIndex = 152;
            this.labelControl14.Text = "Deceased Date :";
            // 
            // FunCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1554, 811);
            this.Controls.Add(this.panelAll);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FunCustomer";
            this.Text = "FunCustomer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FunCustomer_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FunCustomer_FormClosed);
            this.Load += new System.EventHandler(this.FunCustomer_Load);
            this.panelAll.ResumeLayout(false);
            this.panelVitals.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPictureEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox12)).EndInit();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPhone2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPhone1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtServiceId.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmail.Properties)).EndInit();
            this.groupBoxMailing.ResumeLayout(false);
            this.groupBoxMailing.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit4.Properties)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtCounty.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit_patientZipCode.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit_patientAddressLine1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit_patientAddressLine2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit_patientCity.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDeceased.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDeceased.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDec)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDOB.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dateDOB.Properties)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSSN.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelAll;
        private DevExpress.XtraEditors.TextEdit txtEmail;
        private DevExpress.XtraEditors.LabelControl lblEmail;
        private System.Windows.Forms.GroupBox groupBoxMailing;
        private System.Windows.Forms.CheckBox chkSameAsHome;
        private System.Windows.Forms.ComboBox comboBox1;
        private DevExpress.XtraEditors.TextEdit textEdit1;
        private DevExpress.XtraEditors.TextEdit textEdit2;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.TextEdit textEdit3;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.TextEdit textEdit4;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboStates;
        private DevExpress.XtraEditors.TextEdit textEdit_patientZipCode;
        private DevExpress.XtraEditors.TextEdit textEdit_patientAddressLine1;
        private DevExpress.XtraEditors.LabelControl labelControl26;
        private DevExpress.XtraEditors.TextEdit textEdit_patientAddressLine2;
        private DevExpress.XtraEditors.LabelControl labelControl25;
        private DevExpress.XtraEditors.LabelControl labelControl22;
        private DevExpress.XtraEditors.TextEdit textEdit_patientCity;
        private DevExpress.XtraEditors.LabelControl labelControl24;
        private DevExpress.XtraEditors.LabelControl labelControl23;
        private DevExpress.XtraEditors.DateEdit dateDeceased;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.DateEdit dateDOB;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private System.Windows.Forms.TextBox txtMaidenName;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.TextEdit txtSSN;
        private DevExpress.XtraEditors.LabelControl labelControl21;
        private System.Windows.Forms.TextBox txtAge;
        private DevExpress.XtraEditors.LabelControl lblAge;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioFemale;
        private System.Windows.Forms.RadioButton radioMale;
        private System.Windows.Forms.TextBox txtFullLegalName;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private System.Windows.Forms.TextBox txtPreferedName;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private System.Windows.Forms.PictureBox picDec;
        private System.Windows.Forms.TextBox txtSuffix;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtMiddleName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtPrefix;
        private DevExpress.XtraEditors.LabelControl labelControl_nameSuffix;
        private DevExpress.XtraEditors.LabelControl labelControl_nameLast;
        private DevExpress.XtraEditors.LabelControl labelControl_nameMiddle;
        private DevExpress.XtraEditors.LabelControl labelControl_nameFirst;
        private DevExpress.XtraEditors.LabelControl labelControl_namePrefix;
        private System.Windows.Forms.ComboBox cmbPhoneQualifier2;
        private DevExpress.XtraEditors.TextEdit txtPhone2;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private System.Windows.Forms.ComboBox cmbPhoneQualifier1;
        private DevExpress.XtraEditors.LabelControl labelControl31;
        private DevExpress.XtraEditors.TextEdit txtPhone1;
        private DevExpress.XtraEditors.LabelControl labelControl32;
        private System.Windows.Forms.ComboBox cmbDelivery;
        private DevExpress.XtraEditors.LabelControl lblDelivery;
        private DevExpress.XtraEditors.TextEdit txtServiceId;
        private DevExpress.XtraEditors.LabelControl lblServiceId;
        private System.Windows.Forms.TextBox txtDOD;
        private System.Windows.Forms.TextBox txtBday;
        private System.Windows.Forms.Panel panelVitals;
        private DevExpress.XtraGrid.GridControl dgv6;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn86;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn87;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn88;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn89;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn90;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn91;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn92;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn93;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn94;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn97;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn95;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn96;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn98;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit4;
        private DevExpress.XtraEditors.Repository.RepositoryItemPictureEdit repositoryItemPictureEdit4;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox11;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox12;
        private System.Windows.Forms.Button btnSaveAll;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn2;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn3;
        private System.Windows.Forms.TextBox txtServiceDate;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panelTop;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand5;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand7;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand8;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevExpress.XtraEditors.TextEdit txtCounty;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private System.Windows.Forms.ComboBox cmbInsideCity;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private System.Windows.Forms.TextBox txtArrangementDate;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private System.Windows.Forms.TextBox txtFirstPayDate;
        private DevExpress.XtraEditors.LabelControl lblFirstPayDate;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private System.Windows.Forms.TextBox txtArrangementTime;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem changeSSNToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
    }
}