﻿namespace SMFS
{
    partial class Customers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customers));
            this.panelAll = new System.Windows.Forms.Panel();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.dgv2 = new DevExpress.XtraGrid.GridControl();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItemSetLapsed = new System.Windows.Forms.ToolStripMenuItem();
            this.attachAgreementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.detachAgreementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showSimpleSummaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.changeContractNumberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteContractToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gridMain2 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand3 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn36 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn37 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn38 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn39 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand4 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn40 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.bandedGridColumn41 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn42 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn43 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn44 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn59 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn60 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn53 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn51 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn81 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn45 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn47 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn48 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn49 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn77 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn46 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn50 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn52 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn54 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn55 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn56 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn58 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn61 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn62 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn63 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn64 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn65 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn66 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn67 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn68 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn69 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn70 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn71 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn72 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.bandedGridColumn73 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn74 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.dgv = new DevExpress.XtraGrid.GridControl();
            this.gridMain = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand2 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.Num = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn34 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.contractNumber = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn76 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn32 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand1 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn12 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.bandedGridColumn10 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn8 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.firstName = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn2 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.ssn = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn3 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn13 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn57 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn14 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn22 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn26 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn75 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn15 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn78 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn31 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn16 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn23 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn20 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn11 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn21 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn33 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn5 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn4 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn17 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn35 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn27 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn28 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn29 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn30 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn9 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn80 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn82 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn83 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn79 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn24 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn25 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn18 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn19 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn6 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.bandedGridColumn1 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn7 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelTop = new System.Windows.Forms.Panel();
            this.chkDownPayment = new System.Windows.Forms.CheckBox();
            this.btnFixInt = new System.Windows.Forms.Button();
            this.chkLessZero = new System.Windows.Forms.CheckBox();
            this.chkSortLastName = new System.Windows.Forms.CheckBox();
            this.cmbQualify = new System.Windows.Forms.ComboBox();
            this.chkMismatchDates = new System.Windows.Forms.CheckBox();
            this.cmbSelectColumns = new System.Windows.Forms.ComboBox();
            this.btnSelectColumns = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.chkMismatches = new System.Windows.Forms.CheckBox();
            this.txtThreshold = new System.Windows.Forms.TextBox();
            this.btnDOLP = new System.Windows.Forms.Button();
            this.cmbType = new System.Windows.Forms.ComboBox();
            this.barImport = new System.Windows.Forms.ProgressBar();
            this.btnRecalc = new System.Windows.Forms.Button();
            this.chkIncludePaid = new System.Windows.Forms.CheckBox();
            this.labValue = new System.Windows.Forms.Label();
            this.labelValue = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuPrint = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.columnsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importDailyDepositFileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.importACHFileToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.importCreditCardPaymentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miscToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quickLookupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.previousContractsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yearendReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yearendDeathReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.potentialPaidOffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trust85ReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.genericPaymentsReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trustEOMReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportPaymentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paidUpContractsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuRemovalReport = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentsAfterDeathToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.downPaymentsReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.debitsAndCreditsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuUnityReport = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTrustReports = new System.Windows.Forms.ToolStripMenuItem();
            this.menuDeceasedReport = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.allActivityReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activeOnlyReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.balancesPaymentsReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.balancesXReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.massLapseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historicCommissionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feeAllocationReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.byAgentMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.byDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miscellaneousReportsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.lockBoxDepositReportMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.stopBreakReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trustSummaryReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contractsLessThan2039ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mailingLabelsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showForcedPaidOffContractsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verifyTrustBBWithDailyHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.activeContractsByLocationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.monthlyUnityProcessMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.trustTotalsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trustInterest15ReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trustContractsWODemographicsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verificationModuleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insuranceReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.weekTotalsReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lapseReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dailyDepositReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.collectionReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insuranceSummaryReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thirdPartyDumpReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuEarlySecNatPayments = new System.Windows.Forms.ToolStripMenuItem();
            this.menuGenerateInsuranceCoupons = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSecurityNational = new System.Windows.Forms.ToolStripMenuItem();
            this.mailingLabelsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuSecNatNotices = new System.Windows.Forms.ToolStripMenuItem();
            this.findConflictingDeceasedPoliciesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.findProblemInsurancePaymentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.findMismatchedPayersPoliciesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editTrustDownPaymentsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.verifyLocationPaymentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trustCompanyDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.commonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bankPaymentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelAll.SuspendLayout();
            this.panelBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelAll
            // 
            this.panelAll.Controls.Add(this.panelBottom);
            this.panelAll.Controls.Add(this.panelTop);
            this.panelAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAll.Location = new System.Drawing.Point(0, 30);
            this.panelAll.Margin = new System.Windows.Forms.Padding(4);
            this.panelAll.Name = "panelAll";
            this.panelAll.Size = new System.Drawing.Size(1674, 529);
            this.panelAll.TabIndex = 0;
            // 
            // panelBottom
            // 
            this.panelBottom.Controls.Add(this.dgv2);
            this.panelBottom.Controls.Add(this.dgv);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBottom.Location = new System.Drawing.Point(0, 77);
            this.panelBottom.Margin = new System.Windows.Forms.Padding(4);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(1674, 452);
            this.panelBottom.TabIndex = 2;
            // 
            // dgv2
            // 
            this.dgv2.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv2.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4);
            this.dgv2.Location = new System.Drawing.Point(729, 30);
            this.dgv2.LookAndFeel.SkinName = "Stardust";
            this.dgv2.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv2.MainView = this.gridMain2;
            this.dgv2.Margin = new System.Windows.Forms.Padding(4);
            this.dgv2.Name = "dgv2";
            this.dgv2.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit4,
            this.repositoryItemCheckEdit3});
            this.dgv2.Size = new System.Drawing.Size(643, 350);
            this.dgv2.TabIndex = 3;
            this.dgv2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain2});
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItemSetLapsed,
            this.attachAgreementToolStripMenuItem,
            this.detachAgreementToolStripMenuItem,
            this.showSimpleSummaryToolStripMenuItem,
            this.toolStripMenuItem5,
            this.changeContractNumberToolStripMenuItem,
            this.deleteContractToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(247, 220);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(246, 24);
            this.toolStripMenuItem2.Text = "Reinstate Customer";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(246, 24);
            this.toolStripMenuItem3.Text = "Clear Lapsed";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // toolStripMenuItemSetLapsed
            // 
            this.toolStripMenuItemSetLapsed.Name = "toolStripMenuItemSetLapsed";
            this.toolStripMenuItemSetLapsed.Size = new System.Drawing.Size(246, 24);
            this.toolStripMenuItemSetLapsed.Text = "Set Lapsed";
            this.toolStripMenuItemSetLapsed.Click += new System.EventHandler(this.toolStripMenuItemSetLapsed_Click);
            // 
            // attachAgreementToolStripMenuItem
            // 
            this.attachAgreementToolStripMenuItem.Name = "attachAgreementToolStripMenuItem";
            this.attachAgreementToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.attachAgreementToolStripMenuItem.Text = "Attach Agreement";
            this.attachAgreementToolStripMenuItem.Click += new System.EventHandler(this.attachAgreementToolStripMenuItem_Click);
            // 
            // detachAgreementToolStripMenuItem
            // 
            this.detachAgreementToolStripMenuItem.Name = "detachAgreementToolStripMenuItem";
            this.detachAgreementToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.detachAgreementToolStripMenuItem.Text = "Detach Agreement";
            this.detachAgreementToolStripMenuItem.Click += new System.EventHandler(this.detachAgreementToolStripMenuItem_Click);
            // 
            // showSimpleSummaryToolStripMenuItem
            // 
            this.showSimpleSummaryToolStripMenuItem.Name = "showSimpleSummaryToolStripMenuItem";
            this.showSimpleSummaryToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.showSimpleSummaryToolStripMenuItem.Text = "Show Simple Summary";
            this.showSimpleSummaryToolStripMenuItem.Click += new System.EventHandler(this.showSimpleSummaryToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(246, 24);
            this.toolStripMenuItem5.Text = "Test Manual Payment";
            this.toolStripMenuItem5.Click += new System.EventHandler(this.toolStripMenuItem5_Click);
            // 
            // changeContractNumberToolStripMenuItem
            // 
            this.changeContractNumberToolStripMenuItem.Name = "changeContractNumberToolStripMenuItem";
            this.changeContractNumberToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.changeContractNumberToolStripMenuItem.Text = "Change Contract Number";
            this.changeContractNumberToolStripMenuItem.Click += new System.EventHandler(this.changeContractNumberToolStripMenuItem_Click);
            // 
            // deleteContractToolStripMenuItem
            // 
            this.deleteContractToolStripMenuItem.Name = "deleteContractToolStripMenuItem";
            this.deleteContractToolStripMenuItem.Size = new System.Drawing.Size(246, 24);
            this.deleteContractToolStripMenuItem.Text = "Delete Contract";
            this.deleteContractToolStripMenuItem.Click += new System.EventHandler(this.deleteContractToolStripMenuItem_Click);
            // 
            // gridMain2
            // 
            this.gridMain2.Appearance.EvenRow.BackColor = System.Drawing.Color.Cyan;
            this.gridMain2.Appearance.FocusedRow.BackColor = System.Drawing.Color.Yellow;
            this.gridMain2.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.OddRow.BackColor = System.Drawing.Color.Azure;
            this.gridMain2.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand3,
            this.gridBand4});
            this.gridMain2.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain2.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn36,
            this.bandedGridColumn73,
            this.bandedGridColumn38,
            this.bandedGridColumn42,
            this.bandedGridColumn43,
            this.bandedGridColumn44,
            this.bandedGridColumn45,
            this.bandedGridColumn81,
            this.bandedGridColumn46,
            this.bandedGridColumn59,
            this.bandedGridColumn58,
            this.bandedGridColumn72,
            this.bandedGridColumn74,
            this.bandedGridColumn67,
            this.bandedGridColumn41,
            this.bandedGridColumn55,
            this.bandedGridColumn40,
            this.bandedGridColumn47,
            this.bandedGridColumn48,
            this.bandedGridColumn49,
            this.bandedGridColumn50,
            this.bandedGridColumn51,
            this.bandedGridColumn52,
            this.bandedGridColumn53,
            this.bandedGridColumn60,
            this.bandedGridColumn64,
            this.bandedGridColumn61,
            this.bandedGridColumn70,
            this.bandedGridColumn71,
            this.bandedGridColumn54,
            this.bandedGridColumn56,
            this.bandedGridColumn68,
            this.bandedGridColumn69,
            this.bandedGridColumn63,
            this.bandedGridColumn65,
            this.bandedGridColumn66,
            this.bandedGridColumn39,
            this.bandedGridColumn37,
            this.bandedGridColumn62,
            this.bandedGridColumn77});
            this.gridMain2.DetailHeight = 431;
            this.gridMain2.GridControl = this.dgv2;
            this.gridMain2.Name = "gridMain2";
            this.gridMain2.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.MouseDown;
            this.gridMain2.OptionsFind.FindNullPrompt = "Enter text to search . . .";
            this.gridMain2.OptionsPrint.PrintBandHeader = false;
            this.gridMain2.OptionsSelection.MultiSelect = true;
            this.gridMain2.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain2.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain2.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain2.OptionsView.ShowBands = false;
            this.gridMain2.OptionsView.ShowGroupPanel = false;
            this.gridMain2.PaintStyleName = "Skin";
            this.gridMain2.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain2_CustomColumnDisplayText);
            this.gridMain2.DoubleClick += new System.EventHandler(this.gridMain2_DoubleClick);
            // 
            // gridBand3
            // 
            this.gridBand3.Caption = "gridBand2";
            this.gridBand3.Columns.Add(this.bandedGridColumn36);
            this.gridBand3.Columns.Add(this.bandedGridColumn37);
            this.gridBand3.Columns.Add(this.bandedGridColumn38);
            this.gridBand3.Columns.Add(this.bandedGridColumn39);
            this.gridBand3.MinWidth = 20;
            this.gridBand3.Name = "gridBand3";
            this.gridBand3.VisibleIndex = 0;
            this.gridBand3.Width = 265;
            // 
            // bandedGridColumn36
            // 
            this.bandedGridColumn36.Caption = "Num";
            this.bandedGridColumn36.FieldName = "num";
            this.bandedGridColumn36.MinWidth = 42;
            this.bandedGridColumn36.Name = "bandedGridColumn36";
            this.bandedGridColumn36.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn36.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn36.Visible = true;
            this.bandedGridColumn36.Width = 106;
            // 
            // bandedGridColumn37
            // 
            this.bandedGridColumn37.Caption = "Fix";
            this.bandedGridColumn37.FieldName = "fix";
            this.bandedGridColumn37.MinWidth = 42;
            this.bandedGridColumn37.Name = "bandedGridColumn37";
            this.bandedGridColumn37.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn37.Width = 106;
            // 
            // bandedGridColumn38
            // 
            this.bandedGridColumn38.Caption = "Contract";
            this.bandedGridColumn38.FieldName = "contractNumber";
            this.bandedGridColumn38.MinWidth = 42;
            this.bandedGridColumn38.Name = "bandedGridColumn38";
            this.bandedGridColumn38.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn38.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn38.Width = 170;
            // 
            // bandedGridColumn39
            // 
            this.bandedGridColumn39.Caption = "Payer";
            this.bandedGridColumn39.FieldName = "payer";
            this.bandedGridColumn39.MinWidth = 42;
            this.bandedGridColumn39.Name = "bandedGridColumn39";
            this.bandedGridColumn39.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn39.Visible = true;
            this.bandedGridColumn39.Width = 159;
            // 
            // gridBand4
            // 
            this.gridBand4.Caption = "gridBand1";
            this.gridBand4.Columns.Add(this.bandedGridColumn40);
            this.gridBand4.Columns.Add(this.bandedGridColumn41);
            this.gridBand4.Columns.Add(this.bandedGridColumn42);
            this.gridBand4.Columns.Add(this.bandedGridColumn43);
            this.gridBand4.Columns.Add(this.bandedGridColumn44);
            this.gridBand4.Columns.Add(this.bandedGridColumn59);
            this.gridBand4.Columns.Add(this.bandedGridColumn60);
            this.gridBand4.Columns.Add(this.bandedGridColumn53);
            this.gridBand4.Columns.Add(this.bandedGridColumn51);
            this.gridBand4.Columns.Add(this.bandedGridColumn81);
            this.gridBand4.Columns.Add(this.bandedGridColumn45);
            this.gridBand4.Columns.Add(this.bandedGridColumn47);
            this.gridBand4.Columns.Add(this.bandedGridColumn48);
            this.gridBand4.Columns.Add(this.bandedGridColumn49);
            this.gridBand4.Columns.Add(this.bandedGridColumn77);
            this.gridBand4.Columns.Add(this.bandedGridColumn46);
            this.gridBand4.Columns.Add(this.bandedGridColumn50);
            this.gridBand4.Columns.Add(this.bandedGridColumn52);
            this.gridBand4.Columns.Add(this.bandedGridColumn54);
            this.gridBand4.Columns.Add(this.bandedGridColumn55);
            this.gridBand4.Columns.Add(this.bandedGridColumn56);
            this.gridBand4.Columns.Add(this.bandedGridColumn58);
            this.gridBand4.Columns.Add(this.bandedGridColumn61);
            this.gridBand4.Columns.Add(this.bandedGridColumn62);
            this.gridBand4.Columns.Add(this.bandedGridColumn63);
            this.gridBand4.Columns.Add(this.bandedGridColumn64);
            this.gridBand4.Columns.Add(this.bandedGridColumn65);
            this.gridBand4.Columns.Add(this.bandedGridColumn66);
            this.gridBand4.Columns.Add(this.bandedGridColumn67);
            this.gridBand4.Columns.Add(this.bandedGridColumn68);
            this.gridBand4.Columns.Add(this.bandedGridColumn69);
            this.gridBand4.Columns.Add(this.bandedGridColumn70);
            this.gridBand4.Columns.Add(this.bandedGridColumn71);
            this.gridBand4.Columns.Add(this.bandedGridColumn72);
            this.gridBand4.MinWidth = 20;
            this.gridBand4.Name = "gridBand4";
            this.gridBand4.VisibleIndex = 1;
            this.gridBand4.Width = 1562;
            // 
            // bandedGridColumn40
            // 
            this.bandedGridColumn40.Caption = "Select";
            this.bandedGridColumn40.ColumnEdit = this.repositoryItemCheckEdit3;
            this.bandedGridColumn40.FieldName = "select";
            this.bandedGridColumn40.MinWidth = 42;
            this.bandedGridColumn40.Name = "bandedGridColumn40";
            this.bandedGridColumn40.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn40.Width = 159;
            // 
            // repositoryItemCheckEdit3
            // 
            this.repositoryItemCheckEdit3.AutoHeight = false;
            this.repositoryItemCheckEdit3.Name = "repositoryItemCheckEdit3";
            // 
            // bandedGridColumn41
            // 
            this.bandedGridColumn41.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn41.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.bandedGridColumn41.Caption = "L";
            this.bandedGridColumn41.FieldName = "lapsed";
            this.bandedGridColumn41.MinWidth = 42;
            this.bandedGridColumn41.Name = "bandedGridColumn41";
            this.bandedGridColumn41.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn41.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn41.Visible = true;
            this.bandedGridColumn41.Width = 42;
            // 
            // bandedGridColumn42
            // 
            this.bandedGridColumn42.Caption = "Full Name";
            this.bandedGridColumn42.FieldName = "fullname";
            this.bandedGridColumn42.MinWidth = 42;
            this.bandedGridColumn42.Name = "bandedGridColumn42";
            this.bandedGridColumn42.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn42.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn42.Width = 317;
            // 
            // bandedGridColumn43
            // 
            this.bandedGridColumn43.Caption = "FirstName";
            this.bandedGridColumn43.FieldName = "firstName";
            this.bandedGridColumn43.MinWidth = 42;
            this.bandedGridColumn43.Name = "bandedGridColumn43";
            this.bandedGridColumn43.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn43.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn43.Visible = true;
            this.bandedGridColumn43.Width = 173;
            // 
            // bandedGridColumn44
            // 
            this.bandedGridColumn44.Caption = "Last Name";
            this.bandedGridColumn44.FieldName = "lastName";
            this.bandedGridColumn44.MinWidth = 42;
            this.bandedGridColumn44.Name = "bandedGridColumn44";
            this.bandedGridColumn44.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn44.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn44.Visible = true;
            this.bandedGridColumn44.Width = 170;
            // 
            // bandedGridColumn59
            // 
            this.bandedGridColumn59.Caption = "Premium";
            this.bandedGridColumn59.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn59.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn59.FieldName = "amtOfMonthlyPayt";
            this.bandedGridColumn59.MinWidth = 42;
            this.bandedGridColumn59.Name = "bandedGridColumn59";
            this.bandedGridColumn59.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn59.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn59.Visible = true;
            this.bandedGridColumn59.Width = 173;
            // 
            // bandedGridColumn60
            // 
            this.bandedGridColumn60.Caption = "Annual Premium";
            this.bandedGridColumn60.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn60.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn60.FieldName = "annualPremium";
            this.bandedGridColumn60.MinWidth = 42;
            this.bandedGridColumn60.Name = "bandedGridColumn60";
            this.bandedGridColumn60.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn60.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn60.Width = 159;
            // 
            // bandedGridColumn53
            // 
            this.bandedGridColumn53.Caption = "Due Date";
            this.bandedGridColumn53.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn53.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn53.FieldName = "dueDate8";
            this.bandedGridColumn53.MinWidth = 42;
            this.bandedGridColumn53.Name = "bandedGridColumn53";
            this.bandedGridColumn53.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn53.Visible = true;
            this.bandedGridColumn53.Width = 159;
            // 
            // bandedGridColumn51
            // 
            this.bandedGridColumn51.Caption = "DOLP";
            this.bandedGridColumn51.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn51.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn51.FieldName = "lastDatePaid8";
            this.bandedGridColumn51.MinWidth = 42;
            this.bandedGridColumn51.Name = "bandedGridColumn51";
            this.bandedGridColumn51.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn51.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn51.Visible = true;
            this.bandedGridColumn51.Width = 159;
            // 
            // bandedGridColumn81
            // 
            this.bandedGridColumn81.Caption = "Birth Date";
            this.bandedGridColumn81.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn81.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn81.FieldName = "birthDate";
            this.bandedGridColumn81.MinWidth = 29;
            this.bandedGridColumn81.Name = "bandedGridColumn81";
            this.bandedGridColumn81.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn81.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn81.Visible = true;
            this.bandedGridColumn81.Width = 198;
            // 
            // bandedGridColumn45
            // 
            this.bandedGridColumn45.Caption = "SSN";
            this.bandedGridColumn45.FieldName = "ssno";
            this.bandedGridColumn45.MinWidth = 42;
            this.bandedGridColumn45.Name = "bandedGridColumn45";
            this.bandedGridColumn45.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn45.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn45.Width = 190;
            // 
            // bandedGridColumn47
            // 
            this.bandedGridColumn47.Caption = "Issue Date";
            this.bandedGridColumn47.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn47.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn47.FieldName = "issueDate8";
            this.bandedGridColumn47.MinWidth = 42;
            this.bandedGridColumn47.Name = "bandedGridColumn47";
            this.bandedGridColumn47.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn47.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn47.Width = 159;
            // 
            // bandedGridColumn48
            // 
            this.bandedGridColumn48.Caption = "Lapse Date";
            this.bandedGridColumn48.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn48.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn48.FieldName = "lapseDate8";
            this.bandedGridColumn48.MinWidth = 42;
            this.bandedGridColumn48.Name = "bandedGridColumn48";
            this.bandedGridColumn48.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn48.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn48.Visible = true;
            this.bandedGridColumn48.Width = 159;
            // 
            // bandedGridColumn49
            // 
            this.bandedGridColumn49.Caption = "Deceased Date";
            this.bandedGridColumn49.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn49.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn49.FieldName = "deceasedDate";
            this.bandedGridColumn49.MinWidth = 42;
            this.bandedGridColumn49.Name = "bandedGridColumn49";
            this.bandedGridColumn49.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn49.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn49.Visible = true;
            this.bandedGridColumn49.Width = 159;
            // 
            // bandedGridColumn77
            // 
            this.bandedGridColumn77.Caption = "DDATE";
            this.bandedGridColumn77.FieldName = "ddate";
            this.bandedGridColumn77.MinWidth = 40;
            this.bandedGridColumn77.Name = "bandedGridColumn77";
            this.bandedGridColumn77.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn77.Width = 149;
            // 
            // bandedGridColumn46
            // 
            this.bandedGridColumn46.Caption = "Reinstate Date";
            this.bandedGridColumn46.FieldName = "reinstateDate8";
            this.bandedGridColumn46.MinWidth = 42;
            this.bandedGridColumn46.Name = "bandedGridColumn46";
            this.bandedGridColumn46.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn46.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn46.Visible = true;
            this.bandedGridColumn46.Width = 170;
            // 
            // bandedGridColumn50
            // 
            this.bandedGridColumn50.Caption = "Trust Removed";
            this.bandedGridColumn50.FieldName = "trustRemoved";
            this.bandedGridColumn50.MinWidth = 42;
            this.bandedGridColumn50.Name = "bandedGridColumn50";
            this.bandedGridColumn50.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn50.Width = 138;
            // 
            // bandedGridColumn52
            // 
            this.bandedGridColumn52.Caption = "DOLP from Payments";
            this.bandedGridColumn52.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn52.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn52.FieldName = "DOLP";
            this.bandedGridColumn52.MinWidth = 42;
            this.bandedGridColumn52.Name = "bandedGridColumn52";
            this.bandedGridColumn52.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn52.Width = 159;
            // 
            // bandedGridColumn54
            // 
            this.bandedGridColumn54.Caption = "Financed";
            this.bandedGridColumn54.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn54.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn54.FieldName = "financed";
            this.bandedGridColumn54.MinWidth = 42;
            this.bandedGridColumn54.Name = "bandedGridColumn54";
            this.bandedGridColumn54.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn54.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn54.Width = 159;
            // 
            // bandedGridColumn55
            // 
            this.bandedGridColumn55.Caption = "Purchase";
            this.bandedGridColumn55.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn55.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn55.FieldName = "purchase";
            this.bandedGridColumn55.MinWidth = 42;
            this.bandedGridColumn55.Name = "bandedGridColumn55";
            this.bandedGridColumn55.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn55.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn55.Width = 190;
            // 
            // bandedGridColumn56
            // 
            this.bandedGridColumn56.Caption = "APR";
            this.bandedGridColumn56.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn56.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn56.FieldName = "apr";
            this.bandedGridColumn56.MinWidth = 42;
            this.bandedGridColumn56.Name = "bandedGridColumn56";
            this.bandedGridColumn56.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn56.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn56.Width = 159;
            // 
            // bandedGridColumn58
            // 
            this.bandedGridColumn58.Caption = "Now Due";
            this.bandedGridColumn58.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn58.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn58.FieldName = "nowDue";
            this.bandedGridColumn58.MinWidth = 42;
            this.bandedGridColumn58.Name = "bandedGridColumn58";
            this.bandedGridColumn58.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn58.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn58.Width = 190;
            // 
            // bandedGridColumn61
            // 
            this.bandedGridColumn61.Caption = "New Due Date";
            this.bandedGridColumn61.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn61.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn61.FieldName = "newduedate";
            this.bandedGridColumn61.MinWidth = 42;
            this.bandedGridColumn61.Name = "bandedGridColumn61";
            this.bandedGridColumn61.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn61.Width = 159;
            // 
            // bandedGridColumn62
            // 
            this.bandedGridColumn62.Caption = "Days Diff";
            this.bandedGridColumn62.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn62.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn62.FieldName = "days";
            this.bandedGridColumn62.MinWidth = 42;
            this.bandedGridColumn62.Name = "bandedGridColumn62";
            this.bandedGridColumn62.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn62.Width = 106;
            // 
            // bandedGridColumn63
            // 
            this.bandedGridColumn63.Caption = "Credit Balance";
            this.bandedGridColumn63.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn63.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn63.FieldName = "creditBalance";
            this.bandedGridColumn63.MinWidth = 42;
            this.bandedGridColumn63.Name = "bandedGridColumn63";
            this.bandedGridColumn63.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn63.Width = 159;
            // 
            // bandedGridColumn64
            // 
            this.bandedGridColumn64.Caption = "Trust85 Balance";
            this.bandedGridColumn64.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn64.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn64.FieldName = "trust85";
            this.bandedGridColumn64.MinWidth = 42;
            this.bandedGridColumn64.Name = "bandedGridColumn64";
            this.bandedGridColumn64.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn64.Width = 159;
            // 
            // bandedGridColumn65
            // 
            this.bandedGridColumn65.Caption = "Contract Value";
            this.bandedGridColumn65.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn65.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn65.FieldName = "contractValue";
            this.bandedGridColumn65.MinWidth = 42;
            this.bandedGridColumn65.Name = "bandedGridColumn65";
            this.bandedGridColumn65.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn65.Width = 159;
            // 
            // bandedGridColumn66
            // 
            this.bandedGridColumn66.Caption = "% Paid";
            this.bandedGridColumn66.DisplayFormat.FormatString = "{0:P2}";
            this.bandedGridColumn66.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn66.FieldName = "percentPaid";
            this.bandedGridColumn66.MinWidth = 42;
            this.bandedGridColumn66.Name = "bandedGridColumn66";
            this.bandedGridColumn66.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn66.Width = 106;
            // 
            // bandedGridColumn67
            // 
            this.bandedGridColumn67.Caption = "Amt Paid";
            this.bandedGridColumn67.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn67.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn67.FieldName = "paid";
            this.bandedGridColumn67.MinWidth = 42;
            this.bandedGridColumn67.Name = "bandedGridColumn67";
            this.bandedGridColumn67.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn67.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn67.Width = 190;
            // 
            // bandedGridColumn68
            // 
            this.bandedGridColumn68.Caption = "Casket Code";
            this.bandedGridColumn68.FieldName = "extraItemAmtMI1";
            this.bandedGridColumn68.MinWidth = 42;
            this.bandedGridColumn68.Name = "bandedGridColumn68";
            this.bandedGridColumn68.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn68.Width = 159;
            // 
            // bandedGridColumn69
            // 
            this.bandedGridColumn69.Caption = "Vault";
            this.bandedGridColumn69.FieldName = "extraItemAmtMI2";
            this.bandedGridColumn69.MinWidth = 42;
            this.bandedGridColumn69.Name = "bandedGridColumn69";
            this.bandedGridColumn69.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn69.Width = 159;
            // 
            // bandedGridColumn70
            // 
            this.bandedGridColumn70.Caption = "TotInt";
            this.bandedGridColumn70.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn70.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn70.FieldName = "totalInterest";
            this.bandedGridColumn70.MinWidth = 42;
            this.bandedGridColumn70.Name = "bandedGridColumn70";
            this.bandedGridColumn70.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn70.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn70.Width = 159;
            // 
            // bandedGridColumn71
            // 
            this.bandedGridColumn71.Caption = "CInt";
            this.bandedGridColumn71.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn71.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn71.FieldName = "cint";
            this.bandedGridColumn71.MinWidth = 42;
            this.bandedGridColumn71.Name = "bandedGridColumn71";
            this.bandedGridColumn71.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn71.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn71.Width = 159;
            // 
            // bandedGridColumn72
            // 
            this.bandedGridColumn72.Caption = "Agreement";
            this.bandedGridColumn72.ColumnEdit = this.repositoryItemCheckEdit4;
            this.bandedGridColumn72.FieldName = "agreement";
            this.bandedGridColumn72.MinWidth = 42;
            this.bandedGridColumn72.Name = "bandedGridColumn72";
            this.bandedGridColumn72.Width = 170;
            // 
            // repositoryItemCheckEdit4
            // 
            this.repositoryItemCheckEdit4.AutoHeight = false;
            this.repositoryItemCheckEdit4.Name = "repositoryItemCheckEdit4";
            // 
            // bandedGridColumn73
            // 
            this.bandedGridColumn73.Caption = "record";
            this.bandedGridColumn73.FieldName = "record";
            this.bandedGridColumn73.MinWidth = 42;
            this.bandedGridColumn73.Name = "bandedGridColumn73";
            this.bandedGridColumn73.Width = 159;
            // 
            // bandedGridColumn74
            // 
            this.bandedGridColumn74.Caption = "agreementFile";
            this.bandedGridColumn74.FieldName = "agreementFile";
            this.bandedGridColumn74.MinWidth = 42;
            this.bandedGridColumn74.Name = "bandedGridColumn74";
            this.bandedGridColumn74.Visible = true;
            this.bandedGridColumn74.Width = 159;
            // 
            // dgv
            // 
            this.dgv.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(4);
            this.dgv.Location = new System.Drawing.Point(16, 30);
            this.dgv.LookAndFeel.SkinName = "Stardust";
            this.dgv.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv.MainView = this.gridMain;
            this.dgv.Margin = new System.Windows.Forms.Padding(4);
            this.dgv.Name = "dgv";
            this.dgv.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1,
            this.repositoryItemCheckEdit2});
            this.dgv.Size = new System.Drawing.Size(643, 350);
            this.dgv.TabIndex = 2;
            this.dgv.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain});
            // 
            // gridMain
            // 
            this.gridMain.Appearance.EvenRow.BackColor = System.Drawing.Color.Cyan;
            this.gridMain.Appearance.FocusedRow.BackColor = System.Drawing.Color.Yellow;
            this.gridMain.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.OddRow.BackColor = System.Drawing.Color.Azure;
            this.gridMain.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand2,
            this.gridBand1});
            this.gridMain.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.Num,
            this.bandedGridColumn1,
            this.contractNumber,
            this.bandedGridColumn8,
            this.firstName,
            this.bandedGridColumn2,
            this.ssn,
            this.bandedGridColumn3,
            this.bandedGridColumn4,
            this.bandedGridColumn5,
            this.bandedGridColumn6,
            this.bandedGridColumn7,
            this.bandedGridColumn9,
            this.bandedGridColumn10,
            this.bandedGridColumn11,
            this.bandedGridColumn12,
            this.bandedGridColumn13,
            this.bandedGridColumn57,
            this.bandedGridColumn14,
            this.bandedGridColumn15,
            this.bandedGridColumn31,
            this.bandedGridColumn16,
            this.bandedGridColumn75,
            this.bandedGridColumn23,
            this.bandedGridColumn22,
            this.bandedGridColumn17,
            this.bandedGridColumn28,
            this.bandedGridColumn26,
            this.bandedGridColumn18,
            this.bandedGridColumn19,
            this.bandedGridColumn20,
            this.bandedGridColumn21,
            this.bandedGridColumn24,
            this.bandedGridColumn25,
            this.bandedGridColumn27,
            this.bandedGridColumn29,
            this.bandedGridColumn30,
            this.bandedGridColumn32,
            this.bandedGridColumn33,
            this.bandedGridColumn34,
            this.bandedGridColumn35,
            this.bandedGridColumn76,
            this.bandedGridColumn78,
            this.bandedGridColumn79,
            this.bandedGridColumn80,
            this.bandedGridColumn82,
            this.bandedGridColumn83});
            this.gridMain.DetailHeight = 431;
            this.gridMain.GridControl = this.dgv;
            this.gridMain.Name = "gridMain";
            this.gridMain.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.MouseDown;
            this.gridMain.OptionsPrint.PrintBandHeader = false;
            this.gridMain.OptionsSelection.MultiSelect = true;
            this.gridMain.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain.OptionsView.ShowBands = false;
            this.gridMain.OptionsView.ShowGroupPanel = false;
            this.gridMain.PaintStyleName = "Skin";
            this.gridMain.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMain_CustomDrawCell);
            this.gridMain.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMain_CellValueChanged);
            this.gridMain.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMain_CustomRowFilter);
            this.gridMain.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain_CustomColumnDisplayText);
            this.gridMain.DoubleClick += new System.EventHandler(this.gridMain_DoubleClick);
            // 
            // gridBand2
            // 
            this.gridBand2.Caption = "gridBand2";
            this.gridBand2.Columns.Add(this.Num);
            this.gridBand2.Columns.Add(this.bandedGridColumn34);
            this.gridBand2.Columns.Add(this.contractNumber);
            this.gridBand2.Columns.Add(this.bandedGridColumn76);
            this.gridBand2.Columns.Add(this.bandedGridColumn32);
            this.gridBand2.MinWidth = 20;
            this.gridBand2.Name = "gridBand2";
            this.gridBand2.VisibleIndex = 0;
            this.gridBand2.Width = 553;
            // 
            // Num
            // 
            this.Num.Caption = "Num";
            this.Num.FieldName = "num";
            this.Num.MinWidth = 42;
            this.Num.Name = "Num";
            this.Num.OptionsColumn.AllowEdit = false;
            this.Num.OptionsColumn.FixedWidth = true;
            this.Num.Visible = true;
            this.Num.Width = 106;
            // 
            // bandedGridColumn34
            // 
            this.bandedGridColumn34.Caption = "Fix";
            this.bandedGridColumn34.FieldName = "fix";
            this.bandedGridColumn34.MinWidth = 42;
            this.bandedGridColumn34.Name = "bandedGridColumn34";
            this.bandedGridColumn34.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn34.Width = 106;
            // 
            // contractNumber
            // 
            this.contractNumber.Caption = "Contract";
            this.contractNumber.FieldName = "contractNumber";
            this.contractNumber.MinWidth = 42;
            this.contractNumber.Name = "contractNumber";
            this.contractNumber.OptionsColumn.AllowEdit = false;
            this.contractNumber.OptionsColumn.FixedWidth = true;
            this.contractNumber.Visible = true;
            this.contractNumber.Width = 170;
            // 
            // bandedGridColumn76
            // 
            this.bandedGridColumn76.Caption = "Service ID";
            this.bandedGridColumn76.FieldName = "ServiceId1";
            this.bandedGridColumn76.MinWidth = 40;
            this.bandedGridColumn76.Name = "bandedGridColumn76";
            this.bandedGridColumn76.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn76.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn76.Visible = true;
            this.bandedGridColumn76.Width = 118;
            // 
            // bandedGridColumn32
            // 
            this.bandedGridColumn32.Caption = "Payer";
            this.bandedGridColumn32.FieldName = "payer";
            this.bandedGridColumn32.MinWidth = 42;
            this.bandedGridColumn32.Name = "bandedGridColumn32";
            this.bandedGridColumn32.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn32.Visible = true;
            this.bandedGridColumn32.Width = 159;
            // 
            // gridBand1
            // 
            this.gridBand1.Caption = "gridBand1";
            this.gridBand1.Columns.Add(this.bandedGridColumn12);
            this.gridBand1.Columns.Add(this.bandedGridColumn10);
            this.gridBand1.Columns.Add(this.bandedGridColumn8);
            this.gridBand1.Columns.Add(this.firstName);
            this.gridBand1.Columns.Add(this.bandedGridColumn2);
            this.gridBand1.Columns.Add(this.ssn);
            this.gridBand1.Columns.Add(this.bandedGridColumn3);
            this.gridBand1.Columns.Add(this.bandedGridColumn13);
            this.gridBand1.Columns.Add(this.bandedGridColumn57);
            this.gridBand1.Columns.Add(this.bandedGridColumn14);
            this.gridBand1.Columns.Add(this.bandedGridColumn22);
            this.gridBand1.Columns.Add(this.bandedGridColumn26);
            this.gridBand1.Columns.Add(this.bandedGridColumn75);
            this.gridBand1.Columns.Add(this.bandedGridColumn15);
            this.gridBand1.Columns.Add(this.bandedGridColumn78);
            this.gridBand1.Columns.Add(this.bandedGridColumn31);
            this.gridBand1.Columns.Add(this.bandedGridColumn16);
            this.gridBand1.Columns.Add(this.bandedGridColumn23);
            this.gridBand1.Columns.Add(this.bandedGridColumn20);
            this.gridBand1.Columns.Add(this.bandedGridColumn11);
            this.gridBand1.Columns.Add(this.bandedGridColumn21);
            this.gridBand1.Columns.Add(this.bandedGridColumn33);
            this.gridBand1.Columns.Add(this.bandedGridColumn5);
            this.gridBand1.Columns.Add(this.bandedGridColumn4);
            this.gridBand1.Columns.Add(this.bandedGridColumn17);
            this.gridBand1.Columns.Add(this.bandedGridColumn35);
            this.gridBand1.Columns.Add(this.bandedGridColumn27);
            this.gridBand1.Columns.Add(this.bandedGridColumn28);
            this.gridBand1.Columns.Add(this.bandedGridColumn29);
            this.gridBand1.Columns.Add(this.bandedGridColumn30);
            this.gridBand1.Columns.Add(this.bandedGridColumn9);
            this.gridBand1.Columns.Add(this.bandedGridColumn80);
            this.gridBand1.Columns.Add(this.bandedGridColumn82);
            this.gridBand1.Columns.Add(this.bandedGridColumn83);
            this.gridBand1.Columns.Add(this.bandedGridColumn79);
            this.gridBand1.Columns.Add(this.bandedGridColumn24);
            this.gridBand1.Columns.Add(this.bandedGridColumn25);
            this.gridBand1.Columns.Add(this.bandedGridColumn18);
            this.gridBand1.Columns.Add(this.bandedGridColumn19);
            this.gridBand1.Columns.Add(this.bandedGridColumn6);
            this.gridBand1.MinWidth = 20;
            this.gridBand1.Name = "gridBand1";
            this.gridBand1.VisibleIndex = 1;
            this.gridBand1.Width = 4491;
            // 
            // bandedGridColumn12
            // 
            this.bandedGridColumn12.Caption = "Select";
            this.bandedGridColumn12.ColumnEdit = this.repositoryItemCheckEdit2;
            this.bandedGridColumn12.FieldName = "select";
            this.bandedGridColumn12.MinWidth = 42;
            this.bandedGridColumn12.Name = "bandedGridColumn12";
            this.bandedGridColumn12.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn12.Width = 159;
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            this.repositoryItemCheckEdit2.Click += new System.EventHandler(this.repositoryItemCheckEdit2_Click);
            // 
            // bandedGridColumn10
            // 
            this.bandedGridColumn10.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn10.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.bandedGridColumn10.Caption = "L";
            this.bandedGridColumn10.FieldName = "lapsed";
            this.bandedGridColumn10.MinWidth = 42;
            this.bandedGridColumn10.Name = "bandedGridColumn10";
            this.bandedGridColumn10.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn10.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn10.Visible = true;
            this.bandedGridColumn10.Width = 42;
            // 
            // bandedGridColumn8
            // 
            this.bandedGridColumn8.Caption = "Full Name";
            this.bandedGridColumn8.FieldName = "fullname";
            this.bandedGridColumn8.MinWidth = 42;
            this.bandedGridColumn8.Name = "bandedGridColumn8";
            this.bandedGridColumn8.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn8.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn8.Visible = true;
            this.bandedGridColumn8.Width = 317;
            // 
            // firstName
            // 
            this.firstName.Caption = "FirstName";
            this.firstName.FieldName = "firstName";
            this.firstName.MinWidth = 42;
            this.firstName.Name = "firstName";
            this.firstName.OptionsColumn.AllowEdit = false;
            this.firstName.OptionsColumn.FixedWidth = true;
            this.firstName.Width = 173;
            // 
            // bandedGridColumn2
            // 
            this.bandedGridColumn2.Caption = "Last Name";
            this.bandedGridColumn2.FieldName = "lastName";
            this.bandedGridColumn2.MinWidth = 42;
            this.bandedGridColumn2.Name = "bandedGridColumn2";
            this.bandedGridColumn2.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn2.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn2.Width = 170;
            // 
            // ssn
            // 
            this.ssn.Caption = "SSN";
            this.ssn.FieldName = "ssno";
            this.ssn.MinWidth = 42;
            this.ssn.Name = "ssn";
            this.ssn.OptionsColumn.AllowEdit = false;
            this.ssn.OptionsColumn.FixedWidth = true;
            this.ssn.Visible = true;
            this.ssn.Width = 190;
            // 
            // bandedGridColumn3
            // 
            this.bandedGridColumn3.Caption = "Birth Date";
            this.bandedGridColumn3.DisplayFormat.FormatString = "yyyy-MM-dd";
            this.bandedGridColumn3.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn3.FieldName = "birthDate";
            this.bandedGridColumn3.MinWidth = 42;
            this.bandedGridColumn3.Name = "bandedGridColumn3";
            this.bandedGridColumn3.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn3.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn3.Visible = true;
            this.bandedGridColumn3.Width = 170;
            // 
            // bandedGridColumn13
            // 
            this.bandedGridColumn13.Caption = "IssueDate8";
            this.bandedGridColumn13.DisplayFormat.FormatString = "yyyy-MM-dd";
            this.bandedGridColumn13.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn13.FieldName = "issueDate8";
            this.bandedGridColumn13.MinWidth = 42;
            this.bandedGridColumn13.Name = "bandedGridColumn13";
            this.bandedGridColumn13.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn13.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn13.Visible = true;
            this.bandedGridColumn13.Width = 159;
            // 
            // bandedGridColumn57
            // 
            this.bandedGridColumn57.Caption = "Issue Date";
            this.bandedGridColumn57.FieldName = "idate";
            this.bandedGridColumn57.MinWidth = 42;
            this.bandedGridColumn57.Name = "bandedGridColumn57";
            this.bandedGridColumn57.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn57.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn57.Width = 159;
            // 
            // bandedGridColumn14
            // 
            this.bandedGridColumn14.Caption = "Lapse Date";
            this.bandedGridColumn14.DisplayFormat.FormatString = "yyyy-MM-dd";
            this.bandedGridColumn14.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn14.FieldName = "lapseDate8";
            this.bandedGridColumn14.MinWidth = 42;
            this.bandedGridColumn14.Name = "bandedGridColumn14";
            this.bandedGridColumn14.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn14.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn14.Visible = true;
            this.bandedGridColumn14.Width = 159;
            // 
            // bandedGridColumn22
            // 
            this.bandedGridColumn22.Caption = "Due Date";
            this.bandedGridColumn22.DisplayFormat.FormatString = "yyyy-MM-dd";
            this.bandedGridColumn22.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn22.FieldName = "dueDate8";
            this.bandedGridColumn22.MinWidth = 42;
            this.bandedGridColumn22.Name = "bandedGridColumn22";
            this.bandedGridColumn22.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn22.Visible = true;
            this.bandedGridColumn22.Width = 159;
            // 
            // bandedGridColumn26
            // 
            this.bandedGridColumn26.Caption = "New Due Date";
            this.bandedGridColumn26.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn26.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn26.FieldName = "newduedate";
            this.bandedGridColumn26.MinWidth = 42;
            this.bandedGridColumn26.Name = "bandedGridColumn26";
            this.bandedGridColumn26.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn26.Visible = true;
            this.bandedGridColumn26.Width = 159;
            // 
            // bandedGridColumn75
            // 
            this.bandedGridColumn75.Caption = "DOLP";
            this.bandedGridColumn75.FieldName = "realDOLP";
            this.bandedGridColumn75.MinWidth = 42;
            this.bandedGridColumn75.Name = "bandedGridColumn75";
            this.bandedGridColumn75.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn75.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn75.Width = 159;
            // 
            // bandedGridColumn15
            // 
            this.bandedGridColumn15.Caption = "Deceased Date";
            this.bandedGridColumn15.DisplayFormat.FormatString = "yyyy-MM-dd";
            this.bandedGridColumn15.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn15.FieldName = "deceasedDate";
            this.bandedGridColumn15.MinWidth = 42;
            this.bandedGridColumn15.Name = "bandedGridColumn15";
            this.bandedGridColumn15.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn15.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn15.Width = 159;
            // 
            // bandedGridColumn78
            // 
            this.bandedGridColumn78.Caption = "Deceased Date";
            this.bandedGridColumn78.FieldName = "DDATE";
            this.bandedGridColumn78.MinWidth = 34;
            this.bandedGridColumn78.Name = "bandedGridColumn78";
            this.bandedGridColumn78.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn78.Visible = true;
            this.bandedGridColumn78.Width = 128;
            // 
            // bandedGridColumn31
            // 
            this.bandedGridColumn31.Caption = "Trust Removed";
            this.bandedGridColumn31.FieldName = "trustRemoved";
            this.bandedGridColumn31.MinWidth = 42;
            this.bandedGridColumn31.Name = "bandedGridColumn31";
            this.bandedGridColumn31.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn31.Visible = true;
            this.bandedGridColumn31.Width = 138;
            // 
            // bandedGridColumn16
            // 
            this.bandedGridColumn16.Caption = "DOLP";
            this.bandedGridColumn16.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn16.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn16.FieldName = "lastDatePaid8";
            this.bandedGridColumn16.MinWidth = 42;
            this.bandedGridColumn16.Name = "bandedGridColumn16";
            this.bandedGridColumn16.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn16.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn16.Visible = true;
            this.bandedGridColumn16.Width = 159;
            // 
            // bandedGridColumn23
            // 
            this.bandedGridColumn23.Caption = "DOLP from Payments";
            this.bandedGridColumn23.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn23.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn23.FieldName = "DOLP";
            this.bandedGridColumn23.MinWidth = 42;
            this.bandedGridColumn23.Name = "bandedGridColumn23";
            this.bandedGridColumn23.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn23.Width = 159;
            // 
            // bandedGridColumn20
            // 
            this.bandedGridColumn20.Caption = "Financed";
            this.bandedGridColumn20.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn20.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn20.FieldName = "financed";
            this.bandedGridColumn20.MinWidth = 42;
            this.bandedGridColumn20.Name = "bandedGridColumn20";
            this.bandedGridColumn20.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn20.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn20.Visible = true;
            this.bandedGridColumn20.Width = 159;
            // 
            // bandedGridColumn11
            // 
            this.bandedGridColumn11.Caption = "Purchase";
            this.bandedGridColumn11.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn11.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn11.FieldName = "purchase";
            this.bandedGridColumn11.MinWidth = 42;
            this.bandedGridColumn11.Name = "bandedGridColumn11";
            this.bandedGridColumn11.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn11.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn11.Visible = true;
            this.bandedGridColumn11.Width = 190;
            // 
            // bandedGridColumn21
            // 
            this.bandedGridColumn21.Caption = "APR";
            this.bandedGridColumn21.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn21.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn21.FieldName = "apr";
            this.bandedGridColumn21.MinWidth = 42;
            this.bandedGridColumn21.Name = "bandedGridColumn21";
            this.bandedGridColumn21.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn21.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn21.Visible = true;
            this.bandedGridColumn21.Width = 159;
            // 
            // bandedGridColumn33
            // 
            this.bandedGridColumn33.Caption = "Premium";
            this.bandedGridColumn33.FieldName = "amtOfMonthlyPayt";
            this.bandedGridColumn33.MinWidth = 42;
            this.bandedGridColumn33.Name = "bandedGridColumn33";
            this.bandedGridColumn33.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn33.Width = 159;
            // 
            // bandedGridColumn5
            // 
            this.bandedGridColumn5.Caption = "Now Due";
            this.bandedGridColumn5.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn5.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn5.FieldName = "nowDue";
            this.bandedGridColumn5.MinWidth = 42;
            this.bandedGridColumn5.Name = "bandedGridColumn5";
            this.bandedGridColumn5.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn5.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn5.Visible = true;
            this.bandedGridColumn5.Width = 190;
            // 
            // bandedGridColumn4
            // 
            this.bandedGridColumn4.Caption = "Balance";
            this.bandedGridColumn4.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn4.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn4.FieldName = "balanceDue";
            this.bandedGridColumn4.MinWidth = 42;
            this.bandedGridColumn4.Name = "bandedGridColumn4";
            this.bandedGridColumn4.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn4.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn4.Visible = true;
            this.bandedGridColumn4.Width = 173;
            // 
            // bandedGridColumn17
            // 
            this.bandedGridColumn17.Caption = "Calculated Balance";
            this.bandedGridColumn17.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn17.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn17.FieldName = "cbal";
            this.bandedGridColumn17.MinWidth = 42;
            this.bandedGridColumn17.Name = "bandedGridColumn17";
            this.bandedGridColumn17.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn17.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn17.Visible = true;
            this.bandedGridColumn17.Width = 159;
            // 
            // bandedGridColumn35
            // 
            this.bandedGridColumn35.Caption = "Days Diff";
            this.bandedGridColumn35.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn35.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn35.FieldName = "days";
            this.bandedGridColumn35.MinWidth = 42;
            this.bandedGridColumn35.Name = "bandedGridColumn35";
            this.bandedGridColumn35.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn35.Visible = true;
            this.bandedGridColumn35.Width = 106;
            // 
            // bandedGridColumn27
            // 
            this.bandedGridColumn27.Caption = "Credit Balance";
            this.bandedGridColumn27.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn27.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn27.FieldName = "creditBalance";
            this.bandedGridColumn27.MinWidth = 42;
            this.bandedGridColumn27.Name = "bandedGridColumn27";
            this.bandedGridColumn27.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn27.Visible = true;
            this.bandedGridColumn27.Width = 159;
            // 
            // bandedGridColumn28
            // 
            this.bandedGridColumn28.Caption = "Trust85 Balance";
            this.bandedGridColumn28.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn28.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn28.FieldName = "trust85";
            this.bandedGridColumn28.MinWidth = 42;
            this.bandedGridColumn28.Name = "bandedGridColumn28";
            this.bandedGridColumn28.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn28.Visible = true;
            this.bandedGridColumn28.Width = 159;
            // 
            // bandedGridColumn29
            // 
            this.bandedGridColumn29.Caption = "Contract Value";
            this.bandedGridColumn29.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn29.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn29.FieldName = "contractValue";
            this.bandedGridColumn29.MinWidth = 42;
            this.bandedGridColumn29.Name = "bandedGridColumn29";
            this.bandedGridColumn29.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn29.Visible = true;
            this.bandedGridColumn29.Width = 159;
            // 
            // bandedGridColumn30
            // 
            this.bandedGridColumn30.Caption = "% Paid";
            this.bandedGridColumn30.DisplayFormat.FormatString = "{0:P2}";
            this.bandedGridColumn30.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn30.FieldName = "percentPaid";
            this.bandedGridColumn30.MinWidth = 42;
            this.bandedGridColumn30.Name = "bandedGridColumn30";
            this.bandedGridColumn30.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn30.Visible = true;
            this.bandedGridColumn30.Width = 106;
            // 
            // bandedGridColumn9
            // 
            this.bandedGridColumn9.Caption = "Amt Paid";
            this.bandedGridColumn9.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn9.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn9.FieldName = "paid";
            this.bandedGridColumn9.MinWidth = 42;
            this.bandedGridColumn9.Name = "bandedGridColumn9";
            this.bandedGridColumn9.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn9.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn9.Visible = true;
            this.bandedGridColumn9.Width = 190;
            // 
            // bandedGridColumn80
            // 
            this.bandedGridColumn80.Caption = "Allow Insurance";
            this.bandedGridColumn80.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn80.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn80.FieldName = "allowInsurance";
            this.bandedGridColumn80.MinWidth = 29;
            this.bandedGridColumn80.Name = "bandedGridColumn80";
            this.bandedGridColumn80.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn80.Visible = true;
            this.bandedGridColumn80.Width = 110;
            // 
            // bandedGridColumn82
            // 
            this.bandedGridColumn82.Caption = "DownPayment";
            this.bandedGridColumn82.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn82.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn82.FieldName = "downPayment";
            this.bandedGridColumn82.MinWidth = 25;
            this.bandedGridColumn82.Name = "bandedGridColumn82";
            this.bandedGridColumn82.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn82.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn82.Visible = true;
            this.bandedGridColumn82.Width = 94;
            // 
            // bandedGridColumn83
            // 
            this.bandedGridColumn83.Caption = "Daily History DP";
            this.bandedGridColumn83.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn83.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn83.FieldName = "dp";
            this.bandedGridColumn83.MinWidth = 25;
            this.bandedGridColumn83.Name = "bandedGridColumn83";
            this.bandedGridColumn83.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn83.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn83.Width = 94;
            // 
            // bandedGridColumn79
            // 
            this.bandedGridColumn79.Caption = "Allow Merchandise";
            this.bandedGridColumn79.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn79.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn79.FieldName = "allowMerchandise";
            this.bandedGridColumn79.MinWidth = 29;
            this.bandedGridColumn79.Name = "bandedGridColumn79";
            this.bandedGridColumn79.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn79.Visible = true;
            this.bandedGridColumn79.Width = 110;
            // 
            // bandedGridColumn24
            // 
            this.bandedGridColumn24.Caption = "Casket Code";
            this.bandedGridColumn24.FieldName = "extraItemAmtMI1";
            this.bandedGridColumn24.MinWidth = 42;
            this.bandedGridColumn24.Name = "bandedGridColumn24";
            this.bandedGridColumn24.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn24.Visible = true;
            this.bandedGridColumn24.Width = 159;
            // 
            // bandedGridColumn25
            // 
            this.bandedGridColumn25.Caption = "Vault";
            this.bandedGridColumn25.FieldName = "extraItemAmtMI2";
            this.bandedGridColumn25.MinWidth = 42;
            this.bandedGridColumn25.Name = "bandedGridColumn25";
            this.bandedGridColumn25.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn25.Visible = true;
            this.bandedGridColumn25.Width = 159;
            // 
            // bandedGridColumn18
            // 
            this.bandedGridColumn18.Caption = "TotInt";
            this.bandedGridColumn18.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn18.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn18.FieldName = "totalInterest";
            this.bandedGridColumn18.MinWidth = 42;
            this.bandedGridColumn18.Name = "bandedGridColumn18";
            this.bandedGridColumn18.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn18.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn18.Width = 159;
            // 
            // bandedGridColumn19
            // 
            this.bandedGridColumn19.Caption = "CInt";
            this.bandedGridColumn19.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn19.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn19.FieldName = "cint";
            this.bandedGridColumn19.MinWidth = 42;
            this.bandedGridColumn19.Name = "bandedGridColumn19";
            this.bandedGridColumn19.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn19.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn19.Width = 159;
            // 
            // bandedGridColumn6
            // 
            this.bandedGridColumn6.Caption = "Agreement";
            this.bandedGridColumn6.ColumnEdit = this.repositoryItemCheckEdit1;
            this.bandedGridColumn6.FieldName = "agreement";
            this.bandedGridColumn6.MinWidth = 42;
            this.bandedGridColumn6.Name = "bandedGridColumn6";
            this.bandedGridColumn6.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn6.Visible = true;
            this.bandedGridColumn6.Width = 170;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.Click += new System.EventHandler(this.repositoryItemCheckEdit1_Click);
            // 
            // bandedGridColumn1
            // 
            this.bandedGridColumn1.Caption = "record";
            this.bandedGridColumn1.FieldName = "record";
            this.bandedGridColumn1.MinWidth = 42;
            this.bandedGridColumn1.Name = "bandedGridColumn1";
            this.bandedGridColumn1.Width = 159;
            // 
            // bandedGridColumn7
            // 
            this.bandedGridColumn7.Caption = "agreementFile";
            this.bandedGridColumn7.FieldName = "agreementFile";
            this.bandedGridColumn7.MinWidth = 42;
            this.bandedGridColumn7.Name = "bandedGridColumn7";
            this.bandedGridColumn7.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn7.Visible = true;
            this.bandedGridColumn7.Width = 159;
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panelTop.Controls.Add(this.chkDownPayment);
            this.panelTop.Controls.Add(this.btnFixInt);
            this.panelTop.Controls.Add(this.chkLessZero);
            this.panelTop.Controls.Add(this.chkSortLastName);
            this.panelTop.Controls.Add(this.cmbQualify);
            this.panelTop.Controls.Add(this.chkMismatchDates);
            this.panelTop.Controls.Add(this.cmbSelectColumns);
            this.panelTop.Controls.Add(this.btnSelectColumns);
            this.panelTop.Controls.Add(this.label1);
            this.panelTop.Controls.Add(this.chkMismatches);
            this.panelTop.Controls.Add(this.txtThreshold);
            this.panelTop.Controls.Add(this.btnDOLP);
            this.panelTop.Controls.Add(this.cmbType);
            this.panelTop.Controls.Add(this.barImport);
            this.panelTop.Controls.Add(this.btnRecalc);
            this.panelTop.Controls.Add(this.chkIncludePaid);
            this.panelTop.Controls.Add(this.labValue);
            this.panelTop.Controls.Add(this.labelValue);
            this.panelTop.Controls.Add(this.btnRefresh);
            this.panelTop.Controls.Add(this.pictureBox1);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Margin = new System.Windows.Forms.Padding(4);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1674, 77);
            this.panelTop.TabIndex = 1;
            // 
            // chkDownPayment
            // 
            this.chkDownPayment.AutoSize = true;
            this.chkDownPayment.Location = new System.Drawing.Point(71, 50);
            this.chkDownPayment.Margin = new System.Windows.Forms.Padding(4);
            this.chkDownPayment.Name = "chkDownPayment";
            this.chkDownPayment.Size = new System.Drawing.Size(228, 21);
            this.chkDownPayment.TabIndex = 138;
            this.chkDownPayment.Text = "Show Mismatch DownPayments\r\n";
            this.chkDownPayment.UseVisualStyleBackColor = true;
            this.chkDownPayment.CheckedChanged += new System.EventHandler(this.chkDownPayment_CheckedChanged);
            // 
            // btnFixInt
            // 
            this.btnFixInt.Location = new System.Drawing.Point(1561, 44);
            this.btnFixInt.Margin = new System.Windows.Forms.Padding(4);
            this.btnFixInt.Name = "btnFixInt";
            this.btnFixInt.Size = new System.Drawing.Size(100, 28);
            this.btnFixInt.TabIndex = 137;
            this.btnFixInt.Text = "Fix Interest";
            this.btnFixInt.UseVisualStyleBackColor = true;
            this.btnFixInt.Click += new System.EventHandler(this.btnFixInt_Click);
            // 
            // chkLessZero
            // 
            this.chkLessZero.AutoSize = true;
            this.chkLessZero.Location = new System.Drawing.Point(1344, 54);
            this.chkLessZero.Margin = new System.Windows.Forms.Padding(4);
            this.chkLessZero.Name = "chkLessZero";
            this.chkLessZero.Size = new System.Drawing.Size(158, 21);
            this.chkLessZero.TabIndex = 136;
            this.chkLessZero.Text = "Show Balances <= 0";
            this.chkLessZero.UseVisualStyleBackColor = true;
            this.chkLessZero.CheckedChanged += new System.EventHandler(this.chkLessZero_CheckedChanged);
            // 
            // chkSortLastName
            // 
            this.chkSortLastName.AutoSize = true;
            this.chkSortLastName.Location = new System.Drawing.Point(1344, 36);
            this.chkSortLastName.Margin = new System.Windows.Forms.Padding(4);
            this.chkSortLastName.Name = "chkSortLastName";
            this.chkSortLastName.Size = new System.Drawing.Size(206, 21);
            this.chkSortLastName.TabIndex = 135;
            this.chkSortLastName.Text = "Sort by Last,First,Contract #";
            this.chkSortLastName.UseVisualStyleBackColor = true;
            this.chkSortLastName.CheckedChanged += new System.EventHandler(this.chkSortLastName_CheckedChanged);
            // 
            // cmbQualify
            // 
            this.cmbQualify.FormattingEnabled = true;
            this.cmbQualify.Items.AddRange(new object[] {
            "Active",
            "Lapsed",
            "Deceased",
            "All"});
            this.cmbQualify.Location = new System.Drawing.Point(220, 20);
            this.cmbQualify.Margin = new System.Windows.Forms.Padding(4);
            this.cmbQualify.Name = "cmbQualify";
            this.cmbQualify.Size = new System.Drawing.Size(116, 24);
            this.cmbQualify.TabIndex = 90;
            this.cmbQualify.Text = "Active";
            this.cmbQualify.SelectedIndexChanged += new System.EventHandler(this.cmbQualify_SelectedIndexChanged);
            // 
            // chkMismatchDates
            // 
            this.chkMismatchDates.AutoSize = true;
            this.chkMismatchDates.Location = new System.Drawing.Point(639, 27);
            this.chkMismatchDates.Margin = new System.Windows.Forms.Padding(4);
            this.chkMismatchDates.Name = "chkMismatchDates";
            this.chkMismatchDates.Size = new System.Drawing.Size(198, 21);
            this.chkMismatchDates.TabIndex = 89;
            this.chkMismatchDates.Text = "Show Mismatch Due Dates";
            this.chkMismatchDates.UseVisualStyleBackColor = true;
            this.chkMismatchDates.CheckedChanged += new System.EventHandler(this.chkMismatchDates_CheckedChanged);
            // 
            // cmbSelectColumns
            // 
            this.cmbSelectColumns.FormattingEnabled = true;
            this.cmbSelectColumns.Location = new System.Drawing.Point(1019, 4);
            this.cmbSelectColumns.Margin = new System.Windows.Forms.Padding(4);
            this.cmbSelectColumns.Name = "cmbSelectColumns";
            this.cmbSelectColumns.Size = new System.Drawing.Size(204, 24);
            this.cmbSelectColumns.TabIndex = 88;
            this.cmbSelectColumns.SelectedIndexChanged += new System.EventHandler(this.cmbSelectColumns_SelectedIndexChanged);
            // 
            // btnSelectColumns
            // 
            this.btnSelectColumns.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnSelectColumns.Location = new System.Drawing.Point(1231, 2);
            this.btnSelectColumns.Margin = new System.Windows.Forms.Padding(4);
            this.btnSelectColumns.Name = "btnSelectColumns";
            this.btnSelectColumns.Size = new System.Drawing.Size(129, 28);
            this.btnSelectColumns.TabIndex = 87;
            this.btnSelectColumns.Text = "Select Columns";
            this.btnSelectColumns.UseVisualStyleBackColor = false;
            this.btnSelectColumns.Click += new System.EventHandler(this.btnSelectColumns_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(901, 7);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 17);
            this.label1.TabIndex = 20;
            this.label1.Text = "<> Threshold";
            // 
            // chkMismatches
            // 
            this.chkMismatches.AutoSize = true;
            this.chkMismatches.Location = new System.Drawing.Point(639, 9);
            this.chkMismatches.Margin = new System.Windows.Forms.Padding(4);
            this.chkMismatches.Name = "chkMismatches";
            this.chkMismatches.Size = new System.Drawing.Size(189, 21);
            this.chkMismatches.TabIndex = 16;
            this.chkMismatches.Text = "Show Mismatch Balances";
            this.chkMismatches.UseVisualStyleBackColor = true;
            this.chkMismatches.CheckedChanged += new System.EventHandler(this.chkMismatches_CheckedChanged);
            // 
            // txtThreshold
            // 
            this.txtThreshold.Location = new System.Drawing.Point(847, 5);
            this.txtThreshold.Margin = new System.Windows.Forms.Padding(4);
            this.txtThreshold.Name = "txtThreshold";
            this.txtThreshold.Size = new System.Drawing.Size(45, 22);
            this.txtThreshold.TabIndex = 19;
            this.txtThreshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtThreshold.TextChanged += new System.EventHandler(this.txtThreshold_TextChanged);
            this.txtThreshold.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtThreshold_KeyUp);
            // 
            // btnDOLP
            // 
            this.btnDOLP.Location = new System.Drawing.Point(1561, 20);
            this.btnDOLP.Margin = new System.Windows.Forms.Padding(4);
            this.btnDOLP.Name = "btnDOLP";
            this.btnDOLP.Size = new System.Drawing.Size(100, 28);
            this.btnDOLP.TabIndex = 18;
            this.btnDOLP.Text = "Show DOLP";
            this.btnDOLP.UseVisualStyleBackColor = true;
            this.btnDOLP.Click += new System.EventHandler(this.btnDOLP_Click);
            // 
            // cmbType
            // 
            this.cmbType.FormattingEnabled = true;
            this.cmbType.Items.AddRange(new object[] {
            "Trusts",
            "Single Premium",
            "Insurance",
            "Payers",
            "Funerals"});
            this.cmbType.Location = new System.Drawing.Point(71, 20);
            this.cmbType.Margin = new System.Windows.Forms.Padding(4);
            this.cmbType.Name = "cmbType";
            this.cmbType.Size = new System.Drawing.Size(140, 24);
            this.cmbType.TabIndex = 17;
            this.cmbType.Text = "Trusts";
            this.cmbType.SelectedIndexChanged += new System.EventHandler(this.cmbType_SelectedIndexChanged);
            // 
            // barImport
            // 
            this.barImport.BackColor = System.Drawing.Color.Lime;
            this.barImport.Location = new System.Drawing.Point(636, 46);
            this.barImport.Margin = new System.Windows.Forms.Padding(4);
            this.barImport.Name = "barImport";
            this.barImport.Size = new System.Drawing.Size(349, 15);
            this.barImport.TabIndex = 15;
            // 
            // btnRecalc
            // 
            this.btnRecalc.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnRecalc.Location = new System.Drawing.Point(501, 7);
            this.btnRecalc.Margin = new System.Windows.Forms.Padding(4);
            this.btnRecalc.Name = "btnRecalc";
            this.btnRecalc.Size = new System.Drawing.Size(127, 52);
            this.btnRecalc.TabIndex = 14;
            this.btnRecalc.Text = "Re-Calculate Balances";
            this.btnRecalc.UseVisualStyleBackColor = false;
            this.btnRecalc.Click += new System.EventHandler(this.btnRecalc_Click);
            // 
            // chkIncludePaid
            // 
            this.chkIncludePaid.AutoSize = true;
            this.chkIncludePaid.Location = new System.Drawing.Point(1420, 4);
            this.chkIncludePaid.Margin = new System.Windows.Forms.Padding(4);
            this.chkIncludePaid.Name = "chkIncludePaid";
            this.chkIncludePaid.Size = new System.Drawing.Size(135, 21);
            this.chkIncludePaid.TabIndex = 13;
            this.chkIncludePaid.Text = "Include Paid Amt";
            this.chkIncludePaid.UseVisualStyleBackColor = true;
            // 
            // labValue
            // 
            this.labValue.AutoSize = true;
            this.labValue.Font = new System.Drawing.Font("Tahoma", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labValue.Location = new System.Drawing.Point(1156, 36);
            this.labValue.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labValue.Name = "labValue";
            this.labValue.Size = new System.Drawing.Size(90, 33);
            this.labValue.TabIndex = 12;
            this.labValue.Text = "Value";
            // 
            // labelValue
            // 
            this.labelValue.AutoSize = true;
            this.labelValue.Font = new System.Drawing.Font("Tahoma", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelValue.Location = new System.Drawing.Point(1036, 36);
            this.labelValue.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelValue.Name = "labelValue";
            this.labelValue.Size = new System.Drawing.Size(92, 33);
            this.labelValue.TabIndex = 11;
            this.labelValue.Text = "Paid :";
            // 
            // btnRefresh
            // 
            this.btnRefresh.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnRefresh.Location = new System.Drawing.Point(361, 9);
            this.btnRefresh.Margin = new System.Windows.Forms.Padding(4);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(100, 48);
            this.btnRefresh.TabIndex = 2;
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(16, 15);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(47, 41);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.columnsToolStripMenuItem,
            this.importToolStripMenuItem,
            this.miscToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.insuranceReportsToolStripMenuItem,
            this.editToolStripMenuItem,
            this.commonToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1674, 30);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuPrint,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 26);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // menuPrint
            // 
            this.menuPrint.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printPreviewToolStripMenuItem,
            this.printToolStripMenuItem});
            this.menuPrint.Name = "menuPrint";
            this.menuPrint.Size = new System.Drawing.Size(122, 26);
            this.menuPrint.Text = "Print";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printPreviewToolStripMenuItem.Text = "Print Preview";
            this.printPreviewToolStripMenuItem.Click += new System.EventHandler(this.printPreviewToolStripMenuItem_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // columnsToolStripMenuItem
            // 
            this.columnsToolStripMenuItem.Name = "columnsToolStripMenuItem";
            this.columnsToolStripMenuItem.Size = new System.Drawing.Size(80, 26);
            this.columnsToolStripMenuItem.Text = "Columns";
            // 
            // importToolStripMenuItem
            // 
            this.importToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importDailyDepositFileToolStripMenuItem1,
            this.importACHFileToolStripMenuItem1,
            this.importCreditCardPaymentsToolStripMenuItem});
            this.importToolStripMenuItem.Name = "importToolStripMenuItem";
            this.importToolStripMenuItem.Size = new System.Drawing.Size(68, 26);
            this.importToolStripMenuItem.Text = "Import";
            // 
            // importDailyDepositFileToolStripMenuItem1
            // 
            this.importDailyDepositFileToolStripMenuItem1.Name = "importDailyDepositFileToolStripMenuItem1";
            this.importDailyDepositFileToolStripMenuItem1.Size = new System.Drawing.Size(282, 26);
            this.importDailyDepositFileToolStripMenuItem1.Text = "Import Daily Deposit File";
            this.importDailyDepositFileToolStripMenuItem1.Click += new System.EventHandler(this.importDailyDepositFileToolStripMenuItem1_Click);
            // 
            // importACHFileToolStripMenuItem1
            // 
            this.importACHFileToolStripMenuItem1.Name = "importACHFileToolStripMenuItem1";
            this.importACHFileToolStripMenuItem1.Size = new System.Drawing.Size(282, 26);
            this.importACHFileToolStripMenuItem1.Text = "Import ACH File";
            this.importACHFileToolStripMenuItem1.Click += new System.EventHandler(this.importACHFileToolStripMenuItem1_Click);
            // 
            // importCreditCardPaymentsToolStripMenuItem
            // 
            this.importCreditCardPaymentsToolStripMenuItem.Name = "importCreditCardPaymentsToolStripMenuItem";
            this.importCreditCardPaymentsToolStripMenuItem.Size = new System.Drawing.Size(282, 26);
            this.importCreditCardPaymentsToolStripMenuItem.Text = "Import Credit Card Payments";
            this.importCreditCardPaymentsToolStripMenuItem.Click += new System.EventHandler(this.importCreditCardPaymentsToolStripMenuItem_Click);
            // 
            // miscToolStripMenuItem
            // 
            this.miscToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quickLookupToolStripMenuItem,
            this.previousContractsToolStripMenuItem,
            this.yearendReportsToolStripMenuItem,
            this.potentialPaidOffToolStripMenuItem});
            this.miscToolStripMenuItem.Name = "miscToolStripMenuItem";
            this.miscToolStripMenuItem.Size = new System.Drawing.Size(53, 26);
            this.miscToolStripMenuItem.Text = "Misc";
            // 
            // quickLookupToolStripMenuItem
            // 
            this.quickLookupToolStripMenuItem.Name = "quickLookupToolStripMenuItem";
            this.quickLookupToolStripMenuItem.Size = new System.Drawing.Size(301, 26);
            this.quickLookupToolStripMenuItem.Text = "Lookup Contracts and/or Payers";
            this.quickLookupToolStripMenuItem.Click += new System.EventHandler(this.quickLookupToolStripMenuItem_Click);
            // 
            // previousContractsToolStripMenuItem
            // 
            this.previousContractsToolStripMenuItem.Name = "previousContractsToolStripMenuItem";
            this.previousContractsToolStripMenuItem.Size = new System.Drawing.Size(301, 26);
            this.previousContractsToolStripMenuItem.Text = "Previous Contracts";
            // 
            // yearendReportsToolStripMenuItem
            // 
            this.yearendReportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yearendDeathReportToolStripMenuItem});
            this.yearendReportsToolStripMenuItem.Name = "yearendReportsToolStripMenuItem";
            this.yearendReportsToolStripMenuItem.Size = new System.Drawing.Size(301, 26);
            this.yearendReportsToolStripMenuItem.Text = "Yearend Reports";
            // 
            // yearendDeathReportToolStripMenuItem
            // 
            this.yearendDeathReportToolStripMenuItem.Name = "yearendDeathReportToolStripMenuItem";
            this.yearendDeathReportToolStripMenuItem.Size = new System.Drawing.Size(238, 26);
            this.yearendDeathReportToolStripMenuItem.Text = "Yearend Death Report";
            this.yearendDeathReportToolStripMenuItem.Click += new System.EventHandler(this.yearendDeathReportToolStripMenuItem_Click);
            // 
            // potentialPaidOffToolStripMenuItem
            // 
            this.potentialPaidOffToolStripMenuItem.Name = "potentialPaidOffToolStripMenuItem";
            this.potentialPaidOffToolStripMenuItem.Size = new System.Drawing.Size(301, 26);
            this.potentialPaidOffToolStripMenuItem.Text = "Potential Paid-Off";
            this.potentialPaidOffToolStripMenuItem.Click += new System.EventHandler(this.potentialPaidOffToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.trust85ReportToolStripMenuItem,
            this.toolStripMenuItem6,
            this.historicCommissionsToolStripMenuItem,
            this.feeAllocationReportToolStripMenuItem,
            this.toolStripMenuItem16,
            this.miscellaneousReportsMenu});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(74, 26);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // trust85ReportToolStripMenuItem
            // 
            this.trust85ReportToolStripMenuItem.Name = "trust85ReportToolStripMenuItem";
            this.trust85ReportToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.trust85ReportToolStripMenuItem.Text = "Trust85 Report";
            this.trust85ReportToolStripMenuItem.Click += new System.EventHandler(this.trust85ReportToolStripMenuItem_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.genericPaymentsReportToolStripMenuItem,
            this.trustEOMReportToolStripMenuItem,
            this.toolStripMenuItem4,
            this.reportPaymentsToolStripMenuItem,
            this.paidUpContractsToolStripMenuItem,
            this.toolStripMenuItem9,
            this.toolStripMenuItem10,
            this.toolStripMenuItem15,
            this.toolStripMenuItem7,
            this.menuRemovalReport,
            this.toolStripMenuItem8,
            this.paymentsAfterDeathToolStripMenuItem,
            this.downPaymentsReportToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem11,
            this.toolStripMenuItem12,
            this.debitsAndCreditsMenu,
            this.toolStripMenuItem14,
            this.menuUnityReport,
            this.toolStripTrustReports,
            this.menuDeceasedReport,
            this.toolStripMenuItem13,
            this.allActivityReportToolStripMenuItem,
            this.activeOnlyReportToolStripMenuItem,
            this.balancesPaymentsReportToolStripMenuItem,
            this.balancesXReportToolStripMenuItem,
            this.massLapseToolStripMenuItem});
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(240, 26);
            this.toolStripMenuItem6.Text = "Payment Reports";
            // 
            // genericPaymentsReportToolStripMenuItem
            // 
            this.genericPaymentsReportToolStripMenuItem.Name = "genericPaymentsReportToolStripMenuItem";
            this.genericPaymentsReportToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.genericPaymentsReportToolStripMenuItem.Text = "Generic Payments Report";
            this.genericPaymentsReportToolStripMenuItem.Click += new System.EventHandler(this.genericPaymentsReportToolStripMenuItem_Click);
            // 
            // trustEOMReportToolStripMenuItem
            // 
            this.trustEOMReportToolStripMenuItem.Name = "trustEOMReportToolStripMenuItem";
            this.trustEOMReportToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.trustEOMReportToolStripMenuItem.Text = "Trust EOM Report 1.1";
            this.trustEOMReportToolStripMenuItem.Click += new System.EventHandler(this.trustEOMReportToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem4.Text = "New Business Report 1.2";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.toolStripMenuItem4_Click_1);
            // 
            // reportPaymentsToolStripMenuItem
            // 
            this.reportPaymentsToolStripMenuItem.Name = "reportPaymentsToolStripMenuItem";
            this.reportPaymentsToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.reportPaymentsToolStripMenuItem.Text = "Weekly/Monthly Balance Sheet 1.3";
            this.reportPaymentsToolStripMenuItem.Click += new System.EventHandler(this.reportPaymentsToolStripMenuItem_Click);
            // 
            // paidUpContractsToolStripMenuItem
            // 
            this.paidUpContractsToolStripMenuItem.Name = "paidUpContractsToolStripMenuItem";
            this.paidUpContractsToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.paidUpContractsToolStripMenuItem.Text = "Paid Off Contracts Report 2.0";
            this.paidUpContractsToolStripMenuItem.Click += new System.EventHandler(this.paidUpContractsToolStripMenuItem_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem9.Text = "Potential Lapse Report 3.0";
            this.toolStripMenuItem9.Click += new System.EventHandler(this.toolStripMenuItem9_Click);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem10.Text = "Trust Lapse List 4.0";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem15.Text = "Lapse Report 5.0";
            this.toolStripMenuItem15.Click += new System.EventHandler(this.toolStripMenuItem15_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem7.Text = "Reinstatement Report 5.0";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.toolStripMenuItem7_Click);
            // 
            // menuRemovalReport
            // 
            this.menuRemovalReport.Name = "menuRemovalReport";
            this.menuRemovalReport.Size = new System.Drawing.Size(338, 26);
            this.menuRemovalReport.Text = "Removal Report 5.1";
            this.menuRemovalReport.Click += new System.EventHandler(this.menuRemovalReport_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem8.Text = "DBR Report 5.2";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // paymentsAfterDeathToolStripMenuItem
            // 
            this.paymentsAfterDeathToolStripMenuItem.Name = "paymentsAfterDeathToolStripMenuItem";
            this.paymentsAfterDeathToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.paymentsAfterDeathToolStripMenuItem.Text = "Payments After Death Report 5.3";
            this.paymentsAfterDeathToolStripMenuItem.Click += new System.EventHandler(this.paymentsAfterDeathToolStripMenuItem_Click);
            // 
            // downPaymentsReportToolStripMenuItem
            // 
            this.downPaymentsReportToolStripMenuItem.Name = "downPaymentsReportToolStripMenuItem";
            this.downPaymentsReportToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.downPaymentsReportToolStripMenuItem.Text = "Down Payment Master List Report 6.1";
            this.downPaymentsReportToolStripMenuItem.Click += new System.EventHandler(this.downPaymentsReportToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem1.Text = "Payments 85% Master Listing 6.2";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click_1);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem11.Text = "Loss Recovery Report 7.0";
            this.toolStripMenuItem11.Click += new System.EventHandler(this.toolStripMenuItem11_Click);
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem12.Text = "Cash Remitted Report 8.0";
            this.toolStripMenuItem12.Click += new System.EventHandler(this.toolStripMenuItem12_Click);
            // 
            // debitsAndCreditsMenu
            // 
            this.debitsAndCreditsMenu.Name = "debitsAndCreditsMenu";
            this.debitsAndCreditsMenu.Size = new System.Drawing.Size(338, 26);
            this.debitsAndCreditsMenu.Text = "Debits and Credits Report 9.0";
            this.debitsAndCreditsMenu.Click += new System.EventHandler(this.debitsAndCreditsMenu_Click);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem14.Text = "Odd Payments Report 10.0";
            this.toolStripMenuItem14.Click += new System.EventHandler(this.toolStripMenuItem14_Click);
            // 
            // menuUnityReport
            // 
            this.menuUnityReport.Name = "menuUnityReport";
            this.menuUnityReport.Size = new System.Drawing.Size(338, 26);
            this.menuUnityReport.Text = "Unity Report 11.0";
            this.menuUnityReport.Click += new System.EventHandler(this.menuUnityReport_Click);
            // 
            // toolStripTrustReports
            // 
            this.toolStripTrustReports.Name = "toolStripTrustReports";
            this.toolStripTrustReports.Size = new System.Drawing.Size(338, 26);
            this.toolStripTrustReports.Text = "Trust Reports 12.0";
            this.toolStripTrustReports.Click += new System.EventHandler(this.toolStripTrustReports_Click);
            // 
            // menuDeceasedReport
            // 
            this.menuDeceasedReport.Name = "menuDeceasedReport";
            this.menuDeceasedReport.Size = new System.Drawing.Size(338, 26);
            this.menuDeceasedReport.Text = "Deceased Report";
            this.menuDeceasedReport.Click += new System.EventHandler(this.menuDeceasedReport_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(338, 26);
            this.toolStripMenuItem13.Text = "Show Next Due";
            this.toolStripMenuItem13.Click += new System.EventHandler(this.toolStripMenuItem13_Click);
            // 
            // allActivityReportToolStripMenuItem
            // 
            this.allActivityReportToolStripMenuItem.Name = "allActivityReportToolStripMenuItem";
            this.allActivityReportToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.allActivityReportToolStripMenuItem.Text = "All Activity Report";
            this.allActivityReportToolStripMenuItem.Click += new System.EventHandler(this.allActivityReportToolStripMenuItem_Click);
            // 
            // activeOnlyReportToolStripMenuItem
            // 
            this.activeOnlyReportToolStripMenuItem.Name = "activeOnlyReportToolStripMenuItem";
            this.activeOnlyReportToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.activeOnlyReportToolStripMenuItem.Text = "Active Only Report";
            this.activeOnlyReportToolStripMenuItem.Click += new System.EventHandler(this.activeOnlyReportToolStripMenuItem_Click);
            // 
            // balancesPaymentsReportToolStripMenuItem
            // 
            this.balancesPaymentsReportToolStripMenuItem.Name = "balancesPaymentsReportToolStripMenuItem";
            this.balancesPaymentsReportToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.balancesPaymentsReportToolStripMenuItem.Text = "Balances < Payments Report";
            this.balancesPaymentsReportToolStripMenuItem.Click += new System.EventHandler(this.balancesPaymentsReportToolStripMenuItem_Click);
            // 
            // balancesXReportToolStripMenuItem
            // 
            this.balancesXReportToolStripMenuItem.Name = "balancesXReportToolStripMenuItem";
            this.balancesXReportToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.balancesXReportToolStripMenuItem.Text = "Balances < X Report";
            this.balancesXReportToolStripMenuItem.Click += new System.EventHandler(this.balancesXReportToolStripMenuItem_Click);
            // 
            // massLapseToolStripMenuItem
            // 
            this.massLapseToolStripMenuItem.Name = "massLapseToolStripMenuItem";
            this.massLapseToolStripMenuItem.Size = new System.Drawing.Size(338, 26);
            this.massLapseToolStripMenuItem.Text = "Mass Lapse/Reinstate Report";
            this.massLapseToolStripMenuItem.Click += new System.EventHandler(this.massLapseToolStripMenuItem_Click);
            // 
            // historicCommissionsToolStripMenuItem
            // 
            this.historicCommissionsToolStripMenuItem.Name = "historicCommissionsToolStripMenuItem";
            this.historicCommissionsToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.historicCommissionsToolStripMenuItem.Text = "Historic Commissions";
            this.historicCommissionsToolStripMenuItem.Click += new System.EventHandler(this.historicCommissionsToolStripMenuItem_Click);
            // 
            // feeAllocationReportToolStripMenuItem
            // 
            this.feeAllocationReportToolStripMenuItem.Name = "feeAllocationReportToolStripMenuItem";
            this.feeAllocationReportToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.feeAllocationReportToolStripMenuItem.Text = "Fee Allocation Report";
            this.feeAllocationReportToolStripMenuItem.Click += new System.EventHandler(this.feeAllocationReportToolStripMenuItem_Click);
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem17,
            this.byAgentMenu,
            this.toolStripMenuItem18,
            this.byDetailToolStripMenuItem});
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(240, 26);
            this.toolStripMenuItem16.Text = "New Business Reports";
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(230, 26);
            this.toolStripMenuItem17.Text = "New Business Report";
            this.toolStripMenuItem17.Click += new System.EventHandler(this.toolStripMenuItem17_Click);
            // 
            // byAgentMenu
            // 
            this.byAgentMenu.Name = "byAgentMenu";
            this.byAgentMenu.Size = new System.Drawing.Size(230, 26);
            this.byAgentMenu.Text = "By Agent";
            this.byAgentMenu.Click += new System.EventHandler(this.byAgentMenu_Click);
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(230, 26);
            this.toolStripMenuItem18.Text = "By Location";
            this.toolStripMenuItem18.Click += new System.EventHandler(this.toolStripMenuItem18_Click);
            // 
            // byDetailToolStripMenuItem
            // 
            this.byDetailToolStripMenuItem.Name = "byDetailToolStripMenuItem";
            this.byDetailToolStripMenuItem.Size = new System.Drawing.Size(230, 26);
            this.byDetailToolStripMenuItem.Text = "By Location Detail";
            this.byDetailToolStripMenuItem.Click += new System.EventHandler(this.byDetailToolStripMenuItem_Click);
            // 
            // miscellaneousReportsMenu
            // 
            this.miscellaneousReportsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lockBoxDepositReportMenu,
            this.stopBreakReportToolStripMenuItem,
            this.trustSummaryReportToolStripMenuItem,
            this.contractsLessThan2039ToolStripMenuItem,
            this.mailingLabelsToolStripMenuItem,
            this.showForcedPaidOffContractsToolStripMenuItem,
            this.verifyTrustBBWithDailyHistoryToolStripMenuItem,
            this.activeContractsByLocationToolStripMenuItem,
            this.monthlyUnityProcessMenu,
            this.trustTotalsToolStripMenuItem,
            this.trustInterest15ReportToolStripMenuItem,
            this.trustContractsWODemographicsToolStripMenuItem,
            this.verificationModuleToolStripMenuItem});
            this.miscellaneousReportsMenu.Name = "miscellaneousReportsMenu";
            this.miscellaneousReportsMenu.Size = new System.Drawing.Size(240, 26);
            this.miscellaneousReportsMenu.Text = "Miscellaneous Reports";
            // 
            // lockBoxDepositReportMenu
            // 
            this.lockBoxDepositReportMenu.Name = "lockBoxDepositReportMenu";
            this.lockBoxDepositReportMenu.Size = new System.Drawing.Size(325, 26);
            this.lockBoxDepositReportMenu.Text = "Lock Box Deposit Report";
            this.lockBoxDepositReportMenu.Click += new System.EventHandler(this.lockBoxDepositReportMenu_Click);
            // 
            // stopBreakReportToolStripMenuItem
            // 
            this.stopBreakReportToolStripMenuItem.Name = "stopBreakReportToolStripMenuItem";
            this.stopBreakReportToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.stopBreakReportToolStripMenuItem.Text = "Stop/Break Report";
            this.stopBreakReportToolStripMenuItem.Click += new System.EventHandler(this.stopBreakReportToolStripMenuItem_Click);
            // 
            // trustSummaryReportToolStripMenuItem
            // 
            this.trustSummaryReportToolStripMenuItem.Name = "trustSummaryReportToolStripMenuItem";
            this.trustSummaryReportToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.trustSummaryReportToolStripMenuItem.Text = "Trust Summary Report";
            this.trustSummaryReportToolStripMenuItem.Click += new System.EventHandler(this.trustSummaryReportToolStripMenuItem_Click);
            // 
            // contractsLessThan2039ToolStripMenuItem
            // 
            this.contractsLessThan2039ToolStripMenuItem.Name = "contractsLessThan2039ToolStripMenuItem";
            this.contractsLessThan2039ToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.contractsLessThan2039ToolStripMenuItem.Text = "Contracts Less Than 2039";
            this.contractsLessThan2039ToolStripMenuItem.Click += new System.EventHandler(this.contractsLessThan2039ToolStripMenuItem_Click);
            // 
            // mailingLabelsToolStripMenuItem
            // 
            this.mailingLabelsToolStripMenuItem.Name = "mailingLabelsToolStripMenuItem";
            this.mailingLabelsToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.mailingLabelsToolStripMenuItem.Text = "Mailing Labels";
            this.mailingLabelsToolStripMenuItem.Click += new System.EventHandler(this.mailingLabelsToolStripMenuItem_Click);
            // 
            // showForcedPaidOffContractsToolStripMenuItem
            // 
            this.showForcedPaidOffContractsToolStripMenuItem.Name = "showForcedPaidOffContractsToolStripMenuItem";
            this.showForcedPaidOffContractsToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.showForcedPaidOffContractsToolStripMenuItem.Text = "Show Forced Paid Off Contracts";
            this.showForcedPaidOffContractsToolStripMenuItem.Click += new System.EventHandler(this.showForcedPaidOffContractsToolStripMenuItem_Click);
            // 
            // verifyTrustBBWithDailyHistoryToolStripMenuItem
            // 
            this.verifyTrustBBWithDailyHistoryToolStripMenuItem.Name = "verifyTrustBBWithDailyHistoryToolStripMenuItem";
            this.verifyTrustBBWithDailyHistoryToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.verifyTrustBBWithDailyHistoryToolStripMenuItem.Text = "Verify Trust BB with Daily History";
            this.verifyTrustBBWithDailyHistoryToolStripMenuItem.Click += new System.EventHandler(this.verifyTrustBBWithDailyHistoryToolStripMenuItem_Click);
            // 
            // activeContractsByLocationToolStripMenuItem
            // 
            this.activeContractsByLocationToolStripMenuItem.Name = "activeContractsByLocationToolStripMenuItem";
            this.activeContractsByLocationToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.activeContractsByLocationToolStripMenuItem.Text = "Active Contracts Report";
            this.activeContractsByLocationToolStripMenuItem.Click += new System.EventHandler(this.activeContractsByLocationToolStripMenuItem_Click);
            // 
            // monthlyUnityProcessMenu
            // 
            this.monthlyUnityProcessMenu.Name = "monthlyUnityProcessMenu";
            this.monthlyUnityProcessMenu.Size = new System.Drawing.Size(325, 26);
            this.monthlyUnityProcessMenu.Text = "Monthly Unity Process";
            this.monthlyUnityProcessMenu.Click += new System.EventHandler(this.monthlyUnityProcessMenu_Click);
            // 
            // trustTotalsToolStripMenuItem
            // 
            this.trustTotalsToolStripMenuItem.Name = "trustTotalsToolStripMenuItem";
            this.trustTotalsToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.trustTotalsToolStripMenuItem.Text = "Interest and Trust Income";
            this.trustTotalsToolStripMenuItem.Click += new System.EventHandler(this.trustTotalsToolStripMenuItem_Click);
            // 
            // trustInterest15ReportToolStripMenuItem
            // 
            this.trustInterest15ReportToolStripMenuItem.Name = "trustInterest15ReportToolStripMenuItem";
            this.trustInterest15ReportToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.trustInterest15ReportToolStripMenuItem.Text = "Trust Interest and 15% Report";
            this.trustInterest15ReportToolStripMenuItem.Click += new System.EventHandler(this.trustInterest15ReportToolStripMenuItem_Click);
            // 
            // trustContractsWODemographicsToolStripMenuItem
            // 
            this.trustContractsWODemographicsToolStripMenuItem.Name = "trustContractsWODemographicsToolStripMenuItem";
            this.trustContractsWODemographicsToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.trustContractsWODemographicsToolStripMenuItem.Text = "Trust Contracts W/O Demographics";
            this.trustContractsWODemographicsToolStripMenuItem.Click += new System.EventHandler(this.trustContractsWODemographicsToolStripMenuItem_Click);
            // 
            // verificationModuleToolStripMenuItem
            // 
            this.verificationModuleToolStripMenuItem.Name = "verificationModuleToolStripMenuItem";
            this.verificationModuleToolStripMenuItem.Size = new System.Drawing.Size(325, 26);
            this.verificationModuleToolStripMenuItem.Text = "Contracts Diagnostic Tool";
            this.verificationModuleToolStripMenuItem.Click += new System.EventHandler(this.verificationModuleToolStripMenuItem_Click);
            // 
            // insuranceReportsToolStripMenuItem
            // 
            this.insuranceReportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.weekTotalsReportToolStripMenuItem,
            this.lapseReportToolStripMenuItem,
            this.dailyDepositReportToolStripMenuItem,
            this.collectionReportToolStripMenuItem,
            this.insuranceSummaryReportToolStripMenuItem,
            this.thirdPartyDumpReportToolStripMenuItem,
            this.menuEarlySecNatPayments,
            this.menuGenerateInsuranceCoupons,
            this.menuSecurityNational,
            this.mailingLabelsToolStripMenuItem1,
            this.menuSecNatNotices,
            this.findConflictingDeceasedPoliciesToolStripMenuItem,
            this.findProblemInsurancePaymentsToolStripMenuItem,
            this.findMismatchedPayersPoliciesToolStripMenuItem});
            this.insuranceReportsToolStripMenuItem.Name = "insuranceReportsToolStripMenuItem";
            this.insuranceReportsToolStripMenuItem.Size = new System.Drawing.Size(140, 26);
            this.insuranceReportsToolStripMenuItem.Text = "Insurance Reports";
            // 
            // weekTotalsReportToolStripMenuItem
            // 
            this.weekTotalsReportToolStripMenuItem.Name = "weekTotalsReportToolStripMenuItem";
            this.weekTotalsReportToolStripMenuItem.Size = new System.Drawing.Size(318, 26);
            this.weekTotalsReportToolStripMenuItem.Text = "Week Totals Report";
            this.weekTotalsReportToolStripMenuItem.Click += new System.EventHandler(this.weekTotalsReportToolStripMenuItem_Click);
            // 
            // lapseReportToolStripMenuItem
            // 
            this.lapseReportToolStripMenuItem.Name = "lapseReportToolStripMenuItem";
            this.lapseReportToolStripMenuItem.Size = new System.Drawing.Size(318, 26);
            this.lapseReportToolStripMenuItem.Text = "Lapse Report";
            this.lapseReportToolStripMenuItem.Click += new System.EventHandler(this.lapseReportToolStripMenuItem_Click);
            // 
            // dailyDepositReportToolStripMenuItem
            // 
            this.dailyDepositReportToolStripMenuItem.Name = "dailyDepositReportToolStripMenuItem";
            this.dailyDepositReportToolStripMenuItem.Size = new System.Drawing.Size(318, 26);
            this.dailyDepositReportToolStripMenuItem.Text = "Daily Deposit Report";
            this.dailyDepositReportToolStripMenuItem.Click += new System.EventHandler(this.dailyDepositReportToolStripMenuItem_Click);
            // 
            // collectionReportToolStripMenuItem
            // 
            this.collectionReportToolStripMenuItem.Name = "collectionReportToolStripMenuItem";
            this.collectionReportToolStripMenuItem.Size = new System.Drawing.Size(318, 26);
            this.collectionReportToolStripMenuItem.Text = "Collection Report";
            this.collectionReportToolStripMenuItem.Click += new System.EventHandler(this.collectionReportToolStripMenuItem_Click);
            // 
            // insuranceSummaryReportToolStripMenuItem
            // 
            this.insuranceSummaryReportToolStripMenuItem.Name = "insuranceSummaryReportToolStripMenuItem";
            this.insuranceSummaryReportToolStripMenuItem.Size = new System.Drawing.Size(318, 26);
            this.insuranceSummaryReportToolStripMenuItem.Text = "Insurance Summary Report";
            this.insuranceSummaryReportToolStripMenuItem.Click += new System.EventHandler(this.insuranceSummaryReportToolStripMenuItem_Click);
            // 
            // thirdPartyDumpReportToolStripMenuItem
            // 
            this.thirdPartyDumpReportToolStripMenuItem.Name = "thirdPartyDumpReportToolStripMenuItem";
            this.thirdPartyDumpReportToolStripMenuItem.Size = new System.Drawing.Size(318, 26);
            this.thirdPartyDumpReportToolStripMenuItem.Text = "Third Party Dump Report";
            this.thirdPartyDumpReportToolStripMenuItem.Click += new System.EventHandler(this.thirdPartyDumpReportToolStripMenuItem_Click);
            // 
            // menuEarlySecNatPayments
            // 
            this.menuEarlySecNatPayments.Name = "menuEarlySecNatPayments";
            this.menuEarlySecNatPayments.Size = new System.Drawing.Size(318, 26);
            this.menuEarlySecNatPayments.Text = "Early Security National Payments";
            this.menuEarlySecNatPayments.Click += new System.EventHandler(this.menuEarlySecNatPayments_Click);
            // 
            // menuGenerateInsuranceCoupons
            // 
            this.menuGenerateInsuranceCoupons.Name = "menuGenerateInsuranceCoupons";
            this.menuGenerateInsuranceCoupons.Size = new System.Drawing.Size(318, 26);
            this.menuGenerateInsuranceCoupons.Text = "Generate Insurance Coupons";
            this.menuGenerateInsuranceCoupons.Click += new System.EventHandler(this.menuGenerateInsuranceCoupons_Click);
            // 
            // menuSecurityNational
            // 
            this.menuSecurityNational.Name = "menuSecurityNational";
            this.menuSecurityNational.Size = new System.Drawing.Size(318, 26);
            this.menuSecurityNational.Text = "Security National Reporting";
            this.menuSecurityNational.Click += new System.EventHandler(this.menuSecurityNational_Click);
            // 
            // mailingLabelsToolStripMenuItem1
            // 
            this.mailingLabelsToolStripMenuItem1.Name = "mailingLabelsToolStripMenuItem1";
            this.mailingLabelsToolStripMenuItem1.Size = new System.Drawing.Size(318, 26);
            this.mailingLabelsToolStripMenuItem1.Text = "Mailing Labels";
            this.mailingLabelsToolStripMenuItem1.Click += new System.EventHandler(this.mailingLabelsToolStripMenuItem1_Click);
            // 
            // menuSecNatNotices
            // 
            this.menuSecNatNotices.Name = "menuSecNatNotices";
            this.menuSecNatNotices.Size = new System.Drawing.Size(318, 26);
            this.menuSecNatNotices.Text = "Security National Notices";
            this.menuSecNatNotices.Click += new System.EventHandler(this.menuSecNatNotices_Click);
            // 
            // findConflictingDeceasedPoliciesToolStripMenuItem
            // 
            this.findConflictingDeceasedPoliciesToolStripMenuItem.Name = "findConflictingDeceasedPoliciesToolStripMenuItem";
            this.findConflictingDeceasedPoliciesToolStripMenuItem.Size = new System.Drawing.Size(318, 26);
            this.findConflictingDeceasedPoliciesToolStripMenuItem.Text = "Find Conflicting Deceased Policies";
            this.findConflictingDeceasedPoliciesToolStripMenuItem.Click += new System.EventHandler(this.findConflictingDeceasedPoliciesToolStripMenuItem_Click);
            // 
            // findProblemInsurancePaymentsToolStripMenuItem
            // 
            this.findProblemInsurancePaymentsToolStripMenuItem.Name = "findProblemInsurancePaymentsToolStripMenuItem";
            this.findProblemInsurancePaymentsToolStripMenuItem.Size = new System.Drawing.Size(318, 26);
            this.findProblemInsurancePaymentsToolStripMenuItem.Text = "Find Problem Insurance Payments";
            this.findProblemInsurancePaymentsToolStripMenuItem.Click += new System.EventHandler(this.findProblemInsurancePaymentsToolStripMenuItem_Click);
            // 
            // findMismatchedPayersPoliciesToolStripMenuItem
            // 
            this.findMismatchedPayersPoliciesToolStripMenuItem.Name = "findMismatchedPayersPoliciesToolStripMenuItem";
            this.findMismatchedPayersPoliciesToolStripMenuItem.Size = new System.Drawing.Size(318, 26);
            this.findMismatchedPayersPoliciesToolStripMenuItem.Text = "Find Mismatched Payers/Policies";
            this.findMismatchedPayersPoliciesToolStripMenuItem.Click += new System.EventHandler(this.findMismatchedPayersPoliciesToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editTrustDownPaymentsToolStripMenuItem1,
            this.verifyLocationPaymentsToolStripMenuItem,
            this.trustCompanyDataToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(49, 26);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // editTrustDownPaymentsToolStripMenuItem1
            // 
            this.editTrustDownPaymentsToolStripMenuItem1.Name = "editTrustDownPaymentsToolStripMenuItem1";
            this.editTrustDownPaymentsToolStripMenuItem1.Size = new System.Drawing.Size(262, 26);
            this.editTrustDownPaymentsToolStripMenuItem1.Text = "Edit Trust Down Payments";
            this.editTrustDownPaymentsToolStripMenuItem1.Click += new System.EventHandler(this.editTrustDownPaymentsToolStripMenuItem1_Click);
            // 
            // verifyLocationPaymentsToolStripMenuItem
            // 
            this.verifyLocationPaymentsToolStripMenuItem.Name = "verifyLocationPaymentsToolStripMenuItem";
            this.verifyLocationPaymentsToolStripMenuItem.Size = new System.Drawing.Size(262, 26);
            this.verifyLocationPaymentsToolStripMenuItem.Text = "Verify Location Payments";
            this.verifyLocationPaymentsToolStripMenuItem.Click += new System.EventHandler(this.verifyLocationPaymentsToolStripMenuItem_Click);
            // 
            // trustCompanyDataToolStripMenuItem
            // 
            this.trustCompanyDataToolStripMenuItem.Name = "trustCompanyDataToolStripMenuItem";
            this.trustCompanyDataToolStripMenuItem.Size = new System.Drawing.Size(262, 26);
            this.trustCompanyDataToolStripMenuItem.Text = "Trust Company Data";
            this.trustCompanyDataToolStripMenuItem.Click += new System.EventHandler(this.trustCompanyDataToolStripMenuItem_Click);
            // 
            // commonToolStripMenuItem
            // 
            this.commonToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bankPaymentsToolStripMenuItem});
            this.commonToolStripMenuItem.Name = "commonToolStripMenuItem";
            this.commonToolStripMenuItem.Size = new System.Drawing.Size(84, 26);
            this.commonToolStripMenuItem.Text = "Common";
            // 
            // bankPaymentsToolStripMenuItem
            // 
            this.bankPaymentsToolStripMenuItem.Name = "bankPaymentsToolStripMenuItem";
            this.bankPaymentsToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.bankPaymentsToolStripMenuItem.Text = "Bank Payments";
            this.bankPaymentsToolStripMenuItem.Click += new System.EventHandler(this.bankPaymentsToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(55, 26);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // Customers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1674, 559);
            this.Controls.Add(this.panelAll);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Customers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customers";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Customers_FormClosing);
            this.Load += new System.EventHandler(this.Customers_Load);
            this.panelAll.ResumeLayout(false);
            this.panelBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelAll;
        private System.Windows.Forms.Panel panelBottom;
        private DevExpress.XtraGrid.GridControl dgv;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn Num;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn contractNumber;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn firstName;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn ssn;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn1;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn6;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn7;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem attachAgreementToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem detachAgreementToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn8;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuPrint;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem columnsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miscToolStripMenuItem;
        private System.Windows.Forms.Button btnRefresh;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn9;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn11;
        private System.Windows.Forms.Label labValue;
        private System.Windows.Forms.Label labelValue;
        private System.Windows.Forms.CheckBox chkIncludePaid;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn12;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn13;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trust85ReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn14;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn15;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn16;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn17;
        private System.Windows.Forms.Button btnRecalc;
        private System.Windows.Forms.ProgressBar barImport;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn18;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn19;
        private System.Windows.Forms.CheckBox chkMismatches;
        private System.Windows.Forms.ToolStripMenuItem showSimpleSummaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ComboBox cmbType;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn20;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn21;
        private System.Windows.Forms.ToolStripMenuItem historicCommissionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeContractNumberToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn22;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn23;
        private System.Windows.Forms.Button btnDOLP;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn24;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn25;
        private System.Windows.Forms.ToolStripMenuItem previousContractsToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn26;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn27;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtThreshold;
        private System.Windows.Forms.ComboBox cmbSelectColumns;
        private System.Windows.Forms.Button btnSelectColumns;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn28;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn29;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn30;
        private System.Windows.Forms.ToolStripMenuItem feeAllocationReportToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn31;
        private System.Windows.Forms.CheckBox chkMismatchDates;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem genericPaymentsReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentsAfterDeathToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paidUpContractsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportPaymentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allActivityReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem activeOnlyReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem downPaymentsReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem balancesPaymentsReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem balancesXReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem trustEOMReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem menuRemovalReport;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem insuranceReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem weekTotalsReportToolStripMenuItem;
        private System.Windows.Forms.ComboBox cmbQualify;
        private System.Windows.Forms.ToolStripMenuItem lapseReportToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn32;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn33;
        private System.Windows.Forms.CheckBox chkSortLastName;
        private System.Windows.Forms.CheckBox chkLessZero;
        private System.Windows.Forms.ToolStripMenuItem quickLookupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importDailyDepositFileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem importACHFileToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem importCreditCardPaymentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dailyDepositReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem collectionReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem massLapseToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn34;
        private System.Windows.Forms.Button btnFixInt;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn35;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItemSetLapsed;
        private System.Windows.Forms.ToolStripMenuItem toolStripTrustReports;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuDeceasedReport;
        private System.Windows.Forms.ToolStripMenuItem miscellaneousReportsMenu;
        private System.Windows.Forms.ToolStripMenuItem lockBoxDepositReportMenu;
        private System.Windows.Forms.ToolStripMenuItem debitsAndCreditsMenu;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem stopBreakReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuUnityReport;
        private System.Windows.Forms.ToolStripMenuItem trustSummaryReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insuranceSummaryReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contractsLessThan2039ToolStripMenuItem;
        private DevExpress.XtraGrid.GridControl dgv2;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn36;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn37;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn38;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn39;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn40;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn41;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn42;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn43;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn44;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn59;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn60;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn53;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn51;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn45;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn47;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn48;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn49;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn46;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn50;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn52;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn54;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn55;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn56;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn58;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn61;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn62;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn63;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn64;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn65;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn66;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn67;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn68;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn69;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn70;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn71;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn72;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn73;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn74;
        private System.Windows.Forms.ToolStripMenuItem yearendReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yearendDeathReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thirdPartyDumpReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuGenerateInsuranceCoupons;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn57;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn75;
        private System.Windows.Forms.ToolStripMenuItem mailingLabelsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mailingLabelsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem menuSecurityNational;
        private System.Windows.Forms.ToolStripMenuItem menuEarlySecNatPayments;
        private System.Windows.Forms.ToolStripMenuItem commonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bankPaymentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editTrustDownPaymentsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem verifyLocationPaymentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menuSecNatNotices;
        private System.Windows.Forms.ToolStripMenuItem findConflictingDeceasedPoliciesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem findProblemInsurancePaymentsToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn76;
        private System.Windows.Forms.ToolStripMenuItem potentialPaidOffToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteContractToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showForcedPaidOffContractsToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn77;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn78;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand2;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn80;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn79;
        private System.Windows.Forms.ToolStripMenuItem verifyTrustBBWithDailyHistoryToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand3;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn81;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem byAgentMenu;
        private System.Windows.Forms.ToolStripMenuItem byDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem17;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem findMismatchedPayersPoliciesToolStripMenuItem;
        private System.Windows.Forms.CheckBox chkDownPayment;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn82;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn83;
        private System.Windows.Forms.ToolStripMenuItem activeContractsByLocationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem monthlyUnityProcessMenu;
        private System.Windows.Forms.ToolStripMenuItem trustTotalsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trustCompanyDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trustInterest15ReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trustContractsWODemographicsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verificationModuleToolStripMenuItem;
    }
}