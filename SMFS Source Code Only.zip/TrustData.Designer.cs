﻿namespace SMFS
{
    partial class TrustData
    {
        /// <summary>
        /// Required designer variable.column
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrustData));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelAll = new System.Windows.Forms.Panel();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgv = new DevExpress.XtraGrid.GridControl();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addToPolicyContractXReferenceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gridMain = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand5 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn1 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn22 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn19 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn6 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn8 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn12 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn47 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn16 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn3 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn2 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn4 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn14 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn15 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn5 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn13 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn49 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn17 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn10 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn26 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn24 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn51 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn52 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn21 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn20 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn7 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn9 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn11 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn18 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panelTotalsAll = new System.Windows.Forms.Panel();
            this.panelTotalsBottom = new System.Windows.Forms.Panel();
            this.dgv2 = new DevExpress.XtraGrid.GridControl();
            this.gridMain2 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand1 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn23 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn25 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn27 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn29 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn30 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn40 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn41 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn31 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn34 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn35 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn28 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelTotalsTop = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbPreOrPost = new System.Windows.Forms.ComboBox();
            this.btnRunTotals = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panelFDLICAll = new System.Windows.Forms.Panel();
            this.panelFDLICBottom = new System.Windows.Forms.Panel();
            this.dgv3 = new DevExpress.XtraGrid.GridControl();
            this.gridMain3 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand2 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn38 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn37 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn42 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn43 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn44 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn48 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn50 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn32 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn33 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn36 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn39 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn45 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn46 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelFDLICTop = new System.Windows.Forms.Panel();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panelTop = new System.Windows.Forms.Panel();
            this.barImport = new System.Windows.Forms.ProgressBar();
            this.chkTBB = new System.Windows.Forms.CheckBox();
            this.chkGroupContract = new System.Windows.Forms.CheckBox();
            this.chkCmbCompany = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            this.label1 = new System.Windows.Forms.Label();
            this.btnRight = new System.Windows.Forms.Button();
            this.btnLeft = new System.Windows.Forms.Button();
            this.btnRun = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lblYear = new System.Windows.Forms.Label();
            this.cmbYear = new System.Windows.Forms.ComboBox();
            this.lblMonth = new System.Windows.Forms.Label();
            this.cmbMonth = new System.Windows.Forms.ComboBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            this.panelAll.SuspendLayout();
            this.panelBottom.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panelTotalsAll.SuspendLayout();
            this.panelTotalsBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).BeginInit();
            this.panelTotalsTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.panelFDLICAll.SuspendLayout();
            this.panelFDLICBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).BeginInit();
            this.panelFDLICTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkCmbCompany.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1659, 30);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 26);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printPreviewToolStripMenuItem,
            this.printToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(122, 26);
            this.toolStripMenuItem1.Text = "Print";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printPreviewToolStripMenuItem.Text = "Print Preview";
            this.printPreviewToolStripMenuItem.Click += new System.EventHandler(this.printPreviewToolStripMenuItem_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // panelAll
            // 
            this.panelAll.Controls.Add(this.panelBottom);
            this.panelAll.Controls.Add(this.panelTop);
            this.panelAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAll.Location = new System.Drawing.Point(0, 30);
            this.panelAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelAll.Name = "panelAll";
            this.panelAll.Size = new System.Drawing.Size(1659, 412);
            this.panelAll.TabIndex = 6;
            // 
            // panelBottom
            // 
            this.panelBottom.Controls.Add(this.tabControl1);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBottom.Location = new System.Drawing.Point(0, 64);
            this.panelBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(1659, 348);
            this.panelBottom.TabIndex = 8;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1659, 348);
            this.tabControl1.TabIndex = 5;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgv);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(1651, 319);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Pulled Data";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgv
            // 
            this.dgv.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv.Location = new System.Drawing.Point(3, 4);
            this.dgv.MainView = this.gridMain;
            this.dgv.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv.Name = "dgv";
            this.dgv.Size = new System.Drawing.Size(1645, 311);
            this.dgv.TabIndex = 4;
            this.dgv.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain});
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToPolicyContractXReferenceToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(314, 28);
            // 
            // addToPolicyContractXReferenceToolStripMenuItem
            // 
            this.addToPolicyContractXReferenceToolStripMenuItem.Name = "addToPolicyContractXReferenceToolStripMenuItem";
            this.addToPolicyContractXReferenceToolStripMenuItem.Size = new System.Drawing.Size(313, 24);
            this.addToPolicyContractXReferenceToolStripMenuItem.Text = "Add to Policy/Contract X-Reference";
            this.addToPolicyContractXReferenceToolStripMenuItem.Click += new System.EventHandler(this.addToPolicyContractXReferenceToolStripMenuItem_Click);
            // 
            // gridMain
            // 
            this.gridMain.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.BandPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(120)))), ((int)(((byte)(88)))));
            this.gridMain.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(136)))), ((int)(((byte)(91)))));
            this.gridMain.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.FooterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(172)))), ((int)(((byte)(134)))));
            this.gridMain.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(234)))), ((int)(((byte)(216)))));
            this.gridMain.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(169)))), ((int)(((byte)(107)))));
            this.gridMain.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(224)))), ((int)(((byte)(190)))));
            this.gridMain.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(237)))));
            this.gridMain.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(120)))), ((int)(((byte)(88)))));
            this.gridMain.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain.Appearance.Preview.Options.UseFont = true;
            this.gridMain.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.Row.Options.UseBackColor = true;
            this.gridMain.Appearance.Row.Options.UseForeColor = true;
            this.gridMain.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(159)))), ((int)(((byte)(114)))));
            this.gridMain.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(169)))), ((int)(((byte)(107)))));
            this.gridMain.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand5});
            this.gridMain.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn1,
            this.bandedGridColumn6,
            this.bandedGridColumn19,
            this.bandedGridColumn18,
            this.bandedGridColumn12,
            this.bandedGridColumn8,
            this.bandedGridColumn3,
            this.bandedGridColumn2,
            this.bandedGridColumn4,
            this.bandedGridColumn5,
            this.bandedGridColumn13,
            this.bandedGridColumn10,
            this.bandedGridColumn21,
            this.bandedGridColumn20,
            this.bandedGridColumn7,
            this.bandedGridColumn9,
            this.bandedGridColumn11,
            this.bandedGridColumn14,
            this.bandedGridColumn15,
            this.bandedGridColumn16,
            this.bandedGridColumn17,
            this.bandedGridColumn22,
            this.bandedGridColumn24,
            this.bandedGridColumn26,
            this.bandedGridColumn47,
            this.bandedGridColumn49,
            this.bandedGridColumn51,
            this.bandedGridColumn52});
            this.gridMain.DetailHeight = 431;
            this.gridMain.GridControl = this.dgv;
            this.gridMain.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "endingPaymentBalance", this.bandedGridColumn13, "{0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "endingBalance", this.bandedGridColumn49, "{0:0,0.00}")});
            this.gridMain.Name = "gridMain";
            this.gridMain.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain.OptionsPrint.PrintBandHeader = false;
            this.gridMain.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain.OptionsView.ShowFooter = true;
            this.gridMain.OptionsView.ShowGroupPanel = false;
            this.gridMain.PaintStyleName = "Style3D";
            this.gridMain.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMain_CustomDrawCell);
            this.gridMain.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMain_CellValueChanged);
            this.gridMain.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain_CustomColumnDisplayText);
            this.gridMain.DoubleClick += new System.EventHandler(this.gridMain_DoubleClick);
            // 
            // gridBand5
            // 
            this.gridBand5.Columns.Add(this.bandedGridColumn1);
            this.gridBand5.Columns.Add(this.bandedGridColumn22);
            this.gridBand5.Columns.Add(this.bandedGridColumn19);
            this.gridBand5.Columns.Add(this.bandedGridColumn6);
            this.gridBand5.Columns.Add(this.bandedGridColumn8);
            this.gridBand5.Columns.Add(this.bandedGridColumn12);
            this.gridBand5.Columns.Add(this.bandedGridColumn47);
            this.gridBand5.Columns.Add(this.bandedGridColumn16);
            this.gridBand5.Columns.Add(this.bandedGridColumn3);
            this.gridBand5.Columns.Add(this.bandedGridColumn2);
            this.gridBand5.Columns.Add(this.bandedGridColumn4);
            this.gridBand5.Columns.Add(this.bandedGridColumn14);
            this.gridBand5.Columns.Add(this.bandedGridColumn15);
            this.gridBand5.Columns.Add(this.bandedGridColumn5);
            this.gridBand5.Columns.Add(this.bandedGridColumn13);
            this.gridBand5.Columns.Add(this.bandedGridColumn49);
            this.gridBand5.Columns.Add(this.bandedGridColumn17);
            this.gridBand5.Columns.Add(this.bandedGridColumn10);
            this.gridBand5.Columns.Add(this.bandedGridColumn26);
            this.gridBand5.Columns.Add(this.bandedGridColumn24);
            this.gridBand5.Columns.Add(this.bandedGridColumn51);
            this.gridBand5.Columns.Add(this.bandedGridColumn52);
            this.gridBand5.Columns.Add(this.bandedGridColumn21);
            this.gridBand5.Columns.Add(this.bandedGridColumn20);
            this.gridBand5.Columns.Add(this.bandedGridColumn7);
            this.gridBand5.Columns.Add(this.bandedGridColumn9);
            this.gridBand5.Columns.Add(this.bandedGridColumn11);
            this.gridBand5.MinWidth = 26;
            this.gridBand5.Name = "gridBand5";
            this.gridBand5.VisibleIndex = 0;
            this.gridBand5.Width = 3124;
            // 
            // bandedGridColumn1
            // 
            this.bandedGridColumn1.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn1.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn1.Caption = "Num";
            this.bandedGridColumn1.FieldName = "num";
            this.bandedGridColumn1.MinWidth = 49;
            this.bandedGridColumn1.Name = "bandedGridColumn1";
            this.bandedGridColumn1.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn1.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn1.Visible = true;
            this.bandedGridColumn1.Width = 66;
            // 
            // bandedGridColumn22
            // 
            this.bandedGridColumn22.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn22.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn22.Caption = "Trust Company";
            this.bandedGridColumn22.FieldName = "trustCompany";
            this.bandedGridColumn22.MinWidth = 29;
            this.bandedGridColumn22.Name = "bandedGridColumn22";
            this.bandedGridColumn22.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn22.Visible = true;
            this.bandedGridColumn22.Width = 109;
            // 
            // bandedGridColumn19
            // 
            this.bandedGridColumn19.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn19.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn19.Caption = "Date";
            this.bandedGridColumn19.DisplayFormat.FormatString = "yyyyMMDD";
            this.bandedGridColumn19.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn19.FieldName = "date";
            this.bandedGridColumn19.MinWidth = 29;
            this.bandedGridColumn19.Name = "bandedGridColumn19";
            this.bandedGridColumn19.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn19.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn19.Visible = true;
            this.bandedGridColumn19.Width = 85;
            // 
            // bandedGridColumn6
            // 
            this.bandedGridColumn6.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn6.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn6.Caption = "Status";
            this.bandedGridColumn6.FieldName = "status";
            this.bandedGridColumn6.MinWidth = 49;
            this.bandedGridColumn6.Name = "bandedGridColumn6";
            this.bandedGridColumn6.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn6.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn6.Width = 188;
            // 
            // bandedGridColumn8
            // 
            this.bandedGridColumn8.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn8.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn8.Caption = "Trust Number";
            this.bandedGridColumn8.FieldName = "contractNumber";
            this.bandedGridColumn8.MinWidth = 49;
            this.bandedGridColumn8.Name = "bandedGridColumn8";
            this.bandedGridColumn8.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn8.Visible = true;
            this.bandedGridColumn8.Width = 97;
            // 
            // bandedGridColumn12
            // 
            this.bandedGridColumn12.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn12.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn12.Caption = "Trust Name";
            this.bandedGridColumn12.FieldName = "trustName";
            this.bandedGridColumn12.MinWidth = 49;
            this.bandedGridColumn12.Name = "bandedGridColumn12";
            this.bandedGridColumn12.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn12.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn12.Visible = true;
            this.bandedGridColumn12.Width = 300;
            // 
            // bandedGridColumn47
            // 
            this.bandedGridColumn47.AppearanceCell.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn47.AppearanceCell.Options.UseForeColor = true;
            this.bandedGridColumn47.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn47.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn47.Caption = "Deceased Date";
            this.bandedGridColumn47.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn47.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn47.FieldName = "deceasedDate";
            this.bandedGridColumn47.MinWidth = 29;
            this.bandedGridColumn47.Name = "bandedGridColumn47";
            this.bandedGridColumn47.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn47.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn47.Visible = true;
            this.bandedGridColumn47.Width = 90;
            // 
            // bandedGridColumn16
            // 
            this.bandedGridColumn16.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn16.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn16.Caption = "Pre / Post 2002";
            this.bandedGridColumn16.FieldName = "preOrPost";
            this.bandedGridColumn16.MinWidth = 34;
            this.bandedGridColumn16.Name = "bandedGridColumn16";
            this.bandedGridColumn16.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn16.Visible = true;
            this.bandedGridColumn16.Width = 77;
            // 
            // bandedGridColumn3
            // 
            this.bandedGridColumn3.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn3.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn3.Caption = "Policy #";
            this.bandedGridColumn3.FieldName = "policyNumber";
            this.bandedGridColumn3.MinWidth = 49;
            this.bandedGridColumn3.Name = "bandedGridColumn3";
            this.bandedGridColumn3.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn3.Visible = true;
            this.bandedGridColumn3.Width = 171;
            // 
            // bandedGridColumn2
            // 
            this.bandedGridColumn2.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn2.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn2.Caption = "Insured Name";
            this.bandedGridColumn2.FieldName = "insuredName";
            this.bandedGridColumn2.MinWidth = 55;
            this.bandedGridColumn2.Name = "bandedGridColumn2";
            this.bandedGridColumn2.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn2.Visible = true;
            this.bandedGridColumn2.Width = 203;
            // 
            // bandedGridColumn4
            // 
            this.bandedGridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn4.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn4.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn4.Caption = "Premium";
            this.bandedGridColumn4.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn4.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn4.FieldName = "beginningPaymentBalance";
            this.bandedGridColumn4.MinWidth = 49;
            this.bandedGridColumn4.Name = "bandedGridColumn4";
            this.bandedGridColumn4.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn4.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn4.Visible = true;
            this.bandedGridColumn4.Width = 117;
            // 
            // bandedGridColumn14
            // 
            this.bandedGridColumn14.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn14.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn14.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn14.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn14.Caption = "Down Payments";
            this.bandedGridColumn14.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn14.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn14.FieldName = "downPayments";
            this.bandedGridColumn14.MinWidth = 40;
            this.bandedGridColumn14.Name = "bandedGridColumn14";
            this.bandedGridColumn14.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn14.Visible = true;
            this.bandedGridColumn14.Width = 100;
            // 
            // bandedGridColumn15
            // 
            this.bandedGridColumn15.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn15.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn15.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn15.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn15.Caption = "Payments";
            this.bandedGridColumn15.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn15.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn15.FieldName = "payments";
            this.bandedGridColumn15.MinWidth = 40;
            this.bandedGridColumn15.Name = "bandedGridColumn15";
            this.bandedGridColumn15.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn15.Visible = true;
            this.bandedGridColumn15.Width = 106;
            // 
            // bandedGridColumn5
            // 
            this.bandedGridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn5.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn5.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn5.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn5.Caption = "Surrender";
            this.bandedGridColumn5.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn5.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn5.FieldName = "beginningDeathBenefit";
            this.bandedGridColumn5.MinWidth = 49;
            this.bandedGridColumn5.Name = "bandedGridColumn5";
            this.bandedGridColumn5.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn5.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn5.Visible = true;
            this.bandedGridColumn5.Width = 127;
            // 
            // bandedGridColumn13
            // 
            this.bandedGridColumn13.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn13.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn13.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn13.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn13.Caption = "Face Amount";
            this.bandedGridColumn13.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn13.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn13.FieldName = "endingPaymentBalance";
            this.bandedGridColumn13.MinWidth = 49;
            this.bandedGridColumn13.Name = "bandedGridColumn13";
            this.bandedGridColumn13.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn13.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn13.Visible = true;
            this.bandedGridColumn13.Width = 147;
            // 
            // bandedGridColumn49
            // 
            this.bandedGridColumn49.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn49.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn49.Caption = "SMFS TEB";
            this.bandedGridColumn49.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn49.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn49.FieldName = "endingBalance";
            this.bandedGridColumn49.MinWidth = 29;
            this.bandedGridColumn49.Name = "bandedGridColumn49";
            this.bandedGridColumn49.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn49.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn49.Visible = true;
            this.bandedGridColumn49.Width = 110;
            // 
            // bandedGridColumn17
            // 
            this.bandedGridColumn17.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn17.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn17.Caption = "Growth";
            this.bandedGridColumn17.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn17.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn17.FieldName = "growth";
            this.bandedGridColumn17.MinWidth = 29;
            this.bandedGridColumn17.Name = "bandedGridColumn17";
            this.bandedGridColumn17.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn17.Visible = true;
            this.bandedGridColumn17.Width = 110;
            // 
            // bandedGridColumn10
            // 
            this.bandedGridColumn10.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn10.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn10.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn10.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn10.Caption = "Death Benefit";
            this.bandedGridColumn10.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn10.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn10.FieldName = "endingDeathBenefit";
            this.bandedGridColumn10.MinWidth = 49;
            this.bandedGridColumn10.Name = "bandedGridColumn10";
            this.bandedGridColumn10.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn10.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn10.Visible = true;
            this.bandedGridColumn10.Width = 146;
            // 
            // bandedGridColumn26
            // 
            this.bandedGridColumn26.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn26.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn26.AppearanceHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.bandedGridColumn26.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn26.AppearanceHeader.Options.UseBackColor = true;
            this.bandedGridColumn26.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn26.Caption = "Death Claim Amount";
            this.bandedGridColumn26.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn26.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn26.FieldName = "deathClaimAmount";
            this.bandedGridColumn26.MinWidth = 29;
            this.bandedGridColumn26.Name = "bandedGridColumn26";
            this.bandedGridColumn26.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn26.Visible = true;
            this.bandedGridColumn26.Width = 110;
            // 
            // bandedGridColumn24
            // 
            this.bandedGridColumn24.AppearanceHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.bandedGridColumn24.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn24.AppearanceHeader.Options.UseBackColor = true;
            this.bandedGridColumn24.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn24.Caption = "Death Paid Date";
            this.bandedGridColumn24.FieldName = "deathPaidDate";
            this.bandedGridColumn24.MinWidth = 29;
            this.bandedGridColumn24.Name = "bandedGridColumn24";
            this.bandedGridColumn24.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn24.Visible = true;
            this.bandedGridColumn24.Width = 110;
            // 
            // bandedGridColumn51
            // 
            this.bandedGridColumn51.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn51.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn51.Caption = "Billing Reason";
            this.bandedGridColumn51.FieldName = "billingReason";
            this.bandedGridColumn51.MinWidth = 25;
            this.bandedGridColumn51.Name = "bandedGridColumn51";
            this.bandedGridColumn51.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn51.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn51.Visible = true;
            this.bandedGridColumn51.Width = 61;
            // 
            // bandedGridColumn52
            // 
            this.bandedGridColumn52.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn52.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn52.Caption = "Status Reason";
            this.bandedGridColumn52.FieldName = "statusReason";
            this.bandedGridColumn52.MinWidth = 25;
            this.bandedGridColumn52.Name = "bandedGridColumn52";
            this.bandedGridColumn52.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn52.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn52.Visible = true;
            this.bandedGridColumn52.Width = 63;
            // 
            // bandedGridColumn21
            // 
            this.bandedGridColumn21.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn21.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn21.Caption = "Prior Unapplied Cash";
            this.bandedGridColumn21.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn21.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn21.FieldName = "priorUnappliedCash";
            this.bandedGridColumn21.MinWidth = 29;
            this.bandedGridColumn21.Name = "bandedGridColumn21";
            this.bandedGridColumn21.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn21.Visible = true;
            this.bandedGridColumn21.Width = 110;
            // 
            // bandedGridColumn20
            // 
            this.bandedGridColumn20.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn20.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn20.Caption = "Current Unapplied Cash";
            this.bandedGridColumn20.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn20.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn20.FieldName = "currentUnappliedCash";
            this.bandedGridColumn20.MinWidth = 29;
            this.bandedGridColumn20.Name = "bandedGridColumn20";
            this.bandedGridColumn20.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn20.Visible = true;
            this.bandedGridColumn20.Width = 110;
            // 
            // bandedGridColumn7
            // 
            this.bandedGridColumn7.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn7.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn7.Caption = "Last Name";
            this.bandedGridColumn7.FieldName = "lastName";
            this.bandedGridColumn7.MinWidth = 47;
            this.bandedGridColumn7.Name = "bandedGridColumn7";
            this.bandedGridColumn7.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn7.Visible = true;
            this.bandedGridColumn7.Width = 145;
            // 
            // bandedGridColumn9
            // 
            this.bandedGridColumn9.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn9.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn9.Caption = "First Name";
            this.bandedGridColumn9.FieldName = "firstName";
            this.bandedGridColumn9.MinWidth = 47;
            this.bandedGridColumn9.Name = "bandedGridColumn9";
            this.bandedGridColumn9.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn9.Visible = true;
            this.bandedGridColumn9.Width = 134;
            // 
            // bandedGridColumn11
            // 
            this.bandedGridColumn11.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn11.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn11.Caption = "Middle Name";
            this.bandedGridColumn11.FieldName = "middleName";
            this.bandedGridColumn11.MinWidth = 47;
            this.bandedGridColumn11.Name = "bandedGridColumn11";
            this.bandedGridColumn11.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn11.Visible = true;
            this.bandedGridColumn11.Width = 120;
            // 
            // bandedGridColumn18
            // 
            this.bandedGridColumn18.Caption = "Trust Company";
            this.bandedGridColumn18.FieldName = "trustCompany";
            this.bandedGridColumn18.MinWidth = 29;
            this.bandedGridColumn18.Name = "bandedGridColumn18";
            this.bandedGridColumn18.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn18.Width = 110;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panelTotalsAll);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(1651, 319);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Totals";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panelTotalsAll
            // 
            this.panelTotalsAll.Controls.Add(this.panelTotalsBottom);
            this.panelTotalsAll.Controls.Add(this.panelTotalsTop);
            this.panelTotalsAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTotalsAll.Location = new System.Drawing.Point(0, 0);
            this.panelTotalsAll.Name = "panelTotalsAll";
            this.panelTotalsAll.Size = new System.Drawing.Size(1651, 319);
            this.panelTotalsAll.TabIndex = 0;
            // 
            // panelTotalsBottom
            // 
            this.panelTotalsBottom.Controls.Add(this.dgv2);
            this.panelTotalsBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTotalsBottom.Location = new System.Drawing.Point(0, 58);
            this.panelTotalsBottom.Name = "panelTotalsBottom";
            this.panelTotalsBottom.Size = new System.Drawing.Size(1651, 261);
            this.panelTotalsBottom.TabIndex = 2;
            // 
            // dgv2
            // 
            this.dgv2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv2.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Location = new System.Drawing.Point(0, 0);
            this.dgv2.MainView = this.gridMain2;
            this.dgv2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Name = "dgv2";
            this.dgv2.Size = new System.Drawing.Size(1651, 261);
            this.dgv2.TabIndex = 5;
            this.dgv2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain2});
            // 
            // gridMain2
            // 
            this.gridMain2.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.BandPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain2.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain2.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain2.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain2.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain2.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(120)))), ((int)(((byte)(88)))));
            this.gridMain2.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain2.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(136)))), ((int)(((byte)(91)))));
            this.gridMain2.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.FooterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain2.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain2.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain2.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain2.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain2.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain2.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain2.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain2.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain2.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain2.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(172)))), ((int)(((byte)(134)))));
            this.gridMain2.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(234)))), ((int)(((byte)(216)))));
            this.gridMain2.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(169)))), ((int)(((byte)(107)))));
            this.gridMain2.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(224)))), ((int)(((byte)(190)))));
            this.gridMain2.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(237)))));
            this.gridMain2.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain2.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(120)))), ((int)(((byte)(88)))));
            this.gridMain2.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain2.Appearance.Preview.Options.UseFont = true;
            this.gridMain2.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain2.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain2.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.Row.Options.UseBackColor = true;
            this.gridMain2.Appearance.Row.Options.UseForeColor = true;
            this.gridMain2.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain2.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(159)))), ((int)(((byte)(114)))));
            this.gridMain2.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(169)))), ((int)(((byte)(107)))));
            this.gridMain2.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain2.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain2.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain2.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand1});
            this.gridMain2.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn23,
            this.bandedGridColumn25,
            this.bandedGridColumn27,
            this.bandedGridColumn29,
            this.bandedGridColumn30,
            this.bandedGridColumn40,
            this.bandedGridColumn41,
            this.bandedGridColumn31,
            this.bandedGridColumn34,
            this.bandedGridColumn35,
            this.bandedGridColumn28});
            this.gridMain2.DetailHeight = 431;
            this.gridMain2.GridControl = this.dgv2;
            this.gridMain2.Name = "gridMain2";
            this.gridMain2.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain2.OptionsPrint.PrintBandHeader = false;
            this.gridMain2.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain2.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain2.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain2.OptionsView.ShowFooter = true;
            this.gridMain2.OptionsView.ShowGroupPanel = false;
            this.gridMain2.PaintStyleName = "Style3D";
            // 
            // gridBand1
            // 
            this.gridBand1.Columns.Add(this.bandedGridColumn23);
            this.gridBand1.Columns.Add(this.bandedGridColumn25);
            this.gridBand1.Columns.Add(this.bandedGridColumn27);
            this.gridBand1.Columns.Add(this.bandedGridColumn29);
            this.gridBand1.Columns.Add(this.bandedGridColumn30);
            this.gridBand1.Columns.Add(this.bandedGridColumn40);
            this.gridBand1.Columns.Add(this.bandedGridColumn41);
            this.gridBand1.Columns.Add(this.bandedGridColumn31);
            this.gridBand1.Columns.Add(this.bandedGridColumn34);
            this.gridBand1.Columns.Add(this.bandedGridColumn35);
            this.gridBand1.Columns.Add(this.bandedGridColumn28);
            this.gridBand1.MinWidth = 22;
            this.gridBand1.Name = "gridBand1";
            this.gridBand1.VisibleIndex = 0;
            this.gridBand1.Width = 1135;
            // 
            // bandedGridColumn23
            // 
            this.bandedGridColumn23.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn23.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn23.Caption = "Num";
            this.bandedGridColumn23.FieldName = "num";
            this.bandedGridColumn23.MinWidth = 42;
            this.bandedGridColumn23.Name = "bandedGridColumn23";
            this.bandedGridColumn23.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn23.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn23.Visible = true;
            this.bandedGridColumn23.Width = 57;
            // 
            // bandedGridColumn25
            // 
            this.bandedGridColumn25.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn25.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn25.Caption = "Status";
            this.bandedGridColumn25.FieldName = "status";
            this.bandedGridColumn25.MinWidth = 42;
            this.bandedGridColumn25.Name = "bandedGridColumn25";
            this.bandedGridColumn25.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn25.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn25.Width = 161;
            // 
            // bandedGridColumn27
            // 
            this.bandedGridColumn27.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn27.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn27.Caption = "Month";
            this.bandedGridColumn27.FieldName = "month";
            this.bandedGridColumn27.MinWidth = 42;
            this.bandedGridColumn27.Name = "bandedGridColumn27";
            this.bandedGridColumn27.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn27.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn27.Visible = true;
            this.bandedGridColumn27.Width = 128;
            // 
            // bandedGridColumn29
            // 
            this.bandedGridColumn29.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn29.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn29.Caption = "Security National";
            this.bandedGridColumn29.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn29.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn29.FieldName = "Security National";
            this.bandedGridColumn29.MinWidth = 42;
            this.bandedGridColumn29.Name = "bandedGridColumn29";
            this.bandedGridColumn29.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn29.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn29.Visible = true;
            this.bandedGridColumn29.Width = 120;
            // 
            // bandedGridColumn30
            // 
            this.bandedGridColumn30.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn30.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn30.Caption = "Forethought";
            this.bandedGridColumn30.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn30.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn30.FieldName = "Forethought";
            this.bandedGridColumn30.MinWidth = 47;
            this.bandedGridColumn30.Name = "bandedGridColumn30";
            this.bandedGridColumn30.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn30.Visible = true;
            this.bandedGridColumn30.Width = 138;
            // 
            // bandedGridColumn40
            // 
            this.bandedGridColumn40.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn40.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn40.Caption = "CADENCE CD";
            this.bandedGridColumn40.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn40.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn40.FieldName = "CD";
            this.bandedGridColumn40.MinWidth = 40;
            this.bandedGridColumn40.Name = "bandedGridColumn40";
            this.bandedGridColumn40.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn40.Visible = true;
            this.bandedGridColumn40.Width = 124;
            // 
            // bandedGridColumn41
            // 
            this.bandedGridColumn41.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn41.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn41.Caption = "Unity";
            this.bandedGridColumn41.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn41.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn41.FieldName = "Unity";
            this.bandedGridColumn41.MinWidth = 40;
            this.bandedGridColumn41.Name = "bandedGridColumn41";
            this.bandedGridColumn41.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn41.Visible = true;
            this.bandedGridColumn41.Width = 115;
            // 
            // bandedGridColumn31
            // 
            this.bandedGridColumn31.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn31.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn31.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn31.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn31.Caption = "Unity PB";
            this.bandedGridColumn31.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn31.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn31.FieldName = "Unity PB";
            this.bandedGridColumn31.MinWidth = 42;
            this.bandedGridColumn31.Name = "bandedGridColumn31";
            this.bandedGridColumn31.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn31.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn31.Visible = true;
            this.bandedGridColumn31.Width = 100;
            // 
            // bandedGridColumn34
            // 
            this.bandedGridColumn34.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn34.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn34.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn34.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn34.Caption = "FDLIC";
            this.bandedGridColumn34.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn34.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn34.FieldName = "FDLIC";
            this.bandedGridColumn34.MinWidth = 42;
            this.bandedGridColumn34.Name = "bandedGridColumn34";
            this.bandedGridColumn34.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn34.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn34.Visible = true;
            this.bandedGridColumn34.Width = 109;
            // 
            // bandedGridColumn35
            // 
            this.bandedGridColumn35.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn35.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn35.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn35.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn35.Caption = "FDLIC PB";
            this.bandedGridColumn35.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn35.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn35.FieldName = "FDLIC PB";
            this.bandedGridColumn35.MinWidth = 42;
            this.bandedGridColumn35.Name = "bandedGridColumn35";
            this.bandedGridColumn35.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn35.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn35.Visible = true;
            this.bandedGridColumn35.Width = 126;
            // 
            // bandedGridColumn28
            // 
            this.bandedGridColumn28.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn28.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn28.Caption = "Total";
            this.bandedGridColumn28.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn28.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn28.FieldName = "total";
            this.bandedGridColumn28.MinWidth = 29;
            this.bandedGridColumn28.Name = "bandedGridColumn28";
            this.bandedGridColumn28.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn28.Visible = true;
            this.bandedGridColumn28.Width = 118;
            // 
            // panelTotalsTop
            // 
            this.panelTotalsTop.Controls.Add(this.label3);
            this.panelTotalsTop.Controls.Add(this.cmbPreOrPost);
            this.panelTotalsTop.Controls.Add(this.btnRunTotals);
            this.panelTotalsTop.Controls.Add(this.label2);
            this.panelTotalsTop.Controls.Add(this.dateTimePicker3);
            this.panelTotalsTop.Controls.Add(this.pictureBox2);
            this.panelTotalsTop.Controls.Add(this.button1);
            this.panelTotalsTop.Controls.Add(this.button2);
            this.panelTotalsTop.Controls.Add(this.dateTimePicker2);
            this.panelTotalsTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTotalsTop.Location = new System.Drawing.Point(0, 0);
            this.panelTotalsTop.Name = "panelTotalsTop";
            this.panelTotalsTop.Size = new System.Drawing.Size(1651, 58);
            this.panelTotalsTop.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1105, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 17);
            this.label3.TabIndex = 167;
            this.label3.Text = "Post or Pre";
            // 
            // cmbPreOrPost
            // 
            this.cmbPreOrPost.FormattingEnabled = true;
            this.cmbPreOrPost.Items.AddRange(new object[] {
            "Post",
            "Pre"});
            this.cmbPreOrPost.Location = new System.Drawing.Point(1038, 16);
            this.cmbPreOrPost.Name = "cmbPreOrPost";
            this.cmbPreOrPost.Size = new System.Drawing.Size(61, 24);
            this.cmbPreOrPost.TabIndex = 166;
            this.cmbPreOrPost.Text = "Post";
            // 
            // btnRunTotals
            // 
            this.btnRunTotals.BackColor = System.Drawing.Color.Transparent;
            this.btnRunTotals.Location = new System.Drawing.Point(698, 18);
            this.btnRunTotals.Name = "btnRunTotals";
            this.btnRunTotals.Size = new System.Drawing.Size(75, 23);
            this.btnRunTotals.TabIndex = 165;
            this.btnRunTotals.Text = "Run";
            this.btnRunTotals.UseVisualStyleBackColor = false;
            this.btnRunTotals.Click += new System.EventHandler(this.btnRunTotals_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(347, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 17);
            this.label2.TabIndex = 164;
            this.label2.Text = "- to -";
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Location = new System.Drawing.Point(390, 17);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker3.TabIndex = 163;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(10, 12);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(33, 27);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 162;
            this.pictureBox2.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(629, 16);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(33, 28);
            this.button1.TabIndex = 161;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(69, 12);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(33, 28);
            this.button2.TabIndex = 160;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(108, 16);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker2.TabIndex = 159;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panelFDLICAll);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1651, 319);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "FDLIC Report";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panelFDLICAll
            // 
            this.panelFDLICAll.Controls.Add(this.panelFDLICBottom);
            this.panelFDLICAll.Controls.Add(this.panelFDLICTop);
            this.panelFDLICAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelFDLICAll.Location = new System.Drawing.Point(0, 0);
            this.panelFDLICAll.Name = "panelFDLICAll";
            this.panelFDLICAll.Size = new System.Drawing.Size(1651, 319);
            this.panelFDLICAll.TabIndex = 0;
            // 
            // panelFDLICBottom
            // 
            this.panelFDLICBottom.Controls.Add(this.dgv3);
            this.panelFDLICBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelFDLICBottom.Location = new System.Drawing.Point(0, 57);
            this.panelFDLICBottom.Name = "panelFDLICBottom";
            this.panelFDLICBottom.Size = new System.Drawing.Size(1651, 262);
            this.panelFDLICBottom.TabIndex = 2;
            // 
            // dgv3
            // 
            this.dgv3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv3.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Location = new System.Drawing.Point(0, 0);
            this.dgv3.MainView = this.gridMain3;
            this.dgv3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Name = "dgv3";
            this.dgv3.Size = new System.Drawing.Size(1651, 262);
            this.dgv3.TabIndex = 5;
            this.dgv3.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain3});
            // 
            // gridMain3
            // 
            this.gridMain3.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain3.Appearance.BandPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain3.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain3.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain3.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain3.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain3.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain3.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(120)))), ((int)(((byte)(88)))));
            this.gridMain3.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain3.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(136)))), ((int)(((byte)(91)))));
            this.gridMain3.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.FooterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain3.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain3.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain3.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain3.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain3.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain3.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain3.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain3.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain3.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain3.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain3.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(172)))), ((int)(((byte)(134)))));
            this.gridMain3.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(234)))), ((int)(((byte)(216)))));
            this.gridMain3.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(169)))), ((int)(((byte)(107)))));
            this.gridMain3.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain3.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(224)))), ((int)(((byte)(190)))));
            this.gridMain3.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(237)))));
            this.gridMain3.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain3.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(120)))), ((int)(((byte)(88)))));
            this.gridMain3.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain3.Appearance.Preview.Options.UseFont = true;
            this.gridMain3.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain3.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain3.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.Row.Options.UseBackColor = true;
            this.gridMain3.Appearance.Row.Options.UseForeColor = true;
            this.gridMain3.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain3.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain3.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(159)))), ((int)(((byte)(114)))));
            this.gridMain3.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(169)))), ((int)(((byte)(107)))));
            this.gridMain3.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain3.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain3.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain3.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand2});
            this.gridMain3.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn38,
            this.bandedGridColumn37,
            this.bandedGridColumn42,
            this.bandedGridColumn43,
            this.bandedGridColumn44,
            this.bandedGridColumn48,
            this.bandedGridColumn50,
            this.bandedGridColumn32,
            this.bandedGridColumn33,
            this.bandedGridColumn36,
            this.bandedGridColumn39,
            this.bandedGridColumn45,
            this.bandedGridColumn46});
            this.gridMain3.DetailHeight = 431;
            this.gridMain3.GridControl = this.dgv3;
            this.gridMain3.Name = "gridMain3";
            this.gridMain3.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain3.OptionsPrint.PrintBandHeader = false;
            this.gridMain3.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain3.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain3.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain3.OptionsView.ShowFooter = true;
            this.gridMain3.OptionsView.ShowGroupPanel = false;
            this.gridMain3.PaintStyleName = "Style3D";
            this.gridMain3.DoubleClick += new System.EventHandler(this.gridMain3_DoubleClick);
            // 
            // gridBand2
            // 
            this.gridBand2.Columns.Add(this.bandedGridColumn38);
            this.gridBand2.Columns.Add(this.bandedGridColumn37);
            this.gridBand2.Columns.Add(this.bandedGridColumn42);
            this.gridBand2.Columns.Add(this.bandedGridColumn43);
            this.gridBand2.Columns.Add(this.bandedGridColumn44);
            this.gridBand2.Columns.Add(this.bandedGridColumn48);
            this.gridBand2.Columns.Add(this.bandedGridColumn50);
            this.gridBand2.Columns.Add(this.bandedGridColumn32);
            this.gridBand2.Columns.Add(this.bandedGridColumn33);
            this.gridBand2.Columns.Add(this.bandedGridColumn36);
            this.gridBand2.Columns.Add(this.bandedGridColumn39);
            this.gridBand2.Columns.Add(this.bandedGridColumn45);
            this.gridBand2.Columns.Add(this.bandedGridColumn46);
            this.gridBand2.MinWidth = 26;
            this.gridBand2.Name = "gridBand2";
            this.gridBand2.VisibleIndex = 0;
            this.gridBand2.Width = 1549;
            // 
            // bandedGridColumn38
            // 
            this.bandedGridColumn38.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn38.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn38.Caption = "Month";
            this.bandedGridColumn38.FieldName = "month";
            this.bandedGridColumn38.MinWidth = 49;
            this.bandedGridColumn38.Name = "bandedGridColumn38";
            this.bandedGridColumn38.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn38.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn38.Visible = true;
            this.bandedGridColumn38.Width = 120;
            // 
            // bandedGridColumn37
            // 
            this.bandedGridColumn37.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn37.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn37.Caption = "FDLIC TRUST";
            this.bandedGridColumn37.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn37.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn37.FieldName = "FDLICTRUST";
            this.bandedGridColumn37.MinWidth = 49;
            this.bandedGridColumn37.Name = "bandedGridColumn37";
            this.bandedGridColumn37.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn37.Visible = true;
            this.bandedGridColumn37.Width = 210;
            // 
            // bandedGridColumn42
            // 
            this.bandedGridColumn42.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn42.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn42.Caption = "DC";
            this.bandedGridColumn42.FieldName = "DC";
            this.bandedGridColumn42.MinWidth = 49;
            this.bandedGridColumn42.Name = "bandedGridColumn42";
            this.bandedGridColumn42.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn42.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn42.Visible = true;
            this.bandedGridColumn42.Width = 104;
            // 
            // bandedGridColumn43
            // 
            this.bandedGridColumn43.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn43.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn43.Caption = "Description";
            this.bandedGridColumn43.FieldName = "description";
            this.bandedGridColumn43.MinWidth = 55;
            this.bandedGridColumn43.Name = "bandedGridColumn43";
            this.bandedGridColumn43.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn43.Visible = true;
            this.bandedGridColumn43.Width = 203;
            // 
            // bandedGridColumn44
            // 
            this.bandedGridColumn44.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn44.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn44.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn44.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn44.Caption = "CADENCE Date";
            this.bandedGridColumn44.FieldName = "cadenceDate";
            this.bandedGridColumn44.MinWidth = 49;
            this.bandedGridColumn44.Name = "bandedGridColumn44";
            this.bandedGridColumn44.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn44.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn44.Visible = true;
            this.bandedGridColumn44.Width = 96;
            // 
            // bandedGridColumn48
            // 
            this.bandedGridColumn48.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn48.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn48.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn48.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn48.Caption = "Contract Number";
            this.bandedGridColumn48.FieldName = "contractNumber";
            this.bandedGridColumn48.MinWidth = 49;
            this.bandedGridColumn48.Name = "bandedGridColumn48";
            this.bandedGridColumn48.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn48.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn48.Visible = true;
            this.bandedGridColumn48.Width = 105;
            // 
            // bandedGridColumn50
            // 
            this.bandedGridColumn50.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn50.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn50.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn50.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn50.Caption = "Funeral Number";
            this.bandedGridColumn50.FieldName = "funeralNumber";
            this.bandedGridColumn50.MinWidth = 49;
            this.bandedGridColumn50.Name = "bandedGridColumn50";
            this.bandedGridColumn50.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn50.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn50.Visible = true;
            this.bandedGridColumn50.Width = 115;
            // 
            // bandedGridColumn32
            // 
            this.bandedGridColumn32.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn32.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn32.Caption = "FDLICTRUST";
            this.bandedGridColumn32.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn32.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn32.FieldName = "FDLICTRUST2";
            this.bandedGridColumn32.MinWidth = 29;
            this.bandedGridColumn32.Name = "bandedGridColumn32";
            this.bandedGridColumn32.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn32.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn32.Visible = true;
            this.bandedGridColumn32.Width = 107;
            // 
            // bandedGridColumn33
            // 
            this.bandedGridColumn33.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn33.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn33.Caption = "DC";
            this.bandedGridColumn33.FieldName = "DC2";
            this.bandedGridColumn33.MinWidth = 29;
            this.bandedGridColumn33.Name = "bandedGridColumn33";
            this.bandedGridColumn33.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn33.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn33.Visible = true;
            // 
            // bandedGridColumn36
            // 
            this.bandedGridColumn36.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn36.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn36.Caption = "Description";
            this.bandedGridColumn36.FieldName = "description2";
            this.bandedGridColumn36.MinWidth = 29;
            this.bandedGridColumn36.Name = "bandedGridColumn36";
            this.bandedGridColumn36.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn36.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn36.Visible = true;
            this.bandedGridColumn36.Width = 110;
            // 
            // bandedGridColumn39
            // 
            this.bandedGridColumn39.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn39.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn39.Caption = "CADENSE Date";
            this.bandedGridColumn39.FieldName = "cadenceDate2";
            this.bandedGridColumn39.MinWidth = 29;
            this.bandedGridColumn39.Name = "bandedGridColumn39";
            this.bandedGridColumn39.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn39.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn39.Visible = true;
            this.bandedGridColumn39.Width = 92;
            // 
            // bandedGridColumn45
            // 
            this.bandedGridColumn45.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn45.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn45.Caption = "Contract Number";
            this.bandedGridColumn45.FieldName = "contractNumber2";
            this.bandedGridColumn45.MinWidth = 29;
            this.bandedGridColumn45.Name = "bandedGridColumn45";
            this.bandedGridColumn45.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn45.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn45.Visible = true;
            this.bandedGridColumn45.Width = 110;
            // 
            // bandedGridColumn46
            // 
            this.bandedGridColumn46.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn46.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn46.Caption = "Funeral Number";
            this.bandedGridColumn46.FieldName = "funeralNumber2";
            this.bandedGridColumn46.MinWidth = 29;
            this.bandedGridColumn46.Name = "bandedGridColumn46";
            this.bandedGridColumn46.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn46.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn46.Visible = true;
            this.bandedGridColumn46.Width = 102;
            // 
            // panelFDLICTop
            // 
            this.panelFDLICTop.Controls.Add(this.btnGenerate);
            this.panelFDLICTop.Controls.Add(this.pictureBox3);
            this.panelFDLICTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelFDLICTop.Location = new System.Drawing.Point(0, 0);
            this.panelFDLICTop.Name = "panelFDLICTop";
            this.panelFDLICTop.Size = new System.Drawing.Size(1651, 57);
            this.panelFDLICTop.TabIndex = 1;
            // 
            // btnGenerate
            // 
            this.btnGenerate.BackColor = System.Drawing.Color.Transparent;
            this.btnGenerate.Location = new System.Drawing.Point(67, 16);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(83, 23);
            this.btnGenerate.TabIndex = 157;
            this.btnGenerate.Text = "Generate";
            this.btnGenerate.UseVisualStyleBackColor = false;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(10, 13);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(33, 27);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 147;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.barImport);
            this.panelTop.Controls.Add(this.chkTBB);
            this.panelTop.Controls.Add(this.chkGroupContract);
            this.panelTop.Controls.Add(this.chkCmbCompany);
            this.panelTop.Controls.Add(this.label1);
            this.panelTop.Controls.Add(this.btnRight);
            this.panelTop.Controls.Add(this.btnLeft);
            this.panelTop.Controls.Add(this.btnRun);
            this.panelTop.Controls.Add(this.dateTimePicker1);
            this.panelTop.Controls.Add(this.lblYear);
            this.panelTop.Controls.Add(this.cmbYear);
            this.panelTop.Controls.Add(this.lblMonth);
            this.panelTop.Controls.Add(this.cmbMonth);
            this.panelTop.Controls.Add(this.btnSave);
            this.panelTop.Controls.Add(this.pictureBox1);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1659, 64);
            this.panelTop.TabIndex = 7;
            // 
            // barImport
            // 
            this.barImport.BackColor = System.Drawing.Color.Lime;
            this.barImport.Location = new System.Drawing.Point(112, 43);
            this.barImport.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.barImport.Name = "barImport";
            this.barImport.Size = new System.Drawing.Size(581, 15);
            this.barImport.TabIndex = 165;
            // 
            // chkTBB
            // 
            this.chkTBB.AutoSize = true;
            this.chkTBB.Location = new System.Drawing.Point(1035, 40);
            this.chkTBB.Name = "chkTBB";
            this.chkTBB.Size = new System.Drawing.Size(97, 21);
            this.chkTBB.TabIndex = 164;
            this.chkTBB.Text = "Load SMFS";
            this.chkTBB.UseVisualStyleBackColor = true;
            this.chkTBB.CheckedChanged += new System.EventHandler(this.chkTBB_CheckedChanged);
            // 
            // chkGroupContract
            // 
            this.chkGroupContract.AutoSize = true;
            this.chkGroupContract.Location = new System.Drawing.Point(865, 40);
            this.chkGroupContract.Name = "chkGroupContract";
            this.chkGroupContract.Size = new System.Drawing.Size(146, 21);
            this.chkGroupContract.TabIndex = 163;
            this.chkGroupContract.Text = "Group by Contract";
            this.chkGroupContract.UseVisualStyleBackColor = true;
            this.chkGroupContract.CheckedChanged += new System.EventHandler(this.chkGroupContract_CheckedChanged);
            // 
            // chkCmbCompany
            // 
            this.chkCmbCompany.EditValue = "";
            this.chkCmbCompany.Location = new System.Drawing.Point(522, 16);
            this.chkCmbCompany.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkCmbCompany.Name = "chkCmbCompany";
            this.chkCmbCompany.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.chkCmbCompany.Properties.DisplayMember = "trustCompany";
            this.chkCmbCompany.Properties.SeparatorChar = '|';
            this.chkCmbCompany.Size = new System.Drawing.Size(171, 22);
            this.chkCmbCompany.TabIndex = 162;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(699, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 17);
            this.label1.TabIndex = 160;
            this.label1.Text = "Trust Companies";
            // 
            // btnRight
            // 
            this.btnRight.BackColor = System.Drawing.Color.Transparent;
            this.btnRight.Image = ((System.Drawing.Image)(resources.GetObject("btnRight.Image")));
            this.btnRight.Location = new System.Drawing.Point(351, 10);
            this.btnRight.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(33, 28);
            this.btnRight.TabIndex = 158;
            this.btnRight.UseVisualStyleBackColor = false;
            this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
            // 
            // btnLeft
            // 
            this.btnLeft.BackColor = System.Drawing.Color.Transparent;
            this.btnLeft.Image = ((System.Drawing.Image)(resources.GetObject("btnLeft.Image")));
            this.btnLeft.Location = new System.Drawing.Point(73, 9);
            this.btnLeft.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(33, 28);
            this.btnLeft.TabIndex = 157;
            this.btnLeft.UseVisualStyleBackColor = false;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // btnRun
            // 
            this.btnRun.BackColor = System.Drawing.Color.Transparent;
            this.btnRun.Location = new System.Drawing.Point(417, 14);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(75, 23);
            this.btnRun.TabIndex = 156;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = false;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(112, 13);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker1.TabIndex = 155;
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Location = new System.Drawing.Point(1132, 18);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(35, 17);
            this.lblYear.TabIndex = 154;
            this.lblYear.Text = "Year";
            // 
            // cmbYear
            // 
            this.cmbYear.FormattingEnabled = true;
            this.cmbYear.Location = new System.Drawing.Point(1042, 13);
            this.cmbYear.Name = "cmbYear";
            this.cmbYear.Size = new System.Drawing.Size(73, 24);
            this.cmbYear.TabIndex = 153;
            // 
            // lblMonth
            // 
            this.lblMonth.AutoSize = true;
            this.lblMonth.Location = new System.Drawing.Point(989, 17);
            this.lblMonth.Name = "lblMonth";
            this.lblMonth.Size = new System.Drawing.Size(47, 17);
            this.lblMonth.TabIndex = 152;
            this.lblMonth.Text = "Month";
            // 
            // cmbMonth
            // 
            this.cmbMonth.FormattingEnabled = true;
            this.cmbMonth.Location = new System.Drawing.Point(865, 13);
            this.cmbMonth.Name = "cmbMonth";
            this.cmbMonth.Size = new System.Drawing.Size(120, 24);
            this.cmbMonth.TabIndex = 151;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSave.Location = new System.Drawing.Point(1212, 15);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 150;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 27);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 146;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // TrustData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1659, 442);
            this.Controls.Add(this.panelAll);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "TrustData";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trust Company Data";
            this.Load += new System.EventHandler(this.TrustData_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelAll.ResumeLayout(false);
            this.panelBottom.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.panelTotalsAll.ResumeLayout(false);
            this.panelTotalsBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).EndInit();
            this.panelTotalsTop.ResumeLayout(false);
            this.panelTotalsTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.panelFDLICAll.ResumeLayout(false);
            this.panelFDLICBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).EndInit();
            this.panelFDLICTop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkCmbCompany.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Panel panelAll;
        private System.Windows.Forms.Panel panelBottom;
        private DevExpress.XtraGrid.GridControl dgv;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn12;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn13;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn7;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn11;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn9;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn15;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn14;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn16;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn17;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn19;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn18;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn21;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn20;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn22;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRight;
        private System.Windows.Forms.Button btnLeft;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.ComboBox cmbYear;
        private System.Windows.Forms.Label lblMonth;
        private System.Windows.Forms.ComboBox cmbMonth;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevExpress.XtraEditors.CheckedComboBoxEdit chkCmbCompany;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panelTotalsAll;
        private System.Windows.Forms.Panel panelTotalsBottom;
        private DevExpress.XtraGrid.GridControl dgv2;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain2;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn23;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn25;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn27;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn29;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn30;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn40;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn41;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn31;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn34;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn35;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn28;
        private System.Windows.Forms.Panel panelTotalsTop;
        private System.Windows.Forms.Button btnRunTotals;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbPreOrPost;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn24;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn26;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panelFDLICAll;
        private System.Windows.Forms.Panel panelFDLICBottom;
        private DevExpress.XtraGrid.GridControl dgv3;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn38;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn37;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn42;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn43;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn44;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn48;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn50;
        private System.Windows.Forms.Panel panelFDLICTop;
        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.PictureBox pictureBox3;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn32;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn33;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn36;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn39;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn45;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn46;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn47;
        private System.Windows.Forms.CheckBox chkGroupContract;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn49;
        private System.Windows.Forms.CheckBox chkTBB;
        private System.Windows.Forms.ProgressBar barImport;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem addToPolicyContractXReferenceToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn51;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn52;
    }
}