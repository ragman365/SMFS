﻿namespace SMFS
{
    partial class TrustReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrustReports));
            this.gridBand2 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn32 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn35 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn36 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn33 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn34 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn37 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn38 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn39 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn40 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn41 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn42 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn43 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn87 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn44 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn45 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn166 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn46 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn47 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn48 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn49 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn50 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn51 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn52 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn53 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn54 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn55 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn56 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn57 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn167 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn91 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn58 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn74 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn168 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn75 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn85 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn86 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelAll = new System.Windows.Forms.Panel();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabAllData = new System.Windows.Forms.TabPage();
            this.panel1All = new System.Windows.Forms.Panel();
            this.panel1Bottom = new System.Windows.Forms.Panel();
            this.dgv6 = new DevExpress.XtraGrid.GridControl();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editContractToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewContractToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gridMain6 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand6 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn62 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn63 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn59 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.lastName79 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn78 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn1 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn81 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn84 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn83 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn82 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn89 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.contractNumber68 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn88 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn90 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn80 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.prioryear = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.ytdnow = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn60 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn61 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn64 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn65 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn66 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn67 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn69 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn70 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn71 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn72 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn73 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.currentmonth = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.interest204 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.ragCurrentMonth102 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.as40092 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn93 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.original90 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.ytdtotal = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.deathRemYTDprevious205 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.deathRemCurrMonth206 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.refundRemYTDprevious207 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.refundRemCurrMonth208 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.currentRemovals = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.totalpaid = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn161 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn76 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn77 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn9 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panel1Top = new System.Windows.Forms.Panel();
            this.lblStatus = new System.Windows.Forms.Label();
            this.btnSaveData = new System.Windows.Forms.Button();
            this.tabPlacedInTrust = new System.Windows.Forms.TabPage();
            this.dgv2 = new DevExpress.XtraGrid.GridControl();
            this.gridMain2 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand5 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.gridBand13 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.num103 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.loc92 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.location163 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.contract135 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.ssn138 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.lastName126 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.firstName127 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.address129 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.city130 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.state131 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.zip132 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand14 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.beginningBalance139 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn140 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn154 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn159 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn162 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn165 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn128 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn136 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn147 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn150 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn145 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn144 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn141 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn164 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn149 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn153 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn148 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn143 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn146 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn142 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn102 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn155 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn160 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn133 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn158 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn137 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn156 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn157 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn5 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn68 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn10 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.tabBeginning = new System.Windows.Forms.TabPage();
            this.dgv7 = new DevExpress.XtraGrid.GridControl();
            this.gridMain7 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand1 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.gridBand15 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.loc2 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.location209 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.num4 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.contract12 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.ssn13 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.lastName5 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.firstName6 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.address8 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.city9 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.state10 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.zip11 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand16 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.beginningBalance15 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.currentPayments27 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.interest68 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.currentremoval = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.endingBalance29 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn31 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn7 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn22 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn25 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn20 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn19 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn16 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn30 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn24 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn26 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn23 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn18 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn21 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn17 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn3 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn14 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn28 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn11 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.tabRemoved = new System.Windows.Forms.TabPage();
            this.dgv8 = new DevExpress.XtraGrid.GridControl();
            this.gridMain8 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand7 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.gridBand17 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.loc169 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.location210 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.num173 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.contract179 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.fnl200 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.lastName170 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.firstName171 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.address175 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.city176 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.state177 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.zip178 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.ssn180 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand18 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.beginningBalance182 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.interest201 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.currentDeathClaims202 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.currentRefunds196 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.currentInterest203 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.endingBalance197 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn199 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn174 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn189 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn192 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn187 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn186 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn183 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn198 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn191 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn193 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn190 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn185 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn188 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn184 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn172 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn181 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn194 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn195 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn12 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.tabDiff = new System.Windows.Forms.TabPage();
            this.panelDiffAll = new System.Windows.Forms.Panel();
            this.panelDiffBottom = new System.Windows.Forms.Panel();
            this.dgv9 = new DevExpress.XtraGrid.GridControl();
            this.gridMain9 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand3 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn94 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn95 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn96 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn97 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn98 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn99 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn104 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn105 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn106 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn107 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn108 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn109 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn110 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn111 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn112 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn113 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn114 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn115 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn116 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn117 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn118 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn119 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn120 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn121 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn122 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn100 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn101 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn123 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn124 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelDiffTop = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.btnRunDiff = new System.Windows.Forms.Button();
            this.tabCompare = new System.Windows.Forms.TabPage();
            this.panelCompareAll = new System.Windows.Forms.Panel();
            this.panelCompareBottom = new System.Windows.Forms.Panel();
            this.dgv10 = new DevExpress.XtraGrid.GridControl();
            this.gridMain10 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand4 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn125 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn134 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn151 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.as400153 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.difference154 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelCompareTop = new System.Windows.Forms.Panel();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.btnPaul = new System.Windows.Forms.Button();
            this.tabCompareBalance = new System.Windows.Forms.TabPage();
            this.dgv11 = new DevExpress.XtraGrid.GridControl();
            this.gridMain11 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand8 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn2 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn4 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn6 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn8 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelTop = new System.Windows.Forms.Panel();
            this.chkAlphaMode = new System.Windows.Forms.CheckBox();
            this.lblWait = new System.Windows.Forms.Label();
            this.btnVerify = new System.Windows.Forms.Button();
            this.chkLiveOnly = new System.Windows.Forms.CheckBox();
            this.chkRunSMFS = new System.Windows.Forms.CheckBox();
            this.chkShowCurrentMonth = new System.Windows.Forms.CheckBox();
            this.chkShowLocations = new System.Windows.Forms.CheckBox();
            this.chkDBR = new System.Windows.Forms.CheckBox();
            this.chkExpand = new System.Windows.Forms.CheckBox();
            this.chk2002 = new System.Windows.Forms.CheckBox();
            this.chkComboLocNames = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            this.lblContract = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtContract = new System.Windows.Forms.TextBox();
            this.chkComboLocation = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            this.chkFilterNewContracts = new System.Windows.Forms.CheckBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.barImport = new System.Windows.Forms.ProgressBar();
            this.btnRun = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnRight = new System.Windows.Forms.Button();
            this.btnLeft = new System.Windows.Forms.Button();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miscToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importOriginalDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lockScreenPositionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unLockScreenPositionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.compareBeginningBalanceToLastMonthEndingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editMassReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.runTrustSummaryReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.columnsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentsPlacedInTrustToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.paymentsRemovedFromTrustToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trustBeginningBalanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rilesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importNewRilesFromCliffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.myStatus = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panelAll.SuspendLayout();
            this.panelBottom.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabAllData.SuspendLayout();
            this.panel1All.SuspendLayout();
            this.panel1Bottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv6)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain6)).BeginInit();
            this.panel1Top.SuspendLayout();
            this.tabPlacedInTrust.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).BeginInit();
            this.tabBeginning.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain7)).BeginInit();
            this.tabRemoved.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain8)).BeginInit();
            this.tabDiff.SuspendLayout();
            this.panelDiffAll.SuspendLayout();
            this.panelDiffBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain9)).BeginInit();
            this.panelDiffTop.SuspendLayout();
            this.tabCompare.SuspendLayout();
            this.panelCompareAll.SuspendLayout();
            this.panelCompareBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain10)).BeginInit();
            this.panelCompareTop.SuspendLayout();
            this.tabCompareBalance.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain11)).BeginInit();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboLocNames.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboLocation.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gridBand2
            // 
            this.gridBand2.Caption = "gridBandXXX";
            this.gridBand2.Columns.Add(this.bandedGridColumn32);
            this.gridBand2.Columns.Add(this.bandedGridColumn35);
            this.gridBand2.Columns.Add(this.bandedGridColumn36);
            this.gridBand2.Columns.Add(this.bandedGridColumn33);
            this.gridBand2.Columns.Add(this.bandedGridColumn34);
            this.gridBand2.Columns.Add(this.bandedGridColumn37);
            this.gridBand2.Columns.Add(this.bandedGridColumn38);
            this.gridBand2.Columns.Add(this.bandedGridColumn39);
            this.gridBand2.Columns.Add(this.bandedGridColumn40);
            this.gridBand2.Columns.Add(this.bandedGridColumn41);
            this.gridBand2.Columns.Add(this.bandedGridColumn42);
            this.gridBand2.Columns.Add(this.bandedGridColumn43);
            this.gridBand2.Columns.Add(this.bandedGridColumn87);
            this.gridBand2.Columns.Add(this.bandedGridColumn44);
            this.gridBand2.Columns.Add(this.bandedGridColumn45);
            this.gridBand2.Columns.Add(this.bandedGridColumn166);
            this.gridBand2.Columns.Add(this.bandedGridColumn46);
            this.gridBand2.Columns.Add(this.bandedGridColumn47);
            this.gridBand2.Columns.Add(this.bandedGridColumn48);
            this.gridBand2.Columns.Add(this.bandedGridColumn49);
            this.gridBand2.Columns.Add(this.bandedGridColumn50);
            this.gridBand2.Columns.Add(this.bandedGridColumn51);
            this.gridBand2.Columns.Add(this.bandedGridColumn52);
            this.gridBand2.Columns.Add(this.bandedGridColumn53);
            this.gridBand2.Columns.Add(this.bandedGridColumn54);
            this.gridBand2.Columns.Add(this.bandedGridColumn55);
            this.gridBand2.Columns.Add(this.bandedGridColumn56);
            this.gridBand2.Columns.Add(this.bandedGridColumn57);
            this.gridBand2.Columns.Add(this.bandedGridColumn167);
            this.gridBand2.Columns.Add(this.bandedGridColumn91);
            this.gridBand2.Columns.Add(this.bandedGridColumn58);
            this.gridBand2.Columns.Add(this.bandedGridColumn74);
            this.gridBand2.Columns.Add(this.bandedGridColumn168);
            this.gridBand2.Columns.Add(this.bandedGridColumn75);
            this.gridBand2.Columns.Add(this.bandedGridColumn85);
            this.gridBand2.Columns.Add(this.bandedGridColumn86);
            this.gridBand2.Name = "gridBand2";
            this.gridBand2.VisibleIndex = -1;
            this.gridBand2.Width = 1219;
            // 
            // bandedGridColumn32
            // 
            this.bandedGridColumn32.Caption = "Loc";
            this.bandedGridColumn32.FieldName = "loc";
            this.bandedGridColumn32.Name = "bandedGridColumn32";
            this.bandedGridColumn32.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn32.Visible = true;
            this.bandedGridColumn32.Width = 40;
            // 
            // bandedGridColumn35
            // 
            this.bandedGridColumn35.Caption = "Last Name";
            this.bandedGridColumn35.FieldName = "lastName";
            this.bandedGridColumn35.Name = "bandedGridColumn35";
            this.bandedGridColumn35.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn35.Visible = true;
            // 
            // bandedGridColumn36
            // 
            this.bandedGridColumn36.Caption = "First Name";
            this.bandedGridColumn36.FieldName = "firstName";
            this.bandedGridColumn36.Name = "bandedGridColumn36";
            this.bandedGridColumn36.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn36.Visible = true;
            // 
            // bandedGridColumn33
            // 
            this.bandedGridColumn33.Caption = "Location Name";
            this.bandedGridColumn33.FieldName = "Location Name";
            this.bandedGridColumn33.Name = "bandedGridColumn33";
            this.bandedGridColumn33.OptionsColumn.FixedWidth = true;
            // 
            // bandedGridColumn34
            // 
            this.bandedGridColumn34.Caption = "Num";
            this.bandedGridColumn34.FieldName = "num";
            this.bandedGridColumn34.Name = "bandedGridColumn34";
            this.bandedGridColumn34.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn34.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn34.Width = 50;
            // 
            // bandedGridColumn37
            // 
            this.bandedGridColumn37.Caption = "Name";
            this.bandedGridColumn37.FieldName = "fullname";
            this.bandedGridColumn37.Name = "bandedGridColumn37";
            this.bandedGridColumn37.OptionsColumn.FixedWidth = true;
            // 
            // bandedGridColumn38
            // 
            this.bandedGridColumn38.Caption = "Address";
            this.bandedGridColumn38.FieldName = "address1";
            this.bandedGridColumn38.Name = "bandedGridColumn38";
            this.bandedGridColumn38.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn38.Visible = true;
            // 
            // bandedGridColumn39
            // 
            this.bandedGridColumn39.Caption = "City";
            this.bandedGridColumn39.FieldName = "city";
            this.bandedGridColumn39.Name = "bandedGridColumn39";
            this.bandedGridColumn39.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn39.Visible = true;
            // 
            // bandedGridColumn40
            // 
            this.bandedGridColumn40.Caption = "State";
            this.bandedGridColumn40.FieldName = "state";
            this.bandedGridColumn40.Name = "bandedGridColumn40";
            this.bandedGridColumn40.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn40.Visible = true;
            this.bandedGridColumn40.Width = 50;
            // 
            // bandedGridColumn41
            // 
            this.bandedGridColumn41.Caption = "Zip";
            this.bandedGridColumn41.FieldName = "zip1";
            this.bandedGridColumn41.Name = "bandedGridColumn41";
            this.bandedGridColumn41.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn41.Visible = true;
            // 
            // bandedGridColumn42
            // 
            this.bandedGridColumn42.Caption = "Contract";
            this.bandedGridColumn42.FieldName = "contractNumber";
            this.bandedGridColumn42.Name = "bandedGridColumn42";
            this.bandedGridColumn42.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn42.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn42.Visible = true;
            this.bandedGridColumn42.Width = 64;
            // 
            // bandedGridColumn43
            // 
            this.bandedGridColumn43.Caption = "SS#";
            this.bandedGridColumn43.FieldName = "ssn";
            this.bandedGridColumn43.Name = "bandedGridColumn43";
            this.bandedGridColumn43.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn43.Visible = true;
            // 
            // bandedGridColumn87
            // 
            this.bandedGridColumn87.Caption = "FNL# or REF";
            this.bandedGridColumn87.FieldName = "ServiceId2";
            this.bandedGridColumn87.Name = "bandedGridColumn87";
            this.bandedGridColumn87.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn87.Visible = true;
            // 
            // bandedGridColumn44
            // 
            this.bandedGridColumn44.Caption = "17 & Prior Bal PD";
            this.bandedGridColumn44.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn44.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn44.FieldName = "prior";
            this.bandedGridColumn44.Name = "bandedGridColumn44";
            this.bandedGridColumn44.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn44.Width = 100;
            // 
            // bandedGridColumn45
            // 
            this.bandedGridColumn45.Caption = "YTD Prior Clm-Paid";
            this.bandedGridColumn45.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn45.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn45.FieldName = "beginningBalance";
            this.bandedGridColumn45.Name = "bandedGridColumn45";
            this.bandedGridColumn45.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn45.Visible = true;
            this.bandedGridColumn45.Width = 90;
            // 
            // bandedGridColumn166
            // 
            this.bandedGridColumn166.Caption = "YTD Prior Int";
            this.bandedGridColumn166.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn166.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn166.FieldName = "interest";
            this.bandedGridColumn166.Name = "bandedGridColumn166";
            this.bandedGridColumn166.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn166.Visible = true;
            // 
            // bandedGridColumn46
            // 
            this.bandedGridColumn46.Caption = "Agent";
            this.bandedGridColumn46.FieldName = "agentNumber";
            this.bandedGridColumn46.Name = "bandedGridColumn46";
            this.bandedGridColumn46.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn46.Width = 60;
            // 
            // bandedGridColumn47
            // 
            this.bandedGridColumn47.Caption = "Agent Name";
            this.bandedGridColumn47.FieldName = "agentName";
            this.bandedGridColumn47.Name = "bandedGridColumn47";
            this.bandedGridColumn47.OptionsColumn.FixedWidth = true;
            // 
            // bandedGridColumn48
            // 
            this.bandedGridColumn48.Caption = "Trust";
            this.bandedGridColumn48.FieldName = "trust";
            this.bandedGridColumn48.Name = "bandedGridColumn48";
            this.bandedGridColumn48.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn48.Width = 50;
            // 
            // bandedGridColumn49
            // 
            this.bandedGridColumn49.Caption = "Due Date";
            this.bandedGridColumn49.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn49.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn49.FieldName = "dueDate8";
            this.bandedGridColumn49.Name = "bandedGridColumn49";
            this.bandedGridColumn49.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn49.Width = 65;
            // 
            // bandedGridColumn50
            // 
            this.bandedGridColumn50.Caption = "Date Paid";
            this.bandedGridColumn50.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn50.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn50.FieldName = "payDate8";
            this.bandedGridColumn50.Name = "bandedGridColumn50";
            this.bandedGridColumn50.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn50.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn50.Width = 65;
            // 
            // bandedGridColumn51
            // 
            this.bandedGridColumn51.Caption = "Issue Date";
            this.bandedGridColumn51.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn51.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn51.FieldName = "issueDate8";
            this.bandedGridColumn51.Name = "bandedGridColumn51";
            this.bandedGridColumn51.OptionsColumn.FixedWidth = true;
            // 
            // bandedGridColumn52
            // 
            this.bandedGridColumn52.Caption = "Customer";
            this.bandedGridColumn52.FieldName = "customer";
            this.bandedGridColumn52.Name = "bandedGridColumn52";
            this.bandedGridColumn52.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn52.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn52.Width = 150;
            // 
            // bandedGridColumn53
            // 
            this.bandedGridColumn53.Caption = "Contract Value";
            this.bandedGridColumn53.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn53.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn53.FieldName = "contractValue";
            this.bandedGridColumn53.Name = "bandedGridColumn53";
            this.bandedGridColumn53.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn53.Width = 100;
            // 
            // bandedGridColumn54
            // 
            this.bandedGridColumn54.Caption = "Down Payment";
            this.bandedGridColumn54.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn54.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn54.FieldName = "downPayment";
            this.bandedGridColumn54.Name = "bandedGridColumn54";
            this.bandedGridColumn54.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn54.Width = 82;
            // 
            // bandedGridColumn55
            // 
            this.bandedGridColumn55.Caption = "Payment";
            this.bandedGridColumn55.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn55.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn55.FieldName = "paymentAmount";
            this.bandedGridColumn55.Name = "bandedGridColumn55";
            this.bandedGridColumn55.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn55.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn55.Width = 82;
            // 
            // bandedGridColumn56
            // 
            this.bandedGridColumn56.Caption = "Total Payments";
            this.bandedGridColumn56.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn56.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn56.FieldName = "totalPayments";
            this.bandedGridColumn56.Name = "bandedGridColumn56";
            this.bandedGridColumn56.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn56.Width = 82;
            // 
            // bandedGridColumn57
            // 
            this.bandedGridColumn57.Caption = "Current Month";
            this.bandedGridColumn57.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn57.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn57.FieldName = "paymentCurrMonth";
            this.bandedGridColumn57.Name = "bandedGridColumn57";
            this.bandedGridColumn57.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn57.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn57.Width = 82;
            // 
            // bandedGridColumn167
            // 
            this.bandedGridColumn167.Caption = "Current Death Clms";
            this.bandedGridColumn167.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn167.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn167.FieldName = "currentDeathClaims";
            this.bandedGridColumn167.Name = "bandedGridColumn167";
            this.bandedGridColumn167.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn167.Visible = true;
            // 
            // bandedGridColumn91
            // 
            this.bandedGridColumn91.Caption = "AS400";
            this.bandedGridColumn91.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn91.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn91.FieldName = "as400";
            this.bandedGridColumn91.Name = "bandedGridColumn91";
            this.bandedGridColumn91.OptionsColumn.FixedWidth = true;
            // 
            // bandedGridColumn58
            // 
            this.bandedGridColumn58.Caption = "YTD Total PD";
            this.bandedGridColumn58.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn58.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn58.FieldName = "ytdtotal";
            this.bandedGridColumn58.Name = "bandedGridColumn58";
            this.bandedGridColumn58.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn58.Width = 100;
            // 
            // bandedGridColumn74
            // 
            this.bandedGridColumn74.Caption = "Current Refunds";
            this.bandedGridColumn74.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn74.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn74.FieldName = "currentRefunds";
            this.bandedGridColumn74.Name = "bandedGridColumn74";
            this.bandedGridColumn74.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn74.Visible = true;
            this.bandedGridColumn74.Width = 100;
            // 
            // bandedGridColumn168
            // 
            this.bandedGridColumn168.Caption = "Int.";
            this.bandedGridColumn168.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn168.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn168.FieldName = "currentInterest";
            this.bandedGridColumn168.Name = "bandedGridColumn168";
            this.bandedGridColumn168.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn168.Visible = true;
            // 
            // bandedGridColumn75
            // 
            this.bandedGridColumn75.Caption = "Total YTD";
            this.bandedGridColumn75.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn75.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn75.FieldName = "endingBalance";
            this.bandedGridColumn75.Name = "bandedGridColumn75";
            this.bandedGridColumn75.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn75.Visible = true;
            this.bandedGridColumn75.Width = 125;
            // 
            // bandedGridColumn85
            // 
            this.bandedGridColumn85.Caption = "Commission";
            this.bandedGridColumn85.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn85.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn85.FieldName = "commission";
            this.bandedGridColumn85.Name = "bandedGridColumn85";
            this.bandedGridColumn85.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn85.Width = 95;
            // 
            // bandedGridColumn86
            // 
            this.bandedGridColumn86.Caption = "record";
            this.bandedGridColumn86.FieldName = "record";
            this.bandedGridColumn86.Name = "bandedGridColumn86";
            this.bandedGridColumn86.RowCount = 2;
            // 
            // panelAll
            // 
            this.panelAll.Controls.Add(this.panelBottom);
            this.panelAll.Controls.Add(this.panelTop);
            this.panelAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAll.Location = new System.Drawing.Point(0, 30);
            this.panelAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelAll.Name = "panelAll";
            this.panelAll.Size = new System.Drawing.Size(1644, 491);
            this.panelAll.TabIndex = 0;
            // 
            // panelBottom
            // 
            this.panelBottom.Controls.Add(this.tabControl1);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBottom.Location = new System.Drawing.Point(0, 73);
            this.panelBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(1644, 418);
            this.panelBottom.TabIndex = 2;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabAllData);
            this.tabControl1.Controls.Add(this.tabPlacedInTrust);
            this.tabControl1.Controls.Add(this.tabBeginning);
            this.tabControl1.Controls.Add(this.tabRemoved);
            this.tabControl1.Controls.Add(this.tabDiff);
            this.tabControl1.Controls.Add(this.tabCompare);
            this.tabControl1.Controls.Add(this.tabCompareBalance);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1644, 418);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabAllData
            // 
            this.tabAllData.Controls.Add(this.panel1All);
            this.tabAllData.Location = new System.Drawing.Point(4, 25);
            this.tabAllData.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabAllData.Name = "tabAllData";
            this.tabAllData.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabAllData.Size = new System.Drawing.Size(1636, 389);
            this.tabAllData.TabIndex = 0;
            this.tabAllData.Text = "All Data";
            this.tabAllData.UseVisualStyleBackColor = true;
            // 
            // panel1All
            // 
            this.panel1All.Controls.Add(this.panel1Bottom);
            this.panel1All.Controls.Add(this.panel1Top);
            this.panel1All.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1All.Location = new System.Drawing.Point(3, 4);
            this.panel1All.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1All.Name = "panel1All";
            this.panel1All.Size = new System.Drawing.Size(1630, 381);
            this.panel1All.TabIndex = 7;
            // 
            // panel1Bottom
            // 
            this.panel1Bottom.Controls.Add(this.dgv6);
            this.panel1Bottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1Bottom.Location = new System.Drawing.Point(0, 42);
            this.panel1Bottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1Bottom.Name = "panel1Bottom";
            this.panel1Bottom.Size = new System.Drawing.Size(1630, 339);
            this.panel1Bottom.TabIndex = 9;
            // 
            // dgv6
            // 
            this.dgv6.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv6.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv6.Location = new System.Drawing.Point(0, 0);
            this.dgv6.LookAndFeel.SkinName = "iMaginary";
            this.dgv6.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv6.MainView = this.gridMain6;
            this.dgv6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv6.Name = "dgv6";
            this.dgv6.Size = new System.Drawing.Size(1630, 339);
            this.dgv6.TabIndex = 6;
            this.dgv6.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain6});
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editContractToolStripMenuItem,
            this.addNewContractToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(201, 52);
            // 
            // editContractToolStripMenuItem
            // 
            this.editContractToolStripMenuItem.Name = "editContractToolStripMenuItem";
            this.editContractToolStripMenuItem.Size = new System.Drawing.Size(200, 24);
            this.editContractToolStripMenuItem.Text = "Edit Contract";
            this.editContractToolStripMenuItem.Click += new System.EventHandler(this.editContractToolStripMenuItem_Click);
            // 
            // addNewContractToolStripMenuItem
            // 
            this.addNewContractToolStripMenuItem.Name = "addNewContractToolStripMenuItem";
            this.addNewContractToolStripMenuItem.Size = new System.Drawing.Size(200, 24);
            this.addNewContractToolStripMenuItem.Text = "Add New Contract";
            this.addNewContractToolStripMenuItem.Click += new System.EventHandler(this.addNewContractToolStripMenuItem_Click);
            // 
            // gridMain6
            // 
            this.gridMain6.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain6.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain6.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain6.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain6.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain6.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain6.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain6.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain6.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain6.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain6.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain6.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain6.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain6.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain6.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain6.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain6.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain6.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain6.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain6.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain6.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain6.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain6.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain6.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain6.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain6.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain6.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain6.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain6.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain6.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain6.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain6.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain6.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain6.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain6.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain6.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain6.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain6.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain6.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain6.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain6.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain6.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain6.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain6.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain6.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain6.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain6.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain6.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain6.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain6.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain6.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain6.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain6.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain6.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain6.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain6.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain6.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain6.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain6.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain6.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain6.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain6.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain6.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain6.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain6.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain6.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain6.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain6.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain6.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain6.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain6.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.Row.Options.UseBackColor = true;
            this.gridMain6.Appearance.Row.Options.UseForeColor = true;
            this.gridMain6.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain6.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain6.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain6.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain6.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain6.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain6.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain6.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand6});
            this.gridMain6.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain6.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn59,
            this.bandedGridColumn77,
            this.lastName79,
            this.bandedGridColumn78,
            this.bandedGridColumn1,
            this.contractNumber68,
            this.bandedGridColumn88,
            this.bandedGridColumn80,
            this.bandedGridColumn81,
            this.bandedGridColumn84,
            this.bandedGridColumn83,
            this.bandedGridColumn82,
            this.bandedGridColumn69,
            this.bandedGridColumn72,
            this.bandedGridColumn66,
            this.bandedGridColumn65,
            this.bandedGridColumn60,
            this.bandedGridColumn76,
            this.bandedGridColumn71,
            this.bandedGridColumn73,
            this.bandedGridColumn70,
            this.bandedGridColumn64,
            this.bandedGridColumn62,
            this.bandedGridColumn67,
            this.bandedGridColumn61,
            this.bandedGridColumn63,
            this.prioryear,
            this.ytdnow,
            this.currentmonth,
            this.ragCurrentMonth102,
            this.ytdtotal,
            this.totalpaid,
            this.currentRemovals,
            this.bandedGridColumn89,
            this.original90,
            this.bandedGridColumn90,
            this.as40092,
            this.bandedGridColumn93,
            this.bandedGridColumn161,
            this.interest204,
            this.deathRemYTDprevious205,
            this.deathRemCurrMonth206,
            this.refundRemYTDprevious207,
            this.refundRemCurrMonth208,
            this.bandedGridColumn9});
            this.gridMain6.DetailHeight = 431;
            this.gridMain6.GridControl = this.dgv6;
            this.gridMain6.GroupCount = 1;
            this.gridMain6.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "paymentCurrMonth", this.currentmonth, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "beginningBalance", this.prioryear, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ytdPrevious", this.ytdnow, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "currentPayments", this.ytdtotal, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "endingBalance", this.totalpaid, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "currentRemovals", this.currentRemovals, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "original", this.original90, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ragCurrentMonth", this.ragCurrentMonth102, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "deathRemCurrMonth", this.deathRemCurrMonth206, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "deathRemYTDprevious", this.deathRemYTDprevious205, " "),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "refundRemYTDprevious", this.refundRemYTDprevious207, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "refundRemCurrMonth", this.refundRemCurrMonth208, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "interest", this.interest204, "${0:0,0.00}")});
            this.gridMain6.Name = "gridMain6";
            this.gridMain6.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridMain6.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain6.OptionsPrint.PrintBandHeader = false;
            this.gridMain6.OptionsSelection.MultiSelect = true;
            this.gridMain6.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain6.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain6.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain6.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.gridMain6.OptionsView.ShowBands = false;
            this.gridMain6.OptionsView.ShowFooter = true;
            this.gridMain6.OptionsView.ShowGroupPanel = false;
            this.gridMain6.PaintStyleName = "Style3D";
            this.gridMain6.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.bandedGridColumn161, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.gridMain6.BeforePrintRow += new DevExpress.XtraGrid.Views.Base.BeforePrintRowEventHandler(this.gridMain6_BeforePrintRow);
            this.gridMain6.AfterPrintRow += new DevExpress.XtraGrid.Views.Base.AfterPrintRowEventHandler(this.gridMain6_AfterPrintRow);
            this.gridMain6.CustomDrawGroupRow += new DevExpress.XtraGrid.Views.Base.RowObjectCustomDrawEventHandler(this.gridMain6_CustomDrawGroupRow);
            this.gridMain6.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.gridMain6_CustomSummaryCalculate);
            this.gridMain6.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMain6_CustomRowFilter);
            this.gridMain6.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridView_CustomColumnDisplayText);
            this.gridMain6.DoubleClick += new System.EventHandler(this.gridMain6_DoubleClick);
            // 
            // gridBand6
            // 
            this.gridBand6.Caption = "gridBandXXX";
            this.gridBand6.Columns.Add(this.bandedGridColumn62);
            this.gridBand6.Columns.Add(this.bandedGridColumn63);
            this.gridBand6.Columns.Add(this.bandedGridColumn59);
            this.gridBand6.Columns.Add(this.lastName79);
            this.gridBand6.Columns.Add(this.bandedGridColumn78);
            this.gridBand6.Columns.Add(this.bandedGridColumn1);
            this.gridBand6.Columns.Add(this.bandedGridColumn81);
            this.gridBand6.Columns.Add(this.bandedGridColumn84);
            this.gridBand6.Columns.Add(this.bandedGridColumn83);
            this.gridBand6.Columns.Add(this.bandedGridColumn82);
            this.gridBand6.Columns.Add(this.bandedGridColumn89);
            this.gridBand6.Columns.Add(this.contractNumber68);
            this.gridBand6.Columns.Add(this.bandedGridColumn88);
            this.gridBand6.Columns.Add(this.bandedGridColumn90);
            this.gridBand6.Columns.Add(this.bandedGridColumn80);
            this.gridBand6.Columns.Add(this.prioryear);
            this.gridBand6.Columns.Add(this.ytdnow);
            this.gridBand6.Columns.Add(this.bandedGridColumn60);
            this.gridBand6.Columns.Add(this.bandedGridColumn61);
            this.gridBand6.Columns.Add(this.bandedGridColumn64);
            this.gridBand6.Columns.Add(this.bandedGridColumn65);
            this.gridBand6.Columns.Add(this.bandedGridColumn66);
            this.gridBand6.Columns.Add(this.bandedGridColumn67);
            this.gridBand6.Columns.Add(this.bandedGridColumn69);
            this.gridBand6.Columns.Add(this.bandedGridColumn70);
            this.gridBand6.Columns.Add(this.bandedGridColumn71);
            this.gridBand6.Columns.Add(this.bandedGridColumn72);
            this.gridBand6.Columns.Add(this.bandedGridColumn73);
            this.gridBand6.Columns.Add(this.currentmonth);
            this.gridBand6.Columns.Add(this.interest204);
            this.gridBand6.Columns.Add(this.ragCurrentMonth102);
            this.gridBand6.Columns.Add(this.as40092);
            this.gridBand6.Columns.Add(this.bandedGridColumn93);
            this.gridBand6.Columns.Add(this.original90);
            this.gridBand6.Columns.Add(this.ytdtotal);
            this.gridBand6.Columns.Add(this.deathRemYTDprevious205);
            this.gridBand6.Columns.Add(this.deathRemCurrMonth206);
            this.gridBand6.Columns.Add(this.refundRemYTDprevious207);
            this.gridBand6.Columns.Add(this.refundRemCurrMonth208);
            this.gridBand6.Columns.Add(this.currentRemovals);
            this.gridBand6.Columns.Add(this.totalpaid);
            this.gridBand6.Columns.Add(this.bandedGridColumn161);
            this.gridBand6.Columns.Add(this.bandedGridColumn76);
            this.gridBand6.Columns.Add(this.bandedGridColumn77);
            this.gridBand6.MinWidth = 12;
            this.gridBand6.Name = "gridBand6";
            this.gridBand6.VisibleIndex = 0;
            this.gridBand6.Width = 2025;
            // 
            // bandedGridColumn62
            // 
            this.bandedGridColumn62.Caption = "Loc";
            this.bandedGridColumn62.FieldName = "loc";
            this.bandedGridColumn62.MinWidth = 23;
            this.bandedGridColumn62.Name = "bandedGridColumn62";
            this.bandedGridColumn62.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn62.Visible = true;
            this.bandedGridColumn62.Width = 47;
            // 
            // bandedGridColumn63
            // 
            this.bandedGridColumn63.Caption = "Location Name";
            this.bandedGridColumn63.FieldName = "Location Name";
            this.bandedGridColumn63.MinWidth = 23;
            this.bandedGridColumn63.Name = "bandedGridColumn63";
            this.bandedGridColumn63.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn63.Width = 87;
            // 
            // bandedGridColumn59
            // 
            this.bandedGridColumn59.Caption = "Num";
            this.bandedGridColumn59.FieldName = "num";
            this.bandedGridColumn59.MinWidth = 23;
            this.bandedGridColumn59.Name = "bandedGridColumn59";
            this.bandedGridColumn59.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn59.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn59.Width = 58;
            // 
            // lastName79
            // 
            this.lastName79.Caption = "Last Name";
            this.lastName79.FieldName = "lastName";
            this.lastName79.MinWidth = 23;
            this.lastName79.Name = "lastName79";
            this.lastName79.OptionsColumn.FixedWidth = true;
            this.lastName79.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom, "lastName", "Count={0}")});
            this.lastName79.UnboundType = DevExpress.Data.UnboundColumnType.Integer;
            this.lastName79.Visible = true;
            this.lastName79.Width = 87;
            // 
            // bandedGridColumn78
            // 
            this.bandedGridColumn78.Caption = "First Name";
            this.bandedGridColumn78.FieldName = "firstName";
            this.bandedGridColumn78.MinWidth = 23;
            this.bandedGridColumn78.Name = "bandedGridColumn78";
            this.bandedGridColumn78.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn78.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom, "firstName", "New={0}")});
            this.bandedGridColumn78.UnboundType = DevExpress.Data.UnboundColumnType.Integer;
            this.bandedGridColumn78.Visible = true;
            this.bandedGridColumn78.Width = 87;
            // 
            // bandedGridColumn1
            // 
            this.bandedGridColumn1.Caption = "Name";
            this.bandedGridColumn1.FieldName = "fullname";
            this.bandedGridColumn1.MinWidth = 23;
            this.bandedGridColumn1.Name = "bandedGridColumn1";
            this.bandedGridColumn1.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn1.Width = 87;
            // 
            // bandedGridColumn81
            // 
            this.bandedGridColumn81.Caption = "Address";
            this.bandedGridColumn81.FieldName = "address1";
            this.bandedGridColumn81.MinWidth = 23;
            this.bandedGridColumn81.Name = "bandedGridColumn81";
            this.bandedGridColumn81.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn81.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom, "address1", "Removed={0}")});
            this.bandedGridColumn81.UnboundType = DevExpress.Data.UnboundColumnType.Integer;
            this.bandedGridColumn81.Visible = true;
            this.bandedGridColumn81.Width = 98;
            // 
            // bandedGridColumn84
            // 
            this.bandedGridColumn84.Caption = "City";
            this.bandedGridColumn84.FieldName = "city";
            this.bandedGridColumn84.MinWidth = 23;
            this.bandedGridColumn84.Name = "bandedGridColumn84";
            this.bandedGridColumn84.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn84.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom, "city", "Total={0}")});
            this.bandedGridColumn84.UnboundType = DevExpress.Data.UnboundColumnType.Integer;
            this.bandedGridColumn84.Visible = true;
            this.bandedGridColumn84.Width = 87;
            // 
            // bandedGridColumn83
            // 
            this.bandedGridColumn83.Caption = "State";
            this.bandedGridColumn83.FieldName = "state";
            this.bandedGridColumn83.MinWidth = 23;
            this.bandedGridColumn83.Name = "bandedGridColumn83";
            this.bandedGridColumn83.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn83.Visible = true;
            this.bandedGridColumn83.Width = 58;
            // 
            // bandedGridColumn82
            // 
            this.bandedGridColumn82.Caption = "Zip";
            this.bandedGridColumn82.FieldName = "zip1";
            this.bandedGridColumn82.MinWidth = 23;
            this.bandedGridColumn82.Name = "bandedGridColumn82";
            this.bandedGridColumn82.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn82.Visible = true;
            this.bandedGridColumn82.Width = 87;
            // 
            // bandedGridColumn89
            // 
            this.bandedGridColumn89.Caption = "DBR";
            this.bandedGridColumn89.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn89.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn89.FieldName = "dbr";
            this.bandedGridColumn89.MinWidth = 23;
            this.bandedGridColumn89.Name = "bandedGridColumn89";
            this.bandedGridColumn89.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn89.Visible = true;
            this.bandedGridColumn89.Width = 58;
            // 
            // contractNumber68
            // 
            this.contractNumber68.Caption = "Contract";
            this.contractNumber68.FieldName = "contractNumber";
            this.contractNumber68.MinWidth = 23;
            this.contractNumber68.Name = "contractNumber68";
            this.contractNumber68.OptionsColumn.AllowEdit = false;
            this.contractNumber68.OptionsColumn.FixedWidth = true;
            this.contractNumber68.Visible = true;
            // 
            // bandedGridColumn88
            // 
            this.bandedGridColumn88.Caption = "Found";
            this.bandedGridColumn88.FieldName = "found";
            this.bandedGridColumn88.MinWidth = 23;
            this.bandedGridColumn88.Name = "bandedGridColumn88";
            this.bandedGridColumn88.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn88.Width = 58;
            // 
            // bandedGridColumn90
            // 
            this.bandedGridColumn90.Caption = "Deceased Date";
            this.bandedGridColumn90.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn90.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn90.FieldName = "dd";
            this.bandedGridColumn90.MinWidth = 23;
            this.bandedGridColumn90.Name = "bandedGridColumn90";
            this.bandedGridColumn90.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn90.Visible = true;
            this.bandedGridColumn90.Width = 87;
            // 
            // bandedGridColumn80
            // 
            this.bandedGridColumn80.Caption = "SS#";
            this.bandedGridColumn80.FieldName = "ssn";
            this.bandedGridColumn80.MinWidth = 23;
            this.bandedGridColumn80.Name = "bandedGridColumn80";
            this.bandedGridColumn80.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn80.Visible = true;
            this.bandedGridColumn80.Width = 87;
            // 
            // prioryear
            // 
            this.prioryear.Caption = "17 & Prior Bal PD";
            this.prioryear.DisplayFormat.FormatString = "N2";
            this.prioryear.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.prioryear.FieldName = "beginningBalance";
            this.prioryear.MinWidth = 23;
            this.prioryear.Name = "prioryear";
            this.prioryear.OptionsColumn.FixedWidth = true;
            this.prioryear.Visible = true;
            this.prioryear.Width = 117;
            // 
            // ytdnow
            // 
            this.ytdnow.Caption = "YTD Prior Periods";
            this.ytdnow.DisplayFormat.FormatString = "N2";
            this.ytdnow.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.ytdnow.FieldName = "ytdPrevious";
            this.ytdnow.MinWidth = 23;
            this.ytdnow.Name = "ytdnow";
            this.ytdnow.OptionsColumn.FixedWidth = true;
            this.ytdnow.Visible = true;
            this.ytdnow.Width = 93;
            // 
            // bandedGridColumn60
            // 
            this.bandedGridColumn60.Caption = "Agent";
            this.bandedGridColumn60.FieldName = "agentNumber";
            this.bandedGridColumn60.MinWidth = 23;
            this.bandedGridColumn60.Name = "bandedGridColumn60";
            this.bandedGridColumn60.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn60.Width = 70;
            // 
            // bandedGridColumn61
            // 
            this.bandedGridColumn61.Caption = "Agent Name";
            this.bandedGridColumn61.FieldName = "agentName";
            this.bandedGridColumn61.MinWidth = 23;
            this.bandedGridColumn61.Name = "bandedGridColumn61";
            this.bandedGridColumn61.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn61.Width = 87;
            // 
            // bandedGridColumn64
            // 
            this.bandedGridColumn64.Caption = "Trust";
            this.bandedGridColumn64.FieldName = "trust";
            this.bandedGridColumn64.MinWidth = 23;
            this.bandedGridColumn64.Name = "bandedGridColumn64";
            this.bandedGridColumn64.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn64.Width = 58;
            // 
            // bandedGridColumn65
            // 
            this.bandedGridColumn65.Caption = "Due Date";
            this.bandedGridColumn65.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn65.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn65.FieldName = "dueDate8";
            this.bandedGridColumn65.MinWidth = 23;
            this.bandedGridColumn65.Name = "bandedGridColumn65";
            this.bandedGridColumn65.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn65.Width = 76;
            // 
            // bandedGridColumn66
            // 
            this.bandedGridColumn66.Caption = "Date Paid";
            this.bandedGridColumn66.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn66.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn66.FieldName = "payDate8";
            this.bandedGridColumn66.MinWidth = 23;
            this.bandedGridColumn66.Name = "bandedGridColumn66";
            this.bandedGridColumn66.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn66.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn66.Width = 76;
            // 
            // bandedGridColumn67
            // 
            this.bandedGridColumn67.Caption = "Issue Date";
            this.bandedGridColumn67.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn67.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn67.FieldName = "issueDate8";
            this.bandedGridColumn67.MinWidth = 23;
            this.bandedGridColumn67.Name = "bandedGridColumn67";
            this.bandedGridColumn67.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn67.Width = 87;
            // 
            // bandedGridColumn69
            // 
            this.bandedGridColumn69.Caption = "Customer";
            this.bandedGridColumn69.FieldName = "customer";
            this.bandedGridColumn69.MinWidth = 23;
            this.bandedGridColumn69.Name = "bandedGridColumn69";
            this.bandedGridColumn69.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn69.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn69.Width = 175;
            // 
            // bandedGridColumn70
            // 
            this.bandedGridColumn70.Caption = "Contract Value";
            this.bandedGridColumn70.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn70.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn70.FieldName = "contractValue";
            this.bandedGridColumn70.MinWidth = 23;
            this.bandedGridColumn70.Name = "bandedGridColumn70";
            this.bandedGridColumn70.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn70.Width = 117;
            // 
            // bandedGridColumn71
            // 
            this.bandedGridColumn71.Caption = "Down Payment";
            this.bandedGridColumn71.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn71.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn71.FieldName = "downPayment";
            this.bandedGridColumn71.MinWidth = 23;
            this.bandedGridColumn71.Name = "bandedGridColumn71";
            this.bandedGridColumn71.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn71.Width = 96;
            // 
            // bandedGridColumn72
            // 
            this.bandedGridColumn72.Caption = "Payment";
            this.bandedGridColumn72.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn72.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn72.FieldName = "paymentAmount";
            this.bandedGridColumn72.MinWidth = 23;
            this.bandedGridColumn72.Name = "bandedGridColumn72";
            this.bandedGridColumn72.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn72.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn72.Width = 96;
            // 
            // bandedGridColumn73
            // 
            this.bandedGridColumn73.Caption = "Total Payments";
            this.bandedGridColumn73.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn73.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn73.FieldName = "totalPayments";
            this.bandedGridColumn73.MinWidth = 23;
            this.bandedGridColumn73.Name = "bandedGridColumn73";
            this.bandedGridColumn73.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn73.Width = 96;
            // 
            // currentmonth
            // 
            this.currentmonth.Caption = "Current Month";
            this.currentmonth.DisplayFormat.FormatString = "N2";
            this.currentmonth.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.currentmonth.FieldName = "paymentCurrMonth";
            this.currentmonth.MinWidth = 23;
            this.currentmonth.Name = "currentmonth";
            this.currentmonth.OptionsColumn.AllowEdit = false;
            this.currentmonth.OptionsColumn.FixedWidth = true;
            this.currentmonth.Visible = true;
            this.currentmonth.Width = 96;
            // 
            // interest204
            // 
            this.interest204.Caption = "Interest";
            this.interest204.DisplayFormat.FormatString = "N2";
            this.interest204.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.interest204.FieldName = "interest";
            this.interest204.MinWidth = 23;
            this.interest204.Name = "interest204";
            this.interest204.OptionsColumn.FixedWidth = true;
            this.interest204.Visible = true;
            this.interest204.Width = 87;
            // 
            // ragCurrentMonth102
            // 
            this.ragCurrentMonth102.Caption = "RAG Current Month";
            this.ragCurrentMonth102.DisplayFormat.FormatString = "N2";
            this.ragCurrentMonth102.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.ragCurrentMonth102.FieldName = "ragCurrentMonth";
            this.ragCurrentMonth102.MinWidth = 23;
            this.ragCurrentMonth102.Name = "ragCurrentMonth102";
            this.ragCurrentMonth102.Visible = true;
            this.ragCurrentMonth102.Width = 76;
            // 
            // as40092
            // 
            this.as40092.Caption = "AS400";
            this.as40092.DisplayFormat.FormatString = "N2";
            this.as40092.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.as40092.FieldName = "as400";
            this.as40092.MinWidth = 23;
            this.as40092.Name = "as40092";
            this.as40092.OptionsColumn.FixedWidth = true;
            this.as40092.Width = 87;
            // 
            // bandedGridColumn93
            // 
            this.bandedGridColumn93.Caption = "Difference";
            this.bandedGridColumn93.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn93.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn93.FieldName = "difference";
            this.bandedGridColumn93.MinWidth = 23;
            this.bandedGridColumn93.Name = "bandedGridColumn93";
            this.bandedGridColumn93.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn93.Width = 87;
            // 
            // original90
            // 
            this.original90.Caption = "Original";
            this.original90.DisplayFormat.FormatString = "N2";
            this.original90.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.original90.FieldName = "original";
            this.original90.MinWidth = 23;
            this.original90.Name = "original90";
            this.original90.OptionsColumn.FixedWidth = true;
            this.original90.Width = 87;
            // 
            // ytdtotal
            // 
            this.ytdtotal.Caption = "YTD Total PD";
            this.ytdtotal.DisplayFormat.FormatString = "N2";
            this.ytdtotal.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.ytdtotal.FieldName = "currentPayments";
            this.ytdtotal.MinWidth = 23;
            this.ytdtotal.Name = "ytdtotal";
            this.ytdtotal.OptionsColumn.FixedWidth = true;
            this.ytdtotal.Visible = true;
            this.ytdtotal.Width = 117;
            // 
            // deathRemYTDprevious205
            // 
            this.deathRemYTDprevious205.Caption = "DeathRem YTD Previous";
            this.deathRemYTDprevious205.DisplayFormat.FormatString = "N2";
            this.deathRemYTDprevious205.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.deathRemYTDprevious205.FieldName = "deathRemYTDprevious";
            this.deathRemYTDprevious205.MinWidth = 23;
            this.deathRemYTDprevious205.Name = "deathRemYTDprevious205";
            this.deathRemYTDprevious205.OptionsColumn.FixedWidth = true;
            this.deathRemYTDprevious205.Visible = true;
            this.deathRemYTDprevious205.Width = 87;
            // 
            // deathRemCurrMonth206
            // 
            this.deathRemCurrMonth206.Caption = "DeathRem Curr Month";
            this.deathRemCurrMonth206.DisplayFormat.FormatString = "N2";
            this.deathRemCurrMonth206.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.deathRemCurrMonth206.FieldName = "deathRemCurrMonth";
            this.deathRemCurrMonth206.MinWidth = 23;
            this.deathRemCurrMonth206.Name = "deathRemCurrMonth206";
            this.deathRemCurrMonth206.OptionsColumn.FixedWidth = true;
            this.deathRemCurrMonth206.Visible = true;
            this.deathRemCurrMonth206.Width = 87;
            // 
            // refundRemYTDprevious207
            // 
            this.refundRemYTDprevious207.Caption = "RefundRem TYD Previous";
            this.refundRemYTDprevious207.DisplayFormat.FormatString = "N2";
            this.refundRemYTDprevious207.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.refundRemYTDprevious207.FieldName = "refundRemYTDprevious";
            this.refundRemYTDprevious207.MinWidth = 23;
            this.refundRemYTDprevious207.Name = "refundRemYTDprevious207";
            this.refundRemYTDprevious207.OptionsColumn.FixedWidth = true;
            this.refundRemYTDprevious207.Visible = true;
            this.refundRemYTDprevious207.Width = 87;
            // 
            // refundRemCurrMonth208
            // 
            this.refundRemCurrMonth208.Caption = "RefundRem Curr Month";
            this.refundRemCurrMonth208.DisplayFormat.FormatString = "N2";
            this.refundRemCurrMonth208.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.refundRemCurrMonth208.FieldName = "refundRemCurrMonth";
            this.refundRemCurrMonth208.MinWidth = 23;
            this.refundRemCurrMonth208.Name = "refundRemCurrMonth208";
            this.refundRemCurrMonth208.OptionsColumn.FixedWidth = true;
            this.refundRemCurrMonth208.Visible = true;
            this.refundRemCurrMonth208.Width = 87;
            // 
            // currentRemovals
            // 
            this.currentRemovals.Caption = "Current Removals";
            this.currentRemovals.DisplayFormat.FormatString = "N2";
            this.currentRemovals.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.currentRemovals.FieldName = "currentRemovals";
            this.currentRemovals.MinWidth = 23;
            this.currentRemovals.Name = "currentRemovals";
            this.currentRemovals.OptionsColumn.FixedWidth = true;
            this.currentRemovals.Visible = true;
            this.currentRemovals.Width = 87;
            // 
            // totalpaid
            // 
            this.totalpaid.Caption = "Paid";
            this.totalpaid.DisplayFormat.FormatString = "N2";
            this.totalpaid.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.totalpaid.FieldName = "endingBalance";
            this.totalpaid.MinWidth = 23;
            this.totalpaid.Name = "totalpaid";
            this.totalpaid.OptionsColumn.FixedWidth = true;
            this.totalpaid.Visible = true;
            this.totalpaid.Width = 146;
            // 
            // bandedGridColumn161
            // 
            this.bandedGridColumn161.Caption = "locind";
            this.bandedGridColumn161.FieldName = "locind";
            this.bandedGridColumn161.MinWidth = 23;
            this.bandedGridColumn161.Name = "bandedGridColumn161";
            this.bandedGridColumn161.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn161.Width = 87;
            // 
            // bandedGridColumn76
            // 
            this.bandedGridColumn76.Caption = "Commission";
            this.bandedGridColumn76.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn76.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn76.FieldName = "commission";
            this.bandedGridColumn76.MinWidth = 23;
            this.bandedGridColumn76.Name = "bandedGridColumn76";
            this.bandedGridColumn76.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn76.Width = 111;
            // 
            // bandedGridColumn77
            // 
            this.bandedGridColumn77.Caption = "record";
            this.bandedGridColumn77.FieldName = "record";
            this.bandedGridColumn77.MinWidth = 23;
            this.bandedGridColumn77.Name = "bandedGridColumn77";
            this.bandedGridColumn77.RowCount = 2;
            this.bandedGridColumn77.Width = 87;
            // 
            // bandedGridColumn9
            // 
            this.bandedGridColumn9.Caption = "Group";
            this.bandedGridColumn9.FieldName = "group";
            this.bandedGridColumn9.MinWidth = 25;
            this.bandedGridColumn9.Name = "bandedGridColumn9";
            this.bandedGridColumn9.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn9.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn9.Width = 94;
            // 
            // panel1Top
            // 
            this.panel1Top.Controls.Add(this.lblStatus);
            this.panel1Top.Controls.Add(this.btnSaveData);
            this.panel1Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1Top.Location = new System.Drawing.Point(0, 0);
            this.panel1Top.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1Top.Name = "panel1Top";
            this.panel1Top.Size = new System.Drawing.Size(1630, 42);
            this.panel1Top.TabIndex = 8;
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(243, 12);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(59, 17);
            this.lblStatus.TabIndex = 1;
            this.lblStatus.Text = "lblStatus";
            // 
            // btnSaveData
            // 
            this.btnSaveData.BackColor = System.Drawing.Color.Lime;
            this.btnSaveData.Location = new System.Drawing.Point(3, 6);
            this.btnSaveData.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSaveData.Name = "btnSaveData";
            this.btnSaveData.Size = new System.Drawing.Size(215, 28);
            this.btnSaveData.TabIndex = 0;
            this.btnSaveData.Text = "Save Data to Database";
            this.btnSaveData.UseVisualStyleBackColor = false;
            this.btnSaveData.Click += new System.EventHandler(this.btnSaveData_Click);
            // 
            // tabPlacedInTrust
            // 
            this.tabPlacedInTrust.Controls.Add(this.dgv2);
            this.tabPlacedInTrust.Location = new System.Drawing.Point(4, 25);
            this.tabPlacedInTrust.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPlacedInTrust.Name = "tabPlacedInTrust";
            this.tabPlacedInTrust.Size = new System.Drawing.Size(1636, 389);
            this.tabPlacedInTrust.TabIndex = 5;
            this.tabPlacedInTrust.Text = "Payments Placed in Trust";
            this.tabPlacedInTrust.UseVisualStyleBackColor = true;
            // 
            // dgv2
            // 
            this.dgv2.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv2.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Location = new System.Drawing.Point(0, 0);
            this.dgv2.LookAndFeel.SkinName = "iMaginary";
            this.dgv2.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv2.MainView = this.gridMain2;
            this.dgv2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Name = "dgv2";
            this.dgv2.Size = new System.Drawing.Size(1636, 389);
            this.dgv2.TabIndex = 7;
            this.dgv2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain2});
            // 
            // gridMain2
            // 
            this.gridMain2.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain2.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain2.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain2.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain2.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain2.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain2.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain2.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain2.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain2.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain2.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain2.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain2.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain2.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain2.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain2.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain2.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain2.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain2.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain2.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain2.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain2.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain2.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain2.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain2.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain2.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain2.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain2.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain2.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain2.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain2.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain2.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.Row.Options.UseBackColor = true;
            this.gridMain2.Appearance.Row.Options.UseForeColor = true;
            this.gridMain2.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain2.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain2.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain2.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain2.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain2.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand5});
            this.gridMain2.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.num103,
            this.bandedGridColumn165,
            this.lastName126,
            this.firstName127,
            this.bandedGridColumn128,
            this.contract135,
            this.bandedGridColumn136,
            this.ssn138,
            this.address129,
            this.city130,
            this.state131,
            this.zip132,
            this.bandedGridColumn147,
            this.bandedGridColumn150,
            this.bandedGridColumn145,
            this.bandedGridColumn144,
            this.bandedGridColumn141,
            this.bandedGridColumn164,
            this.bandedGridColumn149,
            this.bandedGridColumn153,
            this.bandedGridColumn148,
            this.bandedGridColumn143,
            this.loc92,
            this.bandedGridColumn146,
            this.bandedGridColumn142,
            this.bandedGridColumn102,
            this.beginningBalance139,
            this.bandedGridColumn140,
            this.bandedGridColumn154,
            this.bandedGridColumn155,
            this.bandedGridColumn159,
            this.bandedGridColumn162,
            this.bandedGridColumn160,
            this.bandedGridColumn133,
            this.bandedGridColumn158,
            this.bandedGridColumn137,
            this.bandedGridColumn156,
            this.bandedGridColumn157,
            this.location163,
            this.bandedGridColumn5,
            this.bandedGridColumn68,
            this.bandedGridColumn10});
            this.gridMain2.DetailHeight = 431;
            this.gridMain2.GridControl = this.dgv2;
            this.gridMain2.GroupCount = 1;
            this.gridMain2.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "paymentCurrMonth", this.bandedGridColumn154, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "beginningBalance", this.beginningBalance139, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ytdPrevious", this.bandedGridColumn140, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "currentPayments", this.bandedGridColumn159, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "endingBalance", this.bandedGridColumn162, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "currentRemovals", this.bandedGridColumn160, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "original", this.bandedGridColumn158, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ragCurrentMonth", this.bandedGridColumn155, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "as400", this.bandedGridColumn156, "${0:0,0.00}")});
            this.gridMain2.Name = "gridMain2";
            this.gridMain2.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridMain2.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain2.OptionsPrint.AllowMultilineHeaders = true;
            this.gridMain2.OptionsPrint.PrintBandHeader = false;
            this.gridMain2.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain2.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain2.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain2.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.gridMain2.OptionsView.ShowBands = false;
            this.gridMain2.OptionsView.ShowFooter = true;
            this.gridMain2.OptionsView.ShowGroupPanel = false;
            this.gridMain2.PaintStyleName = "Flat";
            this.gridMain2.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.location163, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.gridMain2.CustomDrawBandHeader += new DevExpress.XtraGrid.Views.BandedGrid.BandHeaderCustomDrawEventHandler(this.gridMain2_CustomDrawBandHeader);
            this.gridMain2.BeforePrintRow += new DevExpress.XtraGrid.Views.Base.BeforePrintRowEventHandler(this.beforePrintRow);
            this.gridMain2.AfterPrintRow += new DevExpress.XtraGrid.Views.Base.AfterPrintRowEventHandler(this.afterPrintRow);
            this.gridMain2.CustomDrawGroupRow += new DevExpress.XtraGrid.Views.Base.RowObjectCustomDrawEventHandler(this.gridMain2_CustomDrawGroupRow);
            this.gridMain2.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridView_CustomColumnDisplayText);
            this.gridMain2.DoubleClick += new System.EventHandler(this.gridMain6_DoubleClick);
            // 
            // gridBand5
            // 
            this.gridBand5.AppearanceHeader.Options.UseTextOptions = true;
            this.gridBand5.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.gridBand5.Caption = "gridBandXXX";
            this.gridBand5.Children.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand13,
            this.gridBand14});
            this.gridBand5.MinWidth = 12;
            this.gridBand5.Name = "gridBand5";
            this.gridBand5.VisibleIndex = 0;
            this.gridBand5.Width = 1166;
            // 
            // gridBand13
            // 
            this.gridBand13.Caption = "gridBand13";
            this.gridBand13.Columns.Add(this.num103);
            this.gridBand13.Columns.Add(this.loc92);
            this.gridBand13.Columns.Add(this.location163);
            this.gridBand13.Columns.Add(this.contract135);
            this.gridBand13.Columns.Add(this.ssn138);
            this.gridBand13.Columns.Add(this.lastName126);
            this.gridBand13.Columns.Add(this.firstName127);
            this.gridBand13.Columns.Add(this.address129);
            this.gridBand13.Columns.Add(this.city130);
            this.gridBand13.Columns.Add(this.state131);
            this.gridBand13.Columns.Add(this.zip132);
            this.gridBand13.Name = "gridBand13";
            this.gridBand13.VisibleIndex = 0;
            this.gridBand13.Width = 610;
            // 
            // num103
            // 
            this.num103.Caption = "Num";
            this.num103.FieldName = "num";
            this.num103.MinWidth = 23;
            this.num103.Name = "num103";
            this.num103.OptionsColumn.AllowEdit = false;
            this.num103.OptionsColumn.FixedWidth = true;
            this.num103.Width = 58;
            // 
            // loc92
            // 
            this.loc92.Caption = "Loc";
            this.loc92.FieldName = "loc";
            this.loc92.MinWidth = 23;
            this.loc92.Name = "loc92";
            this.loc92.OptionsColumn.FixedWidth = true;
            this.loc92.Visible = true;
            this.loc92.Width = 47;
            // 
            // location163
            // 
            this.location163.Caption = "Location";
            this.location163.FieldName = "locind";
            this.location163.MinWidth = 23;
            this.location163.Name = "location163";
            this.location163.OptionsColumn.AllowEdit = false;
            this.location163.OptionsColumn.FixedWidth = true;
            this.location163.Visible = true;
            this.location163.Width = 87;
            // 
            // contract135
            // 
            this.contract135.Caption = "Contract";
            this.contract135.FieldName = "contractNumber";
            this.contract135.MinWidth = 23;
            this.contract135.Name = "contract135";
            this.contract135.OptionsColumn.AllowEdit = false;
            this.contract135.OptionsColumn.FixedWidth = true;
            this.contract135.Visible = true;
            this.contract135.Width = 386;
            // 
            // ssn138
            // 
            this.ssn138.Caption = "SS#";
            this.ssn138.FieldName = "ssn";
            this.ssn138.MinWidth = 23;
            this.ssn138.Name = "ssn138";
            this.ssn138.OptionsColumn.FixedWidth = true;
            this.ssn138.Visible = true;
            this.ssn138.Width = 87;
            // 
            // lastName126
            // 
            this.lastName126.Caption = "Last Name";
            this.lastName126.FieldName = "lastName";
            this.lastName126.MinWidth = 23;
            this.lastName126.Name = "lastName126";
            this.lastName126.OptionsColumn.FixedWidth = true;
            this.lastName126.RowIndex = 1;
            this.lastName126.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Count, "lastName", "Count={0}")});
            this.lastName126.Visible = true;
            this.lastName126.Width = 117;
            // 
            // firstName127
            // 
            this.firstName127.Caption = "First Name";
            this.firstName127.FieldName = "firstName";
            this.firstName127.MinWidth = 23;
            this.firstName127.Name = "firstName127";
            this.firstName127.OptionsColumn.FixedWidth = true;
            this.firstName127.RowIndex = 1;
            this.firstName127.Visible = true;
            this.firstName127.Width = 136;
            // 
            // address129
            // 
            this.address129.Caption = "Address";
            this.address129.FieldName = "address1";
            this.address129.MinWidth = 23;
            this.address129.Name = "address129";
            this.address129.OptionsColumn.FixedWidth = true;
            this.address129.RowIndex = 1;
            this.address129.Visible = true;
            this.address129.Width = 129;
            // 
            // city130
            // 
            this.city130.Caption = "City";
            this.city130.FieldName = "city";
            this.city130.MinWidth = 23;
            this.city130.Name = "city130";
            this.city130.OptionsColumn.FixedWidth = true;
            this.city130.RowIndex = 1;
            this.city130.Visible = true;
            this.city130.Width = 112;
            // 
            // state131
            // 
            this.state131.Caption = "State";
            this.state131.FieldName = "state";
            this.state131.MinWidth = 23;
            this.state131.Name = "state131";
            this.state131.OptionsColumn.FixedWidth = true;
            this.state131.RowIndex = 1;
            this.state131.Visible = true;
            this.state131.Width = 58;
            // 
            // zip132
            // 
            this.zip132.Caption = "Zip";
            this.zip132.FieldName = "zip1";
            this.zip132.MinWidth = 23;
            this.zip132.Name = "zip132";
            this.zip132.OptionsColumn.FixedWidth = true;
            this.zip132.RowIndex = 1;
            this.zip132.Visible = true;
            this.zip132.Width = 58;
            // 
            // gridBand14
            // 
            this.gridBand14.Caption = "gridBand14";
            this.gridBand14.Columns.Add(this.beginningBalance139);
            this.gridBand14.Columns.Add(this.bandedGridColumn140);
            this.gridBand14.Columns.Add(this.bandedGridColumn154);
            this.gridBand14.Columns.Add(this.bandedGridColumn159);
            this.gridBand14.Columns.Add(this.bandedGridColumn162);
            this.gridBand14.Name = "gridBand14";
            this.gridBand14.VisibleIndex = 1;
            this.gridBand14.Width = 556;
            // 
            // beginningBalance139
            // 
            this.beginningBalance139.Caption = "17 & Prior Bal PD";
            this.beginningBalance139.DisplayFormat.FormatString = "N2";
            this.beginningBalance139.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.beginningBalance139.FieldName = "beginningBalance";
            this.beginningBalance139.MinWidth = 23;
            this.beginningBalance139.Name = "beginningBalance139";
            this.beginningBalance139.OptionsColumn.FixedWidth = true;
            this.beginningBalance139.Visible = true;
            this.beginningBalance139.Width = 117;
            // 
            // bandedGridColumn140
            // 
            this.bandedGridColumn140.Caption = "YTD Prior Periods";
            this.bandedGridColumn140.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn140.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn140.FieldName = "ytdPrevious";
            this.bandedGridColumn140.MinWidth = 23;
            this.bandedGridColumn140.Name = "bandedGridColumn140";
            this.bandedGridColumn140.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn140.Visible = true;
            this.bandedGridColumn140.Width = 105;
            // 
            // bandedGridColumn154
            // 
            this.bandedGridColumn154.Caption = "Current Month";
            this.bandedGridColumn154.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn154.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn154.FieldName = "paymentCurrMonth";
            this.bandedGridColumn154.MinWidth = 23;
            this.bandedGridColumn154.Name = "bandedGridColumn154";
            this.bandedGridColumn154.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn154.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn154.Visible = true;
            this.bandedGridColumn154.Width = 96;
            // 
            // bandedGridColumn159
            // 
            this.bandedGridColumn159.Caption = "YTDTOTAL PD";
            this.bandedGridColumn159.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn159.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn159.FieldName = "currentPayments";
            this.bandedGridColumn159.MinWidth = 23;
            this.bandedGridColumn159.Name = "bandedGridColumn159";
            this.bandedGridColumn159.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn159.Visible = true;
            this.bandedGridColumn159.Width = 117;
            // 
            // bandedGridColumn162
            // 
            this.bandedGridColumn162.Caption = "Paid";
            this.bandedGridColumn162.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn162.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn162.FieldName = "endingBalance";
            this.bandedGridColumn162.MinWidth = 23;
            this.bandedGridColumn162.Name = "bandedGridColumn162";
            this.bandedGridColumn162.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn162.Visible = true;
            this.bandedGridColumn162.Width = 121;
            // 
            // bandedGridColumn165
            // 
            this.bandedGridColumn165.Caption = "record";
            this.bandedGridColumn165.FieldName = "record";
            this.bandedGridColumn165.MinWidth = 23;
            this.bandedGridColumn165.Name = "bandedGridColumn165";
            this.bandedGridColumn165.RowCount = 2;
            this.bandedGridColumn165.Width = 87;
            // 
            // bandedGridColumn128
            // 
            this.bandedGridColumn128.Caption = "Name";
            this.bandedGridColumn128.FieldName = "fullname";
            this.bandedGridColumn128.MinWidth = 23;
            this.bandedGridColumn128.Name = "bandedGridColumn128";
            this.bandedGridColumn128.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn128.Width = 87;
            // 
            // bandedGridColumn136
            // 
            this.bandedGridColumn136.Caption = "Found";
            this.bandedGridColumn136.FieldName = "found";
            this.bandedGridColumn136.MinWidth = 23;
            this.bandedGridColumn136.Name = "bandedGridColumn136";
            this.bandedGridColumn136.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn136.Width = 58;
            // 
            // bandedGridColumn147
            // 
            this.bandedGridColumn147.Caption = "Customer";
            this.bandedGridColumn147.FieldName = "customer";
            this.bandedGridColumn147.MinWidth = 23;
            this.bandedGridColumn147.Name = "bandedGridColumn147";
            this.bandedGridColumn147.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn147.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn147.Width = 175;
            // 
            // bandedGridColumn150
            // 
            this.bandedGridColumn150.Caption = "Payment";
            this.bandedGridColumn150.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn150.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn150.FieldName = "paymentAmount";
            this.bandedGridColumn150.MinWidth = 23;
            this.bandedGridColumn150.Name = "bandedGridColumn150";
            this.bandedGridColumn150.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn150.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn150.Width = 96;
            // 
            // bandedGridColumn145
            // 
            this.bandedGridColumn145.Caption = "Date Paid";
            this.bandedGridColumn145.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn145.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn145.FieldName = "payDate8";
            this.bandedGridColumn145.MinWidth = 23;
            this.bandedGridColumn145.Name = "bandedGridColumn145";
            this.bandedGridColumn145.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn145.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn145.Width = 76;
            // 
            // bandedGridColumn144
            // 
            this.bandedGridColumn144.Caption = "Due Date";
            this.bandedGridColumn144.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn144.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn144.FieldName = "dueDate8";
            this.bandedGridColumn144.MinWidth = 23;
            this.bandedGridColumn144.Name = "bandedGridColumn144";
            this.bandedGridColumn144.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn144.Width = 76;
            // 
            // bandedGridColumn141
            // 
            this.bandedGridColumn141.Caption = "Agent";
            this.bandedGridColumn141.FieldName = "agentNumber";
            this.bandedGridColumn141.MinWidth = 23;
            this.bandedGridColumn141.Name = "bandedGridColumn141";
            this.bandedGridColumn141.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn141.Width = 70;
            // 
            // bandedGridColumn164
            // 
            this.bandedGridColumn164.Caption = "Commission";
            this.bandedGridColumn164.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn164.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn164.FieldName = "commission";
            this.bandedGridColumn164.MinWidth = 23;
            this.bandedGridColumn164.Name = "bandedGridColumn164";
            this.bandedGridColumn164.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn164.Width = 111;
            // 
            // bandedGridColumn149
            // 
            this.bandedGridColumn149.Caption = "Down Payment";
            this.bandedGridColumn149.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn149.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn149.FieldName = "downPayment";
            this.bandedGridColumn149.MinWidth = 23;
            this.bandedGridColumn149.Name = "bandedGridColumn149";
            this.bandedGridColumn149.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn149.Width = 96;
            // 
            // bandedGridColumn153
            // 
            this.bandedGridColumn153.Caption = "Total Payments";
            this.bandedGridColumn153.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn153.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn153.FieldName = "totalPayments";
            this.bandedGridColumn153.MinWidth = 23;
            this.bandedGridColumn153.Name = "bandedGridColumn153";
            this.bandedGridColumn153.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn153.Width = 96;
            // 
            // bandedGridColumn148
            // 
            this.bandedGridColumn148.Caption = "Contract Value";
            this.bandedGridColumn148.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn148.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn148.FieldName = "contractValue";
            this.bandedGridColumn148.MinWidth = 23;
            this.bandedGridColumn148.Name = "bandedGridColumn148";
            this.bandedGridColumn148.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn148.Width = 117;
            // 
            // bandedGridColumn143
            // 
            this.bandedGridColumn143.Caption = "Trust";
            this.bandedGridColumn143.FieldName = "trust";
            this.bandedGridColumn143.MinWidth = 23;
            this.bandedGridColumn143.Name = "bandedGridColumn143";
            this.bandedGridColumn143.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn143.Width = 58;
            // 
            // bandedGridColumn146
            // 
            this.bandedGridColumn146.Caption = "Issue Date";
            this.bandedGridColumn146.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn146.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn146.FieldName = "issueDate8";
            this.bandedGridColumn146.MinWidth = 23;
            this.bandedGridColumn146.Name = "bandedGridColumn146";
            this.bandedGridColumn146.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn146.Width = 87;
            // 
            // bandedGridColumn142
            // 
            this.bandedGridColumn142.Caption = "Agent Name";
            this.bandedGridColumn142.FieldName = "agentName";
            this.bandedGridColumn142.MinWidth = 23;
            this.bandedGridColumn142.Name = "bandedGridColumn142";
            this.bandedGridColumn142.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn142.Width = 87;
            // 
            // bandedGridColumn102
            // 
            this.bandedGridColumn102.Caption = "Location Name";
            this.bandedGridColumn102.FieldName = "Location Name";
            this.bandedGridColumn102.MinWidth = 23;
            this.bandedGridColumn102.Name = "bandedGridColumn102";
            this.bandedGridColumn102.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn102.Width = 87;
            // 
            // bandedGridColumn155
            // 
            this.bandedGridColumn155.Caption = "RAG Current Month";
            this.bandedGridColumn155.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn155.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn155.FieldName = "ragCurrentMonth";
            this.bandedGridColumn155.MinWidth = 23;
            this.bandedGridColumn155.Name = "bandedGridColumn155";
            this.bandedGridColumn155.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn155.Width = 87;
            // 
            // bandedGridColumn160
            // 
            this.bandedGridColumn160.Caption = "Current Removals";
            this.bandedGridColumn160.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn160.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn160.FieldName = "currentRemovals";
            this.bandedGridColumn160.MinWidth = 23;
            this.bandedGridColumn160.Name = "bandedGridColumn160";
            this.bandedGridColumn160.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn160.Width = 87;
            // 
            // bandedGridColumn133
            // 
            this.bandedGridColumn133.Caption = "DBR";
            this.bandedGridColumn133.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn133.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn133.FieldName = "dbr";
            this.bandedGridColumn133.MinWidth = 23;
            this.bandedGridColumn133.Name = "bandedGridColumn133";
            this.bandedGridColumn133.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn133.Width = 58;
            // 
            // bandedGridColumn158
            // 
            this.bandedGridColumn158.Caption = "Original";
            this.bandedGridColumn158.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn158.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn158.FieldName = "original";
            this.bandedGridColumn158.MinWidth = 23;
            this.bandedGridColumn158.Name = "bandedGridColumn158";
            this.bandedGridColumn158.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn158.Width = 87;
            // 
            // bandedGridColumn137
            // 
            this.bandedGridColumn137.Caption = "Deceased Date";
            this.bandedGridColumn137.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn137.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn137.FieldName = "dd";
            this.bandedGridColumn137.MinWidth = 23;
            this.bandedGridColumn137.Name = "bandedGridColumn137";
            this.bandedGridColumn137.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn137.Width = 111;
            // 
            // bandedGridColumn156
            // 
            this.bandedGridColumn156.Caption = "AS400";
            this.bandedGridColumn156.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn156.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn156.FieldName = "as400";
            this.bandedGridColumn156.MinWidth = 23;
            this.bandedGridColumn156.Name = "bandedGridColumn156";
            this.bandedGridColumn156.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn156.Width = 87;
            // 
            // bandedGridColumn157
            // 
            this.bandedGridColumn157.Caption = "Difference";
            this.bandedGridColumn157.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn157.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn157.FieldName = "difference";
            this.bandedGridColumn157.MinWidth = 23;
            this.bandedGridColumn157.Name = "bandedGridColumn157";
            this.bandedGridColumn157.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn157.Width = 87;
            // 
            // bandedGridColumn5
            // 
            this.bandedGridColumn5.Caption = "Empty";
            this.bandedGridColumn5.MinWidth = 23;
            this.bandedGridColumn5.Name = "bandedGridColumn5";
            this.bandedGridColumn5.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn5.Width = 87;
            // 
            // bandedGridColumn68
            // 
            this.bandedGridColumn68.Caption = "E1";
            this.bandedGridColumn68.MinWidth = 23;
            this.bandedGridColumn68.Name = "bandedGridColumn68";
            this.bandedGridColumn68.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn68.RowIndex = 1;
            this.bandedGridColumn68.Width = 863;
            // 
            // bandedGridColumn10
            // 
            this.bandedGridColumn10.Caption = "Group";
            this.bandedGridColumn10.FieldName = "group";
            this.bandedGridColumn10.MinWidth = 25;
            this.bandedGridColumn10.Name = "bandedGridColumn10";
            this.bandedGridColumn10.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn10.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn10.Width = 94;
            // 
            // tabBeginning
            // 
            this.tabBeginning.Controls.Add(this.dgv7);
            this.tabBeginning.Location = new System.Drawing.Point(4, 25);
            this.tabBeginning.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabBeginning.Name = "tabBeginning";
            this.tabBeginning.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabBeginning.Size = new System.Drawing.Size(1636, 389);
            this.tabBeginning.TabIndex = 1;
            this.tabBeginning.Text = "Beginning Period Trust Report";
            this.tabBeginning.UseVisualStyleBackColor = true;
            // 
            // dgv7
            // 
            this.dgv7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv7.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv7.Location = new System.Drawing.Point(3, 4);
            this.dgv7.LookAndFeel.SkinName = "iMaginary";
            this.dgv7.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv7.MainView = this.gridMain7;
            this.dgv7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv7.Name = "dgv7";
            this.dgv7.Size = new System.Drawing.Size(1630, 381);
            this.dgv7.TabIndex = 7;
            this.dgv7.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain7});
            // 
            // gridMain7
            // 
            this.gridMain7.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain7.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain7.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain7.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain7.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain7.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain7.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain7.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain7.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain7.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain7.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain7.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain7.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain7.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain7.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain7.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain7.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain7.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain7.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain7.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain7.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain7.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain7.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain7.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain7.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain7.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain7.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain7.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain7.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain7.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain7.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain7.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain7.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain7.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain7.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain7.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain7.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain7.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain7.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain7.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain7.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain7.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain7.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain7.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain7.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain7.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain7.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain7.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain7.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain7.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain7.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain7.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain7.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain7.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain7.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain7.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain7.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain7.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain7.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain7.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.Row.Options.UseBackColor = true;
            this.gridMain7.Appearance.Row.Options.UseForeColor = true;
            this.gridMain7.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain7.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain7.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain7.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain7.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain7.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain7.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand1});
            this.gridMain7.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain7.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.num4,
            this.bandedGridColumn31,
            this.lastName5,
            this.firstName6,
            this.bandedGridColumn7,
            this.contract12,
            this.ssn13,
            this.address8,
            this.city9,
            this.state10,
            this.zip11,
            this.bandedGridColumn22,
            this.bandedGridColumn25,
            this.bandedGridColumn20,
            this.bandedGridColumn19,
            this.bandedGridColumn16,
            this.bandedGridColumn30,
            this.bandedGridColumn24,
            this.bandedGridColumn26,
            this.bandedGridColumn23,
            this.bandedGridColumn18,
            this.loc2,
            this.bandedGridColumn21,
            this.bandedGridColumn17,
            this.bandedGridColumn3,
            this.bandedGridColumn14,
            this.beginningBalance15,
            this.currentPayments27,
            this.bandedGridColumn28,
            this.endingBalance29,
            this.currentremoval,
            this.location209,
            this.interest68,
            this.bandedGridColumn11});
            this.gridMain7.DetailHeight = 431;
            this.gridMain7.GridControl = this.dgv7;
            this.gridMain7.GroupCount = 1;
            this.gridMain7.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "paymentCurrMonth", this.currentPayments27, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "beginningBalance", this.beginningBalance15, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ytdPrevious", this.bandedGridColumn28, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "endingBalance", this.endingBalance29, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "currentRemovals", this.currentremoval, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "interest", this.interest68, "${0:0,0.00}")});
            this.gridMain7.Name = "gridMain7";
            this.gridMain7.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridMain7.OptionsBehavior.Editable = false;
            this.gridMain7.OptionsBehavior.ReadOnly = true;
            this.gridMain7.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain7.OptionsPrint.PrintBandHeader = false;
            this.gridMain7.OptionsSelection.MultiSelect = true;
            this.gridMain7.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain7.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain7.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain7.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.gridMain7.OptionsView.ShowBands = false;
            this.gridMain7.OptionsView.ShowFooter = true;
            this.gridMain7.OptionsView.ShowGroupPanel = false;
            this.gridMain7.PaintStyleName = "Style3D";
            this.gridMain7.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.location209, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.gridMain7.BeforePrintRow += new DevExpress.XtraGrid.Views.Base.BeforePrintRowEventHandler(this.beforePrintRow);
            this.gridMain7.AfterPrintRow += new DevExpress.XtraGrid.Views.Base.AfterPrintRowEventHandler(this.afterPrintRow);
            this.gridMain7.CustomDrawGroupRow += new DevExpress.XtraGrid.Views.Base.RowObjectCustomDrawEventHandler(this.gridMain7_CustomDrawGroupRow);
            this.gridMain7.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.gridMain7_CustomSummaryCalculate);
            this.gridMain7.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMain7_CustomRowFilter);
            this.gridMain7.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain7_CustomColumnDisplayText);
            this.gridMain7.DoubleClick += new System.EventHandler(this.gridMain6_DoubleClick);
            // 
            // gridBand1
            // 
            this.gridBand1.Caption = "gridBandXXX";
            this.gridBand1.Children.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand15,
            this.gridBand16});
            this.gridBand1.MinWidth = 12;
            this.gridBand1.Name = "gridBand1";
            this.gridBand1.VisibleIndex = 0;
            this.gridBand1.Width = 1200;
            // 
            // gridBand15
            // 
            this.gridBand15.Caption = "gridBand15";
            this.gridBand15.Columns.Add(this.loc2);
            this.gridBand15.Columns.Add(this.location209);
            this.gridBand15.Columns.Add(this.num4);
            this.gridBand15.Columns.Add(this.contract12);
            this.gridBand15.Columns.Add(this.ssn13);
            this.gridBand15.Columns.Add(this.lastName5);
            this.gridBand15.Columns.Add(this.firstName6);
            this.gridBand15.Columns.Add(this.address8);
            this.gridBand15.Columns.Add(this.city9);
            this.gridBand15.Columns.Add(this.state10);
            this.gridBand15.Columns.Add(this.zip11);
            this.gridBand15.Name = "gridBand15";
            this.gridBand15.VisibleIndex = 0;
            this.gridBand15.Width = 631;
            // 
            // loc2
            // 
            this.loc2.Caption = "Loc";
            this.loc2.FieldName = "loc";
            this.loc2.MinWidth = 23;
            this.loc2.Name = "loc2";
            this.loc2.OptionsColumn.FixedWidth = true;
            this.loc2.Visible = true;
            this.loc2.Width = 47;
            // 
            // location209
            // 
            this.location209.Caption = "Location";
            this.location209.FieldName = "locind";
            this.location209.MinWidth = 23;
            this.location209.Name = "location209";
            this.location209.OptionsColumn.FixedWidth = true;
            this.location209.Visible = true;
            this.location209.Width = 87;
            // 
            // num4
            // 
            this.num4.Caption = "Num";
            this.num4.FieldName = "num";
            this.num4.MinWidth = 23;
            this.num4.Name = "num4";
            this.num4.OptionsColumn.AllowEdit = false;
            this.num4.OptionsColumn.FixedWidth = true;
            this.num4.Width = 58;
            // 
            // contract12
            // 
            this.contract12.Caption = "Contract";
            this.contract12.FieldName = "contractNumber";
            this.contract12.MinWidth = 23;
            this.contract12.Name = "contract12";
            this.contract12.OptionsColumn.AllowEdit = false;
            this.contract12.OptionsColumn.FixedWidth = true;
            this.contract12.Visible = true;
            // 
            // ssn13
            // 
            this.ssn13.Caption = "SS#";
            this.ssn13.FieldName = "ssn";
            this.ssn13.MinWidth = 23;
            this.ssn13.Name = "ssn13";
            this.ssn13.OptionsColumn.FixedWidth = true;
            this.ssn13.Visible = true;
            this.ssn13.Width = 93;
            // 
            // lastName5
            // 
            this.lastName5.Caption = "Last Name";
            this.lastName5.FieldName = "lastName";
            this.lastName5.MinWidth = 23;
            this.lastName5.Name = "lastName5";
            this.lastName5.OptionsColumn.FixedWidth = true;
            this.lastName5.RowIndex = 1;
            this.lastName5.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom, "lastName", "Count={0}")});
            this.lastName5.Visible = true;
            this.lastName5.Width = 115;
            // 
            // firstName6
            // 
            this.firstName6.Caption = "First Name";
            this.firstName6.FieldName = "firstName";
            this.firstName6.MinWidth = 23;
            this.firstName6.Name = "firstName6";
            this.firstName6.OptionsColumn.FixedWidth = true;
            this.firstName6.RowIndex = 1;
            this.firstName6.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom, "firstName", "New={0}")});
            this.firstName6.UnboundType = DevExpress.Data.UnboundColumnType.Integer;
            this.firstName6.Visible = true;
            this.firstName6.Width = 112;
            // 
            // address8
            // 
            this.address8.Caption = "Address";
            this.address8.FieldName = "address1";
            this.address8.MinWidth = 23;
            this.address8.Name = "address8";
            this.address8.OptionsColumn.FixedWidth = true;
            this.address8.RowIndex = 1;
            this.address8.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom, "address1", "Removed={0}")});
            this.address8.UnboundType = DevExpress.Data.UnboundColumnType.Integer;
            this.address8.Visible = true;
            this.address8.Width = 147;
            // 
            // city9
            // 
            this.city9.Caption = "City";
            this.city9.FieldName = "city";
            this.city9.MinWidth = 23;
            this.city9.Name = "city9";
            this.city9.OptionsColumn.FixedWidth = true;
            this.city9.RowIndex = 1;
            this.city9.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Custom, "city", "Total={0}")});
            this.city9.UnboundType = DevExpress.Data.UnboundColumnType.Integer;
            this.city9.Visible = true;
            this.city9.Width = 141;
            // 
            // state10
            // 
            this.state10.Caption = "State";
            this.state10.FieldName = "state";
            this.state10.MinWidth = 23;
            this.state10.Name = "state10";
            this.state10.OptionsColumn.FixedWidth = true;
            this.state10.RowIndex = 1;
            this.state10.Visible = true;
            this.state10.Width = 58;
            // 
            // zip11
            // 
            this.zip11.Caption = "Zip";
            this.zip11.FieldName = "zip1";
            this.zip11.MinWidth = 23;
            this.zip11.Name = "zip11";
            this.zip11.OptionsColumn.FixedWidth = true;
            this.zip11.RowIndex = 1;
            this.zip11.Visible = true;
            this.zip11.Width = 58;
            // 
            // gridBand16
            // 
            this.gridBand16.Caption = "gridBand16";
            this.gridBand16.Columns.Add(this.beginningBalance15);
            this.gridBand16.Columns.Add(this.currentPayments27);
            this.gridBand16.Columns.Add(this.interest68);
            this.gridBand16.Columns.Add(this.currentremoval);
            this.gridBand16.Columns.Add(this.endingBalance29);
            this.gridBand16.Name = "gridBand16";
            this.gridBand16.VisibleIndex = 1;
            this.gridBand16.Width = 569;
            // 
            // beginningBalance15
            // 
            this.beginningBalance15.Caption = "Beginning Value";
            this.beginningBalance15.DisplayFormat.FormatString = "N2";
            this.beginningBalance15.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.beginningBalance15.FieldName = "beginningBalance";
            this.beginningBalance15.MinWidth = 23;
            this.beginningBalance15.Name = "beginningBalance15";
            this.beginningBalance15.OptionsColumn.FixedWidth = true;
            this.beginningBalance15.Visible = true;
            this.beginningBalance15.Width = 105;
            // 
            // currentPayments27
            // 
            this.currentPayments27.Caption = "Current Payments";
            this.currentPayments27.DisplayFormat.FormatString = "N2";
            this.currentPayments27.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.currentPayments27.FieldName = "paymentCurrMonth";
            this.currentPayments27.MinWidth = 23;
            this.currentPayments27.Name = "currentPayments27";
            this.currentPayments27.OptionsColumn.AllowEdit = false;
            this.currentPayments27.OptionsColumn.FixedWidth = true;
            this.currentPayments27.Visible = true;
            this.currentPayments27.Width = 96;
            // 
            // interest68
            // 
            this.interest68.Caption = "Interest";
            this.interest68.DisplayFormat.FormatString = "N2";
            this.interest68.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.interest68.FieldName = "interest";
            this.interest68.MinWidth = 23;
            this.interest68.Name = "interest68";
            this.interest68.Visible = true;
            this.interest68.Width = 105;
            // 
            // currentremoval
            // 
            this.currentremoval.Caption = "Current Removals";
            this.currentremoval.DisplayFormat.FormatString = "N2";
            this.currentremoval.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.currentremoval.FieldName = "currentRemovals";
            this.currentremoval.MinWidth = 23;
            this.currentremoval.Name = "currentremoval";
            this.currentremoval.OptionsColumn.FixedWidth = true;
            this.currentremoval.Visible = true;
            this.currentremoval.Width = 117;
            // 
            // endingBalance29
            // 
            this.endingBalance29.Caption = "Beginning Val Nx Prd";
            this.endingBalance29.DisplayFormat.FormatString = "N2";
            this.endingBalance29.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.endingBalance29.FieldName = "endingBalance";
            this.endingBalance29.MinWidth = 23;
            this.endingBalance29.Name = "endingBalance29";
            this.endingBalance29.OptionsColumn.FixedWidth = true;
            this.endingBalance29.Visible = true;
            this.endingBalance29.Width = 146;
            // 
            // bandedGridColumn31
            // 
            this.bandedGridColumn31.Caption = "record";
            this.bandedGridColumn31.FieldName = "record";
            this.bandedGridColumn31.MinWidth = 23;
            this.bandedGridColumn31.Name = "bandedGridColumn31";
            this.bandedGridColumn31.RowCount = 2;
            this.bandedGridColumn31.Width = 87;
            // 
            // bandedGridColumn7
            // 
            this.bandedGridColumn7.Caption = "Name";
            this.bandedGridColumn7.FieldName = "fullname";
            this.bandedGridColumn7.MinWidth = 23;
            this.bandedGridColumn7.Name = "bandedGridColumn7";
            this.bandedGridColumn7.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn7.Width = 87;
            // 
            // bandedGridColumn22
            // 
            this.bandedGridColumn22.Caption = "Customer";
            this.bandedGridColumn22.FieldName = "customer";
            this.bandedGridColumn22.MinWidth = 23;
            this.bandedGridColumn22.Name = "bandedGridColumn22";
            this.bandedGridColumn22.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn22.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn22.Width = 175;
            // 
            // bandedGridColumn25
            // 
            this.bandedGridColumn25.Caption = "Payment";
            this.bandedGridColumn25.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn25.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn25.FieldName = "paymentAmount";
            this.bandedGridColumn25.MinWidth = 23;
            this.bandedGridColumn25.Name = "bandedGridColumn25";
            this.bandedGridColumn25.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn25.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn25.Width = 96;
            // 
            // bandedGridColumn20
            // 
            this.bandedGridColumn20.Caption = "Date Paid";
            this.bandedGridColumn20.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn20.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn20.FieldName = "payDate8";
            this.bandedGridColumn20.MinWidth = 23;
            this.bandedGridColumn20.Name = "bandedGridColumn20";
            this.bandedGridColumn20.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn20.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn20.Width = 76;
            // 
            // bandedGridColumn19
            // 
            this.bandedGridColumn19.Caption = "Due Date";
            this.bandedGridColumn19.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn19.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn19.FieldName = "dueDate8";
            this.bandedGridColumn19.MinWidth = 23;
            this.bandedGridColumn19.Name = "bandedGridColumn19";
            this.bandedGridColumn19.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn19.Width = 76;
            // 
            // bandedGridColumn16
            // 
            this.bandedGridColumn16.Caption = "Agent";
            this.bandedGridColumn16.FieldName = "agentNumber";
            this.bandedGridColumn16.MinWidth = 23;
            this.bandedGridColumn16.Name = "bandedGridColumn16";
            this.bandedGridColumn16.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn16.Width = 70;
            // 
            // bandedGridColumn30
            // 
            this.bandedGridColumn30.Caption = "Commission";
            this.bandedGridColumn30.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn30.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn30.FieldName = "commission";
            this.bandedGridColumn30.MinWidth = 23;
            this.bandedGridColumn30.Name = "bandedGridColumn30";
            this.bandedGridColumn30.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn30.Width = 111;
            // 
            // bandedGridColumn24
            // 
            this.bandedGridColumn24.Caption = "Down Payment";
            this.bandedGridColumn24.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn24.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn24.FieldName = "downPayment";
            this.bandedGridColumn24.MinWidth = 23;
            this.bandedGridColumn24.Name = "bandedGridColumn24";
            this.bandedGridColumn24.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn24.Width = 96;
            // 
            // bandedGridColumn26
            // 
            this.bandedGridColumn26.Caption = "Total Payments";
            this.bandedGridColumn26.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn26.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn26.FieldName = "totalPayments";
            this.bandedGridColumn26.MinWidth = 23;
            this.bandedGridColumn26.Name = "bandedGridColumn26";
            this.bandedGridColumn26.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn26.Width = 96;
            // 
            // bandedGridColumn23
            // 
            this.bandedGridColumn23.Caption = "Contract Value";
            this.bandedGridColumn23.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn23.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn23.FieldName = "contractValue";
            this.bandedGridColumn23.MinWidth = 23;
            this.bandedGridColumn23.Name = "bandedGridColumn23";
            this.bandedGridColumn23.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn23.Width = 117;
            // 
            // bandedGridColumn18
            // 
            this.bandedGridColumn18.Caption = "Trust";
            this.bandedGridColumn18.FieldName = "trust";
            this.bandedGridColumn18.MinWidth = 23;
            this.bandedGridColumn18.Name = "bandedGridColumn18";
            this.bandedGridColumn18.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn18.Width = 58;
            // 
            // bandedGridColumn21
            // 
            this.bandedGridColumn21.Caption = "Issue Date";
            this.bandedGridColumn21.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn21.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn21.FieldName = "issueDate8";
            this.bandedGridColumn21.MinWidth = 23;
            this.bandedGridColumn21.Name = "bandedGridColumn21";
            this.bandedGridColumn21.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn21.Width = 87;
            // 
            // bandedGridColumn17
            // 
            this.bandedGridColumn17.Caption = "Agent Name";
            this.bandedGridColumn17.FieldName = "agentName";
            this.bandedGridColumn17.MinWidth = 23;
            this.bandedGridColumn17.Name = "bandedGridColumn17";
            this.bandedGridColumn17.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn17.Width = 87;
            // 
            // bandedGridColumn3
            // 
            this.bandedGridColumn3.Caption = "Location Name";
            this.bandedGridColumn3.FieldName = "Location Name";
            this.bandedGridColumn3.MinWidth = 23;
            this.bandedGridColumn3.Name = "bandedGridColumn3";
            this.bandedGridColumn3.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn3.Width = 87;
            // 
            // bandedGridColumn14
            // 
            this.bandedGridColumn14.Caption = "17 & Prior Bal PD";
            this.bandedGridColumn14.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn14.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn14.FieldName = "prioryear";
            this.bandedGridColumn14.MinWidth = 23;
            this.bandedGridColumn14.Name = "bandedGridColumn14";
            this.bandedGridColumn14.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn14.Width = 117;
            // 
            // bandedGridColumn28
            // 
            this.bandedGridColumn28.Caption = "YTD Total PD";
            this.bandedGridColumn28.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn28.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn28.FieldName = "ytdPrevious";
            this.bandedGridColumn28.MinWidth = 23;
            this.bandedGridColumn28.Name = "bandedGridColumn28";
            this.bandedGridColumn28.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn28.Width = 117;
            // 
            // bandedGridColumn11
            // 
            this.bandedGridColumn11.Caption = "Group";
            this.bandedGridColumn11.FieldName = "group";
            this.bandedGridColumn11.MinWidth = 25;
            this.bandedGridColumn11.Name = "bandedGridColumn11";
            this.bandedGridColumn11.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn11.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn11.Width = 94;
            // 
            // tabRemoved
            // 
            this.tabRemoved.Controls.Add(this.dgv8);
            this.tabRemoved.Location = new System.Drawing.Point(4, 25);
            this.tabRemoved.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabRemoved.Name = "tabRemoved";
            this.tabRemoved.Size = new System.Drawing.Size(1636, 389);
            this.tabRemoved.TabIndex = 2;
            this.tabRemoved.Text = "Payments Removed from Trust";
            this.tabRemoved.UseVisualStyleBackColor = true;
            // 
            // dgv8
            // 
            this.dgv8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv8.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv8.Location = new System.Drawing.Point(0, 0);
            this.dgv8.LookAndFeel.SkinName = "iMaginary";
            this.dgv8.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv8.MainView = this.gridMain8;
            this.dgv8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv8.Name = "dgv8";
            this.dgv8.Size = new System.Drawing.Size(1636, 389);
            this.dgv8.TabIndex = 8;
            this.dgv8.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain8});
            // 
            // gridMain8
            // 
            this.gridMain8.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain8.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain8.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain8.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain8.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain8.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain8.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain8.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain8.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain8.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain8.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain8.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain8.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain8.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain8.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain8.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain8.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain8.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain8.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain8.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain8.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain8.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain8.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain8.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain8.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain8.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain8.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain8.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain8.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain8.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain8.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain8.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain8.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain8.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain8.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain8.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain8.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain8.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain8.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain8.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain8.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain8.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain8.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain8.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain8.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain8.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain8.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain8.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain8.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain8.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain8.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain8.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain8.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain8.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain8.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain8.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain8.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain8.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain8.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain8.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain8.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain8.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain8.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain8.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain8.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.Row.Options.UseBackColor = true;
            this.gridMain8.Appearance.Row.Options.UseForeColor = true;
            this.gridMain8.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain8.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain8.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain8.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain8.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain8.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain8.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain8.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand7});
            this.gridMain8.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain8.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.num173,
            this.bandedGridColumn199,
            this.lastName170,
            this.firstName171,
            this.bandedGridColumn174,
            this.contract179,
            this.ssn180,
            this.address175,
            this.city176,
            this.state177,
            this.zip178,
            this.fnl200,
            this.bandedGridColumn189,
            this.bandedGridColumn192,
            this.bandedGridColumn187,
            this.bandedGridColumn186,
            this.bandedGridColumn183,
            this.bandedGridColumn198,
            this.bandedGridColumn191,
            this.bandedGridColumn193,
            this.bandedGridColumn190,
            this.bandedGridColumn185,
            this.loc169,
            this.bandedGridColumn188,
            this.bandedGridColumn184,
            this.bandedGridColumn172,
            this.bandedGridColumn181,
            this.beginningBalance182,
            this.interest201,
            this.currentDeathClaims202,
            this.bandedGridColumn194,
            this.bandedGridColumn195,
            this.endingBalance197,
            this.currentRefunds196,
            this.currentInterest203,
            this.location210,
            this.bandedGridColumn12});
            this.gridMain8.DetailHeight = 431;
            this.gridMain8.GridControl = this.dgv8;
            this.gridMain8.GroupCount = 1;
            this.gridMain8.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "paymentCurrMonth", this.bandedGridColumn194, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "beginningBalance", this.beginningBalance182, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ytdPrevious", this.bandedGridColumn195, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "endingBalance", this.endingBalance197, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "currentRefunds", this.currentRefunds196, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "interest", this.interest201, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "currentInterest", this.currentInterest203, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "currentDeathClaims", this.currentDeathClaims202, "${0:0,0.00}")});
            this.gridMain8.Name = "gridMain8";
            this.gridMain8.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridMain8.OptionsBehavior.Editable = false;
            this.gridMain8.OptionsBehavior.ReadOnly = true;
            this.gridMain8.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain8.OptionsPrint.PrintBandHeader = false;
            this.gridMain8.OptionsSelection.MultiSelect = true;
            this.gridMain8.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain8.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain8.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain8.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.gridMain8.OptionsView.ShowBands = false;
            this.gridMain8.OptionsView.ShowFooter = true;
            this.gridMain8.OptionsView.ShowGroupPanel = false;
            this.gridMain8.PaintStyleName = "Style3D";
            this.gridMain8.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.location210, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.gridMain8.BeforePrintRow += new DevExpress.XtraGrid.Views.Base.BeforePrintRowEventHandler(this.beforePrintRow);
            this.gridMain8.AfterPrintRow += new DevExpress.XtraGrid.Views.Base.AfterPrintRowEventHandler(this.afterPrintRow);
            this.gridMain8.CustomDrawRowFooterCell += new DevExpress.XtraGrid.Views.Grid.FooterCellCustomDrawEventHandler(this.gridMain8_CustomDrawRowFooterCell);
            this.gridMain8.CustomDrawGroupRow += new DevExpress.XtraGrid.Views.Base.RowObjectCustomDrawEventHandler(this.gridMain8_CustomDrawGroupRow);
            this.gridMain8.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridView_CustomColumnDisplayText);
            this.gridMain8.DoubleClick += new System.EventHandler(this.gridMain6_DoubleClick);
            // 
            // gridBand7
            // 
            this.gridBand7.Caption = "gridBandXXX";
            this.gridBand7.Children.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand17,
            this.gridBand18});
            this.gridBand7.MinWidth = 12;
            this.gridBand7.Name = "gridBand7";
            this.gridBand7.VisibleIndex = 0;
            this.gridBand7.Width = 1327;
            // 
            // gridBand17
            // 
            this.gridBand17.Caption = "gridBand17";
            this.gridBand17.Columns.Add(this.loc169);
            this.gridBand17.Columns.Add(this.location210);
            this.gridBand17.Columns.Add(this.num173);
            this.gridBand17.Columns.Add(this.contract179);
            this.gridBand17.Columns.Add(this.fnl200);
            this.gridBand17.Columns.Add(this.lastName170);
            this.gridBand17.Columns.Add(this.firstName171);
            this.gridBand17.Columns.Add(this.address175);
            this.gridBand17.Columns.Add(this.city176);
            this.gridBand17.Columns.Add(this.state177);
            this.gridBand17.Columns.Add(this.zip178);
            this.gridBand17.Columns.Add(this.ssn180);
            this.gridBand17.Name = "gridBand17";
            this.gridBand17.VisibleIndex = 0;
            this.gridBand17.Width = 719;
            // 
            // loc169
            // 
            this.loc169.Caption = "Loc";
            this.loc169.FieldName = "loc";
            this.loc169.MinWidth = 23;
            this.loc169.Name = "loc169";
            this.loc169.OptionsColumn.FixedWidth = true;
            this.loc169.Visible = true;
            this.loc169.Width = 47;
            // 
            // location210
            // 
            this.location210.Caption = "Location";
            this.location210.FieldName = "locind";
            this.location210.MinWidth = 23;
            this.location210.Name = "location210";
            this.location210.OptionsColumn.FixedWidth = true;
            this.location210.Visible = true;
            this.location210.Width = 87;
            // 
            // num173
            // 
            this.num173.Caption = "Num";
            this.num173.FieldName = "num";
            this.num173.MinWidth = 23;
            this.num173.Name = "num173";
            this.num173.OptionsColumn.AllowEdit = false;
            this.num173.OptionsColumn.FixedWidth = true;
            this.num173.Width = 58;
            // 
            // contract179
            // 
            this.contract179.Caption = "Contract";
            this.contract179.FieldName = "contractNumber";
            this.contract179.MinWidth = 23;
            this.contract179.Name = "contract179";
            this.contract179.OptionsColumn.AllowEdit = false;
            this.contract179.OptionsColumn.FixedWidth = true;
            this.contract179.Visible = true;
            // 
            // fnl200
            // 
            this.fnl200.Caption = "FNL# or Ref";
            this.fnl200.FieldName = "ServiceId2";
            this.fnl200.MinWidth = 23;
            this.fnl200.Name = "fnl200";
            this.fnl200.OptionsColumn.FixedWidth = true;
            this.fnl200.Visible = true;
            this.fnl200.Width = 87;
            // 
            // lastName170
            // 
            this.lastName170.Caption = "Last Name";
            this.lastName170.FieldName = "lastName";
            this.lastName170.MinWidth = 23;
            this.lastName170.Name = "lastName170";
            this.lastName170.OptionsColumn.FixedWidth = true;
            this.lastName170.RowIndex = 1;
            this.lastName170.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Count, "lastName", "Count={0}")});
            this.lastName170.Visible = true;
            this.lastName170.Width = 120;
            // 
            // firstName171
            // 
            this.firstName171.Caption = "First Name";
            this.firstName171.FieldName = "firstName";
            this.firstName171.MinWidth = 23;
            this.firstName171.Name = "firstName171";
            this.firstName171.OptionsColumn.FixedWidth = true;
            this.firstName171.RowIndex = 1;
            this.firstName171.Visible = true;
            this.firstName171.Width = 124;
            // 
            // address175
            // 
            this.address175.Caption = "Address";
            this.address175.FieldName = "address1";
            this.address175.MinWidth = 23;
            this.address175.Name = "address175";
            this.address175.OptionsColumn.FixedWidth = true;
            this.address175.RowIndex = 1;
            this.address175.Visible = true;
            this.address175.Width = 134;
            // 
            // city176
            // 
            this.city176.Caption = "City";
            this.city176.FieldName = "city";
            this.city176.MinWidth = 23;
            this.city176.Name = "city176";
            this.city176.OptionsColumn.FixedWidth = true;
            this.city176.RowIndex = 1;
            this.city176.Visible = true;
            this.city176.Width = 132;
            // 
            // state177
            // 
            this.state177.Caption = "State";
            this.state177.FieldName = "state";
            this.state177.MinWidth = 23;
            this.state177.Name = "state177";
            this.state177.OptionsColumn.FixedWidth = true;
            this.state177.RowIndex = 1;
            this.state177.Visible = true;
            this.state177.Width = 58;
            // 
            // zip178
            // 
            this.zip178.Caption = "Zip";
            this.zip178.FieldName = "zip1";
            this.zip178.MinWidth = 23;
            this.zip178.Name = "zip178";
            this.zip178.OptionsColumn.FixedWidth = true;
            this.zip178.RowIndex = 1;
            this.zip178.Visible = true;
            this.zip178.Width = 58;
            // 
            // ssn180
            // 
            this.ssn180.Caption = "SS#";
            this.ssn180.FieldName = "ssn";
            this.ssn180.MinWidth = 23;
            this.ssn180.Name = "ssn180";
            this.ssn180.OptionsColumn.FixedWidth = true;
            this.ssn180.RowIndex = 1;
            this.ssn180.Visible = true;
            this.ssn180.Width = 93;
            // 
            // gridBand18
            // 
            this.gridBand18.Caption = "gridBand18";
            this.gridBand18.Columns.Add(this.beginningBalance182);
            this.gridBand18.Columns.Add(this.interest201);
            this.gridBand18.Columns.Add(this.currentDeathClaims202);
            this.gridBand18.Columns.Add(this.currentRefunds196);
            this.gridBand18.Columns.Add(this.currentInterest203);
            this.gridBand18.Columns.Add(this.endingBalance197);
            this.gridBand18.Name = "gridBand18";
            this.gridBand18.VisibleIndex = 1;
            this.gridBand18.Width = 608;
            // 
            // beginningBalance182
            // 
            this.beginningBalance182.Caption = "YTD Prior Clm-Paid";
            this.beginningBalance182.DisplayFormat.FormatString = "N2";
            this.beginningBalance182.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.beginningBalance182.FieldName = "beginningBalance";
            this.beginningBalance182.MinWidth = 23;
            this.beginningBalance182.Name = "beginningBalance182";
            this.beginningBalance182.OptionsColumn.FixedWidth = true;
            this.beginningBalance182.Visible = true;
            this.beginningBalance182.Width = 105;
            // 
            // interest201
            // 
            this.interest201.Caption = "YTD Prior Int";
            this.interest201.DisplayFormat.FormatString = "N2";
            this.interest201.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.interest201.FieldName = "interest";
            this.interest201.MinWidth = 23;
            this.interest201.Name = "interest201";
            this.interest201.OptionsColumn.FixedWidth = true;
            this.interest201.Visible = true;
            this.interest201.Width = 87;
            // 
            // currentDeathClaims202
            // 
            this.currentDeathClaims202.Caption = "Current Death Clms";
            this.currentDeathClaims202.DisplayFormat.FormatString = "N2";
            this.currentDeathClaims202.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.currentDeathClaims202.FieldName = "currentDeathClaims";
            this.currentDeathClaims202.MinWidth = 23;
            this.currentDeathClaims202.Name = "currentDeathClaims202";
            this.currentDeathClaims202.OptionsColumn.FixedWidth = true;
            this.currentDeathClaims202.Visible = true;
            this.currentDeathClaims202.Width = 87;
            // 
            // currentRefunds196
            // 
            this.currentRefunds196.Caption = "Current Refunds";
            this.currentRefunds196.DisplayFormat.FormatString = "N2";
            this.currentRefunds196.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.currentRefunds196.FieldName = "currentRefunds";
            this.currentRefunds196.MinWidth = 23;
            this.currentRefunds196.Name = "currentRefunds196";
            this.currentRefunds196.OptionsColumn.FixedWidth = true;
            this.currentRefunds196.Visible = true;
            this.currentRefunds196.Width = 117;
            // 
            // currentInterest203
            // 
            this.currentInterest203.Caption = "Int.";
            this.currentInterest203.DisplayFormat.FormatString = "N2";
            this.currentInterest203.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.currentInterest203.FieldName = "currentInterest";
            this.currentInterest203.MinWidth = 23;
            this.currentInterest203.Name = "currentInterest203";
            this.currentInterest203.OptionsColumn.FixedWidth = true;
            this.currentInterest203.Visible = true;
            this.currentInterest203.Width = 66;
            // 
            // endingBalance197
            // 
            this.endingBalance197.Caption = "Total YTD";
            this.endingBalance197.DisplayFormat.FormatString = "N2";
            this.endingBalance197.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.endingBalance197.FieldName = "endingBalance";
            this.endingBalance197.MinWidth = 23;
            this.endingBalance197.Name = "endingBalance197";
            this.endingBalance197.OptionsColumn.FixedWidth = true;
            this.endingBalance197.Visible = true;
            this.endingBalance197.Width = 146;
            // 
            // bandedGridColumn199
            // 
            this.bandedGridColumn199.Caption = "record";
            this.bandedGridColumn199.FieldName = "record";
            this.bandedGridColumn199.MinWidth = 23;
            this.bandedGridColumn199.Name = "bandedGridColumn199";
            this.bandedGridColumn199.RowCount = 2;
            this.bandedGridColumn199.Width = 87;
            // 
            // bandedGridColumn174
            // 
            this.bandedGridColumn174.Caption = "Name";
            this.bandedGridColumn174.FieldName = "fullname";
            this.bandedGridColumn174.MinWidth = 23;
            this.bandedGridColumn174.Name = "bandedGridColumn174";
            this.bandedGridColumn174.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn174.Width = 87;
            // 
            // bandedGridColumn189
            // 
            this.bandedGridColumn189.Caption = "Customer";
            this.bandedGridColumn189.FieldName = "customer";
            this.bandedGridColumn189.MinWidth = 23;
            this.bandedGridColumn189.Name = "bandedGridColumn189";
            this.bandedGridColumn189.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn189.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn189.Width = 175;
            // 
            // bandedGridColumn192
            // 
            this.bandedGridColumn192.Caption = "Payment";
            this.bandedGridColumn192.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn192.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn192.FieldName = "paymentAmount";
            this.bandedGridColumn192.MinWidth = 23;
            this.bandedGridColumn192.Name = "bandedGridColumn192";
            this.bandedGridColumn192.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn192.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn192.Width = 96;
            // 
            // bandedGridColumn187
            // 
            this.bandedGridColumn187.Caption = "Date Paid";
            this.bandedGridColumn187.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn187.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn187.FieldName = "payDate8";
            this.bandedGridColumn187.MinWidth = 23;
            this.bandedGridColumn187.Name = "bandedGridColumn187";
            this.bandedGridColumn187.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn187.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn187.Width = 76;
            // 
            // bandedGridColumn186
            // 
            this.bandedGridColumn186.Caption = "Due Date";
            this.bandedGridColumn186.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn186.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn186.FieldName = "dueDate8";
            this.bandedGridColumn186.MinWidth = 23;
            this.bandedGridColumn186.Name = "bandedGridColumn186";
            this.bandedGridColumn186.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn186.Width = 76;
            // 
            // bandedGridColumn183
            // 
            this.bandedGridColumn183.Caption = "Agent";
            this.bandedGridColumn183.FieldName = "agentNumber";
            this.bandedGridColumn183.MinWidth = 23;
            this.bandedGridColumn183.Name = "bandedGridColumn183";
            this.bandedGridColumn183.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn183.Width = 70;
            // 
            // bandedGridColumn198
            // 
            this.bandedGridColumn198.Caption = "Commission";
            this.bandedGridColumn198.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn198.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn198.FieldName = "commission";
            this.bandedGridColumn198.MinWidth = 23;
            this.bandedGridColumn198.Name = "bandedGridColumn198";
            this.bandedGridColumn198.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn198.Width = 111;
            // 
            // bandedGridColumn191
            // 
            this.bandedGridColumn191.Caption = "Down Payment";
            this.bandedGridColumn191.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn191.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn191.FieldName = "downPayment";
            this.bandedGridColumn191.MinWidth = 23;
            this.bandedGridColumn191.Name = "bandedGridColumn191";
            this.bandedGridColumn191.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn191.Width = 96;
            // 
            // bandedGridColumn193
            // 
            this.bandedGridColumn193.Caption = "Total Payments";
            this.bandedGridColumn193.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn193.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn193.FieldName = "totalPayments";
            this.bandedGridColumn193.MinWidth = 23;
            this.bandedGridColumn193.Name = "bandedGridColumn193";
            this.bandedGridColumn193.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn193.Width = 96;
            // 
            // bandedGridColumn190
            // 
            this.bandedGridColumn190.Caption = "Contract Value";
            this.bandedGridColumn190.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn190.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn190.FieldName = "contractValue";
            this.bandedGridColumn190.MinWidth = 23;
            this.bandedGridColumn190.Name = "bandedGridColumn190";
            this.bandedGridColumn190.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn190.Width = 117;
            // 
            // bandedGridColumn185
            // 
            this.bandedGridColumn185.Caption = "Trust";
            this.bandedGridColumn185.FieldName = "trust";
            this.bandedGridColumn185.MinWidth = 23;
            this.bandedGridColumn185.Name = "bandedGridColumn185";
            this.bandedGridColumn185.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn185.Width = 58;
            // 
            // bandedGridColumn188
            // 
            this.bandedGridColumn188.Caption = "Issue Date";
            this.bandedGridColumn188.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn188.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn188.FieldName = "issueDate8";
            this.bandedGridColumn188.MinWidth = 23;
            this.bandedGridColumn188.Name = "bandedGridColumn188";
            this.bandedGridColumn188.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn188.Width = 87;
            // 
            // bandedGridColumn184
            // 
            this.bandedGridColumn184.Caption = "Agent Name";
            this.bandedGridColumn184.FieldName = "agentName";
            this.bandedGridColumn184.MinWidth = 23;
            this.bandedGridColumn184.Name = "bandedGridColumn184";
            this.bandedGridColumn184.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn184.Width = 87;
            // 
            // bandedGridColumn172
            // 
            this.bandedGridColumn172.Caption = "Location Name";
            this.bandedGridColumn172.FieldName = "Location Name";
            this.bandedGridColumn172.MinWidth = 23;
            this.bandedGridColumn172.Name = "bandedGridColumn172";
            this.bandedGridColumn172.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn172.Width = 87;
            // 
            // bandedGridColumn181
            // 
            this.bandedGridColumn181.Caption = "17 & Prior Bal PD";
            this.bandedGridColumn181.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn181.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn181.FieldName = "prioryear";
            this.bandedGridColumn181.MinWidth = 23;
            this.bandedGridColumn181.Name = "bandedGridColumn181";
            this.bandedGridColumn181.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn181.Width = 117;
            // 
            // bandedGridColumn194
            // 
            this.bandedGridColumn194.Caption = "Current Month";
            this.bandedGridColumn194.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn194.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn194.FieldName = "paymentCurrMonth";
            this.bandedGridColumn194.MinWidth = 23;
            this.bandedGridColumn194.Name = "bandedGridColumn194";
            this.bandedGridColumn194.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn194.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn194.Width = 96;
            // 
            // bandedGridColumn195
            // 
            this.bandedGridColumn195.Caption = "YTD Total PD";
            this.bandedGridColumn195.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn195.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn195.FieldName = "ytdPrevious";
            this.bandedGridColumn195.MinWidth = 23;
            this.bandedGridColumn195.Name = "bandedGridColumn195";
            this.bandedGridColumn195.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn195.Width = 117;
            // 
            // bandedGridColumn12
            // 
            this.bandedGridColumn12.Caption = "Group";
            this.bandedGridColumn12.FieldName = "group";
            this.bandedGridColumn12.MinWidth = 25;
            this.bandedGridColumn12.Name = "bandedGridColumn12";
            this.bandedGridColumn12.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn12.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn12.Width = 94;
            // 
            // tabDiff
            // 
            this.tabDiff.Controls.Add(this.panelDiffAll);
            this.tabDiff.Location = new System.Drawing.Point(4, 25);
            this.tabDiff.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabDiff.Name = "tabDiff";
            this.tabDiff.Size = new System.Drawing.Size(1636, 389);
            this.tabDiff.TabIndex = 3;
            this.tabDiff.Text = "Trust Difference";
            this.tabDiff.UseVisualStyleBackColor = true;
            // 
            // panelDiffAll
            // 
            this.panelDiffAll.Controls.Add(this.panelDiffBottom);
            this.panelDiffAll.Controls.Add(this.panelDiffTop);
            this.panelDiffAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDiffAll.Location = new System.Drawing.Point(0, 0);
            this.panelDiffAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelDiffAll.Name = "panelDiffAll";
            this.panelDiffAll.Size = new System.Drawing.Size(1636, 389);
            this.panelDiffAll.TabIndex = 0;
            // 
            // panelDiffBottom
            // 
            this.panelDiffBottom.Controls.Add(this.dgv9);
            this.panelDiffBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDiffBottom.Location = new System.Drawing.Point(0, 52);
            this.panelDiffBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelDiffBottom.Name = "panelDiffBottom";
            this.panelDiffBottom.Size = new System.Drawing.Size(1636, 337);
            this.panelDiffBottom.TabIndex = 2;
            // 
            // dgv9
            // 
            this.dgv9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv9.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv9.Location = new System.Drawing.Point(0, 0);
            this.dgv9.LookAndFeel.SkinName = "iMaginary";
            this.dgv9.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv9.MainView = this.gridMain9;
            this.dgv9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv9.Name = "dgv9";
            this.dgv9.Size = new System.Drawing.Size(1636, 337);
            this.dgv9.TabIndex = 8;
            this.dgv9.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain9});
            // 
            // gridMain9
            // 
            this.gridMain9.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain9.Appearance.BandPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(153)))), ((int)(((byte)(182)))));
            this.gridMain9.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain9.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain9.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.BandPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain9.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain9.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain9.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain9.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain9.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain9.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain9.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(153)))), ((int)(((byte)(182)))));
            this.gridMain9.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain9.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.ColumnFilterButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain9.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain9.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain9.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain9.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(198)))), ((int)(((byte)(215)))));
            this.gridMain9.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.ColumnFilterButtonActive.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain9.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain9.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain9.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain9.Appearance.Empty.BackColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain9.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain9.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain9.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(153)))), ((int)(((byte)(182)))));
            this.gridMain9.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain9.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain9.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain9.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain9.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(131)))), ((int)(((byte)(161)))));
            this.gridMain9.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain9.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain9.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(124)))), ((int)(((byte)(148)))));
            this.gridMain9.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain9.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(180)))), ((int)(((byte)(191)))));
            this.gridMain9.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain9.Appearance.FooterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(153)))), ((int)(((byte)(182)))));
            this.gridMain9.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain9.Appearance.FooterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain9.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain9.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain9.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain9.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain9.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain9.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain9.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain9.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain9.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain9.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain9.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain9.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain9.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(131)))), ((int)(((byte)(161)))));
            this.gridMain9.Appearance.GroupPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain9.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain9.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain9.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain9.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain9.Appearance.GroupRow.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain9.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain9.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain9.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain9.Appearance.HeaderPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(153)))), ((int)(((byte)(182)))));
            this.gridMain9.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain9.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.HeaderPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain9.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain9.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain9.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain9.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain9.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain9.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain9.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(219)))), ((int)(((byte)(226)))));
            this.gridMain9.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(131)))), ((int)(((byte)(161)))));
            this.gridMain9.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(164)))), ((int)(((byte)(188)))));
            this.gridMain9.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain9.Appearance.OddRow.BackColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(253)))));
            this.gridMain9.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(165)))), ((int)(((byte)(177)))));
            this.gridMain9.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain9.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain9.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.Row.Options.UseBackColor = true;
            this.gridMain9.Appearance.Row.Options.UseForeColor = true;
            this.gridMain9.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain9.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(197)))), ((int)(((byte)(205)))));
            this.gridMain9.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(164)))), ((int)(((byte)(188)))));
            this.gridMain9.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain9.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain9.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain9.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand3});
            this.gridMain9.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain9.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn96,
            this.bandedGridColumn124,
            this.bandedGridColumn97,
            this.bandedGridColumn98,
            this.bandedGridColumn99,
            this.bandedGridColumn104,
            this.bandedGridColumn105,
            this.bandedGridColumn114,
            this.bandedGridColumn117,
            this.bandedGridColumn112,
            this.bandedGridColumn111,
            this.bandedGridColumn108,
            this.bandedGridColumn123,
            this.bandedGridColumn116,
            this.bandedGridColumn118,
            this.bandedGridColumn115,
            this.bandedGridColumn110,
            this.bandedGridColumn94,
            this.bandedGridColumn113,
            this.bandedGridColumn109,
            this.bandedGridColumn95,
            this.bandedGridColumn106,
            this.bandedGridColumn107,
            this.bandedGridColumn119,
            this.bandedGridColumn120,
            this.bandedGridColumn122,
            this.bandedGridColumn121,
            this.bandedGridColumn100,
            this.bandedGridColumn101});
            this.gridMain9.DetailHeight = 431;
            this.gridMain9.GridControl = this.dgv9;
            this.gridMain9.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "paymentCurrMonth", this.bandedGridColumn119, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "beginningBalance", this.bandedGridColumn106, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ytdPrevious", this.bandedGridColumn107, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "endingBalance", this.bandedGridColumn122, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "currentRemovals", this.bandedGridColumn121, "${0:0,0.00}")});
            this.gridMain9.Name = "gridMain9";
            this.gridMain9.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridMain9.OptionsBehavior.Editable = false;
            this.gridMain9.OptionsBehavior.ReadOnly = true;
            this.gridMain9.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain9.OptionsPrint.PrintBandHeader = false;
            this.gridMain9.OptionsSelection.MultiSelect = true;
            this.gridMain9.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain9.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain9.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain9.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.gridMain9.OptionsView.ShowBands = false;
            this.gridMain9.OptionsView.ShowFooter = true;
            this.gridMain9.OptionsView.ShowGroupPanel = false;
            this.gridMain9.PaintStyleName = "Style3D";
            // 
            // gridBand3
            // 
            this.gridBand3.Caption = "gridBandXXX";
            this.gridBand3.Columns.Add(this.bandedGridColumn94);
            this.gridBand3.Columns.Add(this.bandedGridColumn95);
            this.gridBand3.Columns.Add(this.bandedGridColumn96);
            this.gridBand3.Columns.Add(this.bandedGridColumn97);
            this.gridBand3.Columns.Add(this.bandedGridColumn98);
            this.gridBand3.Columns.Add(this.bandedGridColumn99);
            this.gridBand3.Columns.Add(this.bandedGridColumn104);
            this.gridBand3.Columns.Add(this.bandedGridColumn105);
            this.gridBand3.Columns.Add(this.bandedGridColumn106);
            this.gridBand3.Columns.Add(this.bandedGridColumn107);
            this.gridBand3.Columns.Add(this.bandedGridColumn108);
            this.gridBand3.Columns.Add(this.bandedGridColumn109);
            this.gridBand3.Columns.Add(this.bandedGridColumn110);
            this.gridBand3.Columns.Add(this.bandedGridColumn111);
            this.gridBand3.Columns.Add(this.bandedGridColumn112);
            this.gridBand3.Columns.Add(this.bandedGridColumn113);
            this.gridBand3.Columns.Add(this.bandedGridColumn114);
            this.gridBand3.Columns.Add(this.bandedGridColumn115);
            this.gridBand3.Columns.Add(this.bandedGridColumn116);
            this.gridBand3.Columns.Add(this.bandedGridColumn117);
            this.gridBand3.Columns.Add(this.bandedGridColumn118);
            this.gridBand3.Columns.Add(this.bandedGridColumn119);
            this.gridBand3.Columns.Add(this.bandedGridColumn120);
            this.gridBand3.Columns.Add(this.bandedGridColumn121);
            this.gridBand3.Columns.Add(this.bandedGridColumn122);
            this.gridBand3.Columns.Add(this.bandedGridColumn100);
            this.gridBand3.Columns.Add(this.bandedGridColumn101);
            this.gridBand3.Columns.Add(this.bandedGridColumn123);
            this.gridBand3.Columns.Add(this.bandedGridColumn124);
            this.gridBand3.MinWidth = 12;
            this.gridBand3.Name = "gridBand3";
            this.gridBand3.VisibleIndex = 0;
            this.gridBand3.Width = 994;
            // 
            // bandedGridColumn94
            // 
            this.bandedGridColumn94.Caption = "Loc";
            this.bandedGridColumn94.FieldName = "loc";
            this.bandedGridColumn94.MinWidth = 23;
            this.bandedGridColumn94.Name = "bandedGridColumn94";
            this.bandedGridColumn94.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn94.Visible = true;
            this.bandedGridColumn94.Width = 47;
            // 
            // bandedGridColumn95
            // 
            this.bandedGridColumn95.Caption = "Location Name";
            this.bandedGridColumn95.FieldName = "Location Name";
            this.bandedGridColumn95.MinWidth = 23;
            this.bandedGridColumn95.Name = "bandedGridColumn95";
            this.bandedGridColumn95.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn95.Width = 87;
            // 
            // bandedGridColumn96
            // 
            this.bandedGridColumn96.Caption = "Num";
            this.bandedGridColumn96.FieldName = "num";
            this.bandedGridColumn96.MinWidth = 23;
            this.bandedGridColumn96.Name = "bandedGridColumn96";
            this.bandedGridColumn96.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn96.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn96.Width = 58;
            // 
            // bandedGridColumn97
            // 
            this.bandedGridColumn97.Caption = "Last Name";
            this.bandedGridColumn97.FieldName = "lastName";
            this.bandedGridColumn97.MinWidth = 23;
            this.bandedGridColumn97.Name = "bandedGridColumn97";
            this.bandedGridColumn97.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn97.Width = 87;
            // 
            // bandedGridColumn98
            // 
            this.bandedGridColumn98.Caption = "First Name";
            this.bandedGridColumn98.FieldName = "firstName";
            this.bandedGridColumn98.MinWidth = 23;
            this.bandedGridColumn98.Name = "bandedGridColumn98";
            this.bandedGridColumn98.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn98.Width = 87;
            // 
            // bandedGridColumn99
            // 
            this.bandedGridColumn99.Caption = "Name";
            this.bandedGridColumn99.FieldName = "fullname";
            this.bandedGridColumn99.MinWidth = 23;
            this.bandedGridColumn99.Name = "bandedGridColumn99";
            this.bandedGridColumn99.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn99.Visible = true;
            this.bandedGridColumn99.Width = 87;
            // 
            // bandedGridColumn104
            // 
            this.bandedGridColumn104.Caption = "Contract";
            this.bandedGridColumn104.FieldName = "contractNumber";
            this.bandedGridColumn104.MinWidth = 23;
            this.bandedGridColumn104.Name = "bandedGridColumn104";
            this.bandedGridColumn104.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn104.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn104.Visible = true;
            // 
            // bandedGridColumn105
            // 
            this.bandedGridColumn105.Caption = "SS#";
            this.bandedGridColumn105.FieldName = "ssn";
            this.bandedGridColumn105.MinWidth = 23;
            this.bandedGridColumn105.Name = "bandedGridColumn105";
            this.bandedGridColumn105.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn105.Visible = true;
            this.bandedGridColumn105.Width = 87;
            // 
            // bandedGridColumn106
            // 
            this.bandedGridColumn106.Caption = "17 & Prior Bal PD";
            this.bandedGridColumn106.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn106.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn106.FieldName = "prioryear";
            this.bandedGridColumn106.MinWidth = 23;
            this.bandedGridColumn106.Name = "bandedGridColumn106";
            this.bandedGridColumn106.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn106.Width = 117;
            // 
            // bandedGridColumn107
            // 
            this.bandedGridColumn107.Caption = "Beginning Value";
            this.bandedGridColumn107.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn107.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn107.FieldName = "beginningBalance";
            this.bandedGridColumn107.MinWidth = 23;
            this.bandedGridColumn107.Name = "bandedGridColumn107";
            this.bandedGridColumn107.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn107.Visible = true;
            this.bandedGridColumn107.Width = 105;
            // 
            // bandedGridColumn108
            // 
            this.bandedGridColumn108.Caption = "Agent";
            this.bandedGridColumn108.FieldName = "agentNumber";
            this.bandedGridColumn108.MinWidth = 23;
            this.bandedGridColumn108.Name = "bandedGridColumn108";
            this.bandedGridColumn108.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn108.Width = 70;
            // 
            // bandedGridColumn109
            // 
            this.bandedGridColumn109.Caption = "Agent Name";
            this.bandedGridColumn109.FieldName = "agentName";
            this.bandedGridColumn109.MinWidth = 23;
            this.bandedGridColumn109.Name = "bandedGridColumn109";
            this.bandedGridColumn109.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn109.Width = 87;
            // 
            // bandedGridColumn110
            // 
            this.bandedGridColumn110.Caption = "Trust";
            this.bandedGridColumn110.FieldName = "trust";
            this.bandedGridColumn110.MinWidth = 23;
            this.bandedGridColumn110.Name = "bandedGridColumn110";
            this.bandedGridColumn110.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn110.Width = 58;
            // 
            // bandedGridColumn111
            // 
            this.bandedGridColumn111.Caption = "Due Date";
            this.bandedGridColumn111.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn111.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn111.FieldName = "dueDate8";
            this.bandedGridColumn111.MinWidth = 23;
            this.bandedGridColumn111.Name = "bandedGridColumn111";
            this.bandedGridColumn111.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn111.Width = 76;
            // 
            // bandedGridColumn112
            // 
            this.bandedGridColumn112.Caption = "Date Paid";
            this.bandedGridColumn112.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn112.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn112.FieldName = "payDate8";
            this.bandedGridColumn112.MinWidth = 23;
            this.bandedGridColumn112.Name = "bandedGridColumn112";
            this.bandedGridColumn112.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn112.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn112.Width = 76;
            // 
            // bandedGridColumn113
            // 
            this.bandedGridColumn113.Caption = "Issue Date";
            this.bandedGridColumn113.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn113.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn113.FieldName = "issueDate8";
            this.bandedGridColumn113.MinWidth = 23;
            this.bandedGridColumn113.Name = "bandedGridColumn113";
            this.bandedGridColumn113.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn113.Width = 87;
            // 
            // bandedGridColumn114
            // 
            this.bandedGridColumn114.Caption = "Customer";
            this.bandedGridColumn114.FieldName = "customer";
            this.bandedGridColumn114.MinWidth = 23;
            this.bandedGridColumn114.Name = "bandedGridColumn114";
            this.bandedGridColumn114.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn114.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn114.Width = 175;
            // 
            // bandedGridColumn115
            // 
            this.bandedGridColumn115.Caption = "Contract Value";
            this.bandedGridColumn115.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn115.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn115.FieldName = "contractValue";
            this.bandedGridColumn115.MinWidth = 23;
            this.bandedGridColumn115.Name = "bandedGridColumn115";
            this.bandedGridColumn115.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn115.Width = 117;
            // 
            // bandedGridColumn116
            // 
            this.bandedGridColumn116.Caption = "Down Payment";
            this.bandedGridColumn116.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn116.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn116.FieldName = "downPayment";
            this.bandedGridColumn116.MinWidth = 23;
            this.bandedGridColumn116.Name = "bandedGridColumn116";
            this.bandedGridColumn116.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn116.Width = 96;
            // 
            // bandedGridColumn117
            // 
            this.bandedGridColumn117.Caption = "Payment";
            this.bandedGridColumn117.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn117.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn117.FieldName = "paymentAmount";
            this.bandedGridColumn117.MinWidth = 23;
            this.bandedGridColumn117.Name = "bandedGridColumn117";
            this.bandedGridColumn117.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn117.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn117.Width = 96;
            // 
            // bandedGridColumn118
            // 
            this.bandedGridColumn118.Caption = "Total Payments";
            this.bandedGridColumn118.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn118.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn118.FieldName = "totalPayments";
            this.bandedGridColumn118.MinWidth = 23;
            this.bandedGridColumn118.Name = "bandedGridColumn118";
            this.bandedGridColumn118.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn118.Width = 96;
            // 
            // bandedGridColumn119
            // 
            this.bandedGridColumn119.Caption = "Current Month";
            this.bandedGridColumn119.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn119.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn119.FieldName = "paymentCurrMonth";
            this.bandedGridColumn119.MinWidth = 23;
            this.bandedGridColumn119.Name = "bandedGridColumn119";
            this.bandedGridColumn119.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn119.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn119.Visible = true;
            this.bandedGridColumn119.Width = 96;
            // 
            // bandedGridColumn120
            // 
            this.bandedGridColumn120.Caption = "YTD Total PD";
            this.bandedGridColumn120.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn120.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn120.FieldName = "ytdPrevious";
            this.bandedGridColumn120.MinWidth = 23;
            this.bandedGridColumn120.Name = "bandedGridColumn120";
            this.bandedGridColumn120.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn120.Width = 117;
            // 
            // bandedGridColumn121
            // 
            this.bandedGridColumn121.Caption = "Current Removals";
            this.bandedGridColumn121.FieldName = "currentRemovals";
            this.bandedGridColumn121.MinWidth = 23;
            this.bandedGridColumn121.Name = "bandedGridColumn121";
            this.bandedGridColumn121.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn121.Visible = true;
            this.bandedGridColumn121.Width = 117;
            // 
            // bandedGridColumn122
            // 
            this.bandedGridColumn122.Caption = "Ending Balance";
            this.bandedGridColumn122.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn122.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn122.FieldName = "endingBalance";
            this.bandedGridColumn122.MinWidth = 23;
            this.bandedGridColumn122.Name = "bandedGridColumn122";
            this.bandedGridColumn122.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn122.Visible = true;
            this.bandedGridColumn122.Width = 146;
            // 
            // bandedGridColumn100
            // 
            this.bandedGridColumn100.Caption = "Calculated Trust85";
            this.bandedGridColumn100.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn100.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn100.FieldName = "calcTrust85";
            this.bandedGridColumn100.MinWidth = 23;
            this.bandedGridColumn100.Name = "bandedGridColumn100";
            this.bandedGridColumn100.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn100.Visible = true;
            this.bandedGridColumn100.Width = 117;
            // 
            // bandedGridColumn101
            // 
            this.bandedGridColumn101.Caption = "Difference";
            this.bandedGridColumn101.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn101.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn101.FieldName = "difference";
            this.bandedGridColumn101.MinWidth = 23;
            this.bandedGridColumn101.Name = "bandedGridColumn101";
            this.bandedGridColumn101.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn101.Visible = true;
            this.bandedGridColumn101.Width = 117;
            // 
            // bandedGridColumn123
            // 
            this.bandedGridColumn123.Caption = "Commission";
            this.bandedGridColumn123.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn123.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn123.FieldName = "commission";
            this.bandedGridColumn123.MinWidth = 23;
            this.bandedGridColumn123.Name = "bandedGridColumn123";
            this.bandedGridColumn123.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn123.Width = 111;
            // 
            // bandedGridColumn124
            // 
            this.bandedGridColumn124.Caption = "record";
            this.bandedGridColumn124.FieldName = "record";
            this.bandedGridColumn124.MinWidth = 23;
            this.bandedGridColumn124.Name = "bandedGridColumn124";
            this.bandedGridColumn124.RowCount = 2;
            this.bandedGridColumn124.Width = 87;
            // 
            // panelDiffTop
            // 
            this.panelDiffTop.BackColor = System.Drawing.Color.MintCream;
            this.panelDiffTop.Controls.Add(this.label2);
            this.panelDiffTop.Controls.Add(this.progressBar1);
            this.panelDiffTop.Controls.Add(this.btnRunDiff);
            this.panelDiffTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDiffTop.Location = new System.Drawing.Point(0, 0);
            this.panelDiffTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelDiffTop.Name = "panelDiffTop";
            this.panelDiffTop.Size = new System.Drawing.Size(1636, 52);
            this.panelDiffTop.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(553, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 17);
            this.label2.TabIndex = 33;
            this.label2.Text = "label2";
            // 
            // progressBar1
            // 
            this.progressBar1.BackColor = System.Drawing.Color.Lime;
            this.progressBar1.Location = new System.Drawing.Point(121, 18);
            this.progressBar1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(425, 15);
            this.progressBar1.TabIndex = 32;
            // 
            // btnRunDiff
            // 
            this.btnRunDiff.BackColor = System.Drawing.Color.SeaShell;
            this.btnRunDiff.Font = new System.Drawing.Font("Tahoma", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btnRunDiff.Location = new System.Drawing.Point(9, 6);
            this.btnRunDiff.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRunDiff.Name = "btnRunDiff";
            this.btnRunDiff.Size = new System.Drawing.Size(87, 42);
            this.btnRunDiff.TabIndex = 30;
            this.btnRunDiff.Text = "Run";
            this.btnRunDiff.UseVisualStyleBackColor = false;
            this.btnRunDiff.Click += new System.EventHandler(this.btnRunDiff_Click);
            // 
            // tabCompare
            // 
            this.tabCompare.Controls.Add(this.panelCompareAll);
            this.tabCompare.Location = new System.Drawing.Point(4, 25);
            this.tabCompare.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabCompare.Name = "tabCompare";
            this.tabCompare.Size = new System.Drawing.Size(1636, 389);
            this.tabCompare.TabIndex = 4;
            this.tabCompare.Text = "Compare Payments";
            this.tabCompare.UseVisualStyleBackColor = true;
            // 
            // panelCompareAll
            // 
            this.panelCompareAll.Controls.Add(this.panelCompareBottom);
            this.panelCompareAll.Controls.Add(this.panelCompareTop);
            this.panelCompareAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCompareAll.Location = new System.Drawing.Point(0, 0);
            this.panelCompareAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelCompareAll.Name = "panelCompareAll";
            this.panelCompareAll.Size = new System.Drawing.Size(1636, 389);
            this.panelCompareAll.TabIndex = 0;
            // 
            // panelCompareBottom
            // 
            this.panelCompareBottom.Controls.Add(this.dgv10);
            this.panelCompareBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCompareBottom.Location = new System.Drawing.Point(0, 42);
            this.panelCompareBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelCompareBottom.Name = "panelCompareBottom";
            this.panelCompareBottom.Size = new System.Drawing.Size(1636, 347);
            this.panelCompareBottom.TabIndex = 2;
            // 
            // dgv10
            // 
            this.dgv10.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv10.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv10.Location = new System.Drawing.Point(0, 0);
            this.dgv10.LookAndFeel.SkinName = "iMaginary";
            this.dgv10.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv10.MainView = this.gridMain10;
            this.dgv10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv10.Name = "dgv10";
            this.dgv10.Size = new System.Drawing.Size(1636, 347);
            this.dgv10.TabIndex = 7;
            this.dgv10.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain10});
            // 
            // gridMain10
            // 
            this.gridMain10.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain10.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain10.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain10.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain10.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain10.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain10.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain10.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain10.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain10.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain10.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain10.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain10.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain10.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain10.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain10.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain10.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain10.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain10.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain10.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain10.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain10.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain10.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain10.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain10.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain10.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain10.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain10.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain10.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain10.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain10.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain10.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain10.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain10.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain10.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain10.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain10.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain10.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain10.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain10.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain10.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain10.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain10.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain10.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain10.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain10.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain10.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain10.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain10.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain10.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain10.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain10.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain10.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain10.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain10.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain10.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain10.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain10.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain10.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain10.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain10.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain10.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain10.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain10.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain10.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain10.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain10.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain10.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain10.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain10.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain10.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain10.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain10.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain10.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain10.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain10.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain10.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain10.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain10.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain10.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain10.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain10.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain10.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain10.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain10.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain10.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain10.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain10.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain10.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain10.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.Row.Options.UseBackColor = true;
            this.gridMain10.Appearance.Row.Options.UseForeColor = true;
            this.gridMain10.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain10.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain10.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain10.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain10.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain10.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain10.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain10.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain10.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain10.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand4});
            this.gridMain10.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain10.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn125,
            this.bandedGridColumn134,
            this.bandedGridColumn151,
            this.as400153,
            this.difference154});
            this.gridMain10.DetailHeight = 431;
            this.gridMain10.GridControl = this.dgv10;
            this.gridMain10.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "paymentCurrMonth", this.bandedGridColumn151, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "cashRemitted", this.as400153, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "difference", this.difference154, "${0:0,0.00}")});
            this.gridMain10.Name = "gridMain10";
            this.gridMain10.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridMain10.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain10.OptionsPrint.PrintBandHeader = false;
            this.gridMain10.OptionsSelection.MultiSelect = true;
            this.gridMain10.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain10.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain10.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain10.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.gridMain10.OptionsView.ShowBands = false;
            this.gridMain10.OptionsView.ShowFooter = true;
            this.gridMain10.OptionsView.ShowGroupPanel = false;
            this.gridMain10.PaintStyleName = "Style3D";
            this.gridMain10.DoubleClick += new System.EventHandler(this.gridMain6_DoubleClick);
            // 
            // gridBand4
            // 
            this.gridBand4.Caption = "gridBandXXX";
            this.gridBand4.Columns.Add(this.bandedGridColumn125);
            this.gridBand4.Columns.Add(this.bandedGridColumn134);
            this.gridBand4.Columns.Add(this.bandedGridColumn151);
            this.gridBand4.Columns.Add(this.as400153);
            this.gridBand4.Columns.Add(this.difference154);
            this.gridBand4.MinWidth = 12;
            this.gridBand4.Name = "gridBand4";
            this.gridBand4.VisibleIndex = 0;
            this.gridBand4.Width = 403;
            // 
            // bandedGridColumn125
            // 
            this.bandedGridColumn125.Caption = "Num";
            this.bandedGridColumn125.FieldName = "num";
            this.bandedGridColumn125.MinWidth = 23;
            this.bandedGridColumn125.Name = "bandedGridColumn125";
            this.bandedGridColumn125.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn125.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn125.Visible = true;
            this.bandedGridColumn125.Width = 58;
            // 
            // bandedGridColumn134
            // 
            this.bandedGridColumn134.Caption = "Contract";
            this.bandedGridColumn134.FieldName = "contractNumber";
            this.bandedGridColumn134.MinWidth = 23;
            this.bandedGridColumn134.Name = "bandedGridColumn134";
            this.bandedGridColumn134.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn134.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn134.Visible = true;
            // 
            // bandedGridColumn151
            // 
            this.bandedGridColumn151.Caption = "Current Month";
            this.bandedGridColumn151.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn151.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn151.FieldName = "paymentCurrMonth";
            this.bandedGridColumn151.MinWidth = 23;
            this.bandedGridColumn151.Name = "bandedGridColumn151";
            this.bandedGridColumn151.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn151.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn151.Visible = true;
            this.bandedGridColumn151.Width = 96;
            // 
            // as400153
            // 
            this.as400153.Caption = "Cash Remitted";
            this.as400153.DisplayFormat.FormatString = "N2";
            this.as400153.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.as400153.FieldName = "cashRemitted";
            this.as400153.MinWidth = 23;
            this.as400153.Name = "as400153";
            this.as400153.OptionsColumn.FixedWidth = true;
            this.as400153.Visible = true;
            this.as400153.Width = 87;
            // 
            // difference154
            // 
            this.difference154.Caption = "Difference";
            this.difference154.DisplayFormat.FormatString = "N2";
            this.difference154.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.difference154.FieldName = "difference";
            this.difference154.MinWidth = 23;
            this.difference154.Name = "difference154";
            this.difference154.OptionsColumn.FixedWidth = true;
            this.difference154.Visible = true;
            this.difference154.Width = 87;
            // 
            // panelCompareTop
            // 
            this.panelCompareTop.Controls.Add(this.progressBar2);
            this.panelCompareTop.Controls.Add(this.btnPaul);
            this.panelCompareTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelCompareTop.Location = new System.Drawing.Point(0, 0);
            this.panelCompareTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelCompareTop.Name = "panelCompareTop";
            this.panelCompareTop.Size = new System.Drawing.Size(1636, 42);
            this.panelCompareTop.TabIndex = 1;
            // 
            // progressBar2
            // 
            this.progressBar2.BackColor = System.Drawing.Color.Lime;
            this.progressBar2.Location = new System.Drawing.Point(192, 15);
            this.progressBar2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(425, 15);
            this.progressBar2.TabIndex = 22;
            // 
            // btnPaul
            // 
            this.btnPaul.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPaul.Location = new System.Drawing.Point(9, 9);
            this.btnPaul.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPaul.Name = "btnPaul";
            this.btnPaul.Size = new System.Drawing.Size(145, 26);
            this.btnPaul.TabIndex = 21;
            this.btnPaul.Text = "Get Cash Remitted";
            this.btnPaul.UseVisualStyleBackColor = true;
            this.btnPaul.Click += new System.EventHandler(this.btnPaul_Click);
            // 
            // tabCompareBalance
            // 
            this.tabCompareBalance.Controls.Add(this.dgv11);
            this.tabCompareBalance.Location = new System.Drawing.Point(4, 25);
            this.tabCompareBalance.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabCompareBalance.Name = "tabCompareBalance";
            this.tabCompareBalance.Size = new System.Drawing.Size(1636, 389);
            this.tabCompareBalance.TabIndex = 6;
            this.tabCompareBalance.Text = "Compare Balance to Last Month";
            this.tabCompareBalance.UseVisualStyleBackColor = true;
            // 
            // dgv11
            // 
            this.dgv11.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv11.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv11.Location = new System.Drawing.Point(0, 0);
            this.dgv11.LookAndFeel.SkinName = "iMaginary";
            this.dgv11.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv11.MainView = this.gridMain11;
            this.dgv11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv11.Name = "dgv11";
            this.dgv11.Size = new System.Drawing.Size(1636, 389);
            this.dgv11.TabIndex = 8;
            this.dgv11.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain11});
            // 
            // gridMain11
            // 
            this.gridMain11.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain11.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain11.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain11.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain11.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain11.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain11.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain11.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain11.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain11.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain11.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain11.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain11.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain11.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain11.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain11.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain11.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain11.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain11.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain11.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain11.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain11.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain11.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain11.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain11.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain11.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain11.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain11.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain11.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain11.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain11.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain11.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain11.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain11.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain11.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain11.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain11.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain11.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain11.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain11.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain11.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain11.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain11.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain11.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain11.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain11.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain11.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain11.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain11.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain11.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain11.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain11.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain11.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain11.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain11.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain11.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain11.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain11.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain11.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain11.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain11.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain11.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain11.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain11.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain11.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain11.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain11.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain11.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain11.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain11.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain11.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain11.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain11.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain11.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain11.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain11.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain11.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain11.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain11.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain11.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain11.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain11.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain11.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain11.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain11.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain11.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain11.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain11.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain11.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain11.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain11.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain11.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain11.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain11.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain11.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain11.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain11.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain11.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain11.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain11.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.Row.Options.UseBackColor = true;
            this.gridMain11.Appearance.Row.Options.UseForeColor = true;
            this.gridMain11.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain11.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain11.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain11.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain11.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain11.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain11.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain11.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain11.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain11.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain11.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand8});
            this.gridMain11.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain11.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn2,
            this.bandedGridColumn4,
            this.bandedGridColumn6,
            this.bandedGridColumn8});
            this.gridMain11.DetailHeight = 431;
            this.gridMain11.GridControl = this.dgv11;
            this.gridMain11.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "paymentCurrMonth", this.bandedGridColumn6, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "cashRemitted", this.bandedGridColumn8, "${0:0,0.00}")});
            this.gridMain11.Name = "gridMain11";
            this.gridMain11.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridMain11.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain11.OptionsPrint.PrintBandHeader = false;
            this.gridMain11.OptionsSelection.MultiSelect = true;
            this.gridMain11.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain11.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain11.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain11.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.gridMain11.OptionsView.ShowBands = false;
            this.gridMain11.OptionsView.ShowFooter = true;
            this.gridMain11.OptionsView.ShowGroupPanel = false;
            this.gridMain11.PaintStyleName = "Style3D";
            // 
            // gridBand8
            // 
            this.gridBand8.Caption = "gridBandXXX";
            this.gridBand8.Columns.Add(this.bandedGridColumn2);
            this.gridBand8.Columns.Add(this.bandedGridColumn4);
            this.gridBand8.Columns.Add(this.bandedGridColumn6);
            this.gridBand8.Columns.Add(this.bandedGridColumn8);
            this.gridBand8.MinWidth = 12;
            this.gridBand8.Name = "gridBand8";
            this.gridBand8.VisibleIndex = 0;
            this.gridBand8.Width = 316;
            // 
            // bandedGridColumn2
            // 
            this.bandedGridColumn2.Caption = "Num";
            this.bandedGridColumn2.FieldName = "num";
            this.bandedGridColumn2.MinWidth = 23;
            this.bandedGridColumn2.Name = "bandedGridColumn2";
            this.bandedGridColumn2.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn2.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn2.Visible = true;
            this.bandedGridColumn2.Width = 58;
            // 
            // bandedGridColumn4
            // 
            this.bandedGridColumn4.Caption = "Contract";
            this.bandedGridColumn4.FieldName = "contractNumber";
            this.bandedGridColumn4.MinWidth = 23;
            this.bandedGridColumn4.Name = "bandedGridColumn4";
            this.bandedGridColumn4.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn4.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn4.Visible = true;
            // 
            // bandedGridColumn6
            // 
            this.bandedGridColumn6.Caption = "Ending Balance";
            this.bandedGridColumn6.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn6.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn6.FieldName = "endingBalance";
            this.bandedGridColumn6.MinWidth = 23;
            this.bandedGridColumn6.Name = "bandedGridColumn6";
            this.bandedGridColumn6.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn6.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn6.Visible = true;
            this.bandedGridColumn6.Width = 96;
            // 
            // bandedGridColumn8
            // 
            this.bandedGridColumn8.Caption = "Beginning Balance";
            this.bandedGridColumn8.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn8.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn8.FieldName = "beginningBalance";
            this.bandedGridColumn8.MinWidth = 23;
            this.bandedGridColumn8.Name = "bandedGridColumn8";
            this.bandedGridColumn8.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn8.Visible = true;
            this.bandedGridColumn8.Width = 87;
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.Bisque;
            this.panelTop.Controls.Add(this.chkAlphaMode);
            this.panelTop.Controls.Add(this.lblWait);
            this.panelTop.Controls.Add(this.btnVerify);
            this.panelTop.Controls.Add(this.chkLiveOnly);
            this.panelTop.Controls.Add(this.chkRunSMFS);
            this.panelTop.Controls.Add(this.chkShowCurrentMonth);
            this.panelTop.Controls.Add(this.chkShowLocations);
            this.panelTop.Controls.Add(this.chkDBR);
            this.panelTop.Controls.Add(this.chkExpand);
            this.panelTop.Controls.Add(this.chk2002);
            this.panelTop.Controls.Add(this.chkComboLocNames);
            this.panelTop.Controls.Add(this.lblContract);
            this.panelTop.Controls.Add(this.label5);
            this.panelTop.Controls.Add(this.txtContract);
            this.panelTop.Controls.Add(this.chkComboLocation);
            this.panelTop.Controls.Add(this.chkFilterNewContracts);
            this.panelTop.Controls.Add(this.lblTotal);
            this.panelTop.Controls.Add(this.barImport);
            this.panelTop.Controls.Add(this.btnRun);
            this.panelTop.Controls.Add(this.pictureBox1);
            this.panelTop.Controls.Add(this.btnRight);
            this.panelTop.Controls.Add(this.btnLeft);
            this.panelTop.Controls.Add(this.dateTimePicker2);
            this.panelTop.Controls.Add(this.label1);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1644, 73);
            this.panelTop.TabIndex = 1;
            // 
            // chkAlphaMode
            // 
            this.chkAlphaMode.AutoSize = true;
            this.chkAlphaMode.Location = new System.Drawing.Point(1252, 9);
            this.chkAlphaMode.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkAlphaMode.Name = "chkAlphaMode";
            this.chkAlphaMode.Size = new System.Drawing.Size(124, 21);
            this.chkAlphaMode.TabIndex = 45;
            this.chkAlphaMode.Text = "Set Alpha Mode";
            this.chkAlphaMode.UseVisualStyleBackColor = true;
            this.chkAlphaMode.CheckedChanged += new System.EventHandler(this.chkAlphaMode_CheckedChanged);
            // 
            // lblWait
            // 
            this.lblWait.AutoSize = true;
            this.lblWait.BackColor = System.Drawing.Color.Bisque;
            this.lblWait.Location = new System.Drawing.Point(1345, 50);
            this.lblWait.Name = "lblWait";
            this.lblWait.Size = new System.Drawing.Size(48, 17);
            this.lblWait.TabIndex = 44;
            this.lblWait.Text = "lblWait";
            // 
            // btnVerify
            // 
            this.btnVerify.Location = new System.Drawing.Point(1533, 39);
            this.btnVerify.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnVerify.Name = "btnVerify";
            this.btnVerify.Size = new System.Drawing.Size(87, 28);
            this.btnVerify.TabIndex = 43;
            this.btnVerify.Text = "Verify C";
            this.btnVerify.UseVisualStyleBackColor = true;
            this.btnVerify.Click += new System.EventHandler(this.btnVerify_Click);
            // 
            // chkLiveOnly
            // 
            this.chkLiveOnly.AutoSize = true;
            this.chkLiveOnly.Location = new System.Drawing.Point(1252, 50);
            this.chkLiveOnly.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkLiveOnly.Name = "chkLiveOnly";
            this.chkLiveOnly.Size = new System.Drawing.Size(92, 21);
            this.chkLiveOnly.TabIndex = 42;
            this.chkLiveOnly.Text = "Live ONLY";
            this.chkLiveOnly.UseVisualStyleBackColor = true;
            // 
            // chkRunSMFS
            // 
            this.chkRunSMFS.AutoSize = true;
            this.chkRunSMFS.Location = new System.Drawing.Point(1092, 49);
            this.chkRunSMFS.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkRunSMFS.Name = "chkRunSMFS";
            this.chkRunSMFS.Size = new System.Drawing.Size(138, 21);
            this.chkRunSMFS.TabIndex = 41;
            this.chkRunSMFS.Text = "Run Strictly SMFS";
            this.chkRunSMFS.UseVisualStyleBackColor = true;
            // 
            // chkShowCurrentMonth
            // 
            this.chkShowCurrentMonth.AutoSize = true;
            this.chkShowCurrentMonth.Location = new System.Drawing.Point(1092, 28);
            this.chkShowCurrentMonth.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkShowCurrentMonth.Name = "chkShowCurrentMonth";
            this.chkShowCurrentMonth.Size = new System.Drawing.Size(207, 21);
            this.chkShowCurrentMonth.TabIndex = 40;
            this.chkShowCurrentMonth.Text = "Show Current Month Activity";
            this.chkShowCurrentMonth.UseVisualStyleBackColor = true;
            this.chkShowCurrentMonth.CheckedChanged += new System.EventHandler(this.chkShowCurrentMonth_CheckedChanged);
            // 
            // chkShowLocations
            // 
            this.chkShowLocations.AutoSize = true;
            this.chkShowLocations.Checked = true;
            this.chkShowLocations.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShowLocations.Location = new System.Drawing.Point(574, 6);
            this.chkShowLocations.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkShowLocations.Name = "chkShowLocations";
            this.chkShowLocations.Size = new System.Drawing.Size(126, 21);
            this.chkShowLocations.TabIndex = 39;
            this.chkShowLocations.Text = "Show Locations";
            this.chkShowLocations.UseVisualStyleBackColor = true;
            this.chkShowLocations.CheckedChanged += new System.EventHandler(this.chkShowLocations_CheckedChanged);
            // 
            // chkDBR
            // 
            this.chkDBR.AutoSize = true;
            this.chkDBR.Location = new System.Drawing.Point(1092, 9);
            this.chkDBR.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkDBR.Name = "chkDBR";
            this.chkDBR.Size = new System.Drawing.Size(127, 21);
            this.chkDBR.TabIndex = 38;
            this.chkDBR.Text = "Show DBR Only";
            this.chkDBR.UseVisualStyleBackColor = true;
            this.chkDBR.CheckedChanged += new System.EventHandler(this.chkDBR_CheckedChanged);
            // 
            // chkExpand
            // 
            this.chkExpand.AutoSize = true;
            this.chkExpand.Checked = true;
            this.chkExpand.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkExpand.Location = new System.Drawing.Point(721, 7);
            this.chkExpand.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkExpand.Name = "chkExpand";
            this.chkExpand.Size = new System.Drawing.Size(139, 21);
            this.chkExpand.TabIndex = 37;
            this.chkExpand.Text = "Expand Locations";
            this.chkExpand.UseVisualStyleBackColor = true;
            this.chkExpand.CheckedChanged += new System.EventHandler(this.chkExpand_CheckedChanged);
            // 
            // chk2002
            // 
            this.chk2002.AutoSize = true;
            this.chk2002.Checked = true;
            this.chk2002.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk2002.Location = new System.Drawing.Point(902, 44);
            this.chk2002.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chk2002.Name = "chk2002";
            this.chk2002.Size = new System.Drawing.Size(188, 21);
            this.chk2002.TabIndex = 36;
            this.chk2002.Text = "Run Contracts After 2002";
            this.chk2002.UseVisualStyleBackColor = true;
            // 
            // chkComboLocNames
            // 
            this.chkComboLocNames.EditValue = "";
            this.chkComboLocNames.Location = new System.Drawing.Point(675, 42);
            this.chkComboLocNames.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkComboLocNames.Name = "chkComboLocNames";
            this.chkComboLocNames.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.chkComboLocNames.Properties.DisplayMember = "name";
            this.chkComboLocNames.Properties.DropDownRows = 10;
            this.chkComboLocNames.Properties.SeparatorChar = '|';
            this.chkComboLocNames.Size = new System.Drawing.Size(219, 22);
            this.chkComboLocNames.TabIndex = 30;
            this.chkComboLocNames.EditValueChanged += new System.EventHandler(this.chkComboLocNames_EditValueChanged);
            // 
            // lblContract
            // 
            this.lblContract.AutoSize = true;
            this.lblContract.Location = new System.Drawing.Point(1376, 10);
            this.lblContract.Name = "lblContract";
            this.lblContract.Size = new System.Drawing.Size(97, 17);
            this.lblContract.TabIndex = 35;
            this.lblContract.Text = "Test Contract:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(539, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 17);
            this.label5.TabIndex = 29;
            this.label5.Text = "Locations :";
            // 
            // txtContract
            // 
            this.txtContract.Location = new System.Drawing.Point(1471, 5);
            this.txtContract.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtContract.Name = "txtContract";
            this.txtContract.Size = new System.Drawing.Size(116, 23);
            this.txtContract.TabIndex = 34;
            // 
            // chkComboLocation
            // 
            this.chkComboLocation.EditValue = "";
            this.chkComboLocation.Location = new System.Drawing.Point(615, 42);
            this.chkComboLocation.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkComboLocation.Name = "chkComboLocation";
            this.chkComboLocation.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.chkComboLocation.Properties.DisplayMember = "keycode";
            this.chkComboLocation.Properties.DropDownRows = 10;
            this.chkComboLocation.Properties.SeparatorChar = '|';
            this.chkComboLocation.Size = new System.Drawing.Size(54, 22);
            this.chkComboLocation.TabIndex = 28;
            this.chkComboLocation.EditValueChanged += new System.EventHandler(this.chkComboLocation_EditValueChanged);
            // 
            // chkFilterNewContracts
            // 
            this.chkFilterNewContracts.AutoSize = true;
            this.chkFilterNewContracts.Location = new System.Drawing.Point(861, 9);
            this.chkFilterNewContracts.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkFilterNewContracts.Name = "chkFilterNewContracts";
            this.chkFilterNewContracts.Size = new System.Drawing.Size(243, 21);
            this.chkFilterNewContracts.TabIndex = 33;
            this.chkFilterNewContracts.Text = "Show Only Contracts With Balance";
            this.chkFilterNewContracts.UseVisualStyleBackColor = true;
            this.chkFilterNewContracts.CheckedChanged += new System.EventHandler(this.chkFilterNewContracts_CheckedChanged);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(440, 50);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(50, 17);
            this.lblTotal.TabIndex = 31;
            this.lblTotal.Text = "lblTotal";
            // 
            // barImport
            // 
            this.barImport.BackColor = System.Drawing.Color.Lime;
            this.barImport.Location = new System.Drawing.Point(8, 50);
            this.barImport.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.barImport.Name = "barImport";
            this.barImport.Size = new System.Drawing.Size(425, 15);
            this.barImport.TabIndex = 30;
            // 
            // btnRun
            // 
            this.btnRun.BackColor = System.Drawing.Color.SandyBrown;
            this.btnRun.Font = new System.Drawing.Font("Tahoma", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btnRun.Location = new System.Drawing.Point(437, 4);
            this.btnRun.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(87, 42);
            this.btnRun.TabIndex = 29;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = false;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(8, 11);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 27);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 28;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btnRight
            // 
            this.btnRight.BackColor = System.Drawing.Color.PeachPuff;
            this.btnRight.Image = ((System.Drawing.Image)(resources.GetObject("btnRight.Image")));
            this.btnRight.Location = new System.Drawing.Point(400, 10);
            this.btnRight.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(33, 28);
            this.btnRight.TabIndex = 27;
            this.btnRight.UseVisualStyleBackColor = false;
            this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
            // 
            // btnLeft
            // 
            this.btnLeft.BackColor = System.Drawing.Color.PeachPuff;
            this.btnLeft.Image = ((System.Drawing.Image)(resources.GetObject("btnLeft.Image")));
            this.btnLeft.Location = new System.Drawing.Point(126, 10);
            this.btnLeft.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(33, 28);
            this.btnLeft.TabIndex = 26;
            this.btnLeft.UseVisualStyleBackColor = false;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(163, 11);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker2.TabIndex = 25;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(56, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 17);
            this.label1.TabIndex = 22;
            this.label1.Text = "Date Paid :";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Bisque;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.miscToolStripMenuItem,
            this.columnsToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.rilesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1644, 30);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 26);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printPreviewToolStripMenuItem,
            this.printToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(221, 26);
            this.toolStripMenuItem1.Text = "Print";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printPreviewToolStripMenuItem.Text = "Print Preview";
            this.printPreviewToolStripMenuItem.Click += new System.EventHandler(this.printPreviewToolStripMenuItem_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(221, 26);
            this.toolStripMenuItem2.Text = "Read Previous Data";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(221, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // miscToolStripMenuItem
            // 
            this.miscToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importOriginalDataToolStripMenuItem,
            this.lockScreenPositionToolStripMenuItem,
            this.unLockScreenPositionToolStripMenuItem,
            this.compareBeginningBalanceToLastMonthEndingToolStripMenuItem,
            this.editMassReportsToolStripMenuItem,
            this.runTrustSummaryReportToolStripMenuItem});
            this.miscToolStripMenuItem.Name = "miscToolStripMenuItem";
            this.miscToolStripMenuItem.Size = new System.Drawing.Size(53, 26);
            this.miscToolStripMenuItem.Text = "Misc";
            // 
            // importOriginalDataToolStripMenuItem
            // 
            this.importOriginalDataToolStripMenuItem.Name = "importOriginalDataToolStripMenuItem";
            this.importOriginalDataToolStripMenuItem.Size = new System.Drawing.Size(425, 26);
            this.importOriginalDataToolStripMenuItem.Text = "Import Original Data";
            this.importOriginalDataToolStripMenuItem.Click += new System.EventHandler(this.importOriginalDataToolStripMenuItem_Click);
            // 
            // lockScreenPositionToolStripMenuItem
            // 
            this.lockScreenPositionToolStripMenuItem.Name = "lockScreenPositionToolStripMenuItem";
            this.lockScreenPositionToolStripMenuItem.Size = new System.Drawing.Size(425, 26);
            this.lockScreenPositionToolStripMenuItem.Text = "Lock Screen Position";
            this.lockScreenPositionToolStripMenuItem.Click += new System.EventHandler(this.lockScreenPositionToolStripMenuItem_Click);
            // 
            // unLockScreenPositionToolStripMenuItem
            // 
            this.unLockScreenPositionToolStripMenuItem.Name = "unLockScreenPositionToolStripMenuItem";
            this.unLockScreenPositionToolStripMenuItem.Size = new System.Drawing.Size(425, 26);
            this.unLockScreenPositionToolStripMenuItem.Text = "UnLock Screen Position";
            this.unLockScreenPositionToolStripMenuItem.Click += new System.EventHandler(this.unLockScreenPositionToolStripMenuItem_Click);
            // 
            // compareBeginningBalanceToLastMonthEndingToolStripMenuItem
            // 
            this.compareBeginningBalanceToLastMonthEndingToolStripMenuItem.Name = "compareBeginningBalanceToLastMonthEndingToolStripMenuItem";
            this.compareBeginningBalanceToLastMonthEndingToolStripMenuItem.Size = new System.Drawing.Size(425, 26);
            this.compareBeginningBalanceToLastMonthEndingToolStripMenuItem.Text = "Compare Beginning Balance to Last Month Ending";
            this.compareBeginningBalanceToLastMonthEndingToolStripMenuItem.Click += new System.EventHandler(this.compareBeginningBalanceToLastMonthEndingToolStripMenuItem_Click);
            // 
            // editMassReportsToolStripMenuItem
            // 
            this.editMassReportsToolStripMenuItem.Name = "editMassReportsToolStripMenuItem";
            this.editMassReportsToolStripMenuItem.Size = new System.Drawing.Size(425, 26);
            this.editMassReportsToolStripMenuItem.Text = "Edit Mass Reports";
            this.editMassReportsToolStripMenuItem.Click += new System.EventHandler(this.editMassReportsToolStripMenuItem_Click);
            // 
            // runTrustSummaryReportToolStripMenuItem
            // 
            this.runTrustSummaryReportToolStripMenuItem.Name = "runTrustSummaryReportToolStripMenuItem";
            this.runTrustSummaryReportToolStripMenuItem.Size = new System.Drawing.Size(425, 26);
            this.runTrustSummaryReportToolStripMenuItem.Text = "Run Trust Summary Report";
            this.runTrustSummaryReportToolStripMenuItem.Click += new System.EventHandler(this.runTrustSummaryReportToolStripMenuItem_Click);
            // 
            // columnsToolStripMenuItem
            // 
            this.columnsToolStripMenuItem.Name = "columnsToolStripMenuItem";
            this.columnsToolStripMenuItem.Size = new System.Drawing.Size(80, 26);
            this.columnsToolStripMenuItem.Text = "Columns";
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.paymentsPlacedInTrustToolStripMenuItem,
            this.paymentsRemovedFromTrustToolStripMenuItem,
            this.trustBeginningBalanceToolStripMenuItem});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(74, 26);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // paymentsPlacedInTrustToolStripMenuItem
            // 
            this.paymentsPlacedInTrustToolStripMenuItem.Name = "paymentsPlacedInTrustToolStripMenuItem";
            this.paymentsPlacedInTrustToolStripMenuItem.Size = new System.Drawing.Size(294, 26);
            this.paymentsPlacedInTrustToolStripMenuItem.Text = "Payments Placed In Trust";
            this.paymentsPlacedInTrustToolStripMenuItem.Click += new System.EventHandler(this.paymentsPlacedInTrustToolStripMenuItem_Click);
            // 
            // paymentsRemovedFromTrustToolStripMenuItem
            // 
            this.paymentsRemovedFromTrustToolStripMenuItem.Name = "paymentsRemovedFromTrustToolStripMenuItem";
            this.paymentsRemovedFromTrustToolStripMenuItem.Size = new System.Drawing.Size(294, 26);
            this.paymentsRemovedFromTrustToolStripMenuItem.Text = "Payments Removed From Trust";
            this.paymentsRemovedFromTrustToolStripMenuItem.Click += new System.EventHandler(this.paymentsRemovedFromTrustToolStripMenuItem_Click);
            // 
            // trustBeginningBalanceToolStripMenuItem
            // 
            this.trustBeginningBalanceToolStripMenuItem.Name = "trustBeginningBalanceToolStripMenuItem";
            this.trustBeginningBalanceToolStripMenuItem.Size = new System.Drawing.Size(294, 26);
            this.trustBeginningBalanceToolStripMenuItem.Text = "Trust Beginning Balance";
            this.trustBeginningBalanceToolStripMenuItem.Click += new System.EventHandler(this.trustBeginningBalanceToolStripMenuItem_Click);
            // 
            // rilesToolStripMenuItem
            // 
            this.rilesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importNewRilesFromCliffToolStripMenuItem});
            this.rilesToolStripMenuItem.Name = "rilesToolStripMenuItem";
            this.rilesToolStripMenuItem.Size = new System.Drawing.Size(54, 26);
            this.rilesToolStripMenuItem.Text = "Riles";
            // 
            // importNewRilesFromCliffToolStripMenuItem
            // 
            this.importNewRilesFromCliffToolStripMenuItem.Name = "importNewRilesFromCliffToolStripMenuItem";
            this.importNewRilesFromCliffToolStripMenuItem.Size = new System.Drawing.Size(275, 26);
            this.importNewRilesFromCliffToolStripMenuItem.Text = "Import New Riles From Cliff";
            this.importNewRilesFromCliffToolStripMenuItem.Click += new System.EventHandler(this.importNewRilesFromCliffToolStripMenuItem_Click);
            // 
            // myStatus
            // 
            this.myStatus.AutoSize = true;
            this.myStatus.BackColor = System.Drawing.Color.Bisque;
            this.myStatus.Location = new System.Drawing.Point(701, 6);
            this.myStatus.Name = "myStatus";
            this.myStatus.Size = new System.Drawing.Size(67, 17);
            this.myStatus.TabIndex = 43;
            this.myStatus.Text = "myStatus";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // TrustReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1644, 521);
            this.Controls.Add(this.myStatus);
            this.Controls.Add(this.panelAll);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "TrustReports";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TrustReports";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TrustReports_FormClosing);
            this.Load += new System.EventHandler(this.TrustReports_Load);
            this.panelAll.ResumeLayout(false);
            this.panelBottom.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabAllData.ResumeLayout(false);
            this.panel1All.ResumeLayout(false);
            this.panel1Bottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv6)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridMain6)).EndInit();
            this.panel1Top.ResumeLayout(false);
            this.panel1Top.PerformLayout();
            this.tabPlacedInTrust.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).EndInit();
            this.tabBeginning.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain7)).EndInit();
            this.tabRemoved.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain8)).EndInit();
            this.tabDiff.ResumeLayout(false);
            this.panelDiffAll.ResumeLayout(false);
            this.panelDiffBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain9)).EndInit();
            this.panelDiffTop.ResumeLayout(false);
            this.panelDiffTop.PerformLayout();
            this.tabCompare.ResumeLayout(false);
            this.panelCompareAll.ResumeLayout(false);
            this.panelCompareBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain10)).EndInit();
            this.panelCompareTop.ResumeLayout(false);
            this.tabCompareBalance.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain11)).EndInit();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboLocNames.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboLocation.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelAll;
        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem columnsToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabAllData;
        private System.Windows.Forms.TabPage tabBeginning;
        private DevExpress.XtraGrid.GridControl dgv6;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn62;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn63;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn59;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn lastName79;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn78;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn contractNumber68;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn80;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn prioryear;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn60;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn61;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn64;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn65;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn66;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn67;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn69;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn70;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn71;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn72;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn73;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn currentmonth;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn ytdnow;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn ytdtotal;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn totalpaid;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn76;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn77;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn81;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn84;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn83;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn82;
        private System.Windows.Forms.Button btnRight;
        private System.Windows.Forms.Button btnLeft;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnRun;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn1;
        private System.Windows.Forms.ProgressBar barImport;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.CheckBox chkFilterNewContracts;
        private System.Windows.Forms.Label lblContract;
        private System.Windows.Forms.TextBox txtContract;
        private DevExpress.XtraGrid.GridControl dgv7;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain7;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn loc2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn num4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn lastName5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn firstName6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn7;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn address8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn city9;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn state10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn zip11;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn contract12;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn ssn13;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn14;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn beginningBalance15;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn16;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn17;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn18;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn19;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn20;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn21;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn22;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn23;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn24;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn25;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn26;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn currentPayments27;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn28;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn currentremoval;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn endingBalance29;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn30;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn31;
        private System.Windows.Forms.TabPage tabRemoved;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn32;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn33;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn34;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn35;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn36;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn37;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn38;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn39;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn40;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn41;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn42;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn43;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn87;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn44;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn45;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn46;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn47;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn48;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn49;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn50;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn51;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn52;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn53;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn54;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn55;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn56;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn57;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn58;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn74;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn75;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn85;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn86;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn currentRemovals;
        private DevExpress.XtraEditors.CheckedComboBoxEdit chkComboLocNames;
        private System.Windows.Forms.Label label5;
        private DevExpress.XtraEditors.CheckedComboBoxEdit chkComboLocation;
        private System.Windows.Forms.CheckBox chk2002;
        private System.Windows.Forms.CheckBox chkExpand;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn88;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn89;
        private System.Windows.Forms.CheckBox chkDBR;
        private System.Windows.Forms.CheckBox chkShowLocations;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn original90;
        private System.Windows.Forms.CheckBox chkShowCurrentMonth;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn90;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn91;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn as40092;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn93;
        private System.Windows.Forms.TabPage tabDiff;
        private System.Windows.Forms.Panel panelDiffAll;
        private System.Windows.Forms.Panel panelDiffBottom;
        private DevExpress.XtraGrid.GridControl dgv9;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain9;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn94;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn95;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn96;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn97;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn98;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn99;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn104;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn105;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn106;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn107;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn108;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn109;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn110;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn111;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn112;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn113;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn114;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn115;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn116;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn117;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn118;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn119;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn120;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn121;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn122;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn100;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn101;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn123;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn124;
        private System.Windows.Forms.Panel panelDiffTop;
        private System.Windows.Forms.Button btnRunDiff;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn ragCurrentMonth102;
        private System.Windows.Forms.CheckBox chkRunSMFS;
        private System.Windows.Forms.CheckBox chkLiveOnly;
        private System.Windows.Forms.TabPage tabCompare;
        private System.Windows.Forms.Panel panelCompareBottom;
        private System.Windows.Forms.Panel panelCompareTop;
        private System.Windows.Forms.Panel panelCompareAll;
        private DevExpress.XtraGrid.GridControl dgv10;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain10;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn125;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn134;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn151;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn as400153;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn difference154;
        private System.Windows.Forms.Button btnPaul;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn161;
        private System.Windows.Forms.TabPage tabPlacedInTrust;
        private DevExpress.XtraGrid.GridControl dgv2;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn loc92;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn102;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn num103;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn lastName126;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn firstName127;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn128;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn address129;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn city130;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn state131;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn zip132;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn133;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn contract135;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn136;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn137;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn ssn138;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn beginningBalance139;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn140;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn141;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn142;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn143;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn144;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn145;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn146;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn147;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn148;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn149;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn150;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn153;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn154;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn155;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn156;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn157;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn158;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn159;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn160;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn162;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn location163;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn164;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn165;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn166;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn167;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn168;
        private DevExpress.XtraGrid.GridControl dgv8;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn loc169;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn lastName170;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn firstName171;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn172;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn num173;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn174;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn address175;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn city176;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn state177;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn zip178;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn contract179;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn ssn180;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn181;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn beginningBalance182;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn183;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn184;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn185;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn186;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn187;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn188;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn189;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn190;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn191;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn192;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn193;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn194;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn195;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn currentRefunds196;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn endingBalance197;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn198;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn199;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn fnl200;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn interest201;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn currentDeathClaims202;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn currentInterest203;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn interest204;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn deathRemYTDprevious205;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn deathRemCurrMonth206;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn refundRemYTDprevious207;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn refundRemCurrMonth208;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn location209;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn location210;
        private System.Windows.Forms.Panel panel1All;
        private System.Windows.Forms.Panel panel1Bottom;
        private System.Windows.Forms.Panel panel1Top;
        private System.Windows.Forms.Button btnSaveData;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem miscToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importOriginalDataToolStripMenuItem;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label myStatus;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn interest68;
        private System.Windows.Forms.ToolStripMenuItem editContractToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewContractToolStripMenuItem;
        private System.Windows.Forms.Button btnVerify;
        private System.Windows.Forms.ToolStripMenuItem lockScreenPositionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unLockScreenPositionToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn68;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn5;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand6;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand1;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand15;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand16;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand7;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand17;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand18;
        private System.Windows.Forms.Label lblWait;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand5;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand13;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand14;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.ToolStripMenuItem compareBeginningBalanceToLastMonthEndingToolStripMenuItem;
        private System.Windows.Forms.TabPage tabCompareBalance;
        private DevExpress.XtraGrid.GridControl dgv11;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain11;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn8;
        private System.Windows.Forms.CheckBox chkAlphaMode;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentsPlacedInTrustToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem paymentsRemovedFromTrustToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trustBeginningBalanceToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn9;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn11;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn12;
        private System.Windows.Forms.ToolStripMenuItem editMassReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem runTrustSummaryReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rilesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importNewRilesFromCliffToolStripMenuItem;
    }
}