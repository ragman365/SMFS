﻿namespace SMFS
{
    partial class ImportTrustFile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ImportTrustFile));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelAll = new System.Windows.Forms.Panel();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgv = new DevExpress.XtraGrid.GridControl();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.locateContractNumberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gridMain = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand5 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn1 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn6 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn18 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn8 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn24 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn12 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn16 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn3 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn2 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn4 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn14 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn15 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn5 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn13 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn17 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn10 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn101 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn22 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn23 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn21 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn20 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn7 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn9 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn11 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn97 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn102 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn19 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgv2 = new DevExpress.XtraGrid.GridControl();
            this.gridMain2 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand1 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn25 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn26 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn27 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn28 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn29 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn30 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn31 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn32 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn33 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn34 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn35 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn36 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn37 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn38 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn39 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn40 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn41 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn42 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn43 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn44 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn45 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn46 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn47 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn48 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn49 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn50 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn51 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dgv3 = new DevExpress.XtraGrid.GridControl();
            this.gridMain3 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand2 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn52 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn53 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn54 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn55 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn56 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn57 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn58 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn59 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn60 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn61 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn62 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn63 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn64 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn65 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn66 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn67 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn68 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn69 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn70 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn71 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn72 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn73 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn74 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn75 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn76 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn77 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn78 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dgv4 = new DevExpress.XtraGrid.GridControl();
            this.gridMain4 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand3 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn79 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn80 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn81 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn82 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn83 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn84 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn85 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn86 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn87 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn88 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn89 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn90 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn91 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn92 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn93 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn94 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn95 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn96 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn98 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn99 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn100 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn103 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn104 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn105 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn106 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn107 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn108 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelTop = new System.Windows.Forms.Panel();
            this.btnImport = new System.Windows.Forms.Button();
            this.lblYear = new System.Windows.Forms.Label();
            this.cmbYear = new System.Windows.Forms.ComboBox();
            this.lblMonth = new System.Windows.Forms.Label();
            this.cmbMonth = new System.Windows.Forms.ComboBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            this.panelAll.SuspendLayout();
            this.panelBottom.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain4)).BeginInit();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1659, 30);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 26);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printPreviewToolStripMenuItem,
            this.printToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(122, 26);
            this.toolStripMenuItem1.Text = "Print";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printPreviewToolStripMenuItem.Text = "Print Preview";
            this.printPreviewToolStripMenuItem.Click += new System.EventHandler(this.printPreviewToolStripMenuItem_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // panelAll
            // 
            this.panelAll.Controls.Add(this.panelBottom);
            this.panelAll.Controls.Add(this.panelTop);
            this.panelAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAll.Location = new System.Drawing.Point(0, 30);
            this.panelAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelAll.Name = "panelAll";
            this.panelAll.Size = new System.Drawing.Size(1659, 354);
            this.panelAll.TabIndex = 6;
            // 
            // panelBottom
            // 
            this.panelBottom.Controls.Add(this.tabControl1);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBottom.Location = new System.Drawing.Point(0, 47);
            this.panelBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(1659, 307);
            this.panelBottom.TabIndex = 8;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1659, 307);
            this.tabControl1.TabIndex = 5;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgv);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(1651, 278);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Pulled Data";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgv
            // 
            this.dgv.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv.Location = new System.Drawing.Point(3, 4);
            this.dgv.MainView = this.gridMain;
            this.dgv.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv.Name = "dgv";
            this.dgv.Size = new System.Drawing.Size(1645, 270);
            this.dgv.TabIndex = 4;
            this.dgv.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain});
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.locateContractNumberToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(241, 28);
            // 
            // locateContractNumberToolStripMenuItem
            // 
            this.locateContractNumberToolStripMenuItem.Name = "locateContractNumberToolStripMenuItem";
            this.locateContractNumberToolStripMenuItem.Size = new System.Drawing.Size(240, 24);
            this.locateContractNumberToolStripMenuItem.Text = "Locate Contract Number";
            this.locateContractNumberToolStripMenuItem.Click += new System.EventHandler(this.locateContractNumberToolStripMenuItem_Click);
            // 
            // gridMain
            // 
            this.gridMain.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.BandPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(120)))), ((int)(((byte)(88)))));
            this.gridMain.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(136)))), ((int)(((byte)(91)))));
            this.gridMain.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.FooterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(172)))), ((int)(((byte)(134)))));
            this.gridMain.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(234)))), ((int)(((byte)(216)))));
            this.gridMain.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(169)))), ((int)(((byte)(107)))));
            this.gridMain.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(224)))), ((int)(((byte)(190)))));
            this.gridMain.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(237)))));
            this.gridMain.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(120)))), ((int)(((byte)(88)))));
            this.gridMain.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain.Appearance.Preview.Options.UseFont = true;
            this.gridMain.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.Row.Options.UseBackColor = true;
            this.gridMain.Appearance.Row.Options.UseForeColor = true;
            this.gridMain.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(159)))), ((int)(((byte)(114)))));
            this.gridMain.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(169)))), ((int)(((byte)(107)))));
            this.gridMain.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand5});
            this.gridMain.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn1,
            this.bandedGridColumn6,
            this.bandedGridColumn19,
            this.bandedGridColumn18,
            this.bandedGridColumn12,
            this.bandedGridColumn8,
            this.bandedGridColumn24,
            this.bandedGridColumn3,
            this.bandedGridColumn2,
            this.bandedGridColumn4,
            this.bandedGridColumn5,
            this.bandedGridColumn13,
            this.bandedGridColumn10,
            this.bandedGridColumn21,
            this.bandedGridColumn20,
            this.bandedGridColumn7,
            this.bandedGridColumn9,
            this.bandedGridColumn11,
            this.bandedGridColumn14,
            this.bandedGridColumn15,
            this.bandedGridColumn16,
            this.bandedGridColumn17,
            this.bandedGridColumn101,
            this.bandedGridColumn22,
            this.bandedGridColumn23,
            this.bandedGridColumn97,
            this.bandedGridColumn102});
            this.gridMain.DetailHeight = 431;
            this.gridMain.GridControl = this.dgv;
            this.gridMain.Name = "gridMain";
            this.gridMain.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain.OptionsPrint.PrintBandHeader = false;
            this.gridMain.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain.OptionsView.ShowFooter = true;
            this.gridMain.OptionsView.ShowGroupPanel = false;
            this.gridMain.PaintStyleName = "Style3D";
            this.gridMain.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMain_CustomDrawCell);
            this.gridMain.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMain_CellValueChanged);
            this.gridMain.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain_CustomColumnDisplayText);
            this.gridMain.DoubleClick += new System.EventHandler(this.gridMain_DoubleClick);
            // 
            // gridBand5
            // 
            this.gridBand5.Columns.Add(this.bandedGridColumn1);
            this.gridBand5.Columns.Add(this.bandedGridColumn6);
            this.gridBand5.Columns.Add(this.bandedGridColumn18);
            this.gridBand5.Columns.Add(this.bandedGridColumn8);
            this.gridBand5.Columns.Add(this.bandedGridColumn24);
            this.gridBand5.Columns.Add(this.bandedGridColumn12);
            this.gridBand5.Columns.Add(this.bandedGridColumn16);
            this.gridBand5.Columns.Add(this.bandedGridColumn3);
            this.gridBand5.Columns.Add(this.bandedGridColumn2);
            this.gridBand5.Columns.Add(this.bandedGridColumn4);
            this.gridBand5.Columns.Add(this.bandedGridColumn14);
            this.gridBand5.Columns.Add(this.bandedGridColumn15);
            this.gridBand5.Columns.Add(this.bandedGridColumn5);
            this.gridBand5.Columns.Add(this.bandedGridColumn13);
            this.gridBand5.Columns.Add(this.bandedGridColumn17);
            this.gridBand5.Columns.Add(this.bandedGridColumn10);
            this.gridBand5.Columns.Add(this.bandedGridColumn101);
            this.gridBand5.Columns.Add(this.bandedGridColumn22);
            this.gridBand5.Columns.Add(this.bandedGridColumn23);
            this.gridBand5.Columns.Add(this.bandedGridColumn21);
            this.gridBand5.Columns.Add(this.bandedGridColumn20);
            this.gridBand5.Columns.Add(this.bandedGridColumn7);
            this.gridBand5.Columns.Add(this.bandedGridColumn9);
            this.gridBand5.Columns.Add(this.bandedGridColumn11);
            this.gridBand5.Columns.Add(this.bandedGridColumn97);
            this.gridBand5.Columns.Add(this.bandedGridColumn102);
            this.gridBand5.MinWidth = 22;
            this.gridBand5.Name = "gridBand5";
            this.gridBand5.VisibleIndex = 0;
            this.gridBand5.Width = 2688;
            // 
            // bandedGridColumn1
            // 
            this.bandedGridColumn1.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn1.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn1.Caption = "Num";
            this.bandedGridColumn1.FieldName = "num";
            this.bandedGridColumn1.MinWidth = 42;
            this.bandedGridColumn1.Name = "bandedGridColumn1";
            this.bandedGridColumn1.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn1.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn1.Visible = true;
            this.bandedGridColumn1.Width = 57;
            // 
            // bandedGridColumn6
            // 
            this.bandedGridColumn6.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn6.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn6.Caption = "Status";
            this.bandedGridColumn6.FieldName = "status";
            this.bandedGridColumn6.MinWidth = 42;
            this.bandedGridColumn6.Name = "bandedGridColumn6";
            this.bandedGridColumn6.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn6.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn6.Width = 161;
            // 
            // bandedGridColumn18
            // 
            this.bandedGridColumn18.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn18.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn18.Caption = "Trust Company";
            this.bandedGridColumn18.FieldName = "trustCompany";
            this.bandedGridColumn18.MinWidth = 25;
            this.bandedGridColumn18.Name = "bandedGridColumn18";
            this.bandedGridColumn18.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn18.Visible = true;
            this.bandedGridColumn18.Width = 94;
            // 
            // bandedGridColumn8
            // 
            this.bandedGridColumn8.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn8.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn8.Caption = "Trust Number";
            this.bandedGridColumn8.FieldName = "contractNumber";
            this.bandedGridColumn8.MinWidth = 42;
            this.bandedGridColumn8.Name = "bandedGridColumn8";
            this.bandedGridColumn8.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn8.Visible = true;
            this.bandedGridColumn8.Width = 83;
            // 
            // bandedGridColumn24
            // 
            this.bandedGridColumn24.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn24.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn24.Caption = "Previous Trust Found";
            this.bandedGridColumn24.FieldName = "found";
            this.bandedGridColumn24.MinWidth = 25;
            this.bandedGridColumn24.Name = "bandedGridColumn24";
            this.bandedGridColumn24.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn24.Visible = true;
            this.bandedGridColumn24.Width = 79;
            // 
            // bandedGridColumn12
            // 
            this.bandedGridColumn12.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn12.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn12.Caption = "Trust Name";
            this.bandedGridColumn12.FieldName = "trustName";
            this.bandedGridColumn12.MinWidth = 42;
            this.bandedGridColumn12.Name = "bandedGridColumn12";
            this.bandedGridColumn12.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn12.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn12.Visible = true;
            this.bandedGridColumn12.Width = 257;
            // 
            // bandedGridColumn16
            // 
            this.bandedGridColumn16.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn16.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn16.Caption = "Pre / Post 2002";
            this.bandedGridColumn16.FieldName = "preOrPost";
            this.bandedGridColumn16.MinWidth = 29;
            this.bandedGridColumn16.Name = "bandedGridColumn16";
            this.bandedGridColumn16.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn16.Visible = true;
            this.bandedGridColumn16.Width = 66;
            // 
            // bandedGridColumn3
            // 
            this.bandedGridColumn3.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn3.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn3.Caption = "Policy #";
            this.bandedGridColumn3.FieldName = "policyNumber";
            this.bandedGridColumn3.MinWidth = 42;
            this.bandedGridColumn3.Name = "bandedGridColumn3";
            this.bandedGridColumn3.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn3.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn3.Visible = true;
            this.bandedGridColumn3.Width = 147;
            // 
            // bandedGridColumn2
            // 
            this.bandedGridColumn2.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn2.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn2.Caption = "Insured Name";
            this.bandedGridColumn2.FieldName = "insuredName";
            this.bandedGridColumn2.MinWidth = 47;
            this.bandedGridColumn2.Name = "bandedGridColumn2";
            this.bandedGridColumn2.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn2.Visible = true;
            this.bandedGridColumn2.Width = 174;
            // 
            // bandedGridColumn4
            // 
            this.bandedGridColumn4.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn4.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn4.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn4.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn4.Caption = "Premium";
            this.bandedGridColumn4.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn4.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn4.FieldName = "beginningPaymentBalance";
            this.bandedGridColumn4.MinWidth = 42;
            this.bandedGridColumn4.Name = "bandedGridColumn4";
            this.bandedGridColumn4.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn4.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn4.Visible = true;
            this.bandedGridColumn4.Width = 100;
            // 
            // bandedGridColumn14
            // 
            this.bandedGridColumn14.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn14.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn14.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn14.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn14.Caption = "Down Payments";
            this.bandedGridColumn14.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn14.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn14.FieldName = "downPayments";
            this.bandedGridColumn14.MinWidth = 34;
            this.bandedGridColumn14.Name = "bandedGridColumn14";
            this.bandedGridColumn14.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn14.Visible = true;
            this.bandedGridColumn14.Width = 86;
            // 
            // bandedGridColumn15
            // 
            this.bandedGridColumn15.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn15.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn15.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn15.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn15.Caption = "Payments";
            this.bandedGridColumn15.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn15.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn15.FieldName = "payments";
            this.bandedGridColumn15.MinWidth = 34;
            this.bandedGridColumn15.Name = "bandedGridColumn15";
            this.bandedGridColumn15.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn15.Visible = true;
            this.bandedGridColumn15.Width = 91;
            // 
            // bandedGridColumn5
            // 
            this.bandedGridColumn5.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn5.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn5.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn5.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn5.Caption = "Surrender";
            this.bandedGridColumn5.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn5.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn5.FieldName = "beginningDeathBenefit";
            this.bandedGridColumn5.MinWidth = 42;
            this.bandedGridColumn5.Name = "bandedGridColumn5";
            this.bandedGridColumn5.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn5.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn5.Visible = true;
            this.bandedGridColumn5.Width = 109;
            // 
            // bandedGridColumn13
            // 
            this.bandedGridColumn13.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn13.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn13.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn13.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn13.Caption = "Face Amount";
            this.bandedGridColumn13.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn13.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn13.FieldName = "endingPaymentBalance";
            this.bandedGridColumn13.MinWidth = 42;
            this.bandedGridColumn13.Name = "bandedGridColumn13";
            this.bandedGridColumn13.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn13.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn13.Visible = true;
            this.bandedGridColumn13.Width = 126;
            // 
            // bandedGridColumn17
            // 
            this.bandedGridColumn17.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn17.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn17.Caption = "Growth";
            this.bandedGridColumn17.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn17.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn17.FieldName = "growth";
            this.bandedGridColumn17.MinWidth = 25;
            this.bandedGridColumn17.Name = "bandedGridColumn17";
            this.bandedGridColumn17.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn17.Visible = true;
            this.bandedGridColumn17.Width = 94;
            // 
            // bandedGridColumn10
            // 
            this.bandedGridColumn10.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn10.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn10.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn10.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn10.Caption = "Death Benefit";
            this.bandedGridColumn10.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn10.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn10.FieldName = "endingDeathBenefit";
            this.bandedGridColumn10.MinWidth = 42;
            this.bandedGridColumn10.Name = "bandedGridColumn10";
            this.bandedGridColumn10.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn10.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn10.Visible = true;
            this.bandedGridColumn10.Width = 125;
            // 
            // bandedGridColumn101
            // 
            this.bandedGridColumn101.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn101.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn101.Caption = "Reduced Paid Up Amount";
            this.bandedGridColumn101.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn101.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn101.FieldName = "reducedPaidUpAmount";
            this.bandedGridColumn101.MinWidth = 25;
            this.bandedGridColumn101.Name = "bandedGridColumn101";
            this.bandedGridColumn101.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn101.Visible = true;
            this.bandedGridColumn101.Width = 94;
            // 
            // bandedGridColumn22
            // 
            this.bandedGridColumn22.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn22.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn22.Caption = "Death Claim Amount";
            this.bandedGridColumn22.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn22.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn22.FieldName = "deathClaimAmount";
            this.bandedGridColumn22.MinWidth = 25;
            this.bandedGridColumn22.Name = "bandedGridColumn22";
            this.bandedGridColumn22.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn22.Visible = true;
            this.bandedGridColumn22.Width = 94;
            // 
            // bandedGridColumn23
            // 
            this.bandedGridColumn23.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn23.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn23.Caption = "Death Paid Date";
            this.bandedGridColumn23.FieldName = "deathPaidDate";
            this.bandedGridColumn23.MinWidth = 25;
            this.bandedGridColumn23.Name = "bandedGridColumn23";
            this.bandedGridColumn23.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn23.Visible = true;
            this.bandedGridColumn23.Width = 94;
            // 
            // bandedGridColumn21
            // 
            this.bandedGridColumn21.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn21.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn21.Caption = "Prior Unapplied Cash";
            this.bandedGridColumn21.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn21.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn21.FieldName = "priorUnappliedCash";
            this.bandedGridColumn21.MinWidth = 25;
            this.bandedGridColumn21.Name = "bandedGridColumn21";
            this.bandedGridColumn21.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn21.Visible = true;
            this.bandedGridColumn21.Width = 94;
            // 
            // bandedGridColumn20
            // 
            this.bandedGridColumn20.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn20.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn20.Caption = "Current Unapplied Cash";
            this.bandedGridColumn20.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn20.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn20.FieldName = "currentUnappliedCash";
            this.bandedGridColumn20.MinWidth = 25;
            this.bandedGridColumn20.Name = "bandedGridColumn20";
            this.bandedGridColumn20.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn20.Visible = true;
            this.bandedGridColumn20.Width = 94;
            // 
            // bandedGridColumn7
            // 
            this.bandedGridColumn7.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn7.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn7.Caption = "Last Name";
            this.bandedGridColumn7.FieldName = "lastName";
            this.bandedGridColumn7.MinWidth = 40;
            this.bandedGridColumn7.Name = "bandedGridColumn7";
            this.bandedGridColumn7.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn7.Visible = true;
            this.bandedGridColumn7.Width = 124;
            // 
            // bandedGridColumn9
            // 
            this.bandedGridColumn9.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn9.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn9.Caption = "First Name";
            this.bandedGridColumn9.FieldName = "firstName";
            this.bandedGridColumn9.MinWidth = 40;
            this.bandedGridColumn9.Name = "bandedGridColumn9";
            this.bandedGridColumn9.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn9.Visible = true;
            this.bandedGridColumn9.Width = 115;
            // 
            // bandedGridColumn11
            // 
            this.bandedGridColumn11.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn11.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn11.Caption = "Middle Name";
            this.bandedGridColumn11.FieldName = "middleName";
            this.bandedGridColumn11.MinWidth = 40;
            this.bandedGridColumn11.Name = "bandedGridColumn11";
            this.bandedGridColumn11.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn11.Visible = true;
            this.bandedGridColumn11.Width = 103;
            // 
            // bandedGridColumn97
            // 
            this.bandedGridColumn97.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn97.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn97.Caption = "Policy Extract_Status Reason";
            this.bandedGridColumn97.FieldName = "statusReason";
            this.bandedGridColumn97.MinWidth = 25;
            this.bandedGridColumn97.Name = "bandedGridColumn97";
            this.bandedGridColumn97.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn97.Visible = true;
            this.bandedGridColumn97.Width = 94;
            // 
            // bandedGridColumn102
            // 
            this.bandedGridColumn102.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn102.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn102.Caption = "Policy Extract_Billing Reason";
            this.bandedGridColumn102.FieldName = "billingReason";
            this.bandedGridColumn102.MinWidth = 25;
            this.bandedGridColumn102.Name = "bandedGridColumn102";
            this.bandedGridColumn102.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn102.Visible = true;
            this.bandedGridColumn102.Width = 94;
            // 
            // bandedGridColumn19
            // 
            this.bandedGridColumn19.Caption = "Date";
            this.bandedGridColumn19.DisplayFormat.FormatString = "yyyyMMDD";
            this.bandedGridColumn19.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn19.FieldName = "date";
            this.bandedGridColumn19.MinWidth = 25;
            this.bandedGridColumn19.Name = "bandedGridColumn19";
            this.bandedGridColumn19.Visible = true;
            this.bandedGridColumn19.Width = 94;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dgv2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(1651, 278);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "DC";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dgv2
            // 
            this.dgv2.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv2.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Location = new System.Drawing.Point(0, 0);
            this.dgv2.MainView = this.gridMain2;
            this.dgv2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Name = "dgv2";
            this.dgv2.Size = new System.Drawing.Size(1651, 278);
            this.dgv2.TabIndex = 5;
            this.dgv2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain2});
            // 
            // gridMain2
            // 
            this.gridMain2.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.BandPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain2.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain2.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain2.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain2.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain2.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(120)))), ((int)(((byte)(88)))));
            this.gridMain2.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain2.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(136)))), ((int)(((byte)(91)))));
            this.gridMain2.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.FooterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain2.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain2.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain2.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain2.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain2.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain2.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain2.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain2.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain2.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain2.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain2.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(172)))), ((int)(((byte)(134)))));
            this.gridMain2.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(234)))), ((int)(((byte)(216)))));
            this.gridMain2.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(169)))), ((int)(((byte)(107)))));
            this.gridMain2.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(224)))), ((int)(((byte)(190)))));
            this.gridMain2.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(237)))));
            this.gridMain2.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain2.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(120)))), ((int)(((byte)(88)))));
            this.gridMain2.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain2.Appearance.Preview.Options.UseFont = true;
            this.gridMain2.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain2.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain2.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.Row.Options.UseBackColor = true;
            this.gridMain2.Appearance.Row.Options.UseForeColor = true;
            this.gridMain2.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain2.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(159)))), ((int)(((byte)(114)))));
            this.gridMain2.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(169)))), ((int)(((byte)(107)))));
            this.gridMain2.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain2.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain2.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain2.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand1});
            this.gridMain2.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn25,
            this.bandedGridColumn26,
            this.bandedGridColumn51,
            this.bandedGridColumn27,
            this.bandedGridColumn30,
            this.bandedGridColumn28,
            this.bandedGridColumn29,
            this.bandedGridColumn32,
            this.bandedGridColumn33,
            this.bandedGridColumn34,
            this.bandedGridColumn37,
            this.bandedGridColumn38,
            this.bandedGridColumn40,
            this.bandedGridColumn44,
            this.bandedGridColumn45,
            this.bandedGridColumn46,
            this.bandedGridColumn47,
            this.bandedGridColumn48,
            this.bandedGridColumn35,
            this.bandedGridColumn36,
            this.bandedGridColumn31,
            this.bandedGridColumn39,
            this.bandedGridColumn41,
            this.bandedGridColumn42,
            this.bandedGridColumn43,
            this.bandedGridColumn49,
            this.bandedGridColumn50});
            this.gridMain2.DetailHeight = 431;
            this.gridMain2.GridControl = this.dgv2;
            this.gridMain2.Name = "gridMain2";
            this.gridMain2.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain2.OptionsPrint.PrintBandHeader = false;
            this.gridMain2.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain2.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain2.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain2.OptionsView.ShowFooter = true;
            this.gridMain2.OptionsView.ShowGroupPanel = false;
            this.gridMain2.PaintStyleName = "Style3D";
            this.gridMain2.DoubleClick += new System.EventHandler(this.gridMain2_DoubleClick);
            // 
            // gridBand1
            // 
            this.gridBand1.Columns.Add(this.bandedGridColumn25);
            this.gridBand1.Columns.Add(this.bandedGridColumn26);
            this.gridBand1.Columns.Add(this.bandedGridColumn27);
            this.gridBand1.Columns.Add(this.bandedGridColumn28);
            this.gridBand1.Columns.Add(this.bandedGridColumn29);
            this.gridBand1.Columns.Add(this.bandedGridColumn30);
            this.gridBand1.Columns.Add(this.bandedGridColumn31);
            this.gridBand1.Columns.Add(this.bandedGridColumn32);
            this.gridBand1.Columns.Add(this.bandedGridColumn33);
            this.gridBand1.Columns.Add(this.bandedGridColumn34);
            this.gridBand1.Columns.Add(this.bandedGridColumn35);
            this.gridBand1.Columns.Add(this.bandedGridColumn36);
            this.gridBand1.Columns.Add(this.bandedGridColumn37);
            this.gridBand1.Columns.Add(this.bandedGridColumn38);
            this.gridBand1.Columns.Add(this.bandedGridColumn39);
            this.gridBand1.Columns.Add(this.bandedGridColumn40);
            this.gridBand1.Columns.Add(this.bandedGridColumn41);
            this.gridBand1.Columns.Add(this.bandedGridColumn42);
            this.gridBand1.Columns.Add(this.bandedGridColumn43);
            this.gridBand1.Columns.Add(this.bandedGridColumn44);
            this.gridBand1.Columns.Add(this.bandedGridColumn45);
            this.gridBand1.Columns.Add(this.bandedGridColumn46);
            this.gridBand1.Columns.Add(this.bandedGridColumn47);
            this.gridBand1.Columns.Add(this.bandedGridColumn48);
            this.gridBand1.Columns.Add(this.bandedGridColumn49);
            this.gridBand1.Columns.Add(this.bandedGridColumn50);
            this.gridBand1.MinWidth = 22;
            this.gridBand1.Name = "gridBand1";
            this.gridBand1.VisibleIndex = 0;
            this.gridBand1.Width = 2688;
            // 
            // bandedGridColumn25
            // 
            this.bandedGridColumn25.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn25.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn25.Caption = "Num";
            this.bandedGridColumn25.FieldName = "num";
            this.bandedGridColumn25.MinWidth = 42;
            this.bandedGridColumn25.Name = "bandedGridColumn25";
            this.bandedGridColumn25.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn25.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn25.Visible = true;
            this.bandedGridColumn25.Width = 57;
            // 
            // bandedGridColumn26
            // 
            this.bandedGridColumn26.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn26.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn26.Caption = "Status";
            this.bandedGridColumn26.FieldName = "status";
            this.bandedGridColumn26.MinWidth = 42;
            this.bandedGridColumn26.Name = "bandedGridColumn26";
            this.bandedGridColumn26.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn26.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn26.Width = 161;
            // 
            // bandedGridColumn27
            // 
            this.bandedGridColumn27.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn27.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn27.Caption = "Trust Company";
            this.bandedGridColumn27.FieldName = "trustCompany";
            this.bandedGridColumn27.MinWidth = 25;
            this.bandedGridColumn27.Name = "bandedGridColumn27";
            this.bandedGridColumn27.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn27.Visible = true;
            this.bandedGridColumn27.Width = 94;
            // 
            // bandedGridColumn28
            // 
            this.bandedGridColumn28.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn28.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn28.Caption = "Trust Number";
            this.bandedGridColumn28.FieldName = "contractNumber";
            this.bandedGridColumn28.MinWidth = 42;
            this.bandedGridColumn28.Name = "bandedGridColumn28";
            this.bandedGridColumn28.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn28.Visible = true;
            this.bandedGridColumn28.Width = 83;
            // 
            // bandedGridColumn29
            // 
            this.bandedGridColumn29.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn29.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn29.Caption = "Previous Trust Found";
            this.bandedGridColumn29.FieldName = "found";
            this.bandedGridColumn29.MinWidth = 25;
            this.bandedGridColumn29.Name = "bandedGridColumn29";
            this.bandedGridColumn29.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn29.Visible = true;
            this.bandedGridColumn29.Width = 79;
            // 
            // bandedGridColumn30
            // 
            this.bandedGridColumn30.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn30.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn30.Caption = "Trust Name";
            this.bandedGridColumn30.FieldName = "trustName";
            this.bandedGridColumn30.MinWidth = 42;
            this.bandedGridColumn30.Name = "bandedGridColumn30";
            this.bandedGridColumn30.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn30.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn30.Visible = true;
            this.bandedGridColumn30.Width = 257;
            // 
            // bandedGridColumn31
            // 
            this.bandedGridColumn31.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn31.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn31.Caption = "Pre / Post 2002";
            this.bandedGridColumn31.FieldName = "preOrPost";
            this.bandedGridColumn31.MinWidth = 29;
            this.bandedGridColumn31.Name = "bandedGridColumn31";
            this.bandedGridColumn31.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn31.Visible = true;
            this.bandedGridColumn31.Width = 66;
            // 
            // bandedGridColumn32
            // 
            this.bandedGridColumn32.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn32.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn32.Caption = "Policy #";
            this.bandedGridColumn32.FieldName = "policyNumber";
            this.bandedGridColumn32.MinWidth = 42;
            this.bandedGridColumn32.Name = "bandedGridColumn32";
            this.bandedGridColumn32.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn32.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn32.Visible = true;
            this.bandedGridColumn32.Width = 147;
            // 
            // bandedGridColumn33
            // 
            this.bandedGridColumn33.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn33.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn33.Caption = "Insured Name";
            this.bandedGridColumn33.FieldName = "insuredName";
            this.bandedGridColumn33.MinWidth = 47;
            this.bandedGridColumn33.Name = "bandedGridColumn33";
            this.bandedGridColumn33.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn33.Visible = true;
            this.bandedGridColumn33.Width = 174;
            // 
            // bandedGridColumn34
            // 
            this.bandedGridColumn34.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn34.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn34.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn34.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn34.Caption = "Premium";
            this.bandedGridColumn34.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn34.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn34.FieldName = "beginningPaymentBalance";
            this.bandedGridColumn34.MinWidth = 42;
            this.bandedGridColumn34.Name = "bandedGridColumn34";
            this.bandedGridColumn34.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn34.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn34.Visible = true;
            this.bandedGridColumn34.Width = 100;
            // 
            // bandedGridColumn35
            // 
            this.bandedGridColumn35.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn35.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn35.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn35.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn35.Caption = "Down Payments";
            this.bandedGridColumn35.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn35.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn35.FieldName = "downPayments";
            this.bandedGridColumn35.MinWidth = 34;
            this.bandedGridColumn35.Name = "bandedGridColumn35";
            this.bandedGridColumn35.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn35.Visible = true;
            this.bandedGridColumn35.Width = 86;
            // 
            // bandedGridColumn36
            // 
            this.bandedGridColumn36.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn36.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn36.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn36.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn36.Caption = "Payments";
            this.bandedGridColumn36.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn36.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn36.FieldName = "payments";
            this.bandedGridColumn36.MinWidth = 34;
            this.bandedGridColumn36.Name = "bandedGridColumn36";
            this.bandedGridColumn36.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn36.Visible = true;
            this.bandedGridColumn36.Width = 91;
            // 
            // bandedGridColumn37
            // 
            this.bandedGridColumn37.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn37.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn37.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn37.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn37.Caption = "Surrender";
            this.bandedGridColumn37.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn37.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn37.FieldName = "beginningDeathBenefit";
            this.bandedGridColumn37.MinWidth = 42;
            this.bandedGridColumn37.Name = "bandedGridColumn37";
            this.bandedGridColumn37.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn37.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn37.Visible = true;
            this.bandedGridColumn37.Width = 109;
            // 
            // bandedGridColumn38
            // 
            this.bandedGridColumn38.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn38.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn38.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn38.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn38.Caption = "Face Amount";
            this.bandedGridColumn38.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn38.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn38.FieldName = "endingPaymentBalance";
            this.bandedGridColumn38.MinWidth = 42;
            this.bandedGridColumn38.Name = "bandedGridColumn38";
            this.bandedGridColumn38.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn38.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn38.Visible = true;
            this.bandedGridColumn38.Width = 126;
            // 
            // bandedGridColumn39
            // 
            this.bandedGridColumn39.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn39.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn39.Caption = "Growth";
            this.bandedGridColumn39.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn39.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn39.FieldName = "growth";
            this.bandedGridColumn39.MinWidth = 25;
            this.bandedGridColumn39.Name = "bandedGridColumn39";
            this.bandedGridColumn39.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn39.Visible = true;
            this.bandedGridColumn39.Width = 94;
            // 
            // bandedGridColumn40
            // 
            this.bandedGridColumn40.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn40.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn40.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn40.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn40.Caption = "Death Benefit";
            this.bandedGridColumn40.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn40.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn40.FieldName = "endingDeathBenefit";
            this.bandedGridColumn40.MinWidth = 42;
            this.bandedGridColumn40.Name = "bandedGridColumn40";
            this.bandedGridColumn40.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn40.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn40.Visible = true;
            this.bandedGridColumn40.Width = 125;
            // 
            // bandedGridColumn41
            // 
            this.bandedGridColumn41.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn41.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn41.Caption = "Reduced Paid Up Amount";
            this.bandedGridColumn41.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn41.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn41.FieldName = "reducedPaidUpAmount";
            this.bandedGridColumn41.MinWidth = 25;
            this.bandedGridColumn41.Name = "bandedGridColumn41";
            this.bandedGridColumn41.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn41.Visible = true;
            this.bandedGridColumn41.Width = 94;
            // 
            // bandedGridColumn42
            // 
            this.bandedGridColumn42.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn42.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn42.Caption = "Death Claim Amount";
            this.bandedGridColumn42.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn42.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn42.FieldName = "deathClaimAmount";
            this.bandedGridColumn42.MinWidth = 25;
            this.bandedGridColumn42.Name = "bandedGridColumn42";
            this.bandedGridColumn42.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn42.Visible = true;
            this.bandedGridColumn42.Width = 94;
            // 
            // bandedGridColumn43
            // 
            this.bandedGridColumn43.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn43.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn43.Caption = "Death Paid Date";
            this.bandedGridColumn43.FieldName = "deathPaidDate";
            this.bandedGridColumn43.MinWidth = 25;
            this.bandedGridColumn43.Name = "bandedGridColumn43";
            this.bandedGridColumn43.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn43.Visible = true;
            this.bandedGridColumn43.Width = 94;
            // 
            // bandedGridColumn44
            // 
            this.bandedGridColumn44.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn44.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn44.Caption = "Prior Unapplied Cash";
            this.bandedGridColumn44.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn44.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn44.FieldName = "priorUnappliedCash";
            this.bandedGridColumn44.MinWidth = 25;
            this.bandedGridColumn44.Name = "bandedGridColumn44";
            this.bandedGridColumn44.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn44.Visible = true;
            this.bandedGridColumn44.Width = 94;
            // 
            // bandedGridColumn45
            // 
            this.bandedGridColumn45.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn45.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn45.Caption = "Current Unapplied Cash";
            this.bandedGridColumn45.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn45.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn45.FieldName = "currentUnappliedCash";
            this.bandedGridColumn45.MinWidth = 25;
            this.bandedGridColumn45.Name = "bandedGridColumn45";
            this.bandedGridColumn45.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn45.Visible = true;
            this.bandedGridColumn45.Width = 94;
            // 
            // bandedGridColumn46
            // 
            this.bandedGridColumn46.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn46.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn46.Caption = "Last Name";
            this.bandedGridColumn46.FieldName = "lastName";
            this.bandedGridColumn46.MinWidth = 40;
            this.bandedGridColumn46.Name = "bandedGridColumn46";
            this.bandedGridColumn46.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn46.Visible = true;
            this.bandedGridColumn46.Width = 124;
            // 
            // bandedGridColumn47
            // 
            this.bandedGridColumn47.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn47.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn47.Caption = "First Name";
            this.bandedGridColumn47.FieldName = "firstName";
            this.bandedGridColumn47.MinWidth = 40;
            this.bandedGridColumn47.Name = "bandedGridColumn47";
            this.bandedGridColumn47.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn47.Visible = true;
            this.bandedGridColumn47.Width = 115;
            // 
            // bandedGridColumn48
            // 
            this.bandedGridColumn48.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn48.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn48.Caption = "Middle Name";
            this.bandedGridColumn48.FieldName = "middleName";
            this.bandedGridColumn48.MinWidth = 40;
            this.bandedGridColumn48.Name = "bandedGridColumn48";
            this.bandedGridColumn48.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn48.Visible = true;
            this.bandedGridColumn48.Width = 103;
            // 
            // bandedGridColumn49
            // 
            this.bandedGridColumn49.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn49.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn49.Caption = "Policy Extract_Status Reason";
            this.bandedGridColumn49.FieldName = "statusReason";
            this.bandedGridColumn49.MinWidth = 25;
            this.bandedGridColumn49.Name = "bandedGridColumn49";
            this.bandedGridColumn49.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn49.Visible = true;
            this.bandedGridColumn49.Width = 94;
            // 
            // bandedGridColumn50
            // 
            this.bandedGridColumn50.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn50.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn50.Caption = "Policy Extract_Billing Reason";
            this.bandedGridColumn50.FieldName = "billingReason";
            this.bandedGridColumn50.MinWidth = 25;
            this.bandedGridColumn50.Name = "bandedGridColumn50";
            this.bandedGridColumn50.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn50.Visible = true;
            this.bandedGridColumn50.Width = 94;
            // 
            // bandedGridColumn51
            // 
            this.bandedGridColumn51.Caption = "Date";
            this.bandedGridColumn51.DisplayFormat.FormatString = "yyyyMMDD";
            this.bandedGridColumn51.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn51.FieldName = "date";
            this.bandedGridColumn51.MinWidth = 25;
            this.bandedGridColumn51.Name = "bandedGridColumn51";
            this.bandedGridColumn51.Visible = true;
            this.bandedGridColumn51.Width = 94;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dgv3);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1651, 278);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Last Month";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dgv3
            // 
            this.dgv3.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv3.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Location = new System.Drawing.Point(0, 0);
            this.dgv3.MainView = this.gridMain3;
            this.dgv3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Name = "dgv3";
            this.dgv3.Size = new System.Drawing.Size(1651, 278);
            this.dgv3.TabIndex = 5;
            this.dgv3.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain3});
            // 
            // gridMain3
            // 
            this.gridMain3.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain3.Appearance.BandPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain3.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain3.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain3.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain3.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain3.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain3.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(120)))), ((int)(((byte)(88)))));
            this.gridMain3.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain3.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(136)))), ((int)(((byte)(91)))));
            this.gridMain3.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.FooterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain3.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain3.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain3.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain3.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain3.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain3.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain3.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain3.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain3.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain3.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain3.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain3.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(172)))), ((int)(((byte)(134)))));
            this.gridMain3.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(234)))), ((int)(((byte)(216)))));
            this.gridMain3.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(169)))), ((int)(((byte)(107)))));
            this.gridMain3.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain3.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(224)))), ((int)(((byte)(190)))));
            this.gridMain3.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(237)))));
            this.gridMain3.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain3.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(120)))), ((int)(((byte)(88)))));
            this.gridMain3.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain3.Appearance.Preview.Options.UseFont = true;
            this.gridMain3.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain3.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain3.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.Row.Options.UseBackColor = true;
            this.gridMain3.Appearance.Row.Options.UseForeColor = true;
            this.gridMain3.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain3.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain3.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(159)))), ((int)(((byte)(114)))));
            this.gridMain3.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(169)))), ((int)(((byte)(107)))));
            this.gridMain3.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain3.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain3.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain3.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand2});
            this.gridMain3.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn52,
            this.bandedGridColumn53,
            this.bandedGridColumn78,
            this.bandedGridColumn54,
            this.bandedGridColumn57,
            this.bandedGridColumn55,
            this.bandedGridColumn56,
            this.bandedGridColumn59,
            this.bandedGridColumn60,
            this.bandedGridColumn61,
            this.bandedGridColumn64,
            this.bandedGridColumn65,
            this.bandedGridColumn67,
            this.bandedGridColumn71,
            this.bandedGridColumn72,
            this.bandedGridColumn73,
            this.bandedGridColumn74,
            this.bandedGridColumn75,
            this.bandedGridColumn62,
            this.bandedGridColumn63,
            this.bandedGridColumn58,
            this.bandedGridColumn66,
            this.bandedGridColumn68,
            this.bandedGridColumn69,
            this.bandedGridColumn70,
            this.bandedGridColumn76,
            this.bandedGridColumn77});
            this.gridMain3.DetailHeight = 431;
            this.gridMain3.GridControl = this.dgv3;
            this.gridMain3.Name = "gridMain3";
            this.gridMain3.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain3.OptionsPrint.PrintBandHeader = false;
            this.gridMain3.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain3.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain3.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain3.OptionsView.ShowFooter = true;
            this.gridMain3.OptionsView.ShowGroupPanel = false;
            this.gridMain3.PaintStyleName = "Style3D";
            this.gridMain3.DoubleClick += new System.EventHandler(this.gridMain3_DoubleClick);
            // 
            // gridBand2
            // 
            this.gridBand2.Columns.Add(this.bandedGridColumn52);
            this.gridBand2.Columns.Add(this.bandedGridColumn53);
            this.gridBand2.Columns.Add(this.bandedGridColumn54);
            this.gridBand2.Columns.Add(this.bandedGridColumn55);
            this.gridBand2.Columns.Add(this.bandedGridColumn56);
            this.gridBand2.Columns.Add(this.bandedGridColumn57);
            this.gridBand2.Columns.Add(this.bandedGridColumn58);
            this.gridBand2.Columns.Add(this.bandedGridColumn59);
            this.gridBand2.Columns.Add(this.bandedGridColumn60);
            this.gridBand2.Columns.Add(this.bandedGridColumn61);
            this.gridBand2.Columns.Add(this.bandedGridColumn62);
            this.gridBand2.Columns.Add(this.bandedGridColumn63);
            this.gridBand2.Columns.Add(this.bandedGridColumn64);
            this.gridBand2.Columns.Add(this.bandedGridColumn65);
            this.gridBand2.Columns.Add(this.bandedGridColumn66);
            this.gridBand2.Columns.Add(this.bandedGridColumn67);
            this.gridBand2.Columns.Add(this.bandedGridColumn68);
            this.gridBand2.Columns.Add(this.bandedGridColumn69);
            this.gridBand2.Columns.Add(this.bandedGridColumn70);
            this.gridBand2.Columns.Add(this.bandedGridColumn71);
            this.gridBand2.Columns.Add(this.bandedGridColumn72);
            this.gridBand2.Columns.Add(this.bandedGridColumn73);
            this.gridBand2.Columns.Add(this.bandedGridColumn74);
            this.gridBand2.Columns.Add(this.bandedGridColumn75);
            this.gridBand2.Columns.Add(this.bandedGridColumn76);
            this.gridBand2.Columns.Add(this.bandedGridColumn77);
            this.gridBand2.MinWidth = 22;
            this.gridBand2.Name = "gridBand2";
            this.gridBand2.VisibleIndex = 0;
            this.gridBand2.Width = 2688;
            // 
            // bandedGridColumn52
            // 
            this.bandedGridColumn52.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn52.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn52.Caption = "Num";
            this.bandedGridColumn52.FieldName = "num";
            this.bandedGridColumn52.MinWidth = 42;
            this.bandedGridColumn52.Name = "bandedGridColumn52";
            this.bandedGridColumn52.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn52.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn52.Visible = true;
            this.bandedGridColumn52.Width = 57;
            // 
            // bandedGridColumn53
            // 
            this.bandedGridColumn53.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn53.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn53.Caption = "Status";
            this.bandedGridColumn53.FieldName = "status";
            this.bandedGridColumn53.MinWidth = 42;
            this.bandedGridColumn53.Name = "bandedGridColumn53";
            this.bandedGridColumn53.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn53.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn53.Width = 161;
            // 
            // bandedGridColumn54
            // 
            this.bandedGridColumn54.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn54.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn54.Caption = "Trust Company";
            this.bandedGridColumn54.FieldName = "trustCompany";
            this.bandedGridColumn54.MinWidth = 25;
            this.bandedGridColumn54.Name = "bandedGridColumn54";
            this.bandedGridColumn54.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn54.Visible = true;
            this.bandedGridColumn54.Width = 94;
            // 
            // bandedGridColumn55
            // 
            this.bandedGridColumn55.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn55.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn55.Caption = "Trust Number";
            this.bandedGridColumn55.FieldName = "contractNumber";
            this.bandedGridColumn55.MinWidth = 42;
            this.bandedGridColumn55.Name = "bandedGridColumn55";
            this.bandedGridColumn55.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn55.Visible = true;
            this.bandedGridColumn55.Width = 83;
            // 
            // bandedGridColumn56
            // 
            this.bandedGridColumn56.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn56.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn56.Caption = "Previous Trust Found";
            this.bandedGridColumn56.FieldName = "found";
            this.bandedGridColumn56.MinWidth = 25;
            this.bandedGridColumn56.Name = "bandedGridColumn56";
            this.bandedGridColumn56.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn56.Visible = true;
            this.bandedGridColumn56.Width = 79;
            // 
            // bandedGridColumn57
            // 
            this.bandedGridColumn57.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn57.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn57.Caption = "Trust Name";
            this.bandedGridColumn57.FieldName = "trustName";
            this.bandedGridColumn57.MinWidth = 42;
            this.bandedGridColumn57.Name = "bandedGridColumn57";
            this.bandedGridColumn57.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn57.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn57.Visible = true;
            this.bandedGridColumn57.Width = 257;
            // 
            // bandedGridColumn58
            // 
            this.bandedGridColumn58.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn58.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn58.Caption = "Pre / Post 2002";
            this.bandedGridColumn58.FieldName = "preOrPost";
            this.bandedGridColumn58.MinWidth = 29;
            this.bandedGridColumn58.Name = "bandedGridColumn58";
            this.bandedGridColumn58.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn58.Visible = true;
            this.bandedGridColumn58.Width = 66;
            // 
            // bandedGridColumn59
            // 
            this.bandedGridColumn59.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn59.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn59.Caption = "Policy #";
            this.bandedGridColumn59.FieldName = "policyNumber";
            this.bandedGridColumn59.MinWidth = 42;
            this.bandedGridColumn59.Name = "bandedGridColumn59";
            this.bandedGridColumn59.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn59.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn59.Visible = true;
            this.bandedGridColumn59.Width = 147;
            // 
            // bandedGridColumn60
            // 
            this.bandedGridColumn60.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn60.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn60.Caption = "Insured Name";
            this.bandedGridColumn60.FieldName = "insuredName";
            this.bandedGridColumn60.MinWidth = 47;
            this.bandedGridColumn60.Name = "bandedGridColumn60";
            this.bandedGridColumn60.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn60.Visible = true;
            this.bandedGridColumn60.Width = 174;
            // 
            // bandedGridColumn61
            // 
            this.bandedGridColumn61.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn61.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn61.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn61.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn61.Caption = "Premium";
            this.bandedGridColumn61.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn61.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn61.FieldName = "beginningPaymentBalance";
            this.bandedGridColumn61.MinWidth = 42;
            this.bandedGridColumn61.Name = "bandedGridColumn61";
            this.bandedGridColumn61.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn61.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn61.Visible = true;
            this.bandedGridColumn61.Width = 100;
            // 
            // bandedGridColumn62
            // 
            this.bandedGridColumn62.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn62.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn62.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn62.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn62.Caption = "Down Payments";
            this.bandedGridColumn62.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn62.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn62.FieldName = "downPayments";
            this.bandedGridColumn62.MinWidth = 34;
            this.bandedGridColumn62.Name = "bandedGridColumn62";
            this.bandedGridColumn62.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn62.Visible = true;
            this.bandedGridColumn62.Width = 86;
            // 
            // bandedGridColumn63
            // 
            this.bandedGridColumn63.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn63.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn63.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn63.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn63.Caption = "Payments";
            this.bandedGridColumn63.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn63.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn63.FieldName = "payments";
            this.bandedGridColumn63.MinWidth = 34;
            this.bandedGridColumn63.Name = "bandedGridColumn63";
            this.bandedGridColumn63.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn63.Visible = true;
            this.bandedGridColumn63.Width = 91;
            // 
            // bandedGridColumn64
            // 
            this.bandedGridColumn64.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn64.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn64.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn64.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn64.Caption = "Surrender";
            this.bandedGridColumn64.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn64.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn64.FieldName = "beginningDeathBenefit";
            this.bandedGridColumn64.MinWidth = 42;
            this.bandedGridColumn64.Name = "bandedGridColumn64";
            this.bandedGridColumn64.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn64.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn64.Visible = true;
            this.bandedGridColumn64.Width = 109;
            // 
            // bandedGridColumn65
            // 
            this.bandedGridColumn65.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn65.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn65.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn65.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn65.Caption = "Face Amount";
            this.bandedGridColumn65.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn65.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn65.FieldName = "endingPaymentBalance";
            this.bandedGridColumn65.MinWidth = 42;
            this.bandedGridColumn65.Name = "bandedGridColumn65";
            this.bandedGridColumn65.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn65.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn65.Visible = true;
            this.bandedGridColumn65.Width = 126;
            // 
            // bandedGridColumn66
            // 
            this.bandedGridColumn66.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn66.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn66.Caption = "Growth";
            this.bandedGridColumn66.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn66.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn66.FieldName = "growth";
            this.bandedGridColumn66.MinWidth = 25;
            this.bandedGridColumn66.Name = "bandedGridColumn66";
            this.bandedGridColumn66.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn66.Visible = true;
            this.bandedGridColumn66.Width = 94;
            // 
            // bandedGridColumn67
            // 
            this.bandedGridColumn67.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn67.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn67.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn67.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn67.Caption = "Death Benefit";
            this.bandedGridColumn67.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn67.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn67.FieldName = "endingDeathBenefit";
            this.bandedGridColumn67.MinWidth = 42;
            this.bandedGridColumn67.Name = "bandedGridColumn67";
            this.bandedGridColumn67.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn67.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn67.Visible = true;
            this.bandedGridColumn67.Width = 125;
            // 
            // bandedGridColumn68
            // 
            this.bandedGridColumn68.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn68.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn68.Caption = "Reduced Paid Up Amount";
            this.bandedGridColumn68.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn68.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn68.FieldName = "reducedPaidUpAmount";
            this.bandedGridColumn68.MinWidth = 25;
            this.bandedGridColumn68.Name = "bandedGridColumn68";
            this.bandedGridColumn68.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn68.Visible = true;
            this.bandedGridColumn68.Width = 94;
            // 
            // bandedGridColumn69
            // 
            this.bandedGridColumn69.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn69.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn69.Caption = "Death Claim Amount";
            this.bandedGridColumn69.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn69.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn69.FieldName = "deathClaimAmount";
            this.bandedGridColumn69.MinWidth = 25;
            this.bandedGridColumn69.Name = "bandedGridColumn69";
            this.bandedGridColumn69.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn69.Visible = true;
            this.bandedGridColumn69.Width = 94;
            // 
            // bandedGridColumn70
            // 
            this.bandedGridColumn70.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn70.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn70.Caption = "Death Paid Date";
            this.bandedGridColumn70.FieldName = "deathPaidDate";
            this.bandedGridColumn70.MinWidth = 25;
            this.bandedGridColumn70.Name = "bandedGridColumn70";
            this.bandedGridColumn70.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn70.Visible = true;
            this.bandedGridColumn70.Width = 94;
            // 
            // bandedGridColumn71
            // 
            this.bandedGridColumn71.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn71.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn71.Caption = "Prior Unapplied Cash";
            this.bandedGridColumn71.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn71.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn71.FieldName = "priorUnappliedCash";
            this.bandedGridColumn71.MinWidth = 25;
            this.bandedGridColumn71.Name = "bandedGridColumn71";
            this.bandedGridColumn71.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn71.Visible = true;
            this.bandedGridColumn71.Width = 94;
            // 
            // bandedGridColumn72
            // 
            this.bandedGridColumn72.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn72.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn72.Caption = "Current Unapplied Cash";
            this.bandedGridColumn72.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn72.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn72.FieldName = "currentUnappliedCash";
            this.bandedGridColumn72.MinWidth = 25;
            this.bandedGridColumn72.Name = "bandedGridColumn72";
            this.bandedGridColumn72.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn72.Visible = true;
            this.bandedGridColumn72.Width = 94;
            // 
            // bandedGridColumn73
            // 
            this.bandedGridColumn73.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn73.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn73.Caption = "Last Name";
            this.bandedGridColumn73.FieldName = "lastName";
            this.bandedGridColumn73.MinWidth = 40;
            this.bandedGridColumn73.Name = "bandedGridColumn73";
            this.bandedGridColumn73.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn73.Visible = true;
            this.bandedGridColumn73.Width = 124;
            // 
            // bandedGridColumn74
            // 
            this.bandedGridColumn74.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn74.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn74.Caption = "First Name";
            this.bandedGridColumn74.FieldName = "firstName";
            this.bandedGridColumn74.MinWidth = 40;
            this.bandedGridColumn74.Name = "bandedGridColumn74";
            this.bandedGridColumn74.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn74.Visible = true;
            this.bandedGridColumn74.Width = 115;
            // 
            // bandedGridColumn75
            // 
            this.bandedGridColumn75.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn75.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn75.Caption = "Middle Name";
            this.bandedGridColumn75.FieldName = "middleName";
            this.bandedGridColumn75.MinWidth = 40;
            this.bandedGridColumn75.Name = "bandedGridColumn75";
            this.bandedGridColumn75.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn75.Visible = true;
            this.bandedGridColumn75.Width = 103;
            // 
            // bandedGridColumn76
            // 
            this.bandedGridColumn76.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn76.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn76.Caption = "Policy Extract_Status Reason";
            this.bandedGridColumn76.FieldName = "statusReason";
            this.bandedGridColumn76.MinWidth = 25;
            this.bandedGridColumn76.Name = "bandedGridColumn76";
            this.bandedGridColumn76.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn76.Visible = true;
            this.bandedGridColumn76.Width = 94;
            // 
            // bandedGridColumn77
            // 
            this.bandedGridColumn77.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn77.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn77.Caption = "Policy Extract_Billing Reason";
            this.bandedGridColumn77.FieldName = "billingReason";
            this.bandedGridColumn77.MinWidth = 25;
            this.bandedGridColumn77.Name = "bandedGridColumn77";
            this.bandedGridColumn77.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn77.Visible = true;
            this.bandedGridColumn77.Width = 94;
            // 
            // bandedGridColumn78
            // 
            this.bandedGridColumn78.Caption = "Date";
            this.bandedGridColumn78.DisplayFormat.FormatString = "yyyyMMDD";
            this.bandedGridColumn78.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn78.FieldName = "date";
            this.bandedGridColumn78.MinWidth = 25;
            this.bandedGridColumn78.Name = "bandedGridColumn78";
            this.bandedGridColumn78.Visible = true;
            this.bandedGridColumn78.Width = 94;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.dgv4);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1651, 278);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Problems";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // dgv4
            // 
            this.dgv4.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv4.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv4.Location = new System.Drawing.Point(0, 0);
            this.dgv4.MainView = this.gridMain4;
            this.dgv4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv4.Name = "dgv4";
            this.dgv4.Size = new System.Drawing.Size(1651, 278);
            this.dgv4.TabIndex = 5;
            this.dgv4.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain4});
            // 
            // gridMain4
            // 
            this.gridMain4.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain4.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain4.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.BandPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain4.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain4.Appearance.BandPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain4.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain4.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain4.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain4.Appearance.Empty.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain4.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain4.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain4.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain4.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain4.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(120)))), ((int)(((byte)(88)))));
            this.gridMain4.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain4.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(136)))), ((int)(((byte)(91)))));
            this.gridMain4.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain4.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain4.Appearance.FooterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain4.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(143)))), ((int)(((byte)(62)))));
            this.gridMain4.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain4.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain4.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain4.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain4.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(189)))), ((int)(((byte)(125)))));
            this.gridMain4.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain4.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain4.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain4.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain4.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(166)))), ((int)(((byte)(93)))));
            this.gridMain4.Appearance.HeaderPanelBackground.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain4.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(172)))), ((int)(((byte)(134)))));
            this.gridMain4.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(234)))), ((int)(((byte)(216)))));
            this.gridMain4.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(169)))), ((int)(((byte)(107)))));
            this.gridMain4.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain4.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(224)))), ((int)(((byte)(190)))));
            this.gridMain4.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(252)))), ((int)(((byte)(237)))));
            this.gridMain4.Appearance.Preview.Font = new System.Drawing.Font("Verdana", 7.5F);
            this.gridMain4.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(120)))), ((int)(((byte)(88)))));
            this.gridMain4.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain4.Appearance.Preview.Options.UseFont = true;
            this.gridMain4.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain4.Appearance.Row.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain4.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.Row.Options.UseBackColor = true;
            this.gridMain4.Appearance.Row.Options.UseForeColor = true;
            this.gridMain4.Appearance.RowSeparator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(247)))), ((int)(((byte)(219)))));
            this.gridMain4.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain4.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(187)))), ((int)(((byte)(159)))), ((int)(((byte)(114)))));
            this.gridMain4.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(169)))), ((int)(((byte)(107)))));
            this.gridMain4.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain4.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain4.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain4.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand3});
            this.gridMain4.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn79,
            this.bandedGridColumn80,
            this.bandedGridColumn108,
            this.bandedGridColumn81,
            this.bandedGridColumn84,
            this.bandedGridColumn82,
            this.bandedGridColumn83,
            this.bandedGridColumn86,
            this.bandedGridColumn87,
            this.bandedGridColumn88,
            this.bandedGridColumn91,
            this.bandedGridColumn92,
            this.bandedGridColumn94,
            this.bandedGridColumn99,
            this.bandedGridColumn100,
            this.bandedGridColumn103,
            this.bandedGridColumn104,
            this.bandedGridColumn105,
            this.bandedGridColumn89,
            this.bandedGridColumn90,
            this.bandedGridColumn85,
            this.bandedGridColumn93,
            this.bandedGridColumn95,
            this.bandedGridColumn96,
            this.bandedGridColumn98,
            this.bandedGridColumn106,
            this.bandedGridColumn107});
            this.gridMain4.DetailHeight = 431;
            this.gridMain4.GridControl = this.dgv4;
            this.gridMain4.Name = "gridMain4";
            this.gridMain4.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain4.OptionsPrint.PrintBandHeader = false;
            this.gridMain4.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain4.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain4.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain4.OptionsView.ShowFooter = true;
            this.gridMain4.OptionsView.ShowGroupPanel = false;
            this.gridMain4.PaintStyleName = "Style3D";
            this.gridMain4.DoubleClick += new System.EventHandler(this.gridMain4_DoubleClick);
            // 
            // gridBand3
            // 
            this.gridBand3.Columns.Add(this.bandedGridColumn79);
            this.gridBand3.Columns.Add(this.bandedGridColumn80);
            this.gridBand3.Columns.Add(this.bandedGridColumn81);
            this.gridBand3.Columns.Add(this.bandedGridColumn82);
            this.gridBand3.Columns.Add(this.bandedGridColumn83);
            this.gridBand3.Columns.Add(this.bandedGridColumn84);
            this.gridBand3.Columns.Add(this.bandedGridColumn85);
            this.gridBand3.Columns.Add(this.bandedGridColumn86);
            this.gridBand3.Columns.Add(this.bandedGridColumn87);
            this.gridBand3.Columns.Add(this.bandedGridColumn88);
            this.gridBand3.Columns.Add(this.bandedGridColumn89);
            this.gridBand3.Columns.Add(this.bandedGridColumn90);
            this.gridBand3.Columns.Add(this.bandedGridColumn91);
            this.gridBand3.Columns.Add(this.bandedGridColumn92);
            this.gridBand3.Columns.Add(this.bandedGridColumn93);
            this.gridBand3.Columns.Add(this.bandedGridColumn94);
            this.gridBand3.Columns.Add(this.bandedGridColumn95);
            this.gridBand3.Columns.Add(this.bandedGridColumn96);
            this.gridBand3.Columns.Add(this.bandedGridColumn98);
            this.gridBand3.Columns.Add(this.bandedGridColumn99);
            this.gridBand3.Columns.Add(this.bandedGridColumn100);
            this.gridBand3.Columns.Add(this.bandedGridColumn103);
            this.gridBand3.Columns.Add(this.bandedGridColumn104);
            this.gridBand3.Columns.Add(this.bandedGridColumn105);
            this.gridBand3.Columns.Add(this.bandedGridColumn106);
            this.gridBand3.Columns.Add(this.bandedGridColumn107);
            this.gridBand3.MinWidth = 22;
            this.gridBand3.Name = "gridBand3";
            this.gridBand3.VisibleIndex = 0;
            this.gridBand3.Width = 2688;
            // 
            // bandedGridColumn79
            // 
            this.bandedGridColumn79.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn79.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn79.Caption = "Num";
            this.bandedGridColumn79.FieldName = "num";
            this.bandedGridColumn79.MinWidth = 42;
            this.bandedGridColumn79.Name = "bandedGridColumn79";
            this.bandedGridColumn79.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn79.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn79.Visible = true;
            this.bandedGridColumn79.Width = 57;
            // 
            // bandedGridColumn80
            // 
            this.bandedGridColumn80.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn80.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn80.Caption = "Status";
            this.bandedGridColumn80.FieldName = "status";
            this.bandedGridColumn80.MinWidth = 42;
            this.bandedGridColumn80.Name = "bandedGridColumn80";
            this.bandedGridColumn80.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn80.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn80.Width = 161;
            // 
            // bandedGridColumn81
            // 
            this.bandedGridColumn81.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn81.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn81.Caption = "Trust Company";
            this.bandedGridColumn81.FieldName = "trustCompany";
            this.bandedGridColumn81.MinWidth = 25;
            this.bandedGridColumn81.Name = "bandedGridColumn81";
            this.bandedGridColumn81.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn81.Visible = true;
            this.bandedGridColumn81.Width = 94;
            // 
            // bandedGridColumn82
            // 
            this.bandedGridColumn82.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn82.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn82.Caption = "Trust Number";
            this.bandedGridColumn82.FieldName = "contractNumber";
            this.bandedGridColumn82.MinWidth = 42;
            this.bandedGridColumn82.Name = "bandedGridColumn82";
            this.bandedGridColumn82.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn82.Visible = true;
            this.bandedGridColumn82.Width = 83;
            // 
            // bandedGridColumn83
            // 
            this.bandedGridColumn83.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn83.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn83.Caption = "Previous Trust Found";
            this.bandedGridColumn83.FieldName = "found";
            this.bandedGridColumn83.MinWidth = 25;
            this.bandedGridColumn83.Name = "bandedGridColumn83";
            this.bandedGridColumn83.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn83.Visible = true;
            this.bandedGridColumn83.Width = 79;
            // 
            // bandedGridColumn84
            // 
            this.bandedGridColumn84.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn84.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn84.Caption = "Trust Name";
            this.bandedGridColumn84.FieldName = "trustName";
            this.bandedGridColumn84.MinWidth = 42;
            this.bandedGridColumn84.Name = "bandedGridColumn84";
            this.bandedGridColumn84.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn84.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn84.Visible = true;
            this.bandedGridColumn84.Width = 257;
            // 
            // bandedGridColumn85
            // 
            this.bandedGridColumn85.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn85.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn85.Caption = "Pre / Post 2002";
            this.bandedGridColumn85.FieldName = "preOrPost";
            this.bandedGridColumn85.MinWidth = 29;
            this.bandedGridColumn85.Name = "bandedGridColumn85";
            this.bandedGridColumn85.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn85.Visible = true;
            this.bandedGridColumn85.Width = 66;
            // 
            // bandedGridColumn86
            // 
            this.bandedGridColumn86.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn86.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn86.Caption = "Policy #";
            this.bandedGridColumn86.FieldName = "policyNumber";
            this.bandedGridColumn86.MinWidth = 42;
            this.bandedGridColumn86.Name = "bandedGridColumn86";
            this.bandedGridColumn86.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn86.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn86.Visible = true;
            this.bandedGridColumn86.Width = 147;
            // 
            // bandedGridColumn87
            // 
            this.bandedGridColumn87.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn87.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn87.Caption = "Insured Name";
            this.bandedGridColumn87.FieldName = "insuredName";
            this.bandedGridColumn87.MinWidth = 47;
            this.bandedGridColumn87.Name = "bandedGridColumn87";
            this.bandedGridColumn87.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn87.Visible = true;
            this.bandedGridColumn87.Width = 174;
            // 
            // bandedGridColumn88
            // 
            this.bandedGridColumn88.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn88.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn88.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn88.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn88.Caption = "Premium";
            this.bandedGridColumn88.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn88.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn88.FieldName = "beginningPaymentBalance";
            this.bandedGridColumn88.MinWidth = 42;
            this.bandedGridColumn88.Name = "bandedGridColumn88";
            this.bandedGridColumn88.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn88.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn88.Visible = true;
            this.bandedGridColumn88.Width = 100;
            // 
            // bandedGridColumn89
            // 
            this.bandedGridColumn89.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn89.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn89.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn89.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn89.Caption = "Down Payments";
            this.bandedGridColumn89.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn89.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn89.FieldName = "downPayments";
            this.bandedGridColumn89.MinWidth = 34;
            this.bandedGridColumn89.Name = "bandedGridColumn89";
            this.bandedGridColumn89.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn89.Visible = true;
            this.bandedGridColumn89.Width = 86;
            // 
            // bandedGridColumn90
            // 
            this.bandedGridColumn90.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn90.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn90.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn90.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn90.Caption = "Payments";
            this.bandedGridColumn90.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn90.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn90.FieldName = "payments";
            this.bandedGridColumn90.MinWidth = 34;
            this.bandedGridColumn90.Name = "bandedGridColumn90";
            this.bandedGridColumn90.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn90.Visible = true;
            this.bandedGridColumn90.Width = 91;
            // 
            // bandedGridColumn91
            // 
            this.bandedGridColumn91.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn91.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn91.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn91.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn91.Caption = "Surrender";
            this.bandedGridColumn91.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn91.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn91.FieldName = "beginningDeathBenefit";
            this.bandedGridColumn91.MinWidth = 42;
            this.bandedGridColumn91.Name = "bandedGridColumn91";
            this.bandedGridColumn91.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn91.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn91.Visible = true;
            this.bandedGridColumn91.Width = 109;
            // 
            // bandedGridColumn92
            // 
            this.bandedGridColumn92.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn92.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn92.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn92.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn92.Caption = "Face Amount";
            this.bandedGridColumn92.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn92.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn92.FieldName = "endingPaymentBalance";
            this.bandedGridColumn92.MinWidth = 42;
            this.bandedGridColumn92.Name = "bandedGridColumn92";
            this.bandedGridColumn92.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn92.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn92.Visible = true;
            this.bandedGridColumn92.Width = 126;
            // 
            // bandedGridColumn93
            // 
            this.bandedGridColumn93.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn93.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn93.Caption = "Growth";
            this.bandedGridColumn93.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn93.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn93.FieldName = "growth";
            this.bandedGridColumn93.MinWidth = 25;
            this.bandedGridColumn93.Name = "bandedGridColumn93";
            this.bandedGridColumn93.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn93.Visible = true;
            this.bandedGridColumn93.Width = 94;
            // 
            // bandedGridColumn94
            // 
            this.bandedGridColumn94.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn94.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn94.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn94.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn94.Caption = "Death Benefit";
            this.bandedGridColumn94.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn94.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn94.FieldName = "endingDeathBenefit";
            this.bandedGridColumn94.MinWidth = 42;
            this.bandedGridColumn94.Name = "bandedGridColumn94";
            this.bandedGridColumn94.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn94.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn94.Visible = true;
            this.bandedGridColumn94.Width = 125;
            // 
            // bandedGridColumn95
            // 
            this.bandedGridColumn95.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn95.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn95.Caption = "Reduced Paid Up Amount";
            this.bandedGridColumn95.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn95.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn95.FieldName = "reducedPaidUpAmount";
            this.bandedGridColumn95.MinWidth = 25;
            this.bandedGridColumn95.Name = "bandedGridColumn95";
            this.bandedGridColumn95.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn95.Visible = true;
            this.bandedGridColumn95.Width = 94;
            // 
            // bandedGridColumn96
            // 
            this.bandedGridColumn96.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn96.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn96.Caption = "Death Claim Amount";
            this.bandedGridColumn96.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn96.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn96.FieldName = "deathClaimAmount";
            this.bandedGridColumn96.MinWidth = 25;
            this.bandedGridColumn96.Name = "bandedGridColumn96";
            this.bandedGridColumn96.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn96.Visible = true;
            this.bandedGridColumn96.Width = 94;
            // 
            // bandedGridColumn98
            // 
            this.bandedGridColumn98.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn98.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn98.Caption = "Death Paid Date";
            this.bandedGridColumn98.FieldName = "deathPaidDate";
            this.bandedGridColumn98.MinWidth = 25;
            this.bandedGridColumn98.Name = "bandedGridColumn98";
            this.bandedGridColumn98.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn98.Visible = true;
            this.bandedGridColumn98.Width = 94;
            // 
            // bandedGridColumn99
            // 
            this.bandedGridColumn99.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn99.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn99.Caption = "Prior Unapplied Cash";
            this.bandedGridColumn99.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn99.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn99.FieldName = "priorUnappliedCash";
            this.bandedGridColumn99.MinWidth = 25;
            this.bandedGridColumn99.Name = "bandedGridColumn99";
            this.bandedGridColumn99.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn99.Visible = true;
            this.bandedGridColumn99.Width = 94;
            // 
            // bandedGridColumn100
            // 
            this.bandedGridColumn100.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn100.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn100.Caption = "Current Unapplied Cash";
            this.bandedGridColumn100.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn100.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn100.FieldName = "currentUnappliedCash";
            this.bandedGridColumn100.MinWidth = 25;
            this.bandedGridColumn100.Name = "bandedGridColumn100";
            this.bandedGridColumn100.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn100.Visible = true;
            this.bandedGridColumn100.Width = 94;
            // 
            // bandedGridColumn103
            // 
            this.bandedGridColumn103.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn103.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn103.Caption = "Last Name";
            this.bandedGridColumn103.FieldName = "lastName";
            this.bandedGridColumn103.MinWidth = 40;
            this.bandedGridColumn103.Name = "bandedGridColumn103";
            this.bandedGridColumn103.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn103.Visible = true;
            this.bandedGridColumn103.Width = 124;
            // 
            // bandedGridColumn104
            // 
            this.bandedGridColumn104.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn104.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn104.Caption = "First Name";
            this.bandedGridColumn104.FieldName = "firstName";
            this.bandedGridColumn104.MinWidth = 40;
            this.bandedGridColumn104.Name = "bandedGridColumn104";
            this.bandedGridColumn104.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn104.Visible = true;
            this.bandedGridColumn104.Width = 115;
            // 
            // bandedGridColumn105
            // 
            this.bandedGridColumn105.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn105.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn105.Caption = "Middle Name";
            this.bandedGridColumn105.FieldName = "middleName";
            this.bandedGridColumn105.MinWidth = 40;
            this.bandedGridColumn105.Name = "bandedGridColumn105";
            this.bandedGridColumn105.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn105.Visible = true;
            this.bandedGridColumn105.Width = 103;
            // 
            // bandedGridColumn106
            // 
            this.bandedGridColumn106.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn106.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn106.Caption = "Policy Extract_Status Reason";
            this.bandedGridColumn106.FieldName = "statusReason";
            this.bandedGridColumn106.MinWidth = 25;
            this.bandedGridColumn106.Name = "bandedGridColumn106";
            this.bandedGridColumn106.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn106.Visible = true;
            this.bandedGridColumn106.Width = 94;
            // 
            // bandedGridColumn107
            // 
            this.bandedGridColumn107.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn107.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn107.Caption = "Policy Extract_Billing Reason";
            this.bandedGridColumn107.FieldName = "billingReason";
            this.bandedGridColumn107.MinWidth = 25;
            this.bandedGridColumn107.Name = "bandedGridColumn107";
            this.bandedGridColumn107.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn107.Visible = true;
            this.bandedGridColumn107.Width = 94;
            // 
            // bandedGridColumn108
            // 
            this.bandedGridColumn108.Caption = "Date";
            this.bandedGridColumn108.DisplayFormat.FormatString = "yyyyMMDD";
            this.bandedGridColumn108.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn108.FieldName = "date";
            this.bandedGridColumn108.MinWidth = 25;
            this.bandedGridColumn108.Name = "bandedGridColumn108";
            this.bandedGridColumn108.Visible = true;
            this.bandedGridColumn108.Width = 94;
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.btnImport);
            this.panelTop.Controls.Add(this.lblYear);
            this.panelTop.Controls.Add(this.cmbYear);
            this.panelTop.Controls.Add(this.lblMonth);
            this.panelTop.Controls.Add(this.cmbMonth);
            this.panelTop.Controls.Add(this.btnSave);
            this.panelTop.Controls.Add(this.pictureBox1);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1659, 47);
            this.panelTop.TabIndex = 7;
            // 
            // btnImport
            // 
            this.btnImport.BackColor = System.Drawing.Color.Transparent;
            this.btnImport.Location = new System.Drawing.Point(91, 10);
            this.btnImport.Name = "btnImport";
            this.btnImport.Size = new System.Drawing.Size(90, 29);
            this.btnImport.TabIndex = 155;
            this.btnImport.Text = "Import";
            this.btnImport.UseVisualStyleBackColor = false;
            this.btnImport.Click += new System.EventHandler(this.btnImport_Click);
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Location = new System.Drawing.Point(667, 18);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(35, 17);
            this.lblYear.TabIndex = 154;
            this.lblYear.Text = "Year";
            // 
            // cmbYear
            // 
            this.cmbYear.FormattingEnabled = true;
            this.cmbYear.Location = new System.Drawing.Point(577, 13);
            this.cmbYear.Name = "cmbYear";
            this.cmbYear.Size = new System.Drawing.Size(73, 24);
            this.cmbYear.TabIndex = 153;
            // 
            // lblMonth
            // 
            this.lblMonth.AutoSize = true;
            this.lblMonth.Location = new System.Drawing.Point(524, 17);
            this.lblMonth.Name = "lblMonth";
            this.lblMonth.Size = new System.Drawing.Size(47, 17);
            this.lblMonth.TabIndex = 152;
            this.lblMonth.Text = "Month";
            // 
            // cmbMonth
            // 
            this.cmbMonth.FormattingEnabled = true;
            this.cmbMonth.Location = new System.Drawing.Point(400, 13);
            this.cmbMonth.Name = "cmbMonth";
            this.cmbMonth.Size = new System.Drawing.Size(120, 24);
            this.cmbMonth.TabIndex = 151;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSave.Location = new System.Drawing.Point(286, 14);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 150;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 27);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 146;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // ImportTrustFile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1659, 384);
            this.Controls.Add(this.panelAll);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "ImportTrustFile";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Import Trust Information";
            this.Load += new System.EventHandler(this.ImportTrustFile_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelAll.ResumeLayout(false);
            this.panelBottom.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain4)).EndInit();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Panel panelAll;
        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevExpress.XtraGrid.GridControl dgv;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn12;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn13;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn6;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.ComboBox cmbYear;
        private System.Windows.Forms.Label lblMonth;
        private System.Windows.Forms.ComboBox cmbMonth;
        private System.Windows.Forms.Button btnImport;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn7;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn11;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn9;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn15;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn14;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn16;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn17;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn19;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn18;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn21;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn20;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn22;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn23;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem locateContractNumberToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn24;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn97;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn101;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn102;
        private DevExpress.XtraGrid.GridControl dgv2;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain2;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn25;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn26;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn27;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn28;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn29;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn30;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn31;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn32;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn33;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn34;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn35;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn36;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn37;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn38;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn39;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn40;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn41;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn42;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn43;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn44;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn45;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn46;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn47;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn48;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn49;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn50;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn51;
        private DevExpress.XtraGrid.GridControl dgv3;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain3;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn52;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn53;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn54;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn55;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn56;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn57;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn58;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn59;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn60;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn61;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn62;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn63;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn64;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn65;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn66;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn67;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn68;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn69;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn70;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn71;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn72;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn73;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn74;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn75;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn76;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn77;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn78;
        private DevExpress.XtraGrid.GridControl dgv4;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain4;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn79;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn80;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn81;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn82;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn83;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn84;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn85;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn86;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn87;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn88;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn89;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn90;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn91;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn92;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn93;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn94;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn95;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn96;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn98;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn99;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn100;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn103;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn104;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn105;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn106;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn107;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn108;
    }
}