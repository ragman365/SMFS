﻿namespace SMFS
{
    partial class Trust85
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Trust85));
            this.panelAll = new System.Windows.Forms.Panel();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgv = new DevExpress.XtraGrid.GridControl();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.excludeDBRFromTrustsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gridMain = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand1 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.Num = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn4 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn16 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn14 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn17 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn13 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn100 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn2 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn7 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn35 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn221 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn15 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn274 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.cnum = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn5 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn223 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn224 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn186 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn230 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn12 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn101 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn31 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn30 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn10 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn3 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn29 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn62 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn61 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.interestPaid = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn11 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn107 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn176 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn184 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn6 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn235 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn63 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn64 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn9 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn8 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn189 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn92 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn91 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn104 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.t_lapseContract = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.t_reinstateContract = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn1 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.tabLocations = new System.Windows.Forms.TabPage();
            this.panelBAll = new System.Windows.Forms.Panel();
            this.panelBBottom = new System.Windows.Forms.Panel();
            this.dgv2 = new DevExpress.XtraGrid.GridControl();
            this.gridMain2 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand2 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn18 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn19 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn20 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn21 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn22 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.contractValue29 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.cashAdvance185 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.downPayment30 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn32 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.paymentAmount31 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn87 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.totalPayments32 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.ibTrust87 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.spTrust88 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.xxTrust106 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.total89 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn36 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelBTop = new System.Windows.Forms.Panel();
            this.chkReverseAgentsAndLocations = new System.Windows.Forms.CheckBox();
            this.chkShowOnlyContractValues = new System.Windows.Forms.CheckBox();
            this.chkAgentByLocationTotalLocations = new System.Windows.Forms.CheckBox();
            this.tabAgentLocations = new System.Windows.Forms.TabPage();
            this.panelLAAll = new System.Windows.Forms.Panel();
            this.panelLABottom = new System.Windows.Forms.Panel();
            this.dgv4 = new DevExpress.XtraGrid.GridControl();
            this.gridMain4 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand4 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn38 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn39 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn40 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn41 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn42 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn43 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn44 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn89 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn45 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn88 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn46 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.ibtrust275 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.sptrust276 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.xxtrust277 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.totalTrusts278 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn47 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelLATop = new System.Windows.Forms.Panel();
            this.chkLocationTotal = new System.Windows.Forms.CheckBox();
            this.tabAgentTotals = new System.Windows.Forms.TabPage();
            this.panel3All = new System.Windows.Forms.Panel();
            this.panel3Bottom = new System.Windows.Forms.Panel();
            this.dgv3 = new DevExpress.XtraGrid.GridControl();
            this.gridMain3 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand3 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn23 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn90 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn24 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn25 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn110 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn231 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn232 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn26 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn27 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.contractValue28 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn108 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn106 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.downPayment33 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.dpr276 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.dbc28 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.dbc_5_277 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.fbi234 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.fbiCommission235 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.paymentAmount34 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn185 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn275 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.debit233 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.credit234 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.interestPaid58 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.totalPayments35 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.SplitDownPayment58 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.CashAdvance275 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.SplitPayment58 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn59 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.recapAmount58 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.commission231 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn273 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn37 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn28 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn33 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn34 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panel3Top = new System.Windows.Forms.Panel();
            this.chkToggleGroups = new System.Windows.Forms.CheckBox();
            this.btnMatch = new System.Windows.Forms.Button();
            this.chkCollapes = new System.Windows.Forms.CheckBox();
            this.chkShowCommissions = new System.Windows.Forms.CheckBox();
            this.chkSummarize = new System.Windows.Forms.CheckBox();
            this.chkNoSummary = new System.Windows.Forms.CheckBox();
            this.chkMonthly = new System.Windows.Forms.CheckBox();
            this.tabLocationTotals = new System.Windows.Forms.TabPage();
            this.panel5All = new System.Windows.Forms.Panel();
            this.panel5Bottom = new System.Windows.Forms.Panel();
            this.dgv5 = new DevExpress.XtraGrid.GridControl();
            this.gridMain5 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand5 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn48 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn49 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn50 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn51 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn52 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn53 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn276 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn54 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn277 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn55 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn56 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn74 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn75 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn85 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn109 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn86 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn58 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn57 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panel5Top = new System.Windows.Forms.Panel();
            this.cmbLocationTotals = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            this.tabContractLocations = new System.Windows.Forms.TabPage();
            this.dgv7 = new DevExpress.XtraGrid.GridControl();
            this.gridMain7 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand7 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn93 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn94 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn95 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn96 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn98 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn102 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn103 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn99 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn97 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.contractValue98 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn278 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.downPayment99 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn279 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.paymentAmount100 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.totalPayments100 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.ibtrust102 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.sptrust103 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.xxtrust104 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.total104 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn105 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.tabLapse = new System.Windows.Forms.TabPage();
            this.dgv8 = new DevExpress.XtraGrid.GridControl();
            this.gridMain8 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand8 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn111 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn112 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn113 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn114 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn115 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn116 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn117 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn118 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn119 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn120 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn121 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn122 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn123 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn124 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn125 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn126 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn136 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn137 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn138 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn139 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn127 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn128 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn129 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn130 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn131 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn132 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn133 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn134 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn140 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn142 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn141 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn234 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn135 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.tabReinstate = new System.Windows.Forms.TabPage();
            this.dgv9 = new DevExpress.XtraGrid.GridControl();
            this.gridMain9 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand9 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn143 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn144 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn145 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn146 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn147 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn148 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn149 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn60 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn150 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn151 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn152 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn153 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn225 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn226 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn154 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn155 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn156 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn175 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn157 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn158 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn159 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn160 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn161 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn162 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn163 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn164 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn165 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn166 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn167 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn168 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn169 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn170 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn171 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn172 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn173 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn174 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.tabCombined = new System.Windows.Forms.TabPage();
            this.dgv12 = new DevExpress.XtraGrid.GridControl();
            this.gridMain12 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand12 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn237 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn238 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn239 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn240 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn241 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn242 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn243 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn244 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn245 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn246 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn247 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn248 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn249 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn250 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn251 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn252 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn253 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn254 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn255 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn256 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn257 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn258 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn259 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn260 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn261 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn262 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn263 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn264 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn265 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn266 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn267 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn268 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn269 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn270 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn271 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn272 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.tabCommission = new System.Windows.Forms.TabPage();
            this.panelCommAll = new System.Windows.Forms.Panel();
            this.panelCommBottom = new System.Windows.Forms.Panel();
            this.dgv10 = new DevExpress.XtraGrid.GridControl();
            this.gridMain10 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand6 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.gridBand10 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn65 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn66 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn67 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn233 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn68 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn69 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn70 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn73 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn236 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn229 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn71 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn72 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn227 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn187 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn84 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn76 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn77 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn78 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn188 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn79 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn80 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn81 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn82 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn228 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn83 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn222 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn177 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn178 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn179 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn180 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn181 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn182 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn183 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelCommTop = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.btnChart = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbShow = new System.Windows.Forms.ComboBox();
            this.btnPrintAll = new System.Windows.Forms.Button();
            this.cmbSelectCommission = new System.Windows.Forms.ComboBox();
            this.btnSelectCommission = new System.Windows.Forms.Button();
            this.btnSaveCommissions = new System.Windows.Forms.Button();
            this.chkDoSplits = new System.Windows.Forms.CheckBox();
            this.btnRunCommissions = new System.Windows.Forms.Button();
            this.chkConsolidate = new System.Windows.Forms.CheckBox();
            this.tabDebugTrusts = new System.Windows.Forms.TabPage();
            this.panelDebugAll = new System.Windows.Forms.Panel();
            this.panelDebugBottom = new System.Windows.Forms.Panel();
            this.dgv11 = new DevExpress.XtraGrid.GridControl();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.recalcTrust85ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gridMain11 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand11 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn190 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn192 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn191 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn193 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn194 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn195 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn205 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn215 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn216 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn219 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn220 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn207 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn196 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn197 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn198 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn199 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn212 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn200 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn201 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn202 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn203 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn204 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn206 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn208 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn209 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn210 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn211 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn213 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn214 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.calcTrust85_215 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.difference_216 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn217 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn218 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelDebugTop = new System.Windows.Forms.Panel();
            this.chkOnlyCurrent = new System.Windows.Forms.CheckBox();
            this.chkShowLocations = new System.Windows.Forms.CheckBox();
            this.chkExpand = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.chk2002 = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.btnRunDiff = new System.Windows.Forms.Button();
            this.panelTop = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.cmbRunOn = new System.Windows.Forms.ComboBox();
            this.btnCombine = new DevExpress.XtraEditors.SimpleButton();
            this.barImport = new System.Windows.Forms.ProgressBar();
            this.chkACH = new System.Windows.Forms.CheckBox();
            this.chkMainDoSplits = new System.Windows.Forms.CheckBox();
            this.cmbSelectColumns = new System.Windows.Forms.ComboBox();
            this.btnSelectColumns = new System.Windows.Forms.Button();
            this.chkDBR = new System.Windows.Forms.CheckBox();
            this.chkFilterNewContracts = new System.Windows.Forms.CheckBox();
            this.btnExcel = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioXLSX = new System.Windows.Forms.RadioButton();
            this.radioXLS = new System.Windows.Forms.RadioButton();
            this.chkPresent = new System.Windows.Forms.CheckBox();
            this.chkComboAgentNames = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            this.chkComboLocNames = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            this.label6 = new System.Windows.Forms.Label();
            this.chkComboTrust = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            this.label5 = new System.Windows.Forms.Label();
            this.chkComboLocation = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            this.btnRight = new System.Windows.Forms.Button();
            this.lblAgent = new System.Windows.Forms.Label();
            this.chkComboAgent = new DevExpress.XtraEditors.CheckedComboBoxEdit();
            this.btnLeft = new System.Windows.Forms.Button();
            this.btnCalc = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.btnRun = new System.Windows.Forms.Button();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.columnsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trustReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historicCommissionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agentsPieChartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportGenerator1 = new DevExpress.XtraReports.ReportGeneration.ReportGenerator(this.components);
            this.panelAll.SuspendLayout();
            this.panelBottom.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).BeginInit();
            this.tabLocations.SuspendLayout();
            this.panelBAll.SuspendLayout();
            this.panelBBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).BeginInit();
            this.panelBTop.SuspendLayout();
            this.tabAgentLocations.SuspendLayout();
            this.panelLAAll.SuspendLayout();
            this.panelLABottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain4)).BeginInit();
            this.panelLATop.SuspendLayout();
            this.tabAgentTotals.SuspendLayout();
            this.panel3All.SuspendLayout();
            this.panel3Bottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).BeginInit();
            this.panel3Top.SuspendLayout();
            this.tabLocationTotals.SuspendLayout();
            this.panel5All.SuspendLayout();
            this.panel5Bottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain5)).BeginInit();
            this.panel5Top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbLocationTotals.Properties)).BeginInit();
            this.tabContractLocations.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain7)).BeginInit();
            this.tabLapse.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain8)).BeginInit();
            this.tabReinstate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain9)).BeginInit();
            this.tabCombined.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain12)).BeginInit();
            this.tabCommission.SuspendLayout();
            this.panelCommAll.SuspendLayout();
            this.panelCommBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain10)).BeginInit();
            this.panelCommTop.SuspendLayout();
            this.tabDebugTrusts.SuspendLayout();
            this.panelDebugAll.SuspendLayout();
            this.panelDebugBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv11)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain11)).BeginInit();
            this.panelDebugTop.SuspendLayout();
            this.panelTop.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboAgentNames.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboLocNames.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboTrust.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboLocation.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboAgent.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelAll
            // 
            this.panelAll.Controls.Add(this.panelBottom);
            this.panelAll.Controls.Add(this.panelTop);
            this.panelAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAll.Location = new System.Drawing.Point(0, 30);
            this.panelAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelAll.Name = "panelAll";
            this.panelAll.Size = new System.Drawing.Size(1403, 532);
            this.panelAll.TabIndex = 0;
            // 
            // panelBottom
            // 
            this.panelBottom.Controls.Add(this.tabControl1);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBottom.Location = new System.Drawing.Point(0, 123);
            this.panelBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(1403, 409);
            this.panelBottom.TabIndex = 2;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabLocations);
            this.tabControl1.Controls.Add(this.tabAgentLocations);
            this.tabControl1.Controls.Add(this.tabAgentTotals);
            this.tabControl1.Controls.Add(this.tabLocationTotals);
            this.tabControl1.Controls.Add(this.tabContractLocations);
            this.tabControl1.Controls.Add(this.tabLapse);
            this.tabControl1.Controls.Add(this.tabReinstate);
            this.tabControl1.Controls.Add(this.tabCombined);
            this.tabControl1.Controls.Add(this.tabCommission);
            this.tabControl1.Controls.Add(this.tabDebugTrusts);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1403, 409);
            this.tabControl1.TabIndex = 5;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgv);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(1395, 380);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Details";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgv
            // 
            this.dgv.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv.Location = new System.Drawing.Point(3, 4);
            this.dgv.LookAndFeel.SkinName = "iMaginary";
            this.dgv.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv.MainView = this.gridMain;
            this.dgv.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv.Name = "dgv";
            this.dgv.Size = new System.Drawing.Size(1389, 372);
            this.dgv.TabIndex = 4;
            this.dgv.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain});
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.excludeDBRFromTrustsToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(240, 28);
            // 
            // excludeDBRFromTrustsToolStripMenuItem
            // 
            this.excludeDBRFromTrustsToolStripMenuItem.Name = "excludeDBRFromTrustsToolStripMenuItem";
            this.excludeDBRFromTrustsToolStripMenuItem.Size = new System.Drawing.Size(239, 24);
            this.excludeDBRFromTrustsToolStripMenuItem.Text = "Exclude DBR from Trusts";
            this.excludeDBRFromTrustsToolStripMenuItem.Click += new System.EventHandler(this.excludeDBRFromTrustsToolStripMenuItem_Click);
            // 
            // gridMain
            // 
            this.gridMain.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.Row.Options.UseBackColor = true;
            this.gridMain.Appearance.Row.Options.UseForeColor = true;
            this.gridMain.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand1});
            this.gridMain.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.Num,
            this.bandedGridColumn1,
            this.cnum,
            this.bandedGridColumn100,
            this.bandedGridColumn230,
            this.bandedGridColumn5,
            this.bandedGridColumn223,
            this.bandedGridColumn224,
            this.bandedGridColumn3,
            this.bandedGridColumn62,
            this.bandedGridColumn61,
            this.interestPaid,
            this.bandedGridColumn7,
            this.bandedGridColumn35,
            this.bandedGridColumn221,
            this.bandedGridColumn2,
            this.bandedGridColumn8,
            this.bandedGridColumn9,
            this.bandedGridColumn4,
            this.bandedGridColumn6,
            this.bandedGridColumn10,
            this.bandedGridColumn11,
            this.bandedGridColumn12,
            this.bandedGridColumn13,
            this.bandedGridColumn14,
            this.bandedGridColumn15,
            this.bandedGridColumn16,
            this.bandedGridColumn17,
            this.bandedGridColumn92,
            this.bandedGridColumn91,
            this.bandedGridColumn104,
            this.bandedGridColumn101,
            this.bandedGridColumn63,
            this.bandedGridColumn107,
            this.bandedGridColumn184,
            this.bandedGridColumn64,
            this.bandedGridColumn176,
            this.t_lapseContract,
            this.t_reinstateContract,
            this.bandedGridColumn186,
            this.bandedGridColumn189,
            this.bandedGridColumn235,
            this.bandedGridColumn274,
            this.bandedGridColumn29,
            this.bandedGridColumn30,
            this.bandedGridColumn31});
            this.gridMain.DetailHeight = 431;
            this.gridMain.GridControl = this.dgv;
            this.gridMain.Name = "gridMain";
            this.gridMain.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain.OptionsPrint.AllowMultilineHeaders = true;
            this.gridMain.OptionsPrint.PrintBandHeader = false;
            this.gridMain.OptionsSelection.MultiSelect = true;
            this.gridMain.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain.OptionsView.ShowBands = false;
            this.gridMain.OptionsView.ShowFooter = true;
            this.gridMain.OptionsView.ShowGroupPanel = false;
            this.gridMain.PaintStyleName = "Style3D";
            this.gridMain.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMain_CustomDrawCell);
            this.gridMain.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMain_CellValueChanged);
            this.gridMain.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMain_CustomRowFilter);
            this.gridMain.DoubleClick += new System.EventHandler(this.gridMain_DoubleClick);
            // 
            // gridBand1
            // 
            this.gridBand1.Caption = "gridBand1";
            this.gridBand1.Columns.Add(this.Num);
            this.gridBand1.Columns.Add(this.bandedGridColumn4);
            this.gridBand1.Columns.Add(this.bandedGridColumn16);
            this.gridBand1.Columns.Add(this.bandedGridColumn14);
            this.gridBand1.Columns.Add(this.bandedGridColumn17);
            this.gridBand1.Columns.Add(this.bandedGridColumn13);
            this.gridBand1.Columns.Add(this.bandedGridColumn100);
            this.gridBand1.Columns.Add(this.bandedGridColumn2);
            this.gridBand1.Columns.Add(this.bandedGridColumn7);
            this.gridBand1.Columns.Add(this.bandedGridColumn35);
            this.gridBand1.Columns.Add(this.bandedGridColumn221);
            this.gridBand1.Columns.Add(this.bandedGridColumn15);
            this.gridBand1.Columns.Add(this.bandedGridColumn274);
            this.gridBand1.Columns.Add(this.cnum);
            this.gridBand1.Columns.Add(this.bandedGridColumn5);
            this.gridBand1.Columns.Add(this.bandedGridColumn223);
            this.gridBand1.Columns.Add(this.bandedGridColumn224);
            this.gridBand1.Columns.Add(this.bandedGridColumn186);
            this.gridBand1.Columns.Add(this.bandedGridColumn230);
            this.gridBand1.Columns.Add(this.bandedGridColumn12);
            this.gridBand1.Columns.Add(this.bandedGridColumn101);
            this.gridBand1.Columns.Add(this.bandedGridColumn31);
            this.gridBand1.Columns.Add(this.bandedGridColumn30);
            this.gridBand1.Columns.Add(this.bandedGridColumn10);
            this.gridBand1.Columns.Add(this.bandedGridColumn3);
            this.gridBand1.Columns.Add(this.bandedGridColumn29);
            this.gridBand1.Columns.Add(this.bandedGridColumn62);
            this.gridBand1.Columns.Add(this.bandedGridColumn61);
            this.gridBand1.Columns.Add(this.interestPaid);
            this.gridBand1.Columns.Add(this.bandedGridColumn11);
            this.gridBand1.Columns.Add(this.bandedGridColumn107);
            this.gridBand1.Columns.Add(this.bandedGridColumn176);
            this.gridBand1.Columns.Add(this.bandedGridColumn184);
            this.gridBand1.Columns.Add(this.bandedGridColumn6);
            this.gridBand1.Columns.Add(this.bandedGridColumn235);
            this.gridBand1.Columns.Add(this.bandedGridColumn63);
            this.gridBand1.Columns.Add(this.bandedGridColumn64);
            this.gridBand1.Columns.Add(this.bandedGridColumn9);
            this.gridBand1.Columns.Add(this.bandedGridColumn8);
            this.gridBand1.Columns.Add(this.bandedGridColumn189);
            this.gridBand1.Columns.Add(this.bandedGridColumn92);
            this.gridBand1.Columns.Add(this.bandedGridColumn91);
            this.gridBand1.Columns.Add(this.bandedGridColumn104);
            this.gridBand1.Columns.Add(this.t_lapseContract);
            this.gridBand1.Columns.Add(this.t_reinstateContract);
            this.gridBand1.Columns.Add(this.bandedGridColumn1);
            this.gridBand1.MinWidth = 12;
            this.gridBand1.Name = "gridBand1";
            this.gridBand1.VisibleIndex = 0;
            this.gridBand1.Width = 3224;
            // 
            // Num
            // 
            this.Num.Caption = "Num";
            this.Num.FieldName = "num";
            this.Num.MinWidth = 23;
            this.Num.Name = "Num";
            this.Num.OptionsColumn.AllowEdit = false;
            this.Num.OptionsColumn.FixedWidth = true;
            this.Num.Visible = true;
            this.Num.Width = 52;
            // 
            // bandedGridColumn4
            // 
            this.bandedGridColumn4.Caption = "Agent";
            this.bandedGridColumn4.FieldName = "agentNumber";
            this.bandedGridColumn4.MinWidth = 23;
            this.bandedGridColumn4.Name = "bandedGridColumn4";
            this.bandedGridColumn4.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn4.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn4.Visible = true;
            this.bandedGridColumn4.Width = 70;
            // 
            // bandedGridColumn16
            // 
            this.bandedGridColumn16.Caption = "Agent Name";
            this.bandedGridColumn16.FieldName = "agentName";
            this.bandedGridColumn16.MinWidth = 23;
            this.bandedGridColumn16.Name = "bandedGridColumn16";
            this.bandedGridColumn16.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn16.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn16.Visible = true;
            this.bandedGridColumn16.Width = 87;
            // 
            // bandedGridColumn14
            // 
            this.bandedGridColumn14.Caption = "Loc";
            this.bandedGridColumn14.FieldName = "loc";
            this.bandedGridColumn14.MinWidth = 23;
            this.bandedGridColumn14.Name = "bandedGridColumn14";
            this.bandedGridColumn14.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn14.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn14.Visible = true;
            this.bandedGridColumn14.Width = 47;
            // 
            // bandedGridColumn17
            // 
            this.bandedGridColumn17.Caption = "Location Name";
            this.bandedGridColumn17.FieldName = "Location Name";
            this.bandedGridColumn17.MinWidth = 23;
            this.bandedGridColumn17.Name = "bandedGridColumn17";
            this.bandedGridColumn17.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn17.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn17.Width = 87;
            // 
            // bandedGridColumn13
            // 
            this.bandedGridColumn13.Caption = "Trust";
            this.bandedGridColumn13.FieldName = "trust";
            this.bandedGridColumn13.MinWidth = 23;
            this.bandedGridColumn13.Name = "bandedGridColumn13";
            this.bandedGridColumn13.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn13.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn13.Visible = true;
            this.bandedGridColumn13.Width = 58;
            // 
            // bandedGridColumn100
            // 
            this.bandedGridColumn100.Caption = "DBR";
            this.bandedGridColumn100.FieldName = "dbr";
            this.bandedGridColumn100.MinWidth = 23;
            this.bandedGridColumn100.Name = "bandedGridColumn100";
            this.bandedGridColumn100.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn100.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn100.Visible = true;
            this.bandedGridColumn100.Width = 58;
            // 
            // bandedGridColumn2
            // 
            this.bandedGridColumn2.Caption = "Due Date";
            this.bandedGridColumn2.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn2.FieldName = "dueDate8";
            this.bandedGridColumn2.MinWidth = 23;
            this.bandedGridColumn2.Name = "bandedGridColumn2";
            this.bandedGridColumn2.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn2.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn2.Visible = true;
            this.bandedGridColumn2.Width = 76;
            // 
            // bandedGridColumn7
            // 
            this.bandedGridColumn7.Caption = "Date Paid";
            this.bandedGridColumn7.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn7.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn7.FieldName = "payDate8";
            this.bandedGridColumn7.MinWidth = 23;
            this.bandedGridColumn7.Name = "bandedGridColumn7";
            this.bandedGridColumn7.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn7.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn7.Visible = true;
            this.bandedGridColumn7.Width = 76;
            // 
            // bandedGridColumn35
            // 
            this.bandedGridColumn35.Caption = "Sorted PayDate8";
            this.bandedGridColumn35.FieldName = "sortedPayDate8";
            this.bandedGridColumn35.MinWidth = 23;
            this.bandedGridColumn35.Name = "bandedGridColumn35";
            this.bandedGridColumn35.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn35.Width = 87;
            // 
            // bandedGridColumn221
            // 
            this.bandedGridColumn221.Caption = "Deposit Number";
            this.bandedGridColumn221.FieldName = "depositNumber";
            this.bandedGridColumn221.MinWidth = 23;
            this.bandedGridColumn221.Name = "bandedGridColumn221";
            this.bandedGridColumn221.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn221.Visible = true;
            this.bandedGridColumn221.Width = 87;
            // 
            // bandedGridColumn15
            // 
            this.bandedGridColumn15.Caption = "Issue Date";
            this.bandedGridColumn15.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn15.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn15.FieldName = "issueDate8";
            this.bandedGridColumn15.MinWidth = 23;
            this.bandedGridColumn15.Name = "bandedGridColumn15";
            this.bandedGridColumn15.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn15.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn15.Visible = true;
            this.bandedGridColumn15.Width = 87;
            // 
            // bandedGridColumn274
            // 
            this.bandedGridColumn274.Caption = "Deceased Date";
            this.bandedGridColumn274.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn274.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn274.FieldName = "deceasedDate";
            this.bandedGridColumn274.MinWidth = 23;
            this.bandedGridColumn274.Name = "bandedGridColumn274";
            this.bandedGridColumn274.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn274.Width = 87;
            // 
            // cnum
            // 
            this.cnum.Caption = "Contract";
            this.cnum.FieldName = "contractNumber";
            this.cnum.MinWidth = 23;
            this.cnum.Name = "cnum";
            this.cnum.OptionsColumn.AllowEdit = false;
            this.cnum.OptionsColumn.FixedWidth = true;
            this.cnum.Visible = true;
            this.cnum.Width = 82;
            // 
            // bandedGridColumn5
            // 
            this.bandedGridColumn5.Caption = "Customer";
            this.bandedGridColumn5.FieldName = "customer";
            this.bandedGridColumn5.MinWidth = 23;
            this.bandedGridColumn5.Name = "bandedGridColumn5";
            this.bandedGridColumn5.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn5.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn5.Visible = true;
            this.bandedGridColumn5.Width = 175;
            // 
            // bandedGridColumn223
            // 
            this.bandedGridColumn223.Caption = "Last Name";
            this.bandedGridColumn223.FieldName = "lastName";
            this.bandedGridColumn223.MinWidth = 23;
            this.bandedGridColumn223.Name = "bandedGridColumn223";
            this.bandedGridColumn223.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn223.Width = 87;
            // 
            // bandedGridColumn224
            // 
            this.bandedGridColumn224.Caption = "First Name";
            this.bandedGridColumn224.FieldName = "firstName";
            this.bandedGridColumn224.MinWidth = 23;
            this.bandedGridColumn224.Name = "bandedGridColumn224";
            this.bandedGridColumn224.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn224.Width = 87;
            // 
            // bandedGridColumn186
            // 
            this.bandedGridColumn186.Caption = "FBI";
            this.bandedGridColumn186.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn186.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn186.FieldName = "fbi";
            this.bandedGridColumn186.MinWidth = 23;
            this.bandedGridColumn186.Name = "bandedGridColumn186";
            this.bandedGridColumn186.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn186.Visible = true;
            this.bandedGridColumn186.Width = 47;
            // 
            // bandedGridColumn230
            // 
            this.bandedGridColumn230.Caption = "DBC";
            this.bandedGridColumn230.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn230.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn230.FieldName = "dbc";
            this.bandedGridColumn230.MinWidth = 23;
            this.bandedGridColumn230.Name = "bandedGridColumn230";
            this.bandedGridColumn230.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn230.Visible = true;
            this.bandedGridColumn230.Width = 87;
            // 
            // bandedGridColumn12
            // 
            this.bandedGridColumn12.Caption = "Contract Value";
            this.bandedGridColumn12.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn12.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn12.FieldName = "contractValue";
            this.bandedGridColumn12.MinWidth = 23;
            this.bandedGridColumn12.Name = "bandedGridColumn12";
            this.bandedGridColumn12.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn12.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn12.Visible = true;
            this.bandedGridColumn12.Width = 117;
            // 
            // bandedGridColumn101
            // 
            this.bandedGridColumn101.Caption = "Cash Adv";
            this.bandedGridColumn101.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn101.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn101.FieldName = "cashAdvance";
            this.bandedGridColumn101.MinWidth = 23;
            this.bandedGridColumn101.Name = "bandedGridColumn101";
            this.bandedGridColumn101.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn101.Visible = true;
            this.bandedGridColumn101.Width = 87;
            // 
            // bandedGridColumn31
            // 
            this.bandedGridColumn31.Caption = "Actual Down Payment";
            this.bandedGridColumn31.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn31.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn31.FieldName = "dpp";
            this.bandedGridColumn31.MinWidth = 24;
            this.bandedGridColumn31.Name = "bandedGridColumn31";
            this.bandedGridColumn31.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn31.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn31.Visible = true;
            this.bandedGridColumn31.Width = 96;
            // 
            // bandedGridColumn30
            // 
            this.bandedGridColumn30.Caption = "Actual Payment";
            this.bandedGridColumn30.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn30.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn30.FieldName = "ap";
            this.bandedGridColumn30.MinWidth = 24;
            this.bandedGridColumn30.Name = "bandedGridColumn30";
            this.bandedGridColumn30.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn30.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn30.Visible = true;
            this.bandedGridColumn30.Width = 87;
            // 
            // bandedGridColumn10
            // 
            this.bandedGridColumn10.Caption = "Down Payment";
            this.bandedGridColumn10.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn10.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn10.FieldName = "downPayment";
            this.bandedGridColumn10.MinWidth = 23;
            this.bandedGridColumn10.Name = "bandedGridColumn10";
            this.bandedGridColumn10.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn10.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn10.Visible = true;
            this.bandedGridColumn10.Width = 96;
            // 
            // bandedGridColumn3
            // 
            this.bandedGridColumn3.Caption = "Payment";
            this.bandedGridColumn3.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn3.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn3.FieldName = "paymentAmount";
            this.bandedGridColumn3.MinWidth = 23;
            this.bandedGridColumn3.Name = "bandedGridColumn3";
            this.bandedGridColumn3.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn3.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn3.Visible = true;
            this.bandedGridColumn3.Width = 87;
            // 
            // bandedGridColumn29
            // 
            this.bandedGridColumn29.Caption = "CC Fee";
            this.bandedGridColumn29.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn29.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn29.FieldName = "ccFee";
            this.bandedGridColumn29.MinWidth = 24;
            this.bandedGridColumn29.Name = "bandedGridColumn29";
            this.bandedGridColumn29.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn29.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn29.Visible = true;
            this.bandedGridColumn29.Width = 59;
            // 
            // bandedGridColumn62
            // 
            this.bandedGridColumn62.Caption = "Debit";
            this.bandedGridColumn62.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn62.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn62.FieldName = "debit";
            this.bandedGridColumn62.MinWidth = 23;
            this.bandedGridColumn62.Name = "bandedGridColumn62";
            this.bandedGridColumn62.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn62.Visible = true;
            this.bandedGridColumn62.Width = 87;
            // 
            // bandedGridColumn61
            // 
            this.bandedGridColumn61.Caption = "Credit";
            this.bandedGridColumn61.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn61.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn61.FieldName = "credit";
            this.bandedGridColumn61.MinWidth = 23;
            this.bandedGridColumn61.Name = "bandedGridColumn61";
            this.bandedGridColumn61.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn61.Visible = true;
            this.bandedGridColumn61.Width = 87;
            // 
            // interestPaid
            // 
            this.interestPaid.Caption = "Interest";
            this.interestPaid.FieldName = "interestPaid";
            this.interestPaid.MinWidth = 23;
            this.interestPaid.Name = "interestPaid";
            this.interestPaid.OptionsColumn.FixedWidth = true;
            this.interestPaid.Visible = true;
            this.interestPaid.Width = 87;
            // 
            // bandedGridColumn11
            // 
            this.bandedGridColumn11.Caption = "Total Payments";
            this.bandedGridColumn11.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn11.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn11.FieldName = "totalPayments";
            this.bandedGridColumn11.MinWidth = 23;
            this.bandedGridColumn11.Name = "bandedGridColumn11";
            this.bandedGridColumn11.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn11.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn11.Visible = true;
            this.bandedGridColumn11.Width = 96;
            // 
            // bandedGridColumn107
            // 
            this.bandedGridColumn107.Caption = "Recap";
            this.bandedGridColumn107.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn107.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn107.FieldName = "Recap";
            this.bandedGridColumn107.MinWidth = 23;
            this.bandedGridColumn107.Name = "bandedGridColumn107";
            this.bandedGridColumn107.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn107.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn107.Visible = true;
            this.bandedGridColumn107.Width = 87;
            // 
            // bandedGridColumn176
            // 
            this.bandedGridColumn176.Caption = "Re-Ins";
            this.bandedGridColumn176.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn176.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn176.FieldName = "Reins";
            this.bandedGridColumn176.MinWidth = 23;
            this.bandedGridColumn176.Name = "bandedGridColumn176";
            this.bandedGridColumn176.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn176.Visible = true;
            this.bandedGridColumn176.Width = 87;
            // 
            // bandedGridColumn184
            // 
            this.bandedGridColumn184.Caption = "Recap Contracts";
            this.bandedGridColumn184.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn184.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn184.FieldName = "RecapContracts";
            this.bandedGridColumn184.MinWidth = 23;
            this.bandedGridColumn184.Name = "bandedGridColumn184";
            this.bandedGridColumn184.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn184.Visible = true;
            this.bandedGridColumn184.Width = 87;
            // 
            // bandedGridColumn6
            // 
            this.bandedGridColumn6.Caption = "Commission";
            this.bandedGridColumn6.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn6.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn6.FieldName = "commission";
            this.bandedGridColumn6.MinWidth = 23;
            this.bandedGridColumn6.Name = "bandedGridColumn6";
            this.bandedGridColumn6.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn6.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn6.Width = 111;
            // 
            // bandedGridColumn235
            // 
            this.bandedGridColumn235.Caption = "DBC Money";
            this.bandedGridColumn235.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn235.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn235.FieldName = "dbcMoney";
            this.bandedGridColumn235.MinWidth = 23;
            this.bandedGridColumn235.Name = "bandedGridColumn235";
            this.bandedGridColumn235.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn235.Width = 87;
            // 
            // bandedGridColumn63
            // 
            this.bandedGridColumn63.Caption = "Lapse Date";
            this.bandedGridColumn63.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn63.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn63.FieldName = "lapseDate8";
            this.bandedGridColumn63.MinWidth = 23;
            this.bandedGridColumn63.Name = "bandedGridColumn63";
            this.bandedGridColumn63.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn63.Visible = true;
            this.bandedGridColumn63.Width = 87;
            // 
            // bandedGridColumn64
            // 
            this.bandedGridColumn64.Caption = "ReInsate Date";
            this.bandedGridColumn64.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn64.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn64.FieldName = "reinstateDate8";
            this.bandedGridColumn64.MinWidth = 23;
            this.bandedGridColumn64.Name = "bandedGridColumn64";
            this.bandedGridColumn64.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn64.Visible = true;
            this.bandedGridColumn64.Width = 87;
            // 
            // bandedGridColumn9
            // 
            this.bandedGridColumn9.Caption = "Trust85P";
            this.bandedGridColumn9.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn9.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn9.FieldName = "trust85P";
            this.bandedGridColumn9.MinWidth = 23;
            this.bandedGridColumn9.Name = "bandedGridColumn9";
            this.bandedGridColumn9.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn9.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn9.Visible = true;
            this.bandedGridColumn9.Width = 96;
            // 
            // bandedGridColumn8
            // 
            this.bandedGridColumn8.Caption = "Trust100P";
            this.bandedGridColumn8.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn8.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn8.FieldName = "trust100P";
            this.bandedGridColumn8.MinWidth = 23;
            this.bandedGridColumn8.Name = "bandedGridColumn8";
            this.bandedGridColumn8.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn8.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn8.Visible = true;
            this.bandedGridColumn8.Width = 96;
            // 
            // bandedGridColumn189
            // 
            this.bandedGridColumn189.Caption = "Method";
            this.bandedGridColumn189.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn189.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn189.FieldName = "method";
            this.bandedGridColumn189.MinWidth = 23;
            this.bandedGridColumn189.Name = "bandedGridColumn189";
            this.bandedGridColumn189.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn189.Visible = true;
            this.bandedGridColumn189.Width = 87;
            // 
            // bandedGridColumn92
            // 
            this.bandedGridColumn92.Caption = "IB trust";
            this.bandedGridColumn92.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn92.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn92.FieldName = "ibtrust";
            this.bandedGridColumn92.MinWidth = 23;
            this.bandedGridColumn92.Name = "bandedGridColumn92";
            this.bandedGridColumn92.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn92.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn92.Visible = true;
            this.bandedGridColumn92.Width = 87;
            // 
            // bandedGridColumn91
            // 
            this.bandedGridColumn91.Caption = "SP Trust";
            this.bandedGridColumn91.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn91.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn91.FieldName = "sptrust";
            this.bandedGridColumn91.MinWidth = 23;
            this.bandedGridColumn91.Name = "bandedGridColumn91";
            this.bandedGridColumn91.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn91.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn91.Visible = true;
            this.bandedGridColumn91.Width = 87;
            // 
            // bandedGridColumn104
            // 
            this.bandedGridColumn104.Caption = "XX Trust";
            this.bandedGridColumn104.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn104.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn104.FieldName = "xxtrust";
            this.bandedGridColumn104.MinWidth = 23;
            this.bandedGridColumn104.Name = "bandedGridColumn104";
            this.bandedGridColumn104.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn104.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn104.Visible = true;
            this.bandedGridColumn104.Width = 87;
            // 
            // t_lapseContract
            // 
            this.t_lapseContract.Caption = "Lapse Contract $";
            this.t_lapseContract.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.t_lapseContract.FieldName = "lapseContract$";
            this.t_lapseContract.MinWidth = 23;
            this.t_lapseContract.Name = "t_lapseContract";
            this.t_lapseContract.OptionsColumn.FixedWidth = true;
            this.t_lapseContract.Visible = true;
            this.t_lapseContract.Width = 87;
            // 
            // t_reinstateContract
            // 
            this.t_reinstateContract.Caption = "Reinstate Contract $";
            this.t_reinstateContract.DisplayFormat.FormatString = "N2";
            this.t_reinstateContract.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.t_reinstateContract.FieldName = "reinstateContract$";
            this.t_reinstateContract.MinWidth = 23;
            this.t_reinstateContract.Name = "t_reinstateContract";
            this.t_reinstateContract.OptionsColumn.FixedWidth = true;
            this.t_reinstateContract.Visible = true;
            this.t_reinstateContract.Width = 87;
            // 
            // bandedGridColumn1
            // 
            this.bandedGridColumn1.Caption = "record";
            this.bandedGridColumn1.FieldName = "record";
            this.bandedGridColumn1.MinWidth = 23;
            this.bandedGridColumn1.Name = "bandedGridColumn1";
            this.bandedGridColumn1.RowCount = 2;
            this.bandedGridColumn1.Width = 87;
            // 
            // tabLocations
            // 
            this.tabLocations.Controls.Add(this.panelBAll);
            this.tabLocations.Location = new System.Drawing.Point(4, 25);
            this.tabLocations.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabLocations.Name = "tabLocations";
            this.tabLocations.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabLocations.Size = new System.Drawing.Size(1395, 382);
            this.tabLocations.TabIndex = 1;
            this.tabLocations.Text = "Agent by Location";
            this.tabLocations.UseVisualStyleBackColor = true;
            // 
            // panelBAll
            // 
            this.panelBAll.Controls.Add(this.panelBBottom);
            this.panelBAll.Controls.Add(this.panelBTop);
            this.panelBAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBAll.Location = new System.Drawing.Point(3, 4);
            this.panelBAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelBAll.Name = "panelBAll";
            this.panelBAll.Size = new System.Drawing.Size(1389, 374);
            this.panelBAll.TabIndex = 6;
            // 
            // panelBBottom
            // 
            this.panelBBottom.Controls.Add(this.dgv2);
            this.panelBBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBBottom.Location = new System.Drawing.Point(0, 43);
            this.panelBBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelBBottom.Name = "panelBBottom";
            this.panelBBottom.Size = new System.Drawing.Size(1389, 331);
            this.panelBBottom.TabIndex = 8;
            // 
            // dgv2
            // 
            this.dgv2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv2.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Location = new System.Drawing.Point(0, 0);
            this.dgv2.LookAndFeel.SkinName = "iMaginary";
            this.dgv2.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv2.MainView = this.gridMain2;
            this.dgv2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Name = "dgv2";
            this.dgv2.Size = new System.Drawing.Size(1389, 331);
            this.dgv2.TabIndex = 5;
            this.dgv2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain2});
            // 
            // gridMain2
            // 
            this.gridMain2.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain2.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain2.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain2.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain2.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain2.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain2.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain2.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain2.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain2.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain2.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain2.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain2.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain2.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain2.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain2.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain2.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain2.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain2.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain2.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain2.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain2.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain2.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain2.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain2.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain2.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain2.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain2.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain2.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain2.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain2.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain2.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain2.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.Row.Options.UseBackColor = true;
            this.gridMain2.Appearance.Row.Options.UseForeColor = true;
            this.gridMain2.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain2.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain2.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain2.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain2.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain2.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain2.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand2});
            this.gridMain2.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain2.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn18,
            this.bandedGridColumn36,
            this.paymentAmount31,
            this.bandedGridColumn19,
            this.downPayment30,
            this.totalPayments32,
            this.contractValue29,
            this.bandedGridColumn21,
            this.bandedGridColumn20,
            this.bandedGridColumn22,
            this.ibTrust87,
            this.spTrust88,
            this.xxTrust106,
            this.total89,
            this.cashAdvance185,
            this.bandedGridColumn32,
            this.bandedGridColumn87});
            this.gridMain2.DetailHeight = 431;
            this.gridMain2.GridControl = this.dgv2;
            this.gridMain2.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "contractValue", this.contractValue29, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "paymentAmount", this.paymentAmount31, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "downPayment", this.downPayment30, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "totalPayments", this.totalPayments32, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ibtrust", this.ibTrust87, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "sptrust", this.spTrust88, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "xxtrust", this.xxTrust106, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "total", this.total89, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "cashAdvance", this.cashAdvance185, "${0:0,0.00}")});
            this.gridMain2.Name = "gridMain2";
            this.gridMain2.OptionsBehavior.Editable = false;
            this.gridMain2.OptionsBehavior.ReadOnly = true;
            this.gridMain2.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain2.OptionsPrint.PrintBandHeader = false;
            this.gridMain2.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain2.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain2.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain2.OptionsView.ShowBands = false;
            this.gridMain2.OptionsView.ShowFooter = true;
            this.gridMain2.OptionsView.ShowGroupPanel = false;
            this.gridMain2.PaintStyleName = "Style3D";
            this.gridMain2.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMain2_CustomRowFilter);
            this.gridMain2.DoubleClick += new System.EventHandler(this.gridMain2_DoubleClick);
            // 
            // gridBand2
            // 
            this.gridBand2.Caption = "gridBand1";
            this.gridBand2.Columns.Add(this.bandedGridColumn18);
            this.gridBand2.Columns.Add(this.bandedGridColumn19);
            this.gridBand2.Columns.Add(this.bandedGridColumn20);
            this.gridBand2.Columns.Add(this.bandedGridColumn21);
            this.gridBand2.Columns.Add(this.bandedGridColumn22);
            this.gridBand2.Columns.Add(this.contractValue29);
            this.gridBand2.Columns.Add(this.cashAdvance185);
            this.gridBand2.Columns.Add(this.downPayment30);
            this.gridBand2.Columns.Add(this.bandedGridColumn32);
            this.gridBand2.Columns.Add(this.paymentAmount31);
            this.gridBand2.Columns.Add(this.bandedGridColumn87);
            this.gridBand2.Columns.Add(this.totalPayments32);
            this.gridBand2.Columns.Add(this.ibTrust87);
            this.gridBand2.Columns.Add(this.spTrust88);
            this.gridBand2.Columns.Add(this.xxTrust106);
            this.gridBand2.Columns.Add(this.total89);
            this.gridBand2.Columns.Add(this.bandedGridColumn36);
            this.gridBand2.MinWidth = 12;
            this.gridBand2.Name = "gridBand2";
            this.gridBand2.VisibleIndex = 0;
            this.gridBand2.Width = 1557;
            // 
            // bandedGridColumn18
            // 
            this.bandedGridColumn18.Caption = "Num";
            this.bandedGridColumn18.FieldName = "num";
            this.bandedGridColumn18.MinWidth = 23;
            this.bandedGridColumn18.Name = "bandedGridColumn18";
            this.bandedGridColumn18.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn18.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn18.Visible = true;
            this.bandedGridColumn18.Width = 58;
            // 
            // bandedGridColumn19
            // 
            this.bandedGridColumn19.Caption = "Agent";
            this.bandedGridColumn19.FieldName = "agentNumber";
            this.bandedGridColumn19.MinWidth = 23;
            this.bandedGridColumn19.Name = "bandedGridColumn19";
            this.bandedGridColumn19.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn19.Visible = true;
            this.bandedGridColumn19.Width = 70;
            // 
            // bandedGridColumn20
            // 
            this.bandedGridColumn20.Caption = "Agent Name";
            this.bandedGridColumn20.FieldName = "agentName";
            this.bandedGridColumn20.MinWidth = 23;
            this.bandedGridColumn20.Name = "bandedGridColumn20";
            this.bandedGridColumn20.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn20.Visible = true;
            this.bandedGridColumn20.Width = 175;
            // 
            // bandedGridColumn21
            // 
            this.bandedGridColumn21.Caption = "Loc";
            this.bandedGridColumn21.FieldName = "loc";
            this.bandedGridColumn21.MinWidth = 23;
            this.bandedGridColumn21.Name = "bandedGridColumn21";
            this.bandedGridColumn21.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn21.Visible = true;
            this.bandedGridColumn21.Width = 47;
            // 
            // bandedGridColumn22
            // 
            this.bandedGridColumn22.Caption = "Location Name";
            this.bandedGridColumn22.FieldName = "Location Name";
            this.bandedGridColumn22.MinWidth = 23;
            this.bandedGridColumn22.Name = "bandedGridColumn22";
            this.bandedGridColumn22.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn22.Visible = true;
            this.bandedGridColumn22.Width = 175;
            // 
            // contractValue29
            // 
            this.contractValue29.Caption = "Contract Value";
            this.contractValue29.DisplayFormat.FormatString = "N2";
            this.contractValue29.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.contractValue29.FieldName = "contractValue";
            this.contractValue29.MinWidth = 23;
            this.contractValue29.Name = "contractValue29";
            this.contractValue29.OptionsColumn.FixedWidth = true;
            this.contractValue29.Visible = true;
            this.contractValue29.Width = 117;
            // 
            // cashAdvance185
            // 
            this.cashAdvance185.Caption = "Cash Advance";
            this.cashAdvance185.DisplayFormat.FormatString = "N2";
            this.cashAdvance185.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.cashAdvance185.FieldName = "cashAdvance";
            this.cashAdvance185.MinWidth = 23;
            this.cashAdvance185.Name = "cashAdvance185";
            this.cashAdvance185.OptionsColumn.FixedWidth = true;
            this.cashAdvance185.Visible = true;
            this.cashAdvance185.Width = 87;
            // 
            // downPayment30
            // 
            this.downPayment30.Caption = "Down Payment";
            this.downPayment30.DisplayFormat.FormatString = "N2";
            this.downPayment30.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.downPayment30.FieldName = "downPayment";
            this.downPayment30.MinWidth = 23;
            this.downPayment30.Name = "downPayment30";
            this.downPayment30.OptionsColumn.FixedWidth = true;
            this.downPayment30.Visible = true;
            this.downPayment30.Width = 96;
            // 
            // bandedGridColumn32
            // 
            this.bandedGridColumn32.Caption = "Actual Down Payment";
            this.bandedGridColumn32.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn32.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn32.FieldName = "dpp";
            this.bandedGridColumn32.MinWidth = 24;
            this.bandedGridColumn32.Name = "bandedGridColumn32";
            this.bandedGridColumn32.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn32.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn32.Visible = true;
            this.bandedGridColumn32.Width = 96;
            // 
            // paymentAmount31
            // 
            this.paymentAmount31.Caption = "Payment";
            this.paymentAmount31.DisplayFormat.FormatString = "N2";
            this.paymentAmount31.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.paymentAmount31.FieldName = "paymentAmount";
            this.paymentAmount31.MinWidth = 23;
            this.paymentAmount31.Name = "paymentAmount31";
            this.paymentAmount31.OptionsColumn.AllowEdit = false;
            this.paymentAmount31.OptionsColumn.FixedWidth = true;
            this.paymentAmount31.Visible = true;
            this.paymentAmount31.Width = 96;
            // 
            // bandedGridColumn87
            // 
            this.bandedGridColumn87.Caption = "Actual Payment";
            this.bandedGridColumn87.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn87.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn87.FieldName = "ap";
            this.bandedGridColumn87.MinWidth = 24;
            this.bandedGridColumn87.Name = "bandedGridColumn87";
            this.bandedGridColumn87.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn87.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn87.Visible = true;
            this.bandedGridColumn87.Width = 96;
            // 
            // totalPayments32
            // 
            this.totalPayments32.Caption = "Total Payments";
            this.totalPayments32.DisplayFormat.FormatString = "N2";
            this.totalPayments32.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.totalPayments32.FieldName = "totalPayments";
            this.totalPayments32.MinWidth = 23;
            this.totalPayments32.Name = "totalPayments32";
            this.totalPayments32.OptionsColumn.FixedWidth = true;
            this.totalPayments32.Visible = true;
            this.totalPayments32.Width = 96;
            // 
            // ibTrust87
            // 
            this.ibTrust87.Caption = "IB Trust";
            this.ibTrust87.DisplayFormat.FormatString = "N2";
            this.ibTrust87.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.ibTrust87.FieldName = "ibtrust";
            this.ibTrust87.MinWidth = 23;
            this.ibTrust87.Name = "ibTrust87";
            this.ibTrust87.OptionsColumn.FixedWidth = true;
            this.ibTrust87.Visible = true;
            this.ibTrust87.Width = 87;
            // 
            // spTrust88
            // 
            this.spTrust88.Caption = "SP Trust";
            this.spTrust88.DisplayFormat.FormatString = "N2";
            this.spTrust88.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.spTrust88.FieldName = "sptrust";
            this.spTrust88.MinWidth = 23;
            this.spTrust88.Name = "spTrust88";
            this.spTrust88.OptionsColumn.FixedWidth = true;
            this.spTrust88.Visible = true;
            this.spTrust88.Width = 87;
            // 
            // xxTrust106
            // 
            this.xxTrust106.Caption = "XX Trust";
            this.xxTrust106.DisplayFormat.FormatString = "N2";
            this.xxTrust106.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.xxTrust106.FieldName = "xxtrust";
            this.xxTrust106.MinWidth = 23;
            this.xxTrust106.Name = "xxTrust106";
            this.xxTrust106.OptionsColumn.FixedWidth = true;
            this.xxTrust106.Visible = true;
            this.xxTrust106.Width = 87;
            // 
            // total89
            // 
            this.total89.Caption = "Total";
            this.total89.DisplayFormat.FormatString = "N2";
            this.total89.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.total89.FieldName = "total";
            this.total89.MinWidth = 23;
            this.total89.Name = "total89";
            this.total89.OptionsColumn.FixedWidth = true;
            this.total89.Visible = true;
            this.total89.Width = 87;
            // 
            // bandedGridColumn36
            // 
            this.bandedGridColumn36.Caption = "record";
            this.bandedGridColumn36.FieldName = "record";
            this.bandedGridColumn36.MinWidth = 23;
            this.bandedGridColumn36.Name = "bandedGridColumn36";
            this.bandedGridColumn36.RowCount = 2;
            this.bandedGridColumn36.Width = 87;
            // 
            // panelBTop
            // 
            this.panelBTop.BackColor = System.Drawing.Color.MistyRose;
            this.panelBTop.Controls.Add(this.chkReverseAgentsAndLocations);
            this.panelBTop.Controls.Add(this.chkShowOnlyContractValues);
            this.panelBTop.Controls.Add(this.chkAgentByLocationTotalLocations);
            this.panelBTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelBTop.Location = new System.Drawing.Point(0, 0);
            this.panelBTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelBTop.Name = "panelBTop";
            this.panelBTop.Size = new System.Drawing.Size(1389, 43);
            this.panelBTop.TabIndex = 7;
            // 
            // chkReverseAgentsAndLocations
            // 
            this.chkReverseAgentsAndLocations.AutoSize = true;
            this.chkReverseAgentsAndLocations.Location = new System.Drawing.Point(419, 11);
            this.chkReverseAgentsAndLocations.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkReverseAgentsAndLocations.Name = "chkReverseAgentsAndLocations";
            this.chkReverseAgentsAndLocations.Size = new System.Drawing.Size(214, 21);
            this.chkReverseAgentsAndLocations.TabIndex = 3;
            this.chkReverseAgentsAndLocations.Text = "Reverse Agents and Locations";
            this.chkReverseAgentsAndLocations.UseVisualStyleBackColor = true;
            this.chkReverseAgentsAndLocations.CheckedChanged += new System.EventHandler(this.chkReverseAgentsAndLocations_CheckedChanged);
            // 
            // chkShowOnlyContractValues
            // 
            this.chkShowOnlyContractValues.AutoSize = true;
            this.chkShowOnlyContractValues.Location = new System.Drawing.Point(169, 11);
            this.chkShowOnlyContractValues.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkShowOnlyContractValues.Name = "chkShowOnlyContractValues";
            this.chkShowOnlyContractValues.Size = new System.Drawing.Size(196, 21);
            this.chkShowOnlyContractValues.TabIndex = 2;
            this.chkShowOnlyContractValues.Text = "Show Only Contract Values";
            this.chkShowOnlyContractValues.UseVisualStyleBackColor = true;
            this.chkShowOnlyContractValues.CheckedChanged += new System.EventHandler(this.chkShowOnlyContractValues_CheckedChanged);
            // 
            // chkAgentByLocationTotalLocations
            // 
            this.chkAgentByLocationTotalLocations.AutoSize = true;
            this.chkAgentByLocationTotalLocations.Location = new System.Drawing.Point(6, 11);
            this.chkAgentByLocationTotalLocations.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkAgentByLocationTotalLocations.Name = "chkAgentByLocationTotalLocations";
            this.chkAgentByLocationTotalLocations.Size = new System.Drawing.Size(122, 21);
            this.chkAgentByLocationTotalLocations.TabIndex = 1;
            this.chkAgentByLocationTotalLocations.Text = "Total Locations";
            this.chkAgentByLocationTotalLocations.UseVisualStyleBackColor = true;
            this.chkAgentByLocationTotalLocations.CheckedChanged += new System.EventHandler(this.chkAgentByLocationTotalLocations_CheckedChanged);
            // 
            // tabAgentLocations
            // 
            this.tabAgentLocations.Controls.Add(this.panelLAAll);
            this.tabAgentLocations.Location = new System.Drawing.Point(4, 25);
            this.tabAgentLocations.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabAgentLocations.Name = "tabAgentLocations";
            this.tabAgentLocations.Size = new System.Drawing.Size(1395, 382);
            this.tabAgentLocations.TabIndex = 3;
            this.tabAgentLocations.Text = "Location by Agent";
            this.tabAgentLocations.UseVisualStyleBackColor = true;
            // 
            // panelLAAll
            // 
            this.panelLAAll.Controls.Add(this.panelLABottom);
            this.panelLAAll.Controls.Add(this.panelLATop);
            this.panelLAAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelLAAll.Location = new System.Drawing.Point(0, 0);
            this.panelLAAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelLAAll.Name = "panelLAAll";
            this.panelLAAll.Size = new System.Drawing.Size(1395, 382);
            this.panelLAAll.TabIndex = 7;
            // 
            // panelLABottom
            // 
            this.panelLABottom.Controls.Add(this.dgv4);
            this.panelLABottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelLABottom.Location = new System.Drawing.Point(0, 39);
            this.panelLABottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelLABottom.Name = "panelLABottom";
            this.panelLABottom.Size = new System.Drawing.Size(1395, 343);
            this.panelLABottom.TabIndex = 9;
            // 
            // dgv4
            // 
            this.dgv4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv4.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv4.Location = new System.Drawing.Point(0, 0);
            this.dgv4.LookAndFeel.SkinName = "iMaginary";
            this.dgv4.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv4.MainView = this.gridMain4;
            this.dgv4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv4.Name = "dgv4";
            this.dgv4.Size = new System.Drawing.Size(1395, 343);
            this.dgv4.TabIndex = 6;
            this.dgv4.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain4});
            // 
            // gridMain4
            // 
            this.gridMain4.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain4.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain4.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain4.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain4.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain4.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain4.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain4.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain4.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain4.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain4.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain4.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain4.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain4.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain4.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain4.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain4.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain4.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain4.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain4.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain4.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain4.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain4.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain4.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain4.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain4.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain4.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain4.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain4.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain4.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain4.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain4.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain4.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain4.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain4.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.Row.Options.UseBackColor = true;
            this.gridMain4.Appearance.Row.Options.UseForeColor = true;
            this.gridMain4.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain4.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain4.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain4.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain4.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain4.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain4.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand4});
            this.gridMain4.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain4.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn38,
            this.bandedGridColumn47,
            this.bandedGridColumn45,
            this.bandedGridColumn39,
            this.bandedGridColumn44,
            this.bandedGridColumn46,
            this.bandedGridColumn43,
            this.bandedGridColumn41,
            this.bandedGridColumn40,
            this.bandedGridColumn42,
            this.ibtrust275,
            this.sptrust276,
            this.xxtrust277,
            this.totalTrusts278,
            this.bandedGridColumn88,
            this.bandedGridColumn89});
            this.gridMain4.DetailHeight = 431;
            this.gridMain4.GridControl = this.dgv4;
            this.gridMain4.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ibtrust", this.ibtrust275, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "sptrust", this.sptrust276, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "xxtrust", this.xxtrust277, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "totalTrusts", this.totalTrusts278, "${0:0,0.00}")});
            this.gridMain4.Name = "gridMain4";
            this.gridMain4.OptionsBehavior.Editable = false;
            this.gridMain4.OptionsBehavior.ReadOnly = true;
            this.gridMain4.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain4.OptionsPrint.PrintBandHeader = false;
            this.gridMain4.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain4.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain4.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain4.OptionsView.ShowBands = false;
            this.gridMain4.OptionsView.ShowFooter = true;
            this.gridMain4.OptionsView.ShowGroupPanel = false;
            this.gridMain4.PaintStyleName = "Style3D";
            this.gridMain4.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMain4_CustomRowFilter);
            // 
            // gridBand4
            // 
            this.gridBand4.Caption = "gridBand1";
            this.gridBand4.Columns.Add(this.bandedGridColumn38);
            this.gridBand4.Columns.Add(this.bandedGridColumn39);
            this.gridBand4.Columns.Add(this.bandedGridColumn40);
            this.gridBand4.Columns.Add(this.bandedGridColumn41);
            this.gridBand4.Columns.Add(this.bandedGridColumn42);
            this.gridBand4.Columns.Add(this.bandedGridColumn43);
            this.gridBand4.Columns.Add(this.bandedGridColumn44);
            this.gridBand4.Columns.Add(this.bandedGridColumn89);
            this.gridBand4.Columns.Add(this.bandedGridColumn45);
            this.gridBand4.Columns.Add(this.bandedGridColumn88);
            this.gridBand4.Columns.Add(this.bandedGridColumn46);
            this.gridBand4.Columns.Add(this.ibtrust275);
            this.gridBand4.Columns.Add(this.sptrust276);
            this.gridBand4.Columns.Add(this.xxtrust277);
            this.gridBand4.Columns.Add(this.totalTrusts278);
            this.gridBand4.Columns.Add(this.bandedGridColumn47);
            this.gridBand4.MinWidth = 12;
            this.gridBand4.Name = "gridBand4";
            this.gridBand4.VisibleIndex = 0;
            this.gridBand4.Width = 1470;
            // 
            // bandedGridColumn38
            // 
            this.bandedGridColumn38.Caption = "Num";
            this.bandedGridColumn38.FieldName = "num";
            this.bandedGridColumn38.MinWidth = 23;
            this.bandedGridColumn38.Name = "bandedGridColumn38";
            this.bandedGridColumn38.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn38.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn38.Visible = true;
            this.bandedGridColumn38.Width = 58;
            // 
            // bandedGridColumn39
            // 
            this.bandedGridColumn39.Caption = "Agent";
            this.bandedGridColumn39.FieldName = "agentNumber";
            this.bandedGridColumn39.MinWidth = 23;
            this.bandedGridColumn39.Name = "bandedGridColumn39";
            this.bandedGridColumn39.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn39.Visible = true;
            this.bandedGridColumn39.Width = 70;
            // 
            // bandedGridColumn40
            // 
            this.bandedGridColumn40.Caption = "Agent Name";
            this.bandedGridColumn40.FieldName = "agentName";
            this.bandedGridColumn40.MinWidth = 23;
            this.bandedGridColumn40.Name = "bandedGridColumn40";
            this.bandedGridColumn40.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn40.Visible = true;
            this.bandedGridColumn40.Width = 175;
            // 
            // bandedGridColumn41
            // 
            this.bandedGridColumn41.Caption = "Loc";
            this.bandedGridColumn41.FieldName = "loc";
            this.bandedGridColumn41.MinWidth = 23;
            this.bandedGridColumn41.Name = "bandedGridColumn41";
            this.bandedGridColumn41.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn41.Visible = true;
            this.bandedGridColumn41.Width = 47;
            // 
            // bandedGridColumn42
            // 
            this.bandedGridColumn42.Caption = "Location Name";
            this.bandedGridColumn42.FieldName = "Location Name";
            this.bandedGridColumn42.MinWidth = 23;
            this.bandedGridColumn42.Name = "bandedGridColumn42";
            this.bandedGridColumn42.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn42.Visible = true;
            this.bandedGridColumn42.Width = 175;
            // 
            // bandedGridColumn43
            // 
            this.bandedGridColumn43.Caption = "Contract Value";
            this.bandedGridColumn43.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn43.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn43.FieldName = "contractValue";
            this.bandedGridColumn43.MinWidth = 23;
            this.bandedGridColumn43.Name = "bandedGridColumn43";
            this.bandedGridColumn43.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn43.Visible = true;
            this.bandedGridColumn43.Width = 117;
            // 
            // bandedGridColumn44
            // 
            this.bandedGridColumn44.Caption = "Down Payment";
            this.bandedGridColumn44.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn44.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn44.FieldName = "downPayment";
            this.bandedGridColumn44.MinWidth = 23;
            this.bandedGridColumn44.Name = "bandedGridColumn44";
            this.bandedGridColumn44.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn44.Visible = true;
            this.bandedGridColumn44.Width = 96;
            // 
            // bandedGridColumn89
            // 
            this.bandedGridColumn89.Caption = "Actual Down Payment";
            this.bandedGridColumn89.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn89.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn89.FieldName = "dpp";
            this.bandedGridColumn89.MinWidth = 24;
            this.bandedGridColumn89.Name = "bandedGridColumn89";
            this.bandedGridColumn89.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn89.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn89.Visible = true;
            this.bandedGridColumn89.Width = 96;
            // 
            // bandedGridColumn45
            // 
            this.bandedGridColumn45.Caption = "Payment";
            this.bandedGridColumn45.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn45.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn45.FieldName = "paymentAmount";
            this.bandedGridColumn45.MinWidth = 23;
            this.bandedGridColumn45.Name = "bandedGridColumn45";
            this.bandedGridColumn45.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn45.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn45.Visible = true;
            this.bandedGridColumn45.Width = 96;
            // 
            // bandedGridColumn88
            // 
            this.bandedGridColumn88.Caption = "Actual Payment";
            this.bandedGridColumn88.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn88.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn88.FieldName = "ap";
            this.bandedGridColumn88.MinWidth = 24;
            this.bandedGridColumn88.Name = "bandedGridColumn88";
            this.bandedGridColumn88.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn88.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn88.Visible = true;
            this.bandedGridColumn88.Width = 96;
            // 
            // bandedGridColumn46
            // 
            this.bandedGridColumn46.Caption = "Total Payments";
            this.bandedGridColumn46.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn46.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn46.FieldName = "totalPayments";
            this.bandedGridColumn46.MinWidth = 23;
            this.bandedGridColumn46.Name = "bandedGridColumn46";
            this.bandedGridColumn46.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn46.Visible = true;
            this.bandedGridColumn46.Width = 96;
            // 
            // ibtrust275
            // 
            this.ibtrust275.Caption = "IB Trust";
            this.ibtrust275.DisplayFormat.FormatString = "N2";
            this.ibtrust275.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.ibtrust275.FieldName = "ibtrust";
            this.ibtrust275.MinWidth = 23;
            this.ibtrust275.Name = "ibtrust275";
            this.ibtrust275.OptionsColumn.FixedWidth = true;
            this.ibtrust275.Visible = true;
            this.ibtrust275.Width = 87;
            // 
            // sptrust276
            // 
            this.sptrust276.Caption = "SP Trust";
            this.sptrust276.DisplayFormat.FormatString = "N2";
            this.sptrust276.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.sptrust276.FieldName = "sptrust";
            this.sptrust276.MinWidth = 23;
            this.sptrust276.Name = "sptrust276";
            this.sptrust276.OptionsColumn.FixedWidth = true;
            this.sptrust276.Visible = true;
            this.sptrust276.Width = 87;
            // 
            // xxtrust277
            // 
            this.xxtrust277.Caption = "XX Trust";
            this.xxtrust277.DisplayFormat.FormatString = "N2";
            this.xxtrust277.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.xxtrust277.FieldName = "xxtrust";
            this.xxtrust277.MinWidth = 23;
            this.xxtrust277.Name = "xxtrust277";
            this.xxtrust277.OptionsColumn.FixedWidth = true;
            this.xxtrust277.Visible = true;
            this.xxtrust277.Width = 87;
            // 
            // totalTrusts278
            // 
            this.totalTrusts278.Caption = "Total Trusts";
            this.totalTrusts278.DisplayFormat.FormatString = "N2";
            this.totalTrusts278.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.totalTrusts278.FieldName = "totalTrusts";
            this.totalTrusts278.MinWidth = 23;
            this.totalTrusts278.Name = "totalTrusts278";
            this.totalTrusts278.OptionsColumn.FixedWidth = true;
            this.totalTrusts278.Visible = true;
            this.totalTrusts278.Width = 87;
            // 
            // bandedGridColumn47
            // 
            this.bandedGridColumn47.Caption = "record";
            this.bandedGridColumn47.FieldName = "record";
            this.bandedGridColumn47.MinWidth = 23;
            this.bandedGridColumn47.Name = "bandedGridColumn47";
            this.bandedGridColumn47.RowCount = 2;
            this.bandedGridColumn47.Width = 87;
            // 
            // panelLATop
            // 
            this.panelLATop.BackColor = System.Drawing.Color.MistyRose;
            this.panelLATop.Controls.Add(this.chkLocationTotal);
            this.panelLATop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLATop.Location = new System.Drawing.Point(0, 0);
            this.panelLATop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelLATop.Name = "panelLATop";
            this.panelLATop.Size = new System.Drawing.Size(1395, 39);
            this.panelLATop.TabIndex = 8;
            // 
            // chkLocationTotal
            // 
            this.chkLocationTotal.AutoSize = true;
            this.chkLocationTotal.Location = new System.Drawing.Point(9, 10);
            this.chkLocationTotal.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkLocationTotal.Name = "chkLocationTotal";
            this.chkLocationTotal.Size = new System.Drawing.Size(122, 21);
            this.chkLocationTotal.TabIndex = 0;
            this.chkLocationTotal.Text = "Total Locations";
            this.chkLocationTotal.UseVisualStyleBackColor = true;
            this.chkLocationTotal.CheckedChanged += new System.EventHandler(this.chkLocationTotal_CheckedChanged);
            // 
            // tabAgentTotals
            // 
            this.tabAgentTotals.Controls.Add(this.panel3All);
            this.tabAgentTotals.Location = new System.Drawing.Point(4, 25);
            this.tabAgentTotals.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabAgentTotals.Name = "tabAgentTotals";
            this.tabAgentTotals.Size = new System.Drawing.Size(1395, 382);
            this.tabAgentTotals.TabIndex = 2;
            this.tabAgentTotals.Text = "Agent Totals";
            this.tabAgentTotals.UseVisualStyleBackColor = true;
            // 
            // panel3All
            // 
            this.panel3All.Controls.Add(this.panel3Bottom);
            this.panel3All.Controls.Add(this.panel3Top);
            this.panel3All.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3All.Location = new System.Drawing.Point(0, 0);
            this.panel3All.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel3All.Name = "panel3All";
            this.panel3All.Size = new System.Drawing.Size(1395, 382);
            this.panel3All.TabIndex = 7;
            // 
            // panel3Bottom
            // 
            this.panel3Bottom.Controls.Add(this.dgv3);
            this.panel3Bottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3Bottom.Location = new System.Drawing.Point(0, 31);
            this.panel3Bottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel3Bottom.Name = "panel3Bottom";
            this.panel3Bottom.Size = new System.Drawing.Size(1395, 351);
            this.panel3Bottom.TabIndex = 9;
            // 
            // dgv3
            // 
            this.dgv3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv3.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Location = new System.Drawing.Point(0, 0);
            this.dgv3.LookAndFeel.SkinName = "iMaginary";
            this.dgv3.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv3.MainView = this.gridMain3;
            this.dgv3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Name = "dgv3";
            this.dgv3.Size = new System.Drawing.Size(1395, 351);
            this.dgv3.TabIndex = 6;
            this.dgv3.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain3});
            // 
            // gridMain3
            // 
            this.gridMain3.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain3.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain3.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain3.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain3.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain3.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain3.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain3.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain3.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain3.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain3.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain3.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain3.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain3.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain3.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain3.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain3.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain3.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain3.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain3.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain3.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain3.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain3.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain3.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain3.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain3.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain3.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain3.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain3.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain3.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain3.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain3.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain3.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain3.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain3.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain3.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain3.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain3.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.Row.Options.UseBackColor = true;
            this.gridMain3.Appearance.Row.Options.UseForeColor = true;
            this.gridMain3.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain3.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain3.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain3.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain3.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain3.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain3.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand3});
            this.gridMain3.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain3.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.fbi234,
            this.fbiCommission235,
            this.bandedGridColumn23,
            this.bandedGridColumn37,
            this.bandedGridColumn185,
            this.paymentAmount34,
            this.bandedGridColumn24,
            this.bandedGridColumn106,
            this.downPayment33,
            this.dpr276,
            this.dbc28,
            this.dbc_5_277,
            this.totalPayments35,
            this.SplitDownPayment58,
            this.SplitPayment58,
            this.interestPaid58,
            this.contractValue28,
            this.bandedGridColumn108,
            this.bandedGridColumn26,
            this.bandedGridColumn25,
            this.bandedGridColumn27,
            this.recapAmount58,
            this.bandedGridColumn90,
            this.bandedGridColumn110,
            this.bandedGridColumn59,
            this.commission231,
            this.bandedGridColumn231,
            this.bandedGridColumn232,
            this.bandedGridColumn275,
            this.debit233,
            this.credit234,
            this.bandedGridColumn28,
            this.bandedGridColumn33,
            this.bandedGridColumn34,
            this.bandedGridColumn273,
            this.CashAdvance275});
            this.gridMain3.DetailHeight = 431;
            this.gridMain3.GridControl = this.dgv3;
            this.gridMain3.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "Recap", this.recapAmount58, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "commission", null, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "contractValue", this.contractValue28, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "downPayment", this.downPayment33, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "totalPayments", this.totalPayments35, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "debitAdjustment", this.debit233, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "creditAdjustment", this.credit234, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "commission", this.commission231, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "paymentAmount", this.paymentAmount34, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "dbc", this.dbc28, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "Split Payment", this.SplitPayment58, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "Split DownPayment", this.SplitDownPayment58, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "interestPaid", this.interestPaid58, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "fbiCommission", this.fbiCommission235, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "fbi", this.fbi234, "{0,0}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "dpr", this.dpr276, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "dpc_5", this.dbc_5_277, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "cashAdvance", this.CashAdvance275, "${0:0,0.00}")});
            this.gridMain3.Name = "gridMain3";
            this.gridMain3.OptionsBehavior.Editable = false;
            this.gridMain3.OptionsBehavior.ReadOnly = true;
            this.gridMain3.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain3.OptionsPrint.PrintBandHeader = false;
            this.gridMain3.OptionsSelection.MultiSelect = true;
            this.gridMain3.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain3.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain3.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain3.OptionsView.ShowBands = false;
            this.gridMain3.OptionsView.ShowFooter = true;
            this.gridMain3.OptionsView.ShowGroupPanel = false;
            this.gridMain3.PaintStyleName = "Style3D";
            this.gridMain3.BeforePrintRow += new DevExpress.XtraGrid.Views.Base.BeforePrintRowEventHandler(this.gridMain3_BeforePrintRow);
            this.gridMain3.AfterPrintRow += new DevExpress.XtraGrid.Views.Base.AfterPrintRowEventHandler(this.gridMain3_AfterPrintRow);
            this.gridMain3.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMain3_CustomDrawCell);
            this.gridMain3.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMain3_CustomRowFilter);
            this.gridMain3.DoubleClick += new System.EventHandler(this.gridMain3_DoubleClick);
            // 
            // gridBand3
            // 
            this.gridBand3.Caption = "gridBand1";
            this.gridBand3.Columns.Add(this.bandedGridColumn23);
            this.gridBand3.Columns.Add(this.bandedGridColumn90);
            this.gridBand3.Columns.Add(this.bandedGridColumn24);
            this.gridBand3.Columns.Add(this.bandedGridColumn25);
            this.gridBand3.Columns.Add(this.bandedGridColumn110);
            this.gridBand3.Columns.Add(this.bandedGridColumn231);
            this.gridBand3.Columns.Add(this.bandedGridColumn232);
            this.gridBand3.Columns.Add(this.bandedGridColumn26);
            this.gridBand3.Columns.Add(this.bandedGridColumn27);
            this.gridBand3.Columns.Add(this.contractValue28);
            this.gridBand3.Columns.Add(this.bandedGridColumn108);
            this.gridBand3.Columns.Add(this.bandedGridColumn106);
            this.gridBand3.Columns.Add(this.downPayment33);
            this.gridBand3.Columns.Add(this.dpr276);
            this.gridBand3.Columns.Add(this.dbc28);
            this.gridBand3.Columns.Add(this.dbc_5_277);
            this.gridBand3.Columns.Add(this.fbi234);
            this.gridBand3.Columns.Add(this.fbiCommission235);
            this.gridBand3.Columns.Add(this.paymentAmount34);
            this.gridBand3.Columns.Add(this.bandedGridColumn185);
            this.gridBand3.Columns.Add(this.bandedGridColumn275);
            this.gridBand3.Columns.Add(this.debit233);
            this.gridBand3.Columns.Add(this.credit234);
            this.gridBand3.Columns.Add(this.interestPaid58);
            this.gridBand3.Columns.Add(this.totalPayments35);
            this.gridBand3.Columns.Add(this.SplitDownPayment58);
            this.gridBand3.Columns.Add(this.CashAdvance275);
            this.gridBand3.Columns.Add(this.SplitPayment58);
            this.gridBand3.Columns.Add(this.bandedGridColumn59);
            this.gridBand3.Columns.Add(this.recapAmount58);
            this.gridBand3.Columns.Add(this.commission231);
            this.gridBand3.Columns.Add(this.bandedGridColumn273);
            this.gridBand3.Columns.Add(this.bandedGridColumn37);
            this.gridBand3.MinWidth = 12;
            this.gridBand3.Name = "gridBand3";
            this.gridBand3.VisibleIndex = 0;
            this.gridBand3.Width = 2767;
            // 
            // bandedGridColumn23
            // 
            this.bandedGridColumn23.Caption = "Num";
            this.bandedGridColumn23.FieldName = "num";
            this.bandedGridColumn23.MinWidth = 23;
            this.bandedGridColumn23.Name = "bandedGridColumn23";
            this.bandedGridColumn23.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn23.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn23.Visible = true;
            this.bandedGridColumn23.Width = 58;
            // 
            // bandedGridColumn90
            // 
            this.bandedGridColumn90.Caption = "Date";
            this.bandedGridColumn90.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn90.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn90.FieldName = "payDate8";
            this.bandedGridColumn90.MinWidth = 23;
            this.bandedGridColumn90.Name = "bandedGridColumn90";
            this.bandedGridColumn90.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn90.Width = 87;
            // 
            // bandedGridColumn24
            // 
            this.bandedGridColumn24.Caption = "Agent";
            this.bandedGridColumn24.FieldName = "agentNumber";
            this.bandedGridColumn24.MinWidth = 23;
            this.bandedGridColumn24.Name = "bandedGridColumn24";
            this.bandedGridColumn24.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn24.Visible = true;
            this.bandedGridColumn24.Width = 70;
            // 
            // bandedGridColumn25
            // 
            this.bandedGridColumn25.Caption = "Agent Name";
            this.bandedGridColumn25.FieldName = "agentName";
            this.bandedGridColumn25.MinWidth = 23;
            this.bandedGridColumn25.Name = "bandedGridColumn25";
            this.bandedGridColumn25.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn25.Visible = true;
            this.bandedGridColumn25.Width = 175;
            // 
            // bandedGridColumn110
            // 
            this.bandedGridColumn110.Caption = "Contract";
            this.bandedGridColumn110.FieldName = "contractNumber";
            this.bandedGridColumn110.MinWidth = 23;
            this.bandedGridColumn110.Name = "bandedGridColumn110";
            this.bandedGridColumn110.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn110.Visible = true;
            this.bandedGridColumn110.Width = 175;
            // 
            // bandedGridColumn231
            // 
            this.bandedGridColumn231.Caption = "Last Name";
            this.bandedGridColumn231.FieldName = "lastName";
            this.bandedGridColumn231.MinWidth = 23;
            this.bandedGridColumn231.Name = "bandedGridColumn231";
            this.bandedGridColumn231.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn231.Visible = true;
            this.bandedGridColumn231.Width = 87;
            // 
            // bandedGridColumn232
            // 
            this.bandedGridColumn232.Caption = "First Name";
            this.bandedGridColumn232.FieldName = "firstName";
            this.bandedGridColumn232.MinWidth = 23;
            this.bandedGridColumn232.Name = "bandedGridColumn232";
            this.bandedGridColumn232.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn232.Visible = true;
            this.bandedGridColumn232.Width = 87;
            // 
            // bandedGridColumn26
            // 
            this.bandedGridColumn26.Caption = "Loc";
            this.bandedGridColumn26.FieldName = "loc";
            this.bandedGridColumn26.MinWidth = 23;
            this.bandedGridColumn26.Name = "bandedGridColumn26";
            this.bandedGridColumn26.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn26.Width = 47;
            // 
            // bandedGridColumn27
            // 
            this.bandedGridColumn27.Caption = "Location Name";
            this.bandedGridColumn27.FieldName = "Location Name";
            this.bandedGridColumn27.MinWidth = 23;
            this.bandedGridColumn27.Name = "bandedGridColumn27";
            this.bandedGridColumn27.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn27.Width = 87;
            // 
            // contractValue28
            // 
            this.contractValue28.Caption = "Contract Value";
            this.contractValue28.DisplayFormat.FormatString = "N2";
            this.contractValue28.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.contractValue28.FieldName = "contractValue";
            this.contractValue28.MinWidth = 23;
            this.contractValue28.Name = "contractValue28";
            this.contractValue28.OptionsColumn.FixedWidth = true;
            this.contractValue28.Visible = true;
            this.contractValue28.Width = 117;
            // 
            // bandedGridColumn108
            // 
            this.bandedGridColumn108.Caption = "Recap %Comm";
            this.bandedGridColumn108.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn108.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn108.FieldName = "Recap";
            this.bandedGridColumn108.MinWidth = 23;
            this.bandedGridColumn108.Name = "bandedGridColumn108";
            this.bandedGridColumn108.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn108.Visible = true;
            this.bandedGridColumn108.Width = 87;
            // 
            // bandedGridColumn106
            // 
            this.bandedGridColumn106.Caption = "Actual Down Payment";
            this.bandedGridColumn106.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn106.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn106.FieldName = "dpp";
            this.bandedGridColumn106.MinWidth = 24;
            this.bandedGridColumn106.Name = "bandedGridColumn106";
            this.bandedGridColumn106.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn106.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn106.Visible = true;
            this.bandedGridColumn106.Width = 96;
            // 
            // downPayment33
            // 
            this.downPayment33.Caption = "Down Payment";
            this.downPayment33.DisplayFormat.FormatString = "N2";
            this.downPayment33.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.downPayment33.FieldName = "downPayment";
            this.downPayment33.MinWidth = 23;
            this.downPayment33.Name = "downPayment33";
            this.downPayment33.OptionsColumn.FixedWidth = true;
            this.downPayment33.Visible = true;
            this.downPayment33.Width = 96;
            // 
            // dpr276
            // 
            this.dpr276.Caption = "Down Payment R";
            this.dpr276.DisplayFormat.FormatString = "N2";
            this.dpr276.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.dpr276.FieldName = "dpr";
            this.dpr276.MinWidth = 23;
            this.dpr276.Name = "dpr276";
            this.dpr276.OptionsColumn.FixedWidth = true;
            this.dpr276.Visible = true;
            this.dpr276.Width = 87;
            // 
            // dbc28
            // 
            this.dbc28.Caption = "DBC_1";
            this.dbc28.DisplayFormat.FormatString = "N2";
            this.dbc28.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.dbc28.FieldName = "dbc";
            this.dbc28.MinWidth = 23;
            this.dbc28.Name = "dbc28";
            this.dbc28.OptionsColumn.FixedWidth = true;
            this.dbc28.Visible = true;
            this.dbc28.Width = 87;
            // 
            // dbc_5_277
            // 
            this.dbc_5_277.Caption = "DBC_5";
            this.dbc_5_277.DisplayFormat.FormatString = "N2";
            this.dbc_5_277.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.dbc_5_277.FieldName = "dbc_5";
            this.dbc_5_277.MinWidth = 23;
            this.dbc_5_277.Name = "dbc_5_277";
            this.dbc_5_277.OptionsColumn.FixedWidth = true;
            this.dbc_5_277.Visible = true;
            this.dbc_5_277.Width = 87;
            // 
            // fbi234
            // 
            this.fbi234.Caption = "FBI";
            this.fbi234.FieldName = "fbi";
            this.fbi234.MinWidth = 23;
            this.fbi234.Name = "fbi234";
            this.fbi234.OptionsColumn.FixedWidth = true;
            this.fbi234.Visible = true;
            this.fbi234.Width = 58;
            // 
            // fbiCommission235
            // 
            this.fbiCommission235.Caption = "FBI $";
            this.fbiCommission235.FieldName = "fbiCommission";
            this.fbiCommission235.MinWidth = 23;
            this.fbiCommission235.Name = "fbiCommission235";
            this.fbiCommission235.OptionsColumn.FixedWidth = true;
            this.fbiCommission235.Visible = true;
            this.fbiCommission235.Width = 87;
            // 
            // paymentAmount34
            // 
            this.paymentAmount34.Caption = "Payment";
            this.paymentAmount34.DisplayFormat.FormatString = "N2";
            this.paymentAmount34.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.paymentAmount34.FieldName = "paymentAmount";
            this.paymentAmount34.MinWidth = 23;
            this.paymentAmount34.Name = "paymentAmount34";
            this.paymentAmount34.OptionsColumn.AllowEdit = false;
            this.paymentAmount34.OptionsColumn.FixedWidth = true;
            this.paymentAmount34.Visible = true;
            this.paymentAmount34.Width = 96;
            // 
            // bandedGridColumn185
            // 
            this.bandedGridColumn185.Caption = "Actual Payment";
            this.bandedGridColumn185.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn185.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn185.FieldName = "ap";
            this.bandedGridColumn185.MinWidth = 24;
            this.bandedGridColumn185.Name = "bandedGridColumn185";
            this.bandedGridColumn185.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn185.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn185.Visible = true;
            this.bandedGridColumn185.Width = 96;
            // 
            // bandedGridColumn275
            // 
            this.bandedGridColumn275.Caption = "CC Fee";
            this.bandedGridColumn275.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn275.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn275.FieldName = "ccFee";
            this.bandedGridColumn275.MinWidth = 24;
            this.bandedGridColumn275.Name = "bandedGridColumn275";
            this.bandedGridColumn275.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn275.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn275.Visible = true;
            this.bandedGridColumn275.Width = 94;
            // 
            // debit233
            // 
            this.debit233.Caption = "Debit";
            this.debit233.DisplayFormat.FormatString = "N2";
            this.debit233.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.debit233.FieldName = "debitAdjustment";
            this.debit233.MinWidth = 23;
            this.debit233.Name = "debit233";
            this.debit233.OptionsColumn.FixedWidth = true;
            this.debit233.Visible = true;
            this.debit233.Width = 87;
            // 
            // credit234
            // 
            this.credit234.Caption = "Credit";
            this.credit234.DisplayFormat.FormatString = "N2";
            this.credit234.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.credit234.FieldName = "creditAdjustment";
            this.credit234.MinWidth = 23;
            this.credit234.Name = "credit234";
            this.credit234.OptionsColumn.FixedWidth = true;
            this.credit234.Visible = true;
            this.credit234.Width = 87;
            // 
            // interestPaid58
            // 
            this.interestPaid58.Caption = "Interest";
            this.interestPaid58.DisplayFormat.FormatString = "N2";
            this.interestPaid58.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.interestPaid58.FieldName = "interestPaid";
            this.interestPaid58.MinWidth = 23;
            this.interestPaid58.Name = "interestPaid58";
            this.interestPaid58.OptionsColumn.FixedWidth = true;
            this.interestPaid58.Visible = true;
            this.interestPaid58.Width = 87;
            // 
            // totalPayments35
            // 
            this.totalPayments35.Caption = "Total Payments";
            this.totalPayments35.DisplayFormat.FormatString = "N2";
            this.totalPayments35.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.totalPayments35.FieldName = "totalPayments";
            this.totalPayments35.MinWidth = 23;
            this.totalPayments35.Name = "totalPayments35";
            this.totalPayments35.OptionsColumn.FixedWidth = true;
            this.totalPayments35.Visible = true;
            this.totalPayments35.Width = 96;
            // 
            // SplitDownPayment58
            // 
            this.SplitDownPayment58.Caption = "Split DownPayment";
            this.SplitDownPayment58.DisplayFormat.FormatString = "N2";
            this.SplitDownPayment58.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.SplitDownPayment58.FieldName = "Split DownPayment";
            this.SplitDownPayment58.MinWidth = 23;
            this.SplitDownPayment58.Name = "SplitDownPayment58";
            this.SplitDownPayment58.OptionsColumn.FixedWidth = true;
            this.SplitDownPayment58.Visible = true;
            this.SplitDownPayment58.Width = 118;
            // 
            // CashAdvance275
            // 
            this.CashAdvance275.Caption = "Cash Advance";
            this.CashAdvance275.DisplayFormat.FormatString = "N2";
            this.CashAdvance275.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.CashAdvance275.FieldName = "cashAdvance";
            this.CashAdvance275.MinWidth = 23;
            this.CashAdvance275.Name = "CashAdvance275";
            this.CashAdvance275.OptionsColumn.FixedWidth = true;
            this.CashAdvance275.Visible = true;
            this.CashAdvance275.Width = 87;
            // 
            // SplitPayment58
            // 
            this.SplitPayment58.Caption = "Split Payment";
            this.SplitPayment58.DisplayFormat.FormatString = "N2";
            this.SplitPayment58.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.SplitPayment58.FieldName = "Split Payment";
            this.SplitPayment58.MinWidth = 23;
            this.SplitPayment58.Name = "SplitPayment58";
            this.SplitPayment58.OptionsColumn.FixedWidth = true;
            this.SplitPayment58.Visible = true;
            this.SplitPayment58.Width = 87;
            // 
            // bandedGridColumn59
            // 
            this.bandedGridColumn59.Caption = "Re-Ins";
            this.bandedGridColumn59.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn59.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn59.FieldName = "Reins";
            this.bandedGridColumn59.MinWidth = 23;
            this.bandedGridColumn59.Name = "bandedGridColumn59";
            this.bandedGridColumn59.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn59.Visible = true;
            this.bandedGridColumn59.Width = 87;
            // 
            // recapAmount58
            // 
            this.recapAmount58.Caption = "Recap Amount";
            this.recapAmount58.DisplayFormat.FormatString = "N2";
            this.recapAmount58.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.recapAmount58.FieldName = "recapAmount";
            this.recapAmount58.MinWidth = 23;
            this.recapAmount58.Name = "recapAmount58";
            this.recapAmount58.OptionsColumn.FixedWidth = true;
            this.recapAmount58.Visible = true;
            this.recapAmount58.Width = 87;
            // 
            // commission231
            // 
            this.commission231.Caption = "Commission";
            this.commission231.DisplayFormat.FormatString = "N2";
            this.commission231.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.commission231.FieldName = "commission";
            this.commission231.MinWidth = 23;
            this.commission231.Name = "commission231";
            this.commission231.OptionsColumn.FixedWidth = true;
            this.commission231.Visible = true;
            this.commission231.Width = 117;
            // 
            // bandedGridColumn273
            // 
            this.bandedGridColumn273.Caption = "% Comm";
            this.bandedGridColumn273.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn273.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn273.FieldName = "percentComm";
            this.bandedGridColumn273.MinWidth = 23;
            this.bandedGridColumn273.Name = "bandedGridColumn273";
            this.bandedGridColumn273.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn273.Visible = true;
            this.bandedGridColumn273.Width = 87;
            // 
            // bandedGridColumn37
            // 
            this.bandedGridColumn37.Caption = "record";
            this.bandedGridColumn37.FieldName = "record";
            this.bandedGridColumn37.MinWidth = 23;
            this.bandedGridColumn37.Name = "bandedGridColumn37";
            this.bandedGridColumn37.RowCount = 2;
            this.bandedGridColumn37.Width = 87;
            // 
            // bandedGridColumn28
            // 
            this.bandedGridColumn28.Caption = "Deposit Number";
            this.bandedGridColumn28.FieldName = "depositNumber";
            this.bandedGridColumn28.MinWidth = 23;
            this.bandedGridColumn28.Name = "bandedGridColumn28";
            this.bandedGridColumn28.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn28.Width = 87;
            // 
            // bandedGridColumn33
            // 
            this.bandedGridColumn33.Caption = "UserId";
            this.bandedGridColumn33.FieldName = "userId";
            this.bandedGridColumn33.MinWidth = 23;
            this.bandedGridColumn33.Name = "bandedGridColumn33";
            this.bandedGridColumn33.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn33.Visible = true;
            this.bandedGridColumn33.Width = 87;
            // 
            // bandedGridColumn34
            // 
            this.bandedGridColumn34.Caption = "Edited";
            this.bandedGridColumn34.FieldName = "edited";
            this.bandedGridColumn34.MinWidth = 23;
            this.bandedGridColumn34.Name = "bandedGridColumn34";
            this.bandedGridColumn34.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn34.Visible = true;
            this.bandedGridColumn34.Width = 87;
            // 
            // panel3Top
            // 
            this.panel3Top.BackColor = System.Drawing.Color.Salmon;
            this.panel3Top.Controls.Add(this.chkToggleGroups);
            this.panel3Top.Controls.Add(this.btnMatch);
            this.panel3Top.Controls.Add(this.chkCollapes);
            this.panel3Top.Controls.Add(this.chkShowCommissions);
            this.panel3Top.Controls.Add(this.chkSummarize);
            this.panel3Top.Controls.Add(this.chkNoSummary);
            this.panel3Top.Controls.Add(this.chkMonthly);
            this.panel3Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3Top.Location = new System.Drawing.Point(0, 0);
            this.panel3Top.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel3Top.Name = "panel3Top";
            this.panel3Top.Size = new System.Drawing.Size(1395, 31);
            this.panel3Top.TabIndex = 8;
            // 
            // chkToggleGroups
            // 
            this.chkToggleGroups.AutoSize = true;
            this.chkToggleGroups.Location = new System.Drawing.Point(940, 6);
            this.chkToggleGroups.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkToggleGroups.Name = "chkToggleGroups";
            this.chkToggleGroups.Size = new System.Drawing.Size(131, 21);
            this.chkToggleGroups.TabIndex = 18;
            this.chkToggleGroups.Text = "Toggle Grouping";
            this.chkToggleGroups.UseVisualStyleBackColor = true;
            this.chkToggleGroups.CheckedChanged += new System.EventHandler(this.chkToggleGroups_CheckedChanged);
            // 
            // btnMatch
            // 
            this.btnMatch.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMatch.Location = new System.Drawing.Point(1141, 5);
            this.btnMatch.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnMatch.Name = "btnMatch";
            this.btnMatch.Size = new System.Drawing.Size(87, 22);
            this.btnMatch.TabIndex = 17;
            this.btnMatch.Text = "Match Reports";
            this.btnMatch.UseVisualStyleBackColor = true;
            this.btnMatch.Click += new System.EventHandler(this.btnMatch_Click);
            // 
            // chkCollapes
            // 
            this.chkCollapes.AutoSize = true;
            this.chkCollapes.Location = new System.Drawing.Point(420, 6);
            this.chkCollapes.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkCollapes.Name = "chkCollapes";
            this.chkCollapes.Size = new System.Drawing.Size(79, 21);
            this.chkCollapes.TabIndex = 16;
            this.chkCollapes.Text = "Collapes";
            this.chkCollapes.UseVisualStyleBackColor = true;
            this.chkCollapes.CheckedChanged += new System.EventHandler(this.chkCollapes_CheckedChanged);
            // 
            // chkShowCommissions
            // 
            this.chkShowCommissions.AutoSize = true;
            this.chkShowCommissions.Location = new System.Drawing.Point(769, 5);
            this.chkShowCommissions.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkShowCommissions.Name = "chkShowCommissions";
            this.chkShowCommissions.Size = new System.Drawing.Size(184, 21);
            this.chkShowCommissions.TabIndex = 15;
            this.chkShowCommissions.Text = "Show Detail Commissions";
            this.chkShowCommissions.UseVisualStyleBackColor = true;
            this.chkShowCommissions.CheckedChanged += new System.EventHandler(this.chkShowCommissions_CheckedChanged);
            // 
            // chkSummarize
            // 
            this.chkSummarize.AutoSize = true;
            this.chkSummarize.Location = new System.Drawing.Point(310, 6);
            this.chkSummarize.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkSummarize.Name = "chkSummarize";
            this.chkSummarize.Size = new System.Drawing.Size(97, 21);
            this.chkSummarize.TabIndex = 14;
            this.chkSummarize.Text = "Summarize";
            this.chkSummarize.UseVisualStyleBackColor = true;
            this.chkSummarize.CheckedChanged += new System.EventHandler(this.chkSummarize_CheckedChanged);
            // 
            // chkNoSummary
            // 
            this.chkNoSummary.AutoSize = true;
            this.chkNoSummary.Location = new System.Drawing.Point(167, 9);
            this.chkNoSummary.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkNoSummary.Name = "chkNoSummary";
            this.chkNoSummary.Size = new System.Drawing.Size(107, 21);
            this.chkNoSummary.TabIndex = 13;
            this.chkNoSummary.Text = "Show Details";
            this.chkNoSummary.UseVisualStyleBackColor = true;
            this.chkNoSummary.CheckedChanged += new System.EventHandler(this.chkNoSummary_CheckedChanged);
            // 
            // chkMonthly
            // 
            this.chkMonthly.AutoSize = true;
            this.chkMonthly.Location = new System.Drawing.Point(26, 7);
            this.chkMonthly.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkMonthly.Name = "chkMonthly";
            this.chkMonthly.Size = new System.Drawing.Size(132, 21);
            this.chkMonthly.TabIndex = 12;
            this.chkMonthly.Text = "Month by Month";
            this.chkMonthly.UseVisualStyleBackColor = true;
            this.chkMonthly.CheckedChanged += new System.EventHandler(this.chkMonthly_CheckedChanged);
            // 
            // tabLocationTotals
            // 
            this.tabLocationTotals.Controls.Add(this.panel5All);
            this.tabLocationTotals.Location = new System.Drawing.Point(4, 25);
            this.tabLocationTotals.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabLocationTotals.Name = "tabLocationTotals";
            this.tabLocationTotals.Size = new System.Drawing.Size(1395, 382);
            this.tabLocationTotals.TabIndex = 4;
            this.tabLocationTotals.Text = "Location Totals";
            this.tabLocationTotals.UseVisualStyleBackColor = true;
            // 
            // panel5All
            // 
            this.panel5All.Controls.Add(this.panel5Bottom);
            this.panel5All.Controls.Add(this.panel5Top);
            this.panel5All.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5All.Location = new System.Drawing.Point(0, 0);
            this.panel5All.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel5All.Name = "panel5All";
            this.panel5All.Size = new System.Drawing.Size(1395, 382);
            this.panel5All.TabIndex = 8;
            // 
            // panel5Bottom
            // 
            this.panel5Bottom.Controls.Add(this.dgv5);
            this.panel5Bottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5Bottom.Location = new System.Drawing.Point(0, 46);
            this.panel5Bottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel5Bottom.Name = "panel5Bottom";
            this.panel5Bottom.Size = new System.Drawing.Size(1395, 336);
            this.panel5Bottom.TabIndex = 10;
            // 
            // dgv5
            // 
            this.dgv5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv5.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv5.Location = new System.Drawing.Point(0, 0);
            this.dgv5.LookAndFeel.SkinName = "iMaginary";
            this.dgv5.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv5.MainView = this.gridMain5;
            this.dgv5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv5.Name = "dgv5";
            this.dgv5.Size = new System.Drawing.Size(1395, 336);
            this.dgv5.TabIndex = 7;
            this.dgv5.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain5});
            // 
            // gridMain5
            // 
            this.gridMain5.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain5.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain5.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain5.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain5.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain5.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain5.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain5.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain5.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain5.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain5.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain5.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain5.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain5.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain5.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain5.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain5.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain5.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain5.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain5.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain5.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain5.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain5.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain5.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain5.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain5.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain5.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain5.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain5.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain5.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain5.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain5.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain5.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain5.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain5.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain5.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain5.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain5.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain5.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain5.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain5.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain5.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain5.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain5.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain5.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain5.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain5.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain5.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain5.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain5.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain5.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain5.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain5.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain5.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain5.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain5.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain5.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain5.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain5.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain5.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain5.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain5.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain5.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.Row.Options.UseBackColor = true;
            this.gridMain5.Appearance.Row.Options.UseForeColor = true;
            this.gridMain5.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain5.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain5.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain5.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain5.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain5.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain5.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand5});
            this.gridMain5.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain5.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn48,
            this.bandedGridColumn57,
            this.bandedGridColumn277,
            this.bandedGridColumn55,
            this.bandedGridColumn49,
            this.bandedGridColumn276,
            this.bandedGridColumn54,
            this.bandedGridColumn56,
            this.bandedGridColumn53,
            this.bandedGridColumn51,
            this.bandedGridColumn50,
            this.bandedGridColumn52,
            this.bandedGridColumn74,
            this.bandedGridColumn75,
            this.bandedGridColumn85,
            this.bandedGridColumn109,
            this.bandedGridColumn86,
            this.bandedGridColumn58});
            this.gridMain5.DetailHeight = 431;
            this.gridMain5.GridControl = this.dgv5;
            this.gridMain5.Name = "gridMain5";
            this.gridMain5.OptionsBehavior.Editable = false;
            this.gridMain5.OptionsBehavior.ReadOnly = true;
            this.gridMain5.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain5.OptionsPrint.PrintBandHeader = false;
            this.gridMain5.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain5.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain5.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain5.OptionsView.ShowBands = false;
            this.gridMain5.OptionsView.ShowFooter = true;
            this.gridMain5.OptionsView.ShowGroupPanel = false;
            this.gridMain5.PaintStyleName = "Style3D";
            // 
            // gridBand5
            // 
            this.gridBand5.Caption = "gridBand1";
            this.gridBand5.Columns.Add(this.bandedGridColumn48);
            this.gridBand5.Columns.Add(this.bandedGridColumn49);
            this.gridBand5.Columns.Add(this.bandedGridColumn50);
            this.gridBand5.Columns.Add(this.bandedGridColumn51);
            this.gridBand5.Columns.Add(this.bandedGridColumn52);
            this.gridBand5.Columns.Add(this.bandedGridColumn53);
            this.gridBand5.Columns.Add(this.bandedGridColumn276);
            this.gridBand5.Columns.Add(this.bandedGridColumn54);
            this.gridBand5.Columns.Add(this.bandedGridColumn277);
            this.gridBand5.Columns.Add(this.bandedGridColumn55);
            this.gridBand5.Columns.Add(this.bandedGridColumn56);
            this.gridBand5.Columns.Add(this.bandedGridColumn74);
            this.gridBand5.Columns.Add(this.bandedGridColumn75);
            this.gridBand5.Columns.Add(this.bandedGridColumn85);
            this.gridBand5.Columns.Add(this.bandedGridColumn109);
            this.gridBand5.Columns.Add(this.bandedGridColumn86);
            this.gridBand5.Columns.Add(this.bandedGridColumn58);
            this.gridBand5.Columns.Add(this.bandedGridColumn57);
            this.gridBand5.MinWidth = 12;
            this.gridBand5.Name = "gridBand5";
            this.gridBand5.VisibleIndex = 0;
            this.gridBand5.Width = 1487;
            // 
            // bandedGridColumn48
            // 
            this.bandedGridColumn48.Caption = "Num";
            this.bandedGridColumn48.FieldName = "num";
            this.bandedGridColumn48.MinWidth = 23;
            this.bandedGridColumn48.Name = "bandedGridColumn48";
            this.bandedGridColumn48.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn48.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn48.Visible = true;
            this.bandedGridColumn48.Width = 58;
            // 
            // bandedGridColumn49
            // 
            this.bandedGridColumn49.Caption = "Agent";
            this.bandedGridColumn49.FieldName = "agentNumber";
            this.bandedGridColumn49.MinWidth = 23;
            this.bandedGridColumn49.Name = "bandedGridColumn49";
            this.bandedGridColumn49.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn49.Width = 70;
            // 
            // bandedGridColumn50
            // 
            this.bandedGridColumn50.Caption = "Agent Name";
            this.bandedGridColumn50.FieldName = "agentName";
            this.bandedGridColumn50.MinWidth = 23;
            this.bandedGridColumn50.Name = "bandedGridColumn50";
            this.bandedGridColumn50.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn50.Width = 175;
            // 
            // bandedGridColumn51
            // 
            this.bandedGridColumn51.Caption = "Loc";
            this.bandedGridColumn51.FieldName = "loc";
            this.bandedGridColumn51.MinWidth = 23;
            this.bandedGridColumn51.Name = "bandedGridColumn51";
            this.bandedGridColumn51.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn51.Visible = true;
            this.bandedGridColumn51.Width = 47;
            // 
            // bandedGridColumn52
            // 
            this.bandedGridColumn52.Caption = "Location Name";
            this.bandedGridColumn52.FieldName = "Location Name";
            this.bandedGridColumn52.MinWidth = 23;
            this.bandedGridColumn52.Name = "bandedGridColumn52";
            this.bandedGridColumn52.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn52.Visible = true;
            this.bandedGridColumn52.Width = 175;
            // 
            // bandedGridColumn53
            // 
            this.bandedGridColumn53.Caption = "Contract Value";
            this.bandedGridColumn53.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn53.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn53.FieldName = "contractValue";
            this.bandedGridColumn53.MinWidth = 23;
            this.bandedGridColumn53.Name = "bandedGridColumn53";
            this.bandedGridColumn53.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn53.Visible = true;
            this.bandedGridColumn53.Width = 117;
            // 
            // bandedGridColumn276
            // 
            this.bandedGridColumn276.Caption = "Actual Down Payment";
            this.bandedGridColumn276.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn276.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn276.FieldName = "dpp";
            this.bandedGridColumn276.MinWidth = 24;
            this.bandedGridColumn276.Name = "bandedGridColumn276";
            this.bandedGridColumn276.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn276.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn276.Visible = true;
            this.bandedGridColumn276.Width = 96;
            // 
            // bandedGridColumn54
            // 
            this.bandedGridColumn54.Caption = "Down Payment";
            this.bandedGridColumn54.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn54.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn54.FieldName = "downPayment";
            this.bandedGridColumn54.MinWidth = 23;
            this.bandedGridColumn54.Name = "bandedGridColumn54";
            this.bandedGridColumn54.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn54.Visible = true;
            this.bandedGridColumn54.Width = 96;
            // 
            // bandedGridColumn277
            // 
            this.bandedGridColumn277.Caption = "Actual Payment";
            this.bandedGridColumn277.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn277.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn277.FieldName = "ap";
            this.bandedGridColumn277.MinWidth = 24;
            this.bandedGridColumn277.Name = "bandedGridColumn277";
            this.bandedGridColumn277.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn277.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn277.Visible = true;
            this.bandedGridColumn277.Width = 96;
            // 
            // bandedGridColumn55
            // 
            this.bandedGridColumn55.Caption = "Payment";
            this.bandedGridColumn55.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn55.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn55.FieldName = "paymentAmount";
            this.bandedGridColumn55.MinWidth = 23;
            this.bandedGridColumn55.Name = "bandedGridColumn55";
            this.bandedGridColumn55.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn55.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn55.Visible = true;
            this.bandedGridColumn55.Width = 96;
            // 
            // bandedGridColumn56
            // 
            this.bandedGridColumn56.Caption = "Total Payments";
            this.bandedGridColumn56.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn56.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn56.FieldName = "totalPayments";
            this.bandedGridColumn56.MinWidth = 23;
            this.bandedGridColumn56.Name = "bandedGridColumn56";
            this.bandedGridColumn56.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn56.Visible = true;
            this.bandedGridColumn56.Width = 96;
            // 
            // bandedGridColumn74
            // 
            this.bandedGridColumn74.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn74.AppearanceCell.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.bandedGridColumn74.Caption = "Contract #";
            this.bandedGridColumn74.FieldName = "contracts";
            this.bandedGridColumn74.MinWidth = 23;
            this.bandedGridColumn74.Name = "bandedGridColumn74";
            this.bandedGridColumn74.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn74.Visible = true;
            this.bandedGridColumn74.Width = 262;
            // 
            // bandedGridColumn75
            // 
            this.bandedGridColumn75.Caption = "IB Trust";
            this.bandedGridColumn75.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn75.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn75.FieldName = "ibtrust";
            this.bandedGridColumn75.MinWidth = 23;
            this.bandedGridColumn75.Name = "bandedGridColumn75";
            this.bandedGridColumn75.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn75.Visible = true;
            this.bandedGridColumn75.Width = 87;
            // 
            // bandedGridColumn85
            // 
            this.bandedGridColumn85.Caption = "SP Trust";
            this.bandedGridColumn85.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn85.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn85.FieldName = "sptrust";
            this.bandedGridColumn85.MinWidth = 23;
            this.bandedGridColumn85.Name = "bandedGridColumn85";
            this.bandedGridColumn85.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn85.Visible = true;
            this.bandedGridColumn85.Width = 87;
            // 
            // bandedGridColumn109
            // 
            this.bandedGridColumn109.Caption = "XX Trust";
            this.bandedGridColumn109.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn109.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn109.FieldName = "xxtrust";
            this.bandedGridColumn109.MinWidth = 23;
            this.bandedGridColumn109.Name = "bandedGridColumn109";
            this.bandedGridColumn109.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn109.Visible = true;
            this.bandedGridColumn109.Width = 87;
            // 
            // bandedGridColumn86
            // 
            this.bandedGridColumn86.Caption = "Total";
            this.bandedGridColumn86.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn86.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn86.FieldName = "total";
            this.bandedGridColumn86.MinWidth = 23;
            this.bandedGridColumn86.Name = "bandedGridColumn86";
            this.bandedGridColumn86.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn86.Visible = true;
            this.bandedGridColumn86.Width = 87;
            // 
            // bandedGridColumn58
            // 
            this.bandedGridColumn58.Caption = "Trust85";
            this.bandedGridColumn58.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn58.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn58.FieldName = "trust85P";
            this.bandedGridColumn58.MinWidth = 23;
            this.bandedGridColumn58.Name = "bandedGridColumn58";
            this.bandedGridColumn58.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn58.Width = 87;
            // 
            // bandedGridColumn57
            // 
            this.bandedGridColumn57.Caption = "record";
            this.bandedGridColumn57.FieldName = "record";
            this.bandedGridColumn57.MinWidth = 23;
            this.bandedGridColumn57.Name = "bandedGridColumn57";
            this.bandedGridColumn57.RowCount = 2;
            this.bandedGridColumn57.Width = 87;
            // 
            // panel5Top
            // 
            this.panel5Top.BackColor = System.Drawing.Color.MistyRose;
            this.panel5Top.Controls.Add(this.cmbLocationTotals);
            this.panel5Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5Top.Location = new System.Drawing.Point(0, 0);
            this.panel5Top.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel5Top.Name = "panel5Top";
            this.panel5Top.Size = new System.Drawing.Size(1395, 46);
            this.panel5Top.TabIndex = 9;
            // 
            // cmbLocationTotals
            // 
            this.cmbLocationTotals.EditValue = ", ";
            this.cmbLocationTotals.Location = new System.Drawing.Point(472, 10);
            this.cmbLocationTotals.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbLocationTotals.Name = "cmbLocationTotals";
            this.cmbLocationTotals.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmbLocationTotals.Properties.DisplayMember = "options";
            this.cmbLocationTotals.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.CheckedListBoxItem[] {
            new DevExpress.XtraEditors.Controls.CheckedListBoxItem(null, "Normal", System.Windows.Forms.CheckState.Checked),
            new DevExpress.XtraEditors.Controls.CheckedListBoxItem(null, "Trust Totals")});
            this.cmbLocationTotals.Properties.EditValueChanged += new System.EventHandler(this.checkedComboBoxEdit1_Properties_EditValueChanged);
            this.cmbLocationTotals.Size = new System.Drawing.Size(171, 22);
            this.cmbLocationTotals.TabIndex = 0;
            this.cmbLocationTotals.EditValueChanged += new System.EventHandler(this.cmbLocationTotals_EditValueChanged);
            this.cmbLocationTotals.TextChanged += new System.EventHandler(this.cmbLocationTotals_TextChanged);
            // 
            // tabContractLocations
            // 
            this.tabContractLocations.Controls.Add(this.dgv7);
            this.tabContractLocations.Location = new System.Drawing.Point(4, 25);
            this.tabContractLocations.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabContractLocations.Name = "tabContractLocations";
            this.tabContractLocations.Size = new System.Drawing.Size(1395, 382);
            this.tabContractLocations.TabIndex = 6;
            this.tabContractLocations.Text = "Contracts by Location";
            this.tabContractLocations.UseVisualStyleBackColor = true;
            // 
            // dgv7
            // 
            this.dgv7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv7.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv7.Location = new System.Drawing.Point(0, 0);
            this.dgv7.LookAndFeel.SkinName = "iMaginary";
            this.dgv7.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv7.MainView = this.gridMain7;
            this.dgv7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv7.Name = "dgv7";
            this.dgv7.Size = new System.Drawing.Size(1395, 382);
            this.dgv7.TabIndex = 6;
            this.dgv7.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain7});
            // 
            // gridMain7
            // 
            this.gridMain7.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain7.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain7.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain7.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain7.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain7.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain7.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain7.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain7.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain7.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain7.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain7.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain7.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain7.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain7.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain7.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain7.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain7.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain7.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain7.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain7.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain7.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain7.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain7.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain7.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain7.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain7.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain7.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain7.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain7.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain7.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain7.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain7.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain7.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain7.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain7.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain7.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain7.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain7.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain7.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain7.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain7.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain7.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain7.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain7.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain7.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain7.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain7.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain7.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain7.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain7.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain7.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain7.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain7.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain7.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain7.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain7.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain7.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain7.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain7.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain7.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain7.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain7.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.Row.Options.UseBackColor = true;
            this.gridMain7.Appearance.Row.Options.UseForeColor = true;
            this.gridMain7.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain7.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain7.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain7.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain7.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain7.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain7.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain7.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain7.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain7.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain7.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain7.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand7});
            this.gridMain7.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain7.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn93,
            this.bandedGridColumn105,
            this.bandedGridColumn279,
            this.paymentAmount100,
            this.bandedGridColumn94,
            this.bandedGridColumn278,
            this.downPayment99,
            this.totalPayments100,
            this.contractValue98,
            this.bandedGridColumn96,
            this.bandedGridColumn95,
            this.bandedGridColumn97,
            this.ibtrust102,
            this.sptrust103,
            this.xxtrust104,
            this.total104,
            this.bandedGridColumn102,
            this.bandedGridColumn103,
            this.bandedGridColumn98,
            this.bandedGridColumn99});
            this.gridMain7.DetailHeight = 431;
            this.gridMain7.GridControl = this.dgv7;
            this.gridMain7.GroupCount = 2;
            this.gridMain7.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ibtrust", this.ibtrust102, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "sptrust", this.sptrust103, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "contractValue", this.contractValue98, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "downPayment", this.downPayment99, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "totalPayments", this.totalPayments100, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "total", this.total104, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "xxtrust", this.xxtrust104, "${0:0,0.00}")});
            this.gridMain7.Name = "gridMain7";
            this.gridMain7.OptionsBehavior.AutoExpandAllGroups = true;
            this.gridMain7.OptionsBehavior.Editable = false;
            this.gridMain7.OptionsBehavior.ReadOnly = true;
            this.gridMain7.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain7.OptionsPrint.PrintBandHeader = false;
            this.gridMain7.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain7.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain7.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain7.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.gridMain7.OptionsView.ShowBands = false;
            this.gridMain7.OptionsView.ShowFooter = true;
            this.gridMain7.OptionsView.ShowGroupPanel = false;
            this.gridMain7.PaintStyleName = "Style3D";
            this.gridMain7.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.bandedGridColumn97, DevExpress.Data.ColumnSortOrder.Ascending),
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.bandedGridColumn95, DevExpress.Data.ColumnSortOrder.Ascending)});
            this.gridMain7.BeforePrintRow += new DevExpress.XtraGrid.Views.Base.BeforePrintRowEventHandler(this.gridMain7_BeforePrintRow);
            this.gridMain7.AfterPrintRow += new DevExpress.XtraGrid.Views.Base.AfterPrintRowEventHandler(this.gridMain7_AfterPrintRow);
            // 
            // gridBand7
            // 
            this.gridBand7.Caption = "gridBand1";
            this.gridBand7.Columns.Add(this.bandedGridColumn93);
            this.gridBand7.Columns.Add(this.bandedGridColumn94);
            this.gridBand7.Columns.Add(this.bandedGridColumn95);
            this.gridBand7.Columns.Add(this.bandedGridColumn96);
            this.gridBand7.Columns.Add(this.bandedGridColumn98);
            this.gridBand7.Columns.Add(this.bandedGridColumn102);
            this.gridBand7.Columns.Add(this.bandedGridColumn103);
            this.gridBand7.Columns.Add(this.bandedGridColumn99);
            this.gridBand7.Columns.Add(this.bandedGridColumn97);
            this.gridBand7.Columns.Add(this.contractValue98);
            this.gridBand7.Columns.Add(this.bandedGridColumn278);
            this.gridBand7.Columns.Add(this.downPayment99);
            this.gridBand7.Columns.Add(this.bandedGridColumn279);
            this.gridBand7.Columns.Add(this.paymentAmount100);
            this.gridBand7.Columns.Add(this.totalPayments100);
            this.gridBand7.Columns.Add(this.ibtrust102);
            this.gridBand7.Columns.Add(this.sptrust103);
            this.gridBand7.Columns.Add(this.xxtrust104);
            this.gridBand7.Columns.Add(this.total104);
            this.gridBand7.Columns.Add(this.bandedGridColumn105);
            this.gridBand7.MinWidth = 12;
            this.gridBand7.Name = "gridBand7";
            this.gridBand7.VisibleIndex = 0;
            this.gridBand7.Width = 1357;
            // 
            // bandedGridColumn93
            // 
            this.bandedGridColumn93.Caption = "Num";
            this.bandedGridColumn93.FieldName = "num";
            this.bandedGridColumn93.MinWidth = 23;
            this.bandedGridColumn93.Name = "bandedGridColumn93";
            this.bandedGridColumn93.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn93.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn93.Visible = true;
            this.bandedGridColumn93.Width = 58;
            // 
            // bandedGridColumn94
            // 
            this.bandedGridColumn94.Caption = "Agent";
            this.bandedGridColumn94.FieldName = "agentNumber";
            this.bandedGridColumn94.MinWidth = 23;
            this.bandedGridColumn94.Name = "bandedGridColumn94";
            this.bandedGridColumn94.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn94.Width = 70;
            // 
            // bandedGridColumn95
            // 
            this.bandedGridColumn95.Caption = "Agent Name";
            this.bandedGridColumn95.FieldName = "agentName";
            this.bandedGridColumn95.MinWidth = 23;
            this.bandedGridColumn95.Name = "bandedGridColumn95";
            this.bandedGridColumn95.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn95.Width = 175;
            // 
            // bandedGridColumn96
            // 
            this.bandedGridColumn96.Caption = "Loc";
            this.bandedGridColumn96.FieldName = "loc";
            this.bandedGridColumn96.MinWidth = 23;
            this.bandedGridColumn96.Name = "bandedGridColumn96";
            this.bandedGridColumn96.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn96.Visible = true;
            this.bandedGridColumn96.Width = 47;
            // 
            // bandedGridColumn98
            // 
            this.bandedGridColumn98.Caption = "Issue Date";
            this.bandedGridColumn98.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn98.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn98.FieldName = "issueDate8";
            this.bandedGridColumn98.MinWidth = 23;
            this.bandedGridColumn98.Name = "bandedGridColumn98";
            this.bandedGridColumn98.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn98.Visible = true;
            this.bandedGridColumn98.Width = 87;
            // 
            // bandedGridColumn102
            // 
            this.bandedGridColumn102.Caption = "Contract";
            this.bandedGridColumn102.FieldName = "contractNumber";
            this.bandedGridColumn102.MinWidth = 23;
            this.bandedGridColumn102.Name = "bandedGridColumn102";
            this.bandedGridColumn102.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn102.Visible = true;
            this.bandedGridColumn102.Width = 87;
            // 
            // bandedGridColumn103
            // 
            this.bandedGridColumn103.Caption = "Customer";
            this.bandedGridColumn103.FieldName = "customer";
            this.bandedGridColumn103.MinWidth = 23;
            this.bandedGridColumn103.Name = "bandedGridColumn103";
            this.bandedGridColumn103.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn103.Visible = true;
            this.bandedGridColumn103.Width = 175;
            // 
            // bandedGridColumn99
            // 
            this.bandedGridColumn99.Caption = "DBR";
            this.bandedGridColumn99.FieldName = "dbr";
            this.bandedGridColumn99.MinWidth = 23;
            this.bandedGridColumn99.Name = "bandedGridColumn99";
            this.bandedGridColumn99.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn99.Visible = true;
            this.bandedGridColumn99.Width = 47;
            // 
            // bandedGridColumn97
            // 
            this.bandedGridColumn97.Caption = "Location Name";
            this.bandedGridColumn97.FieldName = "Location Name";
            this.bandedGridColumn97.MinWidth = 23;
            this.bandedGridColumn97.Name = "bandedGridColumn97";
            this.bandedGridColumn97.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn97.Width = 175;
            // 
            // contractValue98
            // 
            this.contractValue98.Caption = "Contract Value";
            this.contractValue98.DisplayFormat.FormatString = "N2";
            this.contractValue98.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.contractValue98.FieldName = "contractValue";
            this.contractValue98.MinWidth = 23;
            this.contractValue98.Name = "contractValue98";
            this.contractValue98.OptionsColumn.FixedWidth = true;
            this.contractValue98.Visible = true;
            this.contractValue98.Width = 117;
            // 
            // bandedGridColumn278
            // 
            this.bandedGridColumn278.Caption = "Actual Down Payment";
            this.bandedGridColumn278.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn278.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn278.FieldName = "dpp";
            this.bandedGridColumn278.MinWidth = 24;
            this.bandedGridColumn278.Name = "bandedGridColumn278";
            this.bandedGridColumn278.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn278.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn278.Visible = true;
            this.bandedGridColumn278.Width = 96;
            // 
            // downPayment99
            // 
            this.downPayment99.Caption = "Down Payment";
            this.downPayment99.DisplayFormat.FormatString = "N2";
            this.downPayment99.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.downPayment99.FieldName = "downPayment";
            this.downPayment99.MinWidth = 23;
            this.downPayment99.Name = "downPayment99";
            this.downPayment99.OptionsColumn.FixedWidth = true;
            this.downPayment99.Visible = true;
            this.downPayment99.Width = 96;
            // 
            // bandedGridColumn279
            // 
            this.bandedGridColumn279.Caption = "Actual Payment";
            this.bandedGridColumn279.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn279.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn279.FieldName = "ap";
            this.bandedGridColumn279.MinWidth = 24;
            this.bandedGridColumn279.Name = "bandedGridColumn279";
            this.bandedGridColumn279.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn279.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn279.Visible = true;
            this.bandedGridColumn279.Width = 96;
            // 
            // paymentAmount100
            // 
            this.paymentAmount100.Caption = "Payment";
            this.paymentAmount100.DisplayFormat.FormatString = "N2";
            this.paymentAmount100.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.paymentAmount100.FieldName = "paymentAmount";
            this.paymentAmount100.MinWidth = 23;
            this.paymentAmount100.Name = "paymentAmount100";
            this.paymentAmount100.OptionsColumn.AllowEdit = false;
            this.paymentAmount100.OptionsColumn.FixedWidth = true;
            this.paymentAmount100.Width = 96;
            // 
            // totalPayments100
            // 
            this.totalPayments100.Caption = "Total Payments";
            this.totalPayments100.DisplayFormat.FormatString = "N2";
            this.totalPayments100.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.totalPayments100.FieldName = "totalPayments";
            this.totalPayments100.MinWidth = 23;
            this.totalPayments100.Name = "totalPayments100";
            this.totalPayments100.OptionsColumn.FixedWidth = true;
            this.totalPayments100.Visible = true;
            this.totalPayments100.Width = 96;
            // 
            // ibtrust102
            // 
            this.ibtrust102.Caption = "IB Trust";
            this.ibtrust102.DisplayFormat.FormatString = "N2";
            this.ibtrust102.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.ibtrust102.FieldName = "ibtrust";
            this.ibtrust102.MinWidth = 23;
            this.ibtrust102.Name = "ibtrust102";
            this.ibtrust102.OptionsColumn.FixedWidth = true;
            this.ibtrust102.Visible = true;
            this.ibtrust102.Width = 87;
            // 
            // sptrust103
            // 
            this.sptrust103.Caption = "SP Trust";
            this.sptrust103.DisplayFormat.FormatString = "N2";
            this.sptrust103.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.sptrust103.FieldName = "sptrust";
            this.sptrust103.MinWidth = 23;
            this.sptrust103.Name = "sptrust103";
            this.sptrust103.OptionsColumn.FixedWidth = true;
            this.sptrust103.Visible = true;
            this.sptrust103.Width = 87;
            // 
            // xxtrust104
            // 
            this.xxtrust104.Caption = "XX Trust";
            this.xxtrust104.DisplayFormat.FormatString = "N2";
            this.xxtrust104.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.xxtrust104.FieldName = "xxtrust";
            this.xxtrust104.MinWidth = 23;
            this.xxtrust104.Name = "xxtrust104";
            this.xxtrust104.OptionsColumn.FixedWidth = true;
            this.xxtrust104.Visible = true;
            this.xxtrust104.Width = 87;
            // 
            // total104
            // 
            this.total104.Caption = "Total";
            this.total104.DisplayFormat.FormatString = "N2";
            this.total104.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.total104.FieldName = "total";
            this.total104.MinWidth = 23;
            this.total104.Name = "total104";
            this.total104.OptionsColumn.FixedWidth = true;
            this.total104.Visible = true;
            this.total104.Width = 87;
            // 
            // bandedGridColumn105
            // 
            this.bandedGridColumn105.Caption = "record";
            this.bandedGridColumn105.FieldName = "record";
            this.bandedGridColumn105.MinWidth = 23;
            this.bandedGridColumn105.Name = "bandedGridColumn105";
            this.bandedGridColumn105.RowCount = 2;
            this.bandedGridColumn105.Width = 87;
            // 
            // tabLapse
            // 
            this.tabLapse.Controls.Add(this.dgv8);
            this.tabLapse.Location = new System.Drawing.Point(4, 25);
            this.tabLapse.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabLapse.Name = "tabLapse";
            this.tabLapse.Size = new System.Drawing.Size(1395, 382);
            this.tabLapse.TabIndex = 7;
            this.tabLapse.Text = "Lapses";
            this.tabLapse.UseVisualStyleBackColor = true;
            // 
            // dgv8
            // 
            this.dgv8.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv8.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv8.Location = new System.Drawing.Point(0, 0);
            this.dgv8.LookAndFeel.SkinName = "iMaginary";
            this.dgv8.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv8.MainView = this.gridMain8;
            this.dgv8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv8.Name = "dgv8";
            this.dgv8.Size = new System.Drawing.Size(1395, 382);
            this.dgv8.TabIndex = 5;
            this.dgv8.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain8});
            // 
            // gridMain8
            // 
            this.gridMain8.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain8.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain8.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain8.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain8.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain8.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain8.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain8.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain8.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain8.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain8.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain8.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain8.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain8.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain8.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain8.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain8.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain8.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain8.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain8.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain8.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain8.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain8.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain8.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain8.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain8.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain8.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain8.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain8.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain8.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain8.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain8.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain8.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain8.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain8.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain8.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain8.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain8.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain8.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain8.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain8.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain8.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain8.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain8.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain8.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain8.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain8.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain8.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain8.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain8.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain8.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain8.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain8.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain8.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain8.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain8.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain8.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain8.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain8.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain8.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain8.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain8.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain8.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain8.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain8.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain8.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain8.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain8.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.Row.Options.UseBackColor = true;
            this.gridMain8.Appearance.Row.Options.UseForeColor = true;
            this.gridMain8.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain8.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain8.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain8.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain8.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain8.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain8.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain8.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain8.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain8.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain8.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain8.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand8});
            this.gridMain8.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain8.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn140,
            this.bandedGridColumn111,
            this.bandedGridColumn135,
            this.bandedGridColumn121,
            this.bandedGridColumn117,
            this.bandedGridColumn122,
            this.bandedGridColumn127,
            this.bandedGridColumn119,
            this.bandedGridColumn118,
            this.bandedGridColumn130,
            this.bandedGridColumn129,
            this.bandedGridColumn112,
            this.bandedGridColumn134,
            this.bandedGridColumn126,
            this.bandedGridColumn128,
            this.bandedGridColumn123,
            this.bandedGridColumn116,
            this.bandedGridColumn114,
            this.bandedGridColumn120,
            this.bandedGridColumn113,
            this.bandedGridColumn115,
            this.bandedGridColumn131,
            this.bandedGridColumn132,
            this.bandedGridColumn133,
            this.bandedGridColumn125,
            this.bandedGridColumn124,
            this.bandedGridColumn136,
            this.bandedGridColumn137,
            this.bandedGridColumn138,
            this.bandedGridColumn139,
            this.bandedGridColumn141,
            this.bandedGridColumn142,
            this.bandedGridColumn234});
            this.gridMain8.DetailHeight = 431;
            this.gridMain8.GridControl = this.dgv8;
            this.gridMain8.Name = "gridMain8";
            this.gridMain8.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain8.OptionsPrint.PrintBandHeader = false;
            this.gridMain8.OptionsSelection.MultiSelect = true;
            this.gridMain8.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain8.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain8.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain8.OptionsView.ShowBands = false;
            this.gridMain8.OptionsView.ShowFooter = true;
            this.gridMain8.OptionsView.ShowGroupPanel = false;
            this.gridMain8.PaintStyleName = "Style3D";
            this.gridMain8.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMain8_CustomDrawCell);
            this.gridMain8.DoubleClick += new System.EventHandler(this.gridMain8_DoubleClick);
            // 
            // gridBand8
            // 
            this.gridBand8.Caption = "gridBand1";
            this.gridBand8.Columns.Add(this.bandedGridColumn111);
            this.gridBand8.Columns.Add(this.bandedGridColumn112);
            this.gridBand8.Columns.Add(this.bandedGridColumn113);
            this.gridBand8.Columns.Add(this.bandedGridColumn114);
            this.gridBand8.Columns.Add(this.bandedGridColumn115);
            this.gridBand8.Columns.Add(this.bandedGridColumn116);
            this.gridBand8.Columns.Add(this.bandedGridColumn117);
            this.gridBand8.Columns.Add(this.bandedGridColumn118);
            this.gridBand8.Columns.Add(this.bandedGridColumn119);
            this.gridBand8.Columns.Add(this.bandedGridColumn120);
            this.gridBand8.Columns.Add(this.bandedGridColumn121);
            this.gridBand8.Columns.Add(this.bandedGridColumn122);
            this.gridBand8.Columns.Add(this.bandedGridColumn123);
            this.gridBand8.Columns.Add(this.bandedGridColumn124);
            this.gridBand8.Columns.Add(this.bandedGridColumn125);
            this.gridBand8.Columns.Add(this.bandedGridColumn126);
            this.gridBand8.Columns.Add(this.bandedGridColumn136);
            this.gridBand8.Columns.Add(this.bandedGridColumn137);
            this.gridBand8.Columns.Add(this.bandedGridColumn138);
            this.gridBand8.Columns.Add(this.bandedGridColumn139);
            this.gridBand8.Columns.Add(this.bandedGridColumn127);
            this.gridBand8.Columns.Add(this.bandedGridColumn128);
            this.gridBand8.Columns.Add(this.bandedGridColumn129);
            this.gridBand8.Columns.Add(this.bandedGridColumn130);
            this.gridBand8.Columns.Add(this.bandedGridColumn131);
            this.gridBand8.Columns.Add(this.bandedGridColumn132);
            this.gridBand8.Columns.Add(this.bandedGridColumn133);
            this.gridBand8.Columns.Add(this.bandedGridColumn134);
            this.gridBand8.Columns.Add(this.bandedGridColumn140);
            this.gridBand8.Columns.Add(this.bandedGridColumn142);
            this.gridBand8.Columns.Add(this.bandedGridColumn141);
            this.gridBand8.Columns.Add(this.bandedGridColumn234);
            this.gridBand8.Columns.Add(this.bandedGridColumn135);
            this.gridBand8.MinWidth = 12;
            this.gridBand8.Name = "gridBand8";
            this.gridBand8.VisibleIndex = 0;
            this.gridBand8.Width = 1707;
            // 
            // bandedGridColumn111
            // 
            this.bandedGridColumn111.Caption = "Num";
            this.bandedGridColumn111.FieldName = "num";
            this.bandedGridColumn111.MinWidth = 23;
            this.bandedGridColumn111.Name = "bandedGridColumn111";
            this.bandedGridColumn111.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn111.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn111.Visible = true;
            this.bandedGridColumn111.Width = 52;
            // 
            // bandedGridColumn112
            // 
            this.bandedGridColumn112.Caption = "Agent";
            this.bandedGridColumn112.FieldName = "agentNumber";
            this.bandedGridColumn112.MinWidth = 23;
            this.bandedGridColumn112.Name = "bandedGridColumn112";
            this.bandedGridColumn112.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn112.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn112.Visible = true;
            this.bandedGridColumn112.Width = 70;
            // 
            // bandedGridColumn113
            // 
            this.bandedGridColumn113.Caption = "Agent Name";
            this.bandedGridColumn113.FieldName = "agentName";
            this.bandedGridColumn113.MinWidth = 23;
            this.bandedGridColumn113.Name = "bandedGridColumn113";
            this.bandedGridColumn113.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn113.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn113.Visible = true;
            this.bandedGridColumn113.Width = 87;
            // 
            // bandedGridColumn114
            // 
            this.bandedGridColumn114.Caption = "Loc";
            this.bandedGridColumn114.FieldName = "loc";
            this.bandedGridColumn114.MinWidth = 23;
            this.bandedGridColumn114.Name = "bandedGridColumn114";
            this.bandedGridColumn114.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn114.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn114.Visible = true;
            this.bandedGridColumn114.Width = 47;
            // 
            // bandedGridColumn115
            // 
            this.bandedGridColumn115.Caption = "Location Name";
            this.bandedGridColumn115.FieldName = "Location Name";
            this.bandedGridColumn115.MinWidth = 23;
            this.bandedGridColumn115.Name = "bandedGridColumn115";
            this.bandedGridColumn115.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn115.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn115.Width = 87;
            // 
            // bandedGridColumn116
            // 
            this.bandedGridColumn116.Caption = "Trust";
            this.bandedGridColumn116.FieldName = "trust";
            this.bandedGridColumn116.MinWidth = 23;
            this.bandedGridColumn116.Name = "bandedGridColumn116";
            this.bandedGridColumn116.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn116.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn116.Visible = true;
            this.bandedGridColumn116.Width = 58;
            // 
            // bandedGridColumn117
            // 
            this.bandedGridColumn117.Caption = "DBR";
            this.bandedGridColumn117.FieldName = "dbr";
            this.bandedGridColumn117.MinWidth = 23;
            this.bandedGridColumn117.Name = "bandedGridColumn117";
            this.bandedGridColumn117.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn117.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn117.Visible = true;
            this.bandedGridColumn117.Width = 58;
            // 
            // bandedGridColumn118
            // 
            this.bandedGridColumn118.Caption = "Lapse  Date";
            this.bandedGridColumn118.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn118.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn118.FieldName = "lapseDate8";
            this.bandedGridColumn118.MinWidth = 23;
            this.bandedGridColumn118.Name = "bandedGridColumn118";
            this.bandedGridColumn118.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn118.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn118.Visible = true;
            this.bandedGridColumn118.Width = 76;
            // 
            // bandedGridColumn119
            // 
            this.bandedGridColumn119.Caption = "Date Paid";
            this.bandedGridColumn119.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn119.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn119.FieldName = "payDate8";
            this.bandedGridColumn119.MinWidth = 23;
            this.bandedGridColumn119.Name = "bandedGridColumn119";
            this.bandedGridColumn119.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn119.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn119.Width = 76;
            // 
            // bandedGridColumn120
            // 
            this.bandedGridColumn120.Caption = "Issue Date";
            this.bandedGridColumn120.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn120.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn120.FieldName = "issueDate8";
            this.bandedGridColumn120.MinWidth = 23;
            this.bandedGridColumn120.Name = "bandedGridColumn120";
            this.bandedGridColumn120.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn120.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn120.Visible = true;
            this.bandedGridColumn120.Width = 87;
            // 
            // bandedGridColumn121
            // 
            this.bandedGridColumn121.Caption = "Contract";
            this.bandedGridColumn121.FieldName = "contractNumber";
            this.bandedGridColumn121.MinWidth = 23;
            this.bandedGridColumn121.Name = "bandedGridColumn121";
            this.bandedGridColumn121.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn121.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn121.Visible = true;
            this.bandedGridColumn121.Width = 82;
            // 
            // bandedGridColumn122
            // 
            this.bandedGridColumn122.Caption = "Customer";
            this.bandedGridColumn122.FieldName = "customer";
            this.bandedGridColumn122.MinWidth = 23;
            this.bandedGridColumn122.Name = "bandedGridColumn122";
            this.bandedGridColumn122.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn122.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn122.Width = 175;
            // 
            // bandedGridColumn123
            // 
            this.bandedGridColumn123.Caption = "Contract Value";
            this.bandedGridColumn123.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn123.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn123.FieldName = "contractValue";
            this.bandedGridColumn123.MinWidth = 23;
            this.bandedGridColumn123.Name = "bandedGridColumn123";
            this.bandedGridColumn123.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn123.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn123.Visible = true;
            this.bandedGridColumn123.Width = 117;
            // 
            // bandedGridColumn124
            // 
            this.bandedGridColumn124.Caption = "Recap";
            this.bandedGridColumn124.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn124.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn124.FieldName = "Recap";
            this.bandedGridColumn124.MinWidth = 23;
            this.bandedGridColumn124.Name = "bandedGridColumn124";
            this.bandedGridColumn124.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn124.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn124.Visible = true;
            this.bandedGridColumn124.Width = 87;
            // 
            // bandedGridColumn125
            // 
            this.bandedGridColumn125.Caption = "Cash Adv";
            this.bandedGridColumn125.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn125.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn125.FieldName = "cashAdvance";
            this.bandedGridColumn125.MinWidth = 23;
            this.bandedGridColumn125.Name = "bandedGridColumn125";
            this.bandedGridColumn125.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn125.Width = 87;
            // 
            // bandedGridColumn126
            // 
            this.bandedGridColumn126.Caption = "Down Payment";
            this.bandedGridColumn126.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn126.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn126.FieldName = "downPayment";
            this.bandedGridColumn126.MinWidth = 23;
            this.bandedGridColumn126.Name = "bandedGridColumn126";
            this.bandedGridColumn126.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn126.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn126.Visible = true;
            this.bandedGridColumn126.Width = 96;
            // 
            // bandedGridColumn136
            // 
            this.bandedGridColumn136.Caption = "Percent";
            this.bandedGridColumn136.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn136.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn136.FieldName = "percent";
            this.bandedGridColumn136.MinWidth = 23;
            this.bandedGridColumn136.Name = "bandedGridColumn136";
            this.bandedGridColumn136.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn136.Visible = true;
            this.bandedGridColumn136.Width = 87;
            // 
            // bandedGridColumn137
            // 
            this.bandedGridColumn137.Caption = "Goal";
            this.bandedGridColumn137.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn137.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn137.FieldName = "goal";
            this.bandedGridColumn137.MinWidth = 23;
            this.bandedGridColumn137.Name = "bandedGridColumn137";
            this.bandedGridColumn137.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn137.Visible = true;
            this.bandedGridColumn137.Width = 87;
            // 
            // bandedGridColumn138
            // 
            this.bandedGridColumn138.Caption = "Formula";
            this.bandedGridColumn138.FieldName = "formula";
            this.bandedGridColumn138.MinWidth = 23;
            this.bandedGridColumn138.Name = "bandedGridColumn138";
            this.bandedGridColumn138.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn138.Visible = true;
            this.bandedGridColumn138.Width = 87;
            // 
            // bandedGridColumn139
            // 
            this.bandedGridColumn139.Caption = "Splits";
            this.bandedGridColumn139.FieldName = "splits";
            this.bandedGridColumn139.MinWidth = 23;
            this.bandedGridColumn139.Name = "bandedGridColumn139";
            this.bandedGridColumn139.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn139.Visible = true;
            this.bandedGridColumn139.Width = 87;
            // 
            // bandedGridColumn127
            // 
            this.bandedGridColumn127.Caption = "Payment";
            this.bandedGridColumn127.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn127.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn127.FieldName = "paymentAmount";
            this.bandedGridColumn127.MinWidth = 23;
            this.bandedGridColumn127.Name = "bandedGridColumn127";
            this.bandedGridColumn127.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn127.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn127.Width = 96;
            // 
            // bandedGridColumn128
            // 
            this.bandedGridColumn128.Caption = "Total Payments";
            this.bandedGridColumn128.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn128.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn128.FieldName = "totalPayments";
            this.bandedGridColumn128.MinWidth = 23;
            this.bandedGridColumn128.Name = "bandedGridColumn128";
            this.bandedGridColumn128.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn128.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn128.Width = 96;
            // 
            // bandedGridColumn129
            // 
            this.bandedGridColumn129.Caption = "Trust85P";
            this.bandedGridColumn129.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn129.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn129.FieldName = "trust85P";
            this.bandedGridColumn129.MinWidth = 23;
            this.bandedGridColumn129.Name = "bandedGridColumn129";
            this.bandedGridColumn129.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn129.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn129.Width = 96;
            // 
            // bandedGridColumn130
            // 
            this.bandedGridColumn130.Caption = "Trust100P";
            this.bandedGridColumn130.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn130.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn130.FieldName = "trust100P";
            this.bandedGridColumn130.MinWidth = 23;
            this.bandedGridColumn130.Name = "bandedGridColumn130";
            this.bandedGridColumn130.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn130.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn130.Width = 96;
            // 
            // bandedGridColumn131
            // 
            this.bandedGridColumn131.Caption = "IB trust";
            this.bandedGridColumn131.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn131.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn131.FieldName = "ibtrust";
            this.bandedGridColumn131.MinWidth = 23;
            this.bandedGridColumn131.Name = "bandedGridColumn131";
            this.bandedGridColumn131.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn131.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn131.Width = 87;
            // 
            // bandedGridColumn132
            // 
            this.bandedGridColumn132.Caption = "SP Trust";
            this.bandedGridColumn132.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn132.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn132.FieldName = "sptrust";
            this.bandedGridColumn132.MinWidth = 23;
            this.bandedGridColumn132.Name = "bandedGridColumn132";
            this.bandedGridColumn132.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn132.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn132.Width = 87;
            // 
            // bandedGridColumn133
            // 
            this.bandedGridColumn133.Caption = "XX Trust";
            this.bandedGridColumn133.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn133.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn133.FieldName = "xxtrust";
            this.bandedGridColumn133.MinWidth = 23;
            this.bandedGridColumn133.Name = "bandedGridColumn133";
            this.bandedGridColumn133.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn133.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn133.Width = 87;
            // 
            // bandedGridColumn134
            // 
            this.bandedGridColumn134.Caption = "Commission";
            this.bandedGridColumn134.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn134.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn134.FieldName = "commission";
            this.bandedGridColumn134.MinWidth = 23;
            this.bandedGridColumn134.Name = "bandedGridColumn134";
            this.bandedGridColumn134.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn134.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn134.Visible = true;
            this.bandedGridColumn134.Width = 111;
            // 
            // bandedGridColumn140
            // 
            this.bandedGridColumn140.Caption = "Total Contracts";
            this.bandedGridColumn140.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn140.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn140.FieldName = "totalContracts";
            this.bandedGridColumn140.MinWidth = 23;
            this.bandedGridColumn140.Name = "bandedGridColumn140";
            this.bandedGridColumn140.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn140.Visible = true;
            this.bandedGridColumn140.Width = 87;
            // 
            // bandedGridColumn142
            // 
            this.bandedGridColumn142.Caption = "DBR Sales";
            this.bandedGridColumn142.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn142.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn142.FieldName = "dbrSales";
            this.bandedGridColumn142.MinWidth = 23;
            this.bandedGridColumn142.Name = "bandedGridColumn142";
            this.bandedGridColumn142.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn142.Visible = true;
            this.bandedGridColumn142.Width = 87;
            // 
            // bandedGridColumn141
            // 
            this.bandedGridColumn141.Caption = "Lapse Recaps";
            this.bandedGridColumn141.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn141.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn141.FieldName = "lapseRecaps";
            this.bandedGridColumn141.MinWidth = 23;
            this.bandedGridColumn141.Name = "bandedGridColumn141";
            this.bandedGridColumn141.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn141.Visible = true;
            this.bandedGridColumn141.Width = 87;
            // 
            // bandedGridColumn234
            // 
            this.bandedGridColumn234.Caption = "LLoc";
            this.bandedGridColumn234.FieldName = "LLoc";
            this.bandedGridColumn234.MinWidth = 23;
            this.bandedGridColumn234.Name = "bandedGridColumn234";
            this.bandedGridColumn234.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn234.Visible = true;
            this.bandedGridColumn234.Width = 70;
            // 
            // bandedGridColumn135
            // 
            this.bandedGridColumn135.Caption = "record";
            this.bandedGridColumn135.FieldName = "record";
            this.bandedGridColumn135.MinWidth = 23;
            this.bandedGridColumn135.Name = "bandedGridColumn135";
            this.bandedGridColumn135.RowCount = 2;
            this.bandedGridColumn135.Width = 87;
            // 
            // tabReinstate
            // 
            this.tabReinstate.Controls.Add(this.dgv9);
            this.tabReinstate.Location = new System.Drawing.Point(4, 25);
            this.tabReinstate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabReinstate.Name = "tabReinstate";
            this.tabReinstate.Size = new System.Drawing.Size(1395, 382);
            this.tabReinstate.TabIndex = 8;
            this.tabReinstate.Text = "Reinstate";
            this.tabReinstate.UseVisualStyleBackColor = true;
            // 
            // dgv9
            // 
            this.dgv9.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv9.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv9.Location = new System.Drawing.Point(0, 0);
            this.dgv9.LookAndFeel.SkinName = "iMaginary";
            this.dgv9.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv9.MainView = this.gridMain9;
            this.dgv9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv9.Name = "dgv9";
            this.dgv9.Size = new System.Drawing.Size(1395, 382);
            this.dgv9.TabIndex = 6;
            this.dgv9.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain9});
            // 
            // gridMain9
            // 
            this.gridMain9.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain9.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain9.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain9.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain9.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain9.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain9.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain9.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain9.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain9.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain9.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain9.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain9.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain9.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain9.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain9.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain9.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain9.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain9.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain9.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain9.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain9.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain9.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain9.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain9.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain9.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain9.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain9.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain9.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain9.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain9.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain9.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain9.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain9.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain9.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain9.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain9.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain9.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain9.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain9.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain9.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain9.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain9.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain9.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain9.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain9.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain9.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain9.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain9.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain9.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain9.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain9.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain9.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain9.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain9.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain9.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain9.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain9.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain9.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain9.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain9.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain9.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain9.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain9.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain9.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain9.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain9.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain9.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain9.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain9.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain9.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain9.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain9.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain9.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain9.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain9.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain9.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain9.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain9.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain9.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain9.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain9.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain9.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain9.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain9.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain9.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain9.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.Row.Options.UseBackColor = true;
            this.gridMain9.Appearance.Row.Options.UseForeColor = true;
            this.gridMain9.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain9.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain9.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain9.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain9.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain9.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain9.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain9.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain9.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain9.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain9.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain9.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand9});
            this.gridMain9.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain9.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn171,
            this.bandedGridColumn143,
            this.bandedGridColumn174,
            this.bandedGridColumn153,
            this.bandedGridColumn149,
            this.bandedGridColumn154,
            this.bandedGridColumn225,
            this.bandedGridColumn226,
            this.bandedGridColumn163,
            this.bandedGridColumn151,
            this.bandedGridColumn60,
            this.bandedGridColumn150,
            this.bandedGridColumn166,
            this.bandedGridColumn165,
            this.bandedGridColumn144,
            this.bandedGridColumn170,
            this.bandedGridColumn158,
            this.bandedGridColumn164,
            this.bandedGridColumn155,
            this.bandedGridColumn148,
            this.bandedGridColumn146,
            this.bandedGridColumn152,
            this.bandedGridColumn145,
            this.bandedGridColumn147,
            this.bandedGridColumn167,
            this.bandedGridColumn168,
            this.bandedGridColumn169,
            this.bandedGridColumn157,
            this.bandedGridColumn156,
            this.bandedGridColumn159,
            this.bandedGridColumn160,
            this.bandedGridColumn161,
            this.bandedGridColumn162,
            this.bandedGridColumn173,
            this.bandedGridColumn172,
            this.bandedGridColumn175});
            this.gridMain9.DetailHeight = 431;
            this.gridMain9.GridControl = this.dgv9;
            this.gridMain9.Name = "gridMain9";
            this.gridMain9.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain9.OptionsPrint.PrintBandHeader = false;
            this.gridMain9.OptionsSelection.MultiSelect = true;
            this.gridMain9.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain9.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain9.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain9.OptionsView.ShowBands = false;
            this.gridMain9.OptionsView.ShowFooter = true;
            this.gridMain9.OptionsView.ShowGroupPanel = false;
            this.gridMain9.PaintStyleName = "Style3D";
            this.gridMain9.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMain9_CustomDrawCell);
            this.gridMain9.DoubleClick += new System.EventHandler(this.gridMain9_DoubleClick);
            // 
            // gridBand9
            // 
            this.gridBand9.Caption = "gridBand1";
            this.gridBand9.Columns.Add(this.bandedGridColumn143);
            this.gridBand9.Columns.Add(this.bandedGridColumn144);
            this.gridBand9.Columns.Add(this.bandedGridColumn145);
            this.gridBand9.Columns.Add(this.bandedGridColumn146);
            this.gridBand9.Columns.Add(this.bandedGridColumn147);
            this.gridBand9.Columns.Add(this.bandedGridColumn148);
            this.gridBand9.Columns.Add(this.bandedGridColumn149);
            this.gridBand9.Columns.Add(this.bandedGridColumn60);
            this.gridBand9.Columns.Add(this.bandedGridColumn150);
            this.gridBand9.Columns.Add(this.bandedGridColumn151);
            this.gridBand9.Columns.Add(this.bandedGridColumn152);
            this.gridBand9.Columns.Add(this.bandedGridColumn153);
            this.gridBand9.Columns.Add(this.bandedGridColumn225);
            this.gridBand9.Columns.Add(this.bandedGridColumn226);
            this.gridBand9.Columns.Add(this.bandedGridColumn154);
            this.gridBand9.Columns.Add(this.bandedGridColumn155);
            this.gridBand9.Columns.Add(this.bandedGridColumn156);
            this.gridBand9.Columns.Add(this.bandedGridColumn175);
            this.gridBand9.Columns.Add(this.bandedGridColumn157);
            this.gridBand9.Columns.Add(this.bandedGridColumn158);
            this.gridBand9.Columns.Add(this.bandedGridColumn159);
            this.gridBand9.Columns.Add(this.bandedGridColumn160);
            this.gridBand9.Columns.Add(this.bandedGridColumn161);
            this.gridBand9.Columns.Add(this.bandedGridColumn162);
            this.gridBand9.Columns.Add(this.bandedGridColumn163);
            this.gridBand9.Columns.Add(this.bandedGridColumn164);
            this.gridBand9.Columns.Add(this.bandedGridColumn165);
            this.gridBand9.Columns.Add(this.bandedGridColumn166);
            this.gridBand9.Columns.Add(this.bandedGridColumn167);
            this.gridBand9.Columns.Add(this.bandedGridColumn168);
            this.gridBand9.Columns.Add(this.bandedGridColumn169);
            this.gridBand9.Columns.Add(this.bandedGridColumn170);
            this.gridBand9.Columns.Add(this.bandedGridColumn171);
            this.gridBand9.Columns.Add(this.bandedGridColumn172);
            this.gridBand9.Columns.Add(this.bandedGridColumn173);
            this.gridBand9.Columns.Add(this.bandedGridColumn174);
            this.gridBand9.MinWidth = 12;
            this.gridBand9.Name = "gridBand9";
            this.gridBand9.VisibleIndex = 0;
            this.gridBand9.Width = 1985;
            // 
            // bandedGridColumn143
            // 
            this.bandedGridColumn143.Caption = "Num";
            this.bandedGridColumn143.FieldName = "num";
            this.bandedGridColumn143.MinWidth = 23;
            this.bandedGridColumn143.Name = "bandedGridColumn143";
            this.bandedGridColumn143.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn143.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn143.Visible = true;
            this.bandedGridColumn143.Width = 52;
            // 
            // bandedGridColumn144
            // 
            this.bandedGridColumn144.Caption = "Agent";
            this.bandedGridColumn144.FieldName = "agentNumber";
            this.bandedGridColumn144.MinWidth = 23;
            this.bandedGridColumn144.Name = "bandedGridColumn144";
            this.bandedGridColumn144.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn144.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn144.Visible = true;
            this.bandedGridColumn144.Width = 70;
            // 
            // bandedGridColumn145
            // 
            this.bandedGridColumn145.Caption = "Agent Name";
            this.bandedGridColumn145.FieldName = "agentName";
            this.bandedGridColumn145.MinWidth = 23;
            this.bandedGridColumn145.Name = "bandedGridColumn145";
            this.bandedGridColumn145.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn145.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn145.Visible = true;
            this.bandedGridColumn145.Width = 87;
            // 
            // bandedGridColumn146
            // 
            this.bandedGridColumn146.Caption = "Loc";
            this.bandedGridColumn146.FieldName = "loc";
            this.bandedGridColumn146.MinWidth = 23;
            this.bandedGridColumn146.Name = "bandedGridColumn146";
            this.bandedGridColumn146.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn146.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn146.Visible = true;
            this.bandedGridColumn146.Width = 47;
            // 
            // bandedGridColumn147
            // 
            this.bandedGridColumn147.Caption = "Location Name";
            this.bandedGridColumn147.FieldName = "Location Name";
            this.bandedGridColumn147.MinWidth = 23;
            this.bandedGridColumn147.Name = "bandedGridColumn147";
            this.bandedGridColumn147.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn147.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn147.Width = 87;
            // 
            // bandedGridColumn148
            // 
            this.bandedGridColumn148.Caption = "Trust";
            this.bandedGridColumn148.FieldName = "trust";
            this.bandedGridColumn148.MinWidth = 23;
            this.bandedGridColumn148.Name = "bandedGridColumn148";
            this.bandedGridColumn148.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn148.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn148.Visible = true;
            this.bandedGridColumn148.Width = 58;
            // 
            // bandedGridColumn149
            // 
            this.bandedGridColumn149.Caption = "DBR";
            this.bandedGridColumn149.FieldName = "dbr";
            this.bandedGridColumn149.MinWidth = 23;
            this.bandedGridColumn149.Name = "bandedGridColumn149";
            this.bandedGridColumn149.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn149.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn149.Visible = true;
            this.bandedGridColumn149.Width = 58;
            // 
            // bandedGridColumn60
            // 
            this.bandedGridColumn60.Caption = "Reinstate Date";
            this.bandedGridColumn60.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn60.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn60.FieldName = "reinstateDate8";
            this.bandedGridColumn60.MinWidth = 23;
            this.bandedGridColumn60.Name = "bandedGridColumn60";
            this.bandedGridColumn60.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn60.Visible = true;
            this.bandedGridColumn60.Width = 87;
            // 
            // bandedGridColumn150
            // 
            this.bandedGridColumn150.Caption = "Lapse  Date";
            this.bandedGridColumn150.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn150.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn150.FieldName = "lapseDate8";
            this.bandedGridColumn150.MinWidth = 23;
            this.bandedGridColumn150.Name = "bandedGridColumn150";
            this.bandedGridColumn150.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn150.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn150.Visible = true;
            this.bandedGridColumn150.Width = 76;
            // 
            // bandedGridColumn151
            // 
            this.bandedGridColumn151.Caption = "Date Paid";
            this.bandedGridColumn151.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn151.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn151.FieldName = "payDate8";
            this.bandedGridColumn151.MinWidth = 23;
            this.bandedGridColumn151.Name = "bandedGridColumn151";
            this.bandedGridColumn151.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn151.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn151.Width = 76;
            // 
            // bandedGridColumn152
            // 
            this.bandedGridColumn152.Caption = "Issue Date";
            this.bandedGridColumn152.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn152.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn152.FieldName = "issueDate8";
            this.bandedGridColumn152.MinWidth = 23;
            this.bandedGridColumn152.Name = "bandedGridColumn152";
            this.bandedGridColumn152.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn152.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn152.Visible = true;
            this.bandedGridColumn152.Width = 87;
            // 
            // bandedGridColumn153
            // 
            this.bandedGridColumn153.Caption = "Contract";
            this.bandedGridColumn153.FieldName = "contractNumber";
            this.bandedGridColumn153.MinWidth = 23;
            this.bandedGridColumn153.Name = "bandedGridColumn153";
            this.bandedGridColumn153.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn153.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn153.Visible = true;
            this.bandedGridColumn153.Width = 82;
            // 
            // bandedGridColumn225
            // 
            this.bandedGridColumn225.Caption = "Last Name";
            this.bandedGridColumn225.FieldName = "lastName";
            this.bandedGridColumn225.MinWidth = 23;
            this.bandedGridColumn225.Name = "bandedGridColumn225";
            this.bandedGridColumn225.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn225.Visible = true;
            this.bandedGridColumn225.Width = 87;
            // 
            // bandedGridColumn226
            // 
            this.bandedGridColumn226.Caption = "First Name";
            this.bandedGridColumn226.FieldName = "firstName";
            this.bandedGridColumn226.MinWidth = 23;
            this.bandedGridColumn226.Name = "bandedGridColumn226";
            this.bandedGridColumn226.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn226.Visible = true;
            this.bandedGridColumn226.Width = 87;
            // 
            // bandedGridColumn154
            // 
            this.bandedGridColumn154.Caption = "Customer";
            this.bandedGridColumn154.FieldName = "customer";
            this.bandedGridColumn154.MinWidth = 23;
            this.bandedGridColumn154.Name = "bandedGridColumn154";
            this.bandedGridColumn154.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn154.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn154.Width = 175;
            // 
            // bandedGridColumn155
            // 
            this.bandedGridColumn155.Caption = "Contract Value";
            this.bandedGridColumn155.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn155.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn155.FieldName = "contractValue";
            this.bandedGridColumn155.MinWidth = 23;
            this.bandedGridColumn155.Name = "bandedGridColumn155";
            this.bandedGridColumn155.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn155.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn155.Visible = true;
            this.bandedGridColumn155.Width = 117;
            // 
            // bandedGridColumn156
            // 
            this.bandedGridColumn156.Caption = "Recap";
            this.bandedGridColumn156.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn156.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn156.FieldName = "Recap";
            this.bandedGridColumn156.MinWidth = 23;
            this.bandedGridColumn156.Name = "bandedGridColumn156";
            this.bandedGridColumn156.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn156.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn156.Visible = true;
            this.bandedGridColumn156.Width = 87;
            // 
            // bandedGridColumn175
            // 
            this.bandedGridColumn175.Caption = "Re-Ins";
            this.bandedGridColumn175.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn175.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn175.FieldName = "Reins";
            this.bandedGridColumn175.MinWidth = 23;
            this.bandedGridColumn175.Name = "bandedGridColumn175";
            this.bandedGridColumn175.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn175.Visible = true;
            this.bandedGridColumn175.Width = 87;
            // 
            // bandedGridColumn157
            // 
            this.bandedGridColumn157.Caption = "Cash Adv";
            this.bandedGridColumn157.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn157.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn157.FieldName = "cashAdvance";
            this.bandedGridColumn157.MinWidth = 23;
            this.bandedGridColumn157.Name = "bandedGridColumn157";
            this.bandedGridColumn157.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn157.Width = 87;
            // 
            // bandedGridColumn158
            // 
            this.bandedGridColumn158.Caption = "Down Payment";
            this.bandedGridColumn158.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn158.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn158.FieldName = "downPayment";
            this.bandedGridColumn158.MinWidth = 23;
            this.bandedGridColumn158.Name = "bandedGridColumn158";
            this.bandedGridColumn158.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn158.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn158.Visible = true;
            this.bandedGridColumn158.Width = 96;
            // 
            // bandedGridColumn159
            // 
            this.bandedGridColumn159.Caption = "Percent";
            this.bandedGridColumn159.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn159.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn159.FieldName = "percent";
            this.bandedGridColumn159.MinWidth = 23;
            this.bandedGridColumn159.Name = "bandedGridColumn159";
            this.bandedGridColumn159.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn159.Visible = true;
            this.bandedGridColumn159.Width = 87;
            // 
            // bandedGridColumn160
            // 
            this.bandedGridColumn160.Caption = "Goal";
            this.bandedGridColumn160.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn160.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn160.FieldName = "goal";
            this.bandedGridColumn160.MinWidth = 23;
            this.bandedGridColumn160.Name = "bandedGridColumn160";
            this.bandedGridColumn160.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn160.Visible = true;
            this.bandedGridColumn160.Width = 87;
            // 
            // bandedGridColumn161
            // 
            this.bandedGridColumn161.Caption = "Formula";
            this.bandedGridColumn161.FieldName = "formula";
            this.bandedGridColumn161.MinWidth = 23;
            this.bandedGridColumn161.Name = "bandedGridColumn161";
            this.bandedGridColumn161.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn161.Visible = true;
            this.bandedGridColumn161.Width = 87;
            // 
            // bandedGridColumn162
            // 
            this.bandedGridColumn162.Caption = "Splits";
            this.bandedGridColumn162.FieldName = "splits";
            this.bandedGridColumn162.MinWidth = 23;
            this.bandedGridColumn162.Name = "bandedGridColumn162";
            this.bandedGridColumn162.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn162.Visible = true;
            this.bandedGridColumn162.Width = 87;
            // 
            // bandedGridColumn163
            // 
            this.bandedGridColumn163.Caption = "Payment";
            this.bandedGridColumn163.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn163.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn163.FieldName = "paymentAmount";
            this.bandedGridColumn163.MinWidth = 23;
            this.bandedGridColumn163.Name = "bandedGridColumn163";
            this.bandedGridColumn163.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn163.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn163.Width = 96;
            // 
            // bandedGridColumn164
            // 
            this.bandedGridColumn164.Caption = "Total Payments";
            this.bandedGridColumn164.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn164.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn164.FieldName = "totalPayments";
            this.bandedGridColumn164.MinWidth = 23;
            this.bandedGridColumn164.Name = "bandedGridColumn164";
            this.bandedGridColumn164.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn164.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn164.Width = 96;
            // 
            // bandedGridColumn165
            // 
            this.bandedGridColumn165.Caption = "Trust85P";
            this.bandedGridColumn165.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn165.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn165.FieldName = "trust85P";
            this.bandedGridColumn165.MinWidth = 23;
            this.bandedGridColumn165.Name = "bandedGridColumn165";
            this.bandedGridColumn165.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn165.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn165.Width = 96;
            // 
            // bandedGridColumn166
            // 
            this.bandedGridColumn166.Caption = "Trust100P";
            this.bandedGridColumn166.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn166.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn166.FieldName = "trust100P";
            this.bandedGridColumn166.MinWidth = 23;
            this.bandedGridColumn166.Name = "bandedGridColumn166";
            this.bandedGridColumn166.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn166.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn166.Width = 96;
            // 
            // bandedGridColumn167
            // 
            this.bandedGridColumn167.Caption = "IB trust";
            this.bandedGridColumn167.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn167.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn167.FieldName = "ibtrust";
            this.bandedGridColumn167.MinWidth = 23;
            this.bandedGridColumn167.Name = "bandedGridColumn167";
            this.bandedGridColumn167.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn167.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn167.Width = 87;
            // 
            // bandedGridColumn168
            // 
            this.bandedGridColumn168.Caption = "SP Trust";
            this.bandedGridColumn168.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn168.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn168.FieldName = "sptrust";
            this.bandedGridColumn168.MinWidth = 23;
            this.bandedGridColumn168.Name = "bandedGridColumn168";
            this.bandedGridColumn168.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn168.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn168.Width = 87;
            // 
            // bandedGridColumn169
            // 
            this.bandedGridColumn169.Caption = "XX Trust";
            this.bandedGridColumn169.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn169.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn169.FieldName = "xxtrust";
            this.bandedGridColumn169.MinWidth = 23;
            this.bandedGridColumn169.Name = "bandedGridColumn169";
            this.bandedGridColumn169.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn169.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn169.Width = 87;
            // 
            // bandedGridColumn170
            // 
            this.bandedGridColumn170.Caption = "Commission";
            this.bandedGridColumn170.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn170.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn170.FieldName = "commission";
            this.bandedGridColumn170.MinWidth = 23;
            this.bandedGridColumn170.Name = "bandedGridColumn170";
            this.bandedGridColumn170.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn170.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn170.Visible = true;
            this.bandedGridColumn170.Width = 111;
            // 
            // bandedGridColumn171
            // 
            this.bandedGridColumn171.Caption = "Total Contracts";
            this.bandedGridColumn171.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn171.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn171.FieldName = "totalContracts";
            this.bandedGridColumn171.MinWidth = 23;
            this.bandedGridColumn171.Name = "bandedGridColumn171";
            this.bandedGridColumn171.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn171.Visible = true;
            this.bandedGridColumn171.Width = 87;
            // 
            // bandedGridColumn172
            // 
            this.bandedGridColumn172.Caption = "DBR Sales";
            this.bandedGridColumn172.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn172.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn172.FieldName = "dbrSales";
            this.bandedGridColumn172.MinWidth = 23;
            this.bandedGridColumn172.Name = "bandedGridColumn172";
            this.bandedGridColumn172.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn172.Visible = true;
            this.bandedGridColumn172.Width = 87;
            // 
            // bandedGridColumn173
            // 
            this.bandedGridColumn173.Caption = "Lapse Re-Ins";
            this.bandedGridColumn173.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn173.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn173.FieldName = "lapseRecaps";
            this.bandedGridColumn173.MinWidth = 23;
            this.bandedGridColumn173.Name = "bandedGridColumn173";
            this.bandedGridColumn173.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn173.Visible = true;
            this.bandedGridColumn173.Width = 87;
            // 
            // bandedGridColumn174
            // 
            this.bandedGridColumn174.Caption = "record";
            this.bandedGridColumn174.FieldName = "record";
            this.bandedGridColumn174.MinWidth = 23;
            this.bandedGridColumn174.Name = "bandedGridColumn174";
            this.bandedGridColumn174.RowCount = 2;
            this.bandedGridColumn174.Width = 87;
            // 
            // tabCombined
            // 
            this.tabCombined.Controls.Add(this.dgv12);
            this.tabCombined.Location = new System.Drawing.Point(4, 25);
            this.tabCombined.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabCombined.Name = "tabCombined";
            this.tabCombined.Size = new System.Drawing.Size(1395, 382);
            this.tabCombined.TabIndex = 11;
            this.tabCombined.Text = "Combined";
            this.tabCombined.UseVisualStyleBackColor = true;
            // 
            // dgv12
            // 
            this.dgv12.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv12.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv12.Location = new System.Drawing.Point(0, 0);
            this.dgv12.LookAndFeel.SkinName = "iMaginary";
            this.dgv12.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv12.MainView = this.gridMain12;
            this.dgv12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv12.Name = "dgv12";
            this.dgv12.Size = new System.Drawing.Size(1395, 382);
            this.dgv12.TabIndex = 7;
            this.dgv12.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain12});
            // 
            // gridMain12
            // 
            this.gridMain12.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain12.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain12.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain12.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain12.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain12.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain12.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain12.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain12.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain12.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain12.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain12.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain12.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain12.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain12.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain12.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain12.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain12.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain12.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain12.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain12.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain12.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain12.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain12.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain12.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain12.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain12.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain12.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain12.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain12.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain12.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain12.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain12.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain12.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain12.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain12.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain12.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain12.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain12.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain12.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain12.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain12.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain12.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain12.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain12.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain12.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain12.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain12.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain12.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain12.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain12.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain12.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain12.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain12.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain12.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain12.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain12.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain12.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain12.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain12.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain12.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain12.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain12.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain12.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain12.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain12.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain12.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain12.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain12.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain12.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain12.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain12.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain12.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain12.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain12.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain12.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain12.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain12.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain12.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain12.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain12.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain12.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain12.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain12.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain12.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain12.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain12.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain12.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain12.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain12.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain12.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain12.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain12.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain12.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain12.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain12.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain12.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain12.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain12.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain12.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain12.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain12.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain12.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain12.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain12.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain12.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain12.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain12.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain12.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain12.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain12.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain12.Appearance.Row.Options.UseBackColor = true;
            this.gridMain12.Appearance.Row.Options.UseForeColor = true;
            this.gridMain12.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain12.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain12.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain12.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain12.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain12.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain12.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain12.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain12.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain12.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain12.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain12.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand12});
            this.gridMain12.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain12.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn269,
            this.bandedGridColumn237,
            this.bandedGridColumn272,
            this.bandedGridColumn248,
            this.bandedGridColumn243,
            this.bandedGridColumn251,
            this.bandedGridColumn249,
            this.bandedGridColumn250,
            this.bandedGridColumn261,
            this.bandedGridColumn246,
            this.bandedGridColumn244,
            this.bandedGridColumn245,
            this.bandedGridColumn264,
            this.bandedGridColumn263,
            this.bandedGridColumn238,
            this.bandedGridColumn268,
            this.bandedGridColumn256,
            this.bandedGridColumn262,
            this.bandedGridColumn252,
            this.bandedGridColumn242,
            this.bandedGridColumn240,
            this.bandedGridColumn247,
            this.bandedGridColumn239,
            this.bandedGridColumn241,
            this.bandedGridColumn265,
            this.bandedGridColumn266,
            this.bandedGridColumn267,
            this.bandedGridColumn255,
            this.bandedGridColumn253,
            this.bandedGridColumn257,
            this.bandedGridColumn258,
            this.bandedGridColumn259,
            this.bandedGridColumn260,
            this.bandedGridColumn271,
            this.bandedGridColumn270,
            this.bandedGridColumn254});
            this.gridMain12.DetailHeight = 431;
            this.gridMain12.GridControl = this.dgv12;
            this.gridMain12.Name = "gridMain12";
            this.gridMain12.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain12.OptionsPrint.PrintBandHeader = false;
            this.gridMain12.OptionsSelection.MultiSelect = true;
            this.gridMain12.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain12.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain12.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain12.OptionsView.ShowBands = false;
            this.gridMain12.OptionsView.ShowFooter = true;
            this.gridMain12.OptionsView.ShowGroupPanel = false;
            this.gridMain12.PaintStyleName = "Style3D";
            // 
            // gridBand12
            // 
            this.gridBand12.Caption = "gridBand1";
            this.gridBand12.Columns.Add(this.bandedGridColumn237);
            this.gridBand12.Columns.Add(this.bandedGridColumn238);
            this.gridBand12.Columns.Add(this.bandedGridColumn239);
            this.gridBand12.Columns.Add(this.bandedGridColumn240);
            this.gridBand12.Columns.Add(this.bandedGridColumn241);
            this.gridBand12.Columns.Add(this.bandedGridColumn242);
            this.gridBand12.Columns.Add(this.bandedGridColumn243);
            this.gridBand12.Columns.Add(this.bandedGridColumn244);
            this.gridBand12.Columns.Add(this.bandedGridColumn245);
            this.gridBand12.Columns.Add(this.bandedGridColumn246);
            this.gridBand12.Columns.Add(this.bandedGridColumn247);
            this.gridBand12.Columns.Add(this.bandedGridColumn248);
            this.gridBand12.Columns.Add(this.bandedGridColumn249);
            this.gridBand12.Columns.Add(this.bandedGridColumn250);
            this.gridBand12.Columns.Add(this.bandedGridColumn251);
            this.gridBand12.Columns.Add(this.bandedGridColumn252);
            this.gridBand12.Columns.Add(this.bandedGridColumn253);
            this.gridBand12.Columns.Add(this.bandedGridColumn254);
            this.gridBand12.Columns.Add(this.bandedGridColumn255);
            this.gridBand12.Columns.Add(this.bandedGridColumn256);
            this.gridBand12.Columns.Add(this.bandedGridColumn257);
            this.gridBand12.Columns.Add(this.bandedGridColumn258);
            this.gridBand12.Columns.Add(this.bandedGridColumn259);
            this.gridBand12.Columns.Add(this.bandedGridColumn260);
            this.gridBand12.Columns.Add(this.bandedGridColumn261);
            this.gridBand12.Columns.Add(this.bandedGridColumn262);
            this.gridBand12.Columns.Add(this.bandedGridColumn263);
            this.gridBand12.Columns.Add(this.bandedGridColumn264);
            this.gridBand12.Columns.Add(this.bandedGridColumn265);
            this.gridBand12.Columns.Add(this.bandedGridColumn266);
            this.gridBand12.Columns.Add(this.bandedGridColumn267);
            this.gridBand12.Columns.Add(this.bandedGridColumn268);
            this.gridBand12.Columns.Add(this.bandedGridColumn269);
            this.gridBand12.Columns.Add(this.bandedGridColumn270);
            this.gridBand12.Columns.Add(this.bandedGridColumn271);
            this.gridBand12.Columns.Add(this.bandedGridColumn272);
            this.gridBand12.MinWidth = 12;
            this.gridBand12.Name = "gridBand12";
            this.gridBand12.VisibleIndex = 0;
            this.gridBand12.Width = 1985;
            // 
            // bandedGridColumn237
            // 
            this.bandedGridColumn237.Caption = "Num";
            this.bandedGridColumn237.FieldName = "num";
            this.bandedGridColumn237.MinWidth = 23;
            this.bandedGridColumn237.Name = "bandedGridColumn237";
            this.bandedGridColumn237.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn237.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn237.Visible = true;
            this.bandedGridColumn237.Width = 52;
            // 
            // bandedGridColumn238
            // 
            this.bandedGridColumn238.Caption = "Agent";
            this.bandedGridColumn238.FieldName = "agentNumber";
            this.bandedGridColumn238.MinWidth = 23;
            this.bandedGridColumn238.Name = "bandedGridColumn238";
            this.bandedGridColumn238.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn238.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn238.Visible = true;
            this.bandedGridColumn238.Width = 70;
            // 
            // bandedGridColumn239
            // 
            this.bandedGridColumn239.Caption = "Agent Name";
            this.bandedGridColumn239.FieldName = "agentName";
            this.bandedGridColumn239.MinWidth = 23;
            this.bandedGridColumn239.Name = "bandedGridColumn239";
            this.bandedGridColumn239.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn239.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn239.Visible = true;
            this.bandedGridColumn239.Width = 87;
            // 
            // bandedGridColumn240
            // 
            this.bandedGridColumn240.Caption = "Loc";
            this.bandedGridColumn240.FieldName = "loc";
            this.bandedGridColumn240.MinWidth = 23;
            this.bandedGridColumn240.Name = "bandedGridColumn240";
            this.bandedGridColumn240.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn240.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn240.Visible = true;
            this.bandedGridColumn240.Width = 47;
            // 
            // bandedGridColumn241
            // 
            this.bandedGridColumn241.Caption = "Location Name";
            this.bandedGridColumn241.FieldName = "Location Name";
            this.bandedGridColumn241.MinWidth = 23;
            this.bandedGridColumn241.Name = "bandedGridColumn241";
            this.bandedGridColumn241.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn241.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn241.Width = 87;
            // 
            // bandedGridColumn242
            // 
            this.bandedGridColumn242.Caption = "Trust";
            this.bandedGridColumn242.FieldName = "trust";
            this.bandedGridColumn242.MinWidth = 23;
            this.bandedGridColumn242.Name = "bandedGridColumn242";
            this.bandedGridColumn242.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn242.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn242.Visible = true;
            this.bandedGridColumn242.Width = 58;
            // 
            // bandedGridColumn243
            // 
            this.bandedGridColumn243.Caption = "DBR";
            this.bandedGridColumn243.FieldName = "dbr";
            this.bandedGridColumn243.MinWidth = 23;
            this.bandedGridColumn243.Name = "bandedGridColumn243";
            this.bandedGridColumn243.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn243.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn243.Visible = true;
            this.bandedGridColumn243.Width = 58;
            // 
            // bandedGridColumn244
            // 
            this.bandedGridColumn244.Caption = "Reinstate Date";
            this.bandedGridColumn244.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn244.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn244.FieldName = "reinstateDate8";
            this.bandedGridColumn244.MinWidth = 23;
            this.bandedGridColumn244.Name = "bandedGridColumn244";
            this.bandedGridColumn244.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn244.Visible = true;
            this.bandedGridColumn244.Width = 87;
            // 
            // bandedGridColumn245
            // 
            this.bandedGridColumn245.Caption = "Lapse  Date";
            this.bandedGridColumn245.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn245.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn245.FieldName = "lapseDate8";
            this.bandedGridColumn245.MinWidth = 23;
            this.bandedGridColumn245.Name = "bandedGridColumn245";
            this.bandedGridColumn245.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn245.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn245.Visible = true;
            this.bandedGridColumn245.Width = 76;
            // 
            // bandedGridColumn246
            // 
            this.bandedGridColumn246.Caption = "Date Paid";
            this.bandedGridColumn246.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn246.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn246.FieldName = "payDate8";
            this.bandedGridColumn246.MinWidth = 23;
            this.bandedGridColumn246.Name = "bandedGridColumn246";
            this.bandedGridColumn246.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn246.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn246.Width = 76;
            // 
            // bandedGridColumn247
            // 
            this.bandedGridColumn247.Caption = "Issue Date";
            this.bandedGridColumn247.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn247.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn247.FieldName = "issueDate8";
            this.bandedGridColumn247.MinWidth = 23;
            this.bandedGridColumn247.Name = "bandedGridColumn247";
            this.bandedGridColumn247.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn247.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn247.Visible = true;
            this.bandedGridColumn247.Width = 87;
            // 
            // bandedGridColumn248
            // 
            this.bandedGridColumn248.Caption = "Contract";
            this.bandedGridColumn248.FieldName = "contractNumber";
            this.bandedGridColumn248.MinWidth = 23;
            this.bandedGridColumn248.Name = "bandedGridColumn248";
            this.bandedGridColumn248.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn248.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn248.Visible = true;
            this.bandedGridColumn248.Width = 82;
            // 
            // bandedGridColumn249
            // 
            this.bandedGridColumn249.Caption = "Last Name";
            this.bandedGridColumn249.FieldName = "lastName";
            this.bandedGridColumn249.MinWidth = 23;
            this.bandedGridColumn249.Name = "bandedGridColumn249";
            this.bandedGridColumn249.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn249.Visible = true;
            this.bandedGridColumn249.Width = 87;
            // 
            // bandedGridColumn250
            // 
            this.bandedGridColumn250.Caption = "First Name";
            this.bandedGridColumn250.FieldName = "firstName";
            this.bandedGridColumn250.MinWidth = 23;
            this.bandedGridColumn250.Name = "bandedGridColumn250";
            this.bandedGridColumn250.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn250.Visible = true;
            this.bandedGridColumn250.Width = 87;
            // 
            // bandedGridColumn251
            // 
            this.bandedGridColumn251.Caption = "Customer";
            this.bandedGridColumn251.FieldName = "customer";
            this.bandedGridColumn251.MinWidth = 23;
            this.bandedGridColumn251.Name = "bandedGridColumn251";
            this.bandedGridColumn251.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn251.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn251.Width = 175;
            // 
            // bandedGridColumn252
            // 
            this.bandedGridColumn252.Caption = "Contract Value";
            this.bandedGridColumn252.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn252.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn252.FieldName = "contractValue";
            this.bandedGridColumn252.MinWidth = 23;
            this.bandedGridColumn252.Name = "bandedGridColumn252";
            this.bandedGridColumn252.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn252.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn252.Visible = true;
            this.bandedGridColumn252.Width = 117;
            // 
            // bandedGridColumn253
            // 
            this.bandedGridColumn253.Caption = "Recap";
            this.bandedGridColumn253.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn253.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn253.FieldName = "Recap";
            this.bandedGridColumn253.MinWidth = 23;
            this.bandedGridColumn253.Name = "bandedGridColumn253";
            this.bandedGridColumn253.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn253.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn253.Visible = true;
            this.bandedGridColumn253.Width = 87;
            // 
            // bandedGridColumn254
            // 
            this.bandedGridColumn254.Caption = "Re-Ins";
            this.bandedGridColumn254.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn254.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn254.FieldName = "Reins";
            this.bandedGridColumn254.MinWidth = 23;
            this.bandedGridColumn254.Name = "bandedGridColumn254";
            this.bandedGridColumn254.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn254.Visible = true;
            this.bandedGridColumn254.Width = 87;
            // 
            // bandedGridColumn255
            // 
            this.bandedGridColumn255.Caption = "Cash Adv";
            this.bandedGridColumn255.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn255.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn255.FieldName = "cashAdvance";
            this.bandedGridColumn255.MinWidth = 23;
            this.bandedGridColumn255.Name = "bandedGridColumn255";
            this.bandedGridColumn255.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn255.Width = 87;
            // 
            // bandedGridColumn256
            // 
            this.bandedGridColumn256.Caption = "Down Payment";
            this.bandedGridColumn256.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn256.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn256.FieldName = "downPayment";
            this.bandedGridColumn256.MinWidth = 23;
            this.bandedGridColumn256.Name = "bandedGridColumn256";
            this.bandedGridColumn256.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn256.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn256.Visible = true;
            this.bandedGridColumn256.Width = 96;
            // 
            // bandedGridColumn257
            // 
            this.bandedGridColumn257.Caption = "Percent";
            this.bandedGridColumn257.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn257.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn257.FieldName = "percent";
            this.bandedGridColumn257.MinWidth = 23;
            this.bandedGridColumn257.Name = "bandedGridColumn257";
            this.bandedGridColumn257.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn257.Visible = true;
            this.bandedGridColumn257.Width = 87;
            // 
            // bandedGridColumn258
            // 
            this.bandedGridColumn258.Caption = "Goal";
            this.bandedGridColumn258.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn258.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn258.FieldName = "goal";
            this.bandedGridColumn258.MinWidth = 23;
            this.bandedGridColumn258.Name = "bandedGridColumn258";
            this.bandedGridColumn258.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn258.Visible = true;
            this.bandedGridColumn258.Width = 87;
            // 
            // bandedGridColumn259
            // 
            this.bandedGridColumn259.Caption = "Formula";
            this.bandedGridColumn259.FieldName = "formula";
            this.bandedGridColumn259.MinWidth = 23;
            this.bandedGridColumn259.Name = "bandedGridColumn259";
            this.bandedGridColumn259.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn259.Visible = true;
            this.bandedGridColumn259.Width = 87;
            // 
            // bandedGridColumn260
            // 
            this.bandedGridColumn260.Caption = "Splits";
            this.bandedGridColumn260.FieldName = "splits";
            this.bandedGridColumn260.MinWidth = 23;
            this.bandedGridColumn260.Name = "bandedGridColumn260";
            this.bandedGridColumn260.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn260.Visible = true;
            this.bandedGridColumn260.Width = 87;
            // 
            // bandedGridColumn261
            // 
            this.bandedGridColumn261.Caption = "Payment";
            this.bandedGridColumn261.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn261.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn261.FieldName = "paymentAmount";
            this.bandedGridColumn261.MinWidth = 23;
            this.bandedGridColumn261.Name = "bandedGridColumn261";
            this.bandedGridColumn261.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn261.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn261.Width = 96;
            // 
            // bandedGridColumn262
            // 
            this.bandedGridColumn262.Caption = "Total Payments";
            this.bandedGridColumn262.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn262.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn262.FieldName = "totalPayments";
            this.bandedGridColumn262.MinWidth = 23;
            this.bandedGridColumn262.Name = "bandedGridColumn262";
            this.bandedGridColumn262.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn262.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn262.Width = 96;
            // 
            // bandedGridColumn263
            // 
            this.bandedGridColumn263.Caption = "Trust85P";
            this.bandedGridColumn263.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn263.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn263.FieldName = "trust85P";
            this.bandedGridColumn263.MinWidth = 23;
            this.bandedGridColumn263.Name = "bandedGridColumn263";
            this.bandedGridColumn263.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn263.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn263.Width = 96;
            // 
            // bandedGridColumn264
            // 
            this.bandedGridColumn264.Caption = "Trust100P";
            this.bandedGridColumn264.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn264.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn264.FieldName = "trust100P";
            this.bandedGridColumn264.MinWidth = 23;
            this.bandedGridColumn264.Name = "bandedGridColumn264";
            this.bandedGridColumn264.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn264.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn264.Width = 96;
            // 
            // bandedGridColumn265
            // 
            this.bandedGridColumn265.Caption = "IB trust";
            this.bandedGridColumn265.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn265.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn265.FieldName = "ibtrust";
            this.bandedGridColumn265.MinWidth = 23;
            this.bandedGridColumn265.Name = "bandedGridColumn265";
            this.bandedGridColumn265.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn265.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn265.Width = 87;
            // 
            // bandedGridColumn266
            // 
            this.bandedGridColumn266.Caption = "SP Trust";
            this.bandedGridColumn266.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn266.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn266.FieldName = "sptrust";
            this.bandedGridColumn266.MinWidth = 23;
            this.bandedGridColumn266.Name = "bandedGridColumn266";
            this.bandedGridColumn266.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn266.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn266.Width = 87;
            // 
            // bandedGridColumn267
            // 
            this.bandedGridColumn267.Caption = "XX Trust";
            this.bandedGridColumn267.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn267.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn267.FieldName = "xxtrust";
            this.bandedGridColumn267.MinWidth = 23;
            this.bandedGridColumn267.Name = "bandedGridColumn267";
            this.bandedGridColumn267.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn267.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn267.Width = 87;
            // 
            // bandedGridColumn268
            // 
            this.bandedGridColumn268.Caption = "Commission";
            this.bandedGridColumn268.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn268.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn268.FieldName = "commission";
            this.bandedGridColumn268.MinWidth = 23;
            this.bandedGridColumn268.Name = "bandedGridColumn268";
            this.bandedGridColumn268.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn268.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn268.Visible = true;
            this.bandedGridColumn268.Width = 111;
            // 
            // bandedGridColumn269
            // 
            this.bandedGridColumn269.Caption = "Total Contracts";
            this.bandedGridColumn269.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn269.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn269.FieldName = "totalContracts";
            this.bandedGridColumn269.MinWidth = 23;
            this.bandedGridColumn269.Name = "bandedGridColumn269";
            this.bandedGridColumn269.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn269.Visible = true;
            this.bandedGridColumn269.Width = 87;
            // 
            // bandedGridColumn270
            // 
            this.bandedGridColumn270.Caption = "DBR Sales";
            this.bandedGridColumn270.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn270.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn270.FieldName = "dbrSales";
            this.bandedGridColumn270.MinWidth = 23;
            this.bandedGridColumn270.Name = "bandedGridColumn270";
            this.bandedGridColumn270.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn270.Visible = true;
            this.bandedGridColumn270.Width = 87;
            // 
            // bandedGridColumn271
            // 
            this.bandedGridColumn271.Caption = "Lapse Re-Ins";
            this.bandedGridColumn271.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn271.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn271.FieldName = "lapseRecaps";
            this.bandedGridColumn271.MinWidth = 23;
            this.bandedGridColumn271.Name = "bandedGridColumn271";
            this.bandedGridColumn271.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn271.Visible = true;
            this.bandedGridColumn271.Width = 87;
            // 
            // bandedGridColumn272
            // 
            this.bandedGridColumn272.Caption = "record";
            this.bandedGridColumn272.FieldName = "record";
            this.bandedGridColumn272.MinWidth = 23;
            this.bandedGridColumn272.Name = "bandedGridColumn272";
            this.bandedGridColumn272.RowCount = 2;
            this.bandedGridColumn272.Width = 87;
            // 
            // tabCommission
            // 
            this.tabCommission.Controls.Add(this.panelCommAll);
            this.tabCommission.Location = new System.Drawing.Point(4, 25);
            this.tabCommission.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabCommission.Name = "tabCommission";
            this.tabCommission.Size = new System.Drawing.Size(1395, 382);
            this.tabCommission.TabIndex = 9;
            this.tabCommission.Text = "Commissions";
            this.tabCommission.UseVisualStyleBackColor = true;
            // 
            // panelCommAll
            // 
            this.panelCommAll.Controls.Add(this.panelCommBottom);
            this.panelCommAll.Controls.Add(this.panelCommTop);
            this.panelCommAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCommAll.Location = new System.Drawing.Point(0, 0);
            this.panelCommAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelCommAll.Name = "panelCommAll";
            this.panelCommAll.Size = new System.Drawing.Size(1395, 382);
            this.panelCommAll.TabIndex = 0;
            // 
            // panelCommBottom
            // 
            this.panelCommBottom.Controls.Add(this.dgv10);
            this.panelCommBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCommBottom.Location = new System.Drawing.Point(0, 48);
            this.panelCommBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelCommBottom.Name = "panelCommBottom";
            this.panelCommBottom.Size = new System.Drawing.Size(1395, 334);
            this.panelCommBottom.TabIndex = 2;
            // 
            // dgv10
            // 
            this.dgv10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv10.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv10.Location = new System.Drawing.Point(0, 0);
            this.dgv10.LookAndFeel.SkinName = "iMaginary";
            this.dgv10.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv10.MainView = this.gridMain10;
            this.dgv10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv10.Name = "dgv10";
            this.dgv10.Size = new System.Drawing.Size(1395, 334);
            this.dgv10.TabIndex = 5;
            this.dgv10.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain10});
            // 
            // gridMain10
            // 
            this.gridMain10.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain10.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain10.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain10.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain10.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain10.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain10.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain10.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain10.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain10.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain10.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain10.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain10.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain10.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain10.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain10.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain10.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain10.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain10.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain10.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain10.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain10.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain10.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain10.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain10.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain10.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain10.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain10.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain10.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain10.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain10.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain10.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain10.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain10.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain10.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain10.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain10.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain10.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain10.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain10.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain10.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain10.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain10.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain10.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain10.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain10.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain10.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain10.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain10.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain10.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain10.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain10.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain10.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain10.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain10.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain10.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain10.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain10.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain10.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain10.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain10.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain10.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain10.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain10.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain10.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain10.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain10.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain10.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain10.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain10.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain10.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain10.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain10.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain10.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain10.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain10.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain10.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain10.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain10.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain10.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain10.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain10.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain10.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain10.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain10.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain10.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain10.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain10.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain10.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain10.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.Row.Options.UseBackColor = true;
            this.gridMain10.Appearance.Row.Options.UseForeColor = true;
            this.gridMain10.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain10.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain10.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain10.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain10.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain10.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain10.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain10.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain10.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain10.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain10.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain10.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand6});
            this.gridMain10.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain10.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn65,
            this.bandedGridColumn180,
            this.bandedGridColumn84,
            this.bandedGridColumn66,
            this.bandedGridColumn177,
            this.bandedGridColumn67,
            this.bandedGridColumn233,
            this.bandedGridColumn77,
            this.bandedGridColumn78,
            this.bandedGridColumn183,
            this.bandedGridColumn178,
            this.bandedGridColumn179,
            this.bandedGridColumn182,
            this.bandedGridColumn222,
            this.bandedGridColumn228,
            this.bandedGridColumn181,
            this.bandedGridColumn72,
            this.bandedGridColumn71,
            this.bandedGridColumn69,
            this.bandedGridColumn70,
            this.bandedGridColumn73,
            this.bandedGridColumn236,
            this.bandedGridColumn229,
            this.bandedGridColumn79,
            this.bandedGridColumn81,
            this.bandedGridColumn82,
            this.bandedGridColumn76,
            this.bandedGridColumn83,
            this.bandedGridColumn68,
            this.bandedGridColumn80,
            this.bandedGridColumn187,
            this.bandedGridColumn188,
            this.bandedGridColumn227});
            this.gridMain10.DetailHeight = 431;
            this.gridMain10.GridControl = this.dgv10;
            this.gridMain10.Name = "gridMain10";
            this.gridMain10.OptionsBehavior.Editable = false;
            this.gridMain10.OptionsBehavior.ReadOnly = true;
            this.gridMain10.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain10.OptionsPrint.AllowMultilineHeaders = true;
            this.gridMain10.OptionsPrint.PrintBandHeader = false;
            this.gridMain10.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain10.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain10.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain10.OptionsView.ShowBands = false;
            this.gridMain10.OptionsView.ShowFooter = true;
            this.gridMain10.OptionsView.ShowGroupPanel = false;
            this.gridMain10.PaintStyleName = "Style3D";
            this.gridMain10.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMain10_CustomRowFilter);
            this.gridMain10.DoubleClick += new System.EventHandler(this.gridMain10_DoubleClick);
            // 
            // gridBand6
            // 
            this.gridBand6.Caption = "gridBand5";
            this.gridBand6.Children.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand10});
            this.gridBand6.MinWidth = 12;
            this.gridBand6.Name = "gridBand6";
            this.gridBand6.VisibleIndex = 0;
            this.gridBand6.Width = 1875;
            // 
            // gridBand10
            // 
            this.gridBand10.Caption = "gridBand2";
            this.gridBand10.Columns.Add(this.bandedGridColumn65);
            this.gridBand10.Columns.Add(this.bandedGridColumn66);
            this.gridBand10.Columns.Add(this.bandedGridColumn67);
            this.gridBand10.Columns.Add(this.bandedGridColumn233);
            this.gridBand10.Columns.Add(this.bandedGridColumn68);
            this.gridBand10.Columns.Add(this.bandedGridColumn69);
            this.gridBand10.Columns.Add(this.bandedGridColumn70);
            this.gridBand10.Columns.Add(this.bandedGridColumn73);
            this.gridBand10.Columns.Add(this.bandedGridColumn236);
            this.gridBand10.Columns.Add(this.bandedGridColumn229);
            this.gridBand10.Columns.Add(this.bandedGridColumn71);
            this.gridBand10.Columns.Add(this.bandedGridColumn72);
            this.gridBand10.Columns.Add(this.bandedGridColumn227);
            this.gridBand10.Columns.Add(this.bandedGridColumn187);
            this.gridBand10.Columns.Add(this.bandedGridColumn84);
            this.gridBand10.Columns.Add(this.bandedGridColumn76);
            this.gridBand10.Columns.Add(this.bandedGridColumn77);
            this.gridBand10.Columns.Add(this.bandedGridColumn78);
            this.gridBand10.Columns.Add(this.bandedGridColumn188);
            this.gridBand10.Columns.Add(this.bandedGridColumn79);
            this.gridBand10.Columns.Add(this.bandedGridColumn80);
            this.gridBand10.Columns.Add(this.bandedGridColumn81);
            this.gridBand10.Columns.Add(this.bandedGridColumn82);
            this.gridBand10.Columns.Add(this.bandedGridColumn228);
            this.gridBand10.Columns.Add(this.bandedGridColumn83);
            this.gridBand10.Columns.Add(this.bandedGridColumn222);
            this.gridBand10.Columns.Add(this.bandedGridColumn177);
            this.gridBand10.Columns.Add(this.bandedGridColumn178);
            this.gridBand10.Columns.Add(this.bandedGridColumn179);
            this.gridBand10.Columns.Add(this.bandedGridColumn180);
            this.gridBand10.Columns.Add(this.bandedGridColumn181);
            this.gridBand10.Columns.Add(this.bandedGridColumn182);
            this.gridBand10.Columns.Add(this.bandedGridColumn183);
            this.gridBand10.Name = "gridBand10";
            this.gridBand10.VisibleIndex = 0;
            this.gridBand10.Width = 1875;
            // 
            // bandedGridColumn65
            // 
            this.bandedGridColumn65.Caption = "#";
            this.bandedGridColumn65.FieldName = "num";
            this.bandedGridColumn65.MinWidth = 23;
            this.bandedGridColumn65.Name = "bandedGridColumn65";
            this.bandedGridColumn65.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn65.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn65.Width = 47;
            // 
            // bandedGridColumn66
            // 
            this.bandedGridColumn66.Caption = "Agent";
            this.bandedGridColumn66.FieldName = "agentNumber";
            this.bandedGridColumn66.MinWidth = 23;
            this.bandedGridColumn66.Name = "bandedGridColumn66";
            this.bandedGridColumn66.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn66.Visible = true;
            this.bandedGridColumn66.Width = 58;
            // 
            // bandedGridColumn67
            // 
            this.bandedGridColumn67.Caption = "Name";
            this.bandedGridColumn67.FieldName = "customer";
            this.bandedGridColumn67.MinWidth = 23;
            this.bandedGridColumn67.Name = "bandedGridColumn67";
            this.bandedGridColumn67.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn67.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn67.Visible = true;
            this.bandedGridColumn67.Width = 117;
            // 
            // bandedGridColumn233
            // 
            this.bandedGridColumn233.Caption = "Type";
            this.bandedGridColumn233.FieldName = "type";
            this.bandedGridColumn233.MinWidth = 23;
            this.bandedGridColumn233.Name = "bandedGridColumn233";
            this.bandedGridColumn233.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn233.Visible = true;
            this.bandedGridColumn233.Width = 87;
            // 
            // bandedGridColumn68
            // 
            this.bandedGridColumn68.Caption = "Formula";
            this.bandedGridColumn68.FieldName = "formula";
            this.bandedGridColumn68.MinWidth = 23;
            this.bandedGridColumn68.Name = "bandedGridColumn68";
            this.bandedGridColumn68.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn68.Visible = true;
            this.bandedGridColumn68.Width = 87;
            // 
            // bandedGridColumn69
            // 
            this.bandedGridColumn69.Caption = "Formula Sales";
            this.bandedGridColumn69.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn69.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn69.FieldName = "Formula Sales";
            this.bandedGridColumn69.MinWidth = 23;
            this.bandedGridColumn69.Name = "bandedGridColumn69";
            this.bandedGridColumn69.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn69.Visible = true;
            this.bandedGridColumn69.Width = 87;
            // 
            // bandedGridColumn70
            // 
            this.bandedGridColumn70.Caption = "Location Sales";
            this.bandedGridColumn70.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn70.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn70.FieldName = "Location Sales";
            this.bandedGridColumn70.MinWidth = 23;
            this.bandedGridColumn70.Name = "bandedGridColumn70";
            this.bandedGridColumn70.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn70.Visible = true;
            this.bandedGridColumn70.Width = 87;
            // 
            // bandedGridColumn73
            // 
            this.bandedGridColumn73.Caption = "DBC Value";
            this.bandedGridColumn73.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn73.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn73.FieldName = "dbrValue";
            this.bandedGridColumn73.MinWidth = 23;
            this.bandedGridColumn73.Name = "bandedGridColumn73";
            this.bandedGridColumn73.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn73.Visible = true;
            this.bandedGridColumn73.Width = 87;
            // 
            // bandedGridColumn236
            // 
            this.bandedGridColumn236.Caption = "DBC Money";
            this.bandedGridColumn236.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn236.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn236.FieldName = "dbcMoney";
            this.bandedGridColumn236.MinWidth = 23;
            this.bandedGridColumn236.Name = "bandedGridColumn236";
            this.bandedGridColumn236.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn236.Visible = true;
            this.bandedGridColumn236.Width = 87;
            // 
            // bandedGridColumn229
            // 
            this.bandedGridColumn229.Caption = "DBC";
            this.bandedGridColumn229.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn229.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn229.FieldName = "dbc";
            this.bandedGridColumn229.MinWidth = 23;
            this.bandedGridColumn229.Name = "bandedGridColumn229";
            this.bandedGridColumn229.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn229.Width = 87;
            // 
            // bandedGridColumn71
            // 
            this.bandedGridColumn71.Caption = "Goal Percent";
            this.bandedGridColumn71.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn71.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn71.FieldName = "goalPercent";
            this.bandedGridColumn71.MinWidth = 23;
            this.bandedGridColumn71.Name = "bandedGridColumn71";
            this.bandedGridColumn71.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn71.Width = 87;
            // 
            // bandedGridColumn72
            // 
            this.bandedGridColumn72.Caption = "Contract Value";
            this.bandedGridColumn72.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn72.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn72.FieldName = "contractValue";
            this.bandedGridColumn72.MinWidth = 23;
            this.bandedGridColumn72.Name = "bandedGridColumn72";
            this.bandedGridColumn72.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn72.Width = 96;
            // 
            // bandedGridColumn227
            // 
            this.bandedGridColumn227.Caption = "Past DBR";
            this.bandedGridColumn227.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn227.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn227.FieldName = "pastDBR";
            this.bandedGridColumn227.MinWidth = 23;
            this.bandedGridColumn227.Name = "bandedGridColumn227";
            this.bandedGridColumn227.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn227.Width = 87;
            // 
            // bandedGridColumn187
            // 
            this.bandedGridColumn187.Caption = "FBI";
            this.bandedGridColumn187.FieldName = "fbi";
            this.bandedGridColumn187.GroupFormat.FormatString = "N0";
            this.bandedGridColumn187.GroupFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn187.MinWidth = 23;
            this.bandedGridColumn187.Name = "bandedGridColumn187";
            this.bandedGridColumn187.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn187.Visible = true;
            this.bandedGridColumn187.Width = 52;
            // 
            // bandedGridColumn84
            // 
            this.bandedGridColumn84.Caption = "Total Payments";
            this.bandedGridColumn84.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn84.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn84.FieldName = "totalPayments";
            this.bandedGridColumn84.MinWidth = 23;
            this.bandedGridColumn84.Name = "bandedGridColumn84";
            this.bandedGridColumn84.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn84.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn84.Visible = true;
            this.bandedGridColumn84.Width = 96;
            // 
            // bandedGridColumn76
            // 
            this.bandedGridColumn76.Caption = "Total Contracts";
            this.bandedGridColumn76.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn76.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn76.FieldName = "totalContracts";
            this.bandedGridColumn76.MinWidth = 23;
            this.bandedGridColumn76.Name = "bandedGridColumn76";
            this.bandedGridColumn76.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn76.Visible = true;
            this.bandedGridColumn76.Width = 87;
            // 
            // bandedGridColumn77
            // 
            this.bandedGridColumn77.Caption = "Goal";
            this.bandedGridColumn77.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn77.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn77.FieldName = "goal";
            this.bandedGridColumn77.MinWidth = 23;
            this.bandedGridColumn77.Name = "bandedGridColumn77";
            this.bandedGridColumn77.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn77.Visible = true;
            this.bandedGridColumn77.Width = 93;
            // 
            // bandedGridColumn78
            // 
            this.bandedGridColumn78.Caption = "Goal Commission";
            this.bandedGridColumn78.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn78.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn78.FieldName = "goalCommission";
            this.bandedGridColumn78.MinWidth = 23;
            this.bandedGridColumn78.Name = "bandedGridColumn78";
            this.bandedGridColumn78.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn78.Visible = true;
            this.bandedGridColumn78.Width = 117;
            // 
            // bandedGridColumn188
            // 
            this.bandedGridColumn188.Caption = "FBI$";
            this.bandedGridColumn188.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn188.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn188.FieldName = "fbi$";
            this.bandedGridColumn188.MinWidth = 23;
            this.bandedGridColumn188.Name = "bandedGridColumn188";
            this.bandedGridColumn188.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn188.Visible = true;
            this.bandedGridColumn188.Width = 70;
            // 
            // bandedGridColumn79
            // 
            this.bandedGridColumn79.Caption = "Current Recap";
            this.bandedGridColumn79.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn79.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn79.FieldName = "Recap";
            this.bandedGridColumn79.MinWidth = 23;
            this.bandedGridColumn79.Name = "bandedGridColumn79";
            this.bandedGridColumn79.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn79.Visible = true;
            this.bandedGridColumn79.Width = 87;
            // 
            // bandedGridColumn80
            // 
            this.bandedGridColumn80.Caption = "Re-Ins";
            this.bandedGridColumn80.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn80.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn80.FieldName = "Reins";
            this.bandedGridColumn80.MinWidth = 23;
            this.bandedGridColumn80.Name = "bandedGridColumn80";
            this.bandedGridColumn80.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn80.Visible = true;
            this.bandedGridColumn80.Width = 87;
            // 
            // bandedGridColumn81
            // 
            this.bandedGridColumn81.Caption = "Past Re-Ins";
            this.bandedGridColumn81.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn81.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn81.FieldName = "pastRecap";
            this.bandedGridColumn81.MinWidth = 23;
            this.bandedGridColumn81.Name = "bandedGridColumn81";
            this.bandedGridColumn81.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn81.Visible = true;
            this.bandedGridColumn81.Width = 87;
            // 
            // bandedGridColumn82
            // 
            this.bandedGridColumn82.Caption = "Past Failures";
            this.bandedGridColumn82.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn82.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn82.FieldName = "pastFailures";
            this.bandedGridColumn82.MinWidth = 23;
            this.bandedGridColumn82.Name = "bandedGridColumn82";
            this.bandedGridColumn82.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn82.Visible = true;
            this.bandedGridColumn82.Width = 87;
            // 
            // bandedGridColumn228
            // 
            this.bandedGridColumn228.Caption = "Split Goal Commission";
            this.bandedGridColumn228.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn228.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn228.FieldName = "splitGoalCommission";
            this.bandedGridColumn228.MinWidth = 23;
            this.bandedGridColumn228.Name = "bandedGridColumn228";
            this.bandedGridColumn228.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn228.Width = 99;
            // 
            // bandedGridColumn83
            // 
            this.bandedGridColumn83.Caption = "Contract Commission";
            this.bandedGridColumn83.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn83.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn83.FieldName = "contractCommission";
            this.bandedGridColumn83.MinWidth = 23;
            this.bandedGridColumn83.Name = "bandedGridColumn83";
            this.bandedGridColumn83.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn83.Visible = true;
            this.bandedGridColumn83.Width = 87;
            // 
            // bandedGridColumn222
            // 
            this.bandedGridColumn222.Caption = "Split Base Commission";
            this.bandedGridColumn222.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn222.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn222.FieldName = "splitBaseCommission";
            this.bandedGridColumn222.MinWidth = 23;
            this.bandedGridColumn222.Name = "bandedGridColumn222";
            this.bandedGridColumn222.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn222.Width = 107;
            // 
            // bandedGridColumn177
            // 
            this.bandedGridColumn177.Caption = "Base Commission";
            this.bandedGridColumn177.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn177.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn177.FieldName = "commission";
            this.bandedGridColumn177.MinWidth = 23;
            this.bandedGridColumn177.Name = "bandedGridColumn177";
            this.bandedGridColumn177.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn177.Visible = true;
            this.bandedGridColumn177.Width = 111;
            // 
            // bandedGridColumn178
            // 
            this.bandedGridColumn178.Caption = "splits";
            this.bandedGridColumn178.FieldName = "splits";
            this.bandedGridColumn178.MinWidth = 23;
            this.bandedGridColumn178.Name = "bandedGridColumn178";
            this.bandedGridColumn178.Width = 87;
            // 
            // bandedGridColumn179
            // 
            this.bandedGridColumn179.Caption = "additional";
            this.bandedGridColumn179.FieldName = "additionalGoals";
            this.bandedGridColumn179.MinWidth = 23;
            this.bandedGridColumn179.Name = "bandedGridColumn179";
            this.bandedGridColumn179.Width = 87;
            // 
            // bandedGridColumn180
            // 
            this.bandedGridColumn180.Caption = "record";
            this.bandedGridColumn180.FieldName = "record";
            this.bandedGridColumn180.MinWidth = 23;
            this.bandedGridColumn180.Name = "bandedGridColumn180";
            this.bandedGridColumn180.RowCount = 2;
            this.bandedGridColumn180.Width = 87;
            // 
            // bandedGridColumn181
            // 
            this.bandedGridColumn181.Caption = "Main Commission";
            this.bandedGridColumn181.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn181.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn181.FieldName = "mainCommission";
            this.bandedGridColumn181.MinWidth = 23;
            this.bandedGridColumn181.Name = "bandedGridColumn181";
            this.bandedGridColumn181.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn181.Width = 117;
            // 
            // bandedGridColumn182
            // 
            this.bandedGridColumn182.Caption = "Split Commission";
            this.bandedGridColumn182.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn182.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn182.FieldName = "splitCommission";
            this.bandedGridColumn182.MinWidth = 23;
            this.bandedGridColumn182.Name = "bandedGridColumn182";
            this.bandedGridColumn182.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn182.Width = 87;
            // 
            // bandedGridColumn183
            // 
            this.bandedGridColumn183.Caption = "Total Commission";
            this.bandedGridColumn183.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn183.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn183.FieldName = "totalCommission";
            this.bandedGridColumn183.MinWidth = 23;
            this.bandedGridColumn183.Name = "bandedGridColumn183";
            this.bandedGridColumn183.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn183.Visible = true;
            this.bandedGridColumn183.Width = 117;
            // 
            // panelCommTop
            // 
            this.panelCommTop.BackColor = System.Drawing.Color.PeachPuff;
            this.panelCommTop.Controls.Add(this.label9);
            this.panelCommTop.Controls.Add(this.cmbStatus);
            this.panelCommTop.Controls.Add(this.btnChart);
            this.panelCommTop.Controls.Add(this.label8);
            this.panelCommTop.Controls.Add(this.cmbShow);
            this.panelCommTop.Controls.Add(this.btnPrintAll);
            this.panelCommTop.Controls.Add(this.cmbSelectCommission);
            this.panelCommTop.Controls.Add(this.btnSelectCommission);
            this.panelCommTop.Controls.Add(this.btnSaveCommissions);
            this.panelCommTop.Controls.Add(this.chkDoSplits);
            this.panelCommTop.Controls.Add(this.btnRunCommissions);
            this.panelCommTop.Controls.Add(this.chkConsolidate);
            this.panelCommTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelCommTop.Location = new System.Drawing.Point(0, 0);
            this.panelCommTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelCommTop.Name = "panelCommTop";
            this.panelCommTop.Size = new System.Drawing.Size(1395, 48);
            this.panelCommTop.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1161, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 17);
            this.label9.TabIndex = 94;
            this.label9.Text = "For Status";
            // 
            // cmbStatus
            // 
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Items.AddRange(new object[] {
            "All",
            "Active",
            "Inactive"});
            this.cmbStatus.Location = new System.Drawing.Point(1084, 14);
            this.cmbStatus.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(74, 24);
            this.cmbStatus.TabIndex = 93;
            this.cmbStatus.Text = "All";
            // 
            // btnChart
            // 
            this.btnChart.BackColor = System.Drawing.Color.OrangeRed;
            this.btnChart.Location = new System.Drawing.Point(1300, 0);
            this.btnChart.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnChart.Name = "btnChart";
            this.btnChart.Size = new System.Drawing.Size(87, 42);
            this.btnChart.TabIndex = 92;
            this.btnChart.Text = "Run Chart";
            this.btnChart.UseVisualStyleBackColor = false;
            this.btnChart.Click += new System.EventHandler(this.btnChart_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(964, 18);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 17);
            this.label8.TabIndex = 91;
            this.label8.Text = "Show Report";
            // 
            // cmbShow
            // 
            this.cmbShow.FormattingEnabled = true;
            this.cmbShow.Items.AddRange(new object[] {
            "All",
            "5%",
            "1%"});
            this.cmbShow.Location = new System.Drawing.Point(882, 12);
            this.cmbShow.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbShow.Name = "cmbShow";
            this.cmbShow.Size = new System.Drawing.Size(74, 24);
            this.cmbShow.TabIndex = 90;
            this.cmbShow.Text = "All";
            this.cmbShow.SelectedIndexChanged += new System.EventHandler(this.cmbShow_SelectedIndexChanged);
            // 
            // btnPrintAll
            // 
            this.btnPrintAll.BackColor = System.Drawing.Color.Lime;
            this.btnPrintAll.Location = new System.Drawing.Point(744, 4);
            this.btnPrintAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPrintAll.Name = "btnPrintAll";
            this.btnPrintAll.Size = new System.Drawing.Size(87, 42);
            this.btnPrintAll.TabIndex = 89;
            this.btnPrintAll.Text = "Print All Detail";
            this.btnPrintAll.UseVisualStyleBackColor = false;
            this.btnPrintAll.Click += new System.EventHandler(this.btnPrintAll_Click);
            // 
            // cmbSelectCommission
            // 
            this.cmbSelectCommission.FormattingEnabled = true;
            this.cmbSelectCommission.Location = new System.Drawing.Point(324, 11);
            this.cmbSelectCommission.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbSelectCommission.Name = "cmbSelectCommission";
            this.cmbSelectCommission.Size = new System.Drawing.Size(179, 24);
            this.cmbSelectCommission.TabIndex = 88;
            this.cmbSelectCommission.SelectedIndexChanged += new System.EventHandler(this.cmbSelectCommission_SelectedIndexChanged);
            // 
            // btnSelectCommission
            // 
            this.btnSelectCommission.BackColor = System.Drawing.Color.SandyBrown;
            this.btnSelectCommission.Location = new System.Drawing.Point(510, 10);
            this.btnSelectCommission.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSelectCommission.Name = "btnSelectCommission";
            this.btnSelectCommission.Size = new System.Drawing.Size(113, 28);
            this.btnSelectCommission.TabIndex = 87;
            this.btnSelectCommission.Text = "Select Columns";
            this.btnSelectCommission.UseVisualStyleBackColor = false;
            this.btnSelectCommission.Click += new System.EventHandler(this.btnSelectCommission_Click);
            // 
            // btnSaveCommissions
            // 
            this.btnSaveCommissions.BackColor = System.Drawing.Color.Tomato;
            this.btnSaveCommissions.Location = new System.Drawing.Point(650, 2);
            this.btnSaveCommissions.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSaveCommissions.Name = "btnSaveCommissions";
            this.btnSaveCommissions.Size = new System.Drawing.Size(87, 42);
            this.btnSaveCommissions.TabIndex = 33;
            this.btnSaveCommissions.Text = "Save Commissions";
            this.btnSaveCommissions.UseVisualStyleBackColor = false;
            this.btnSaveCommissions.Click += new System.EventHandler(this.btnSaveCommissions_Click);
            // 
            // chkDoSplits
            // 
            this.chkDoSplits.AutoSize = true;
            this.chkDoSplits.Location = new System.Drawing.Point(236, 14);
            this.chkDoSplits.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkDoSplits.Name = "chkDoSplits";
            this.chkDoSplits.Size = new System.Drawing.Size(83, 21);
            this.chkDoSplits.TabIndex = 32;
            this.chkDoSplits.Text = "Do Splits";
            this.chkDoSplits.UseVisualStyleBackColor = true;
            // 
            // btnRunCommissions
            // 
            this.btnRunCommissions.BackColor = System.Drawing.Color.OrangeRed;
            this.btnRunCommissions.Location = new System.Drawing.Point(125, 1);
            this.btnRunCommissions.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRunCommissions.Name = "btnRunCommissions";
            this.btnRunCommissions.Size = new System.Drawing.Size(87, 42);
            this.btnRunCommissions.TabIndex = 31;
            this.btnRunCommissions.Text = "Run Commissions";
            this.btnRunCommissions.UseVisualStyleBackColor = false;
            this.btnRunCommissions.Click += new System.EventHandler(this.btnRunCommissions_Click);
            // 
            // chkConsolidate
            // 
            this.chkConsolidate.AutoSize = true;
            this.chkConsolidate.Location = new System.Drawing.Point(16, 12);
            this.chkConsolidate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkConsolidate.Name = "chkConsolidate";
            this.chkConsolidate.Size = new System.Drawing.Size(100, 21);
            this.chkConsolidate.TabIndex = 28;
            this.chkConsolidate.Text = "Consolidate";
            this.chkConsolidate.UseVisualStyleBackColor = true;
            this.chkConsolidate.CheckedChanged += new System.EventHandler(this.chkConsolidate_CheckedChanged);
            // 
            // tabDebugTrusts
            // 
            this.tabDebugTrusts.Controls.Add(this.panelDebugAll);
            this.tabDebugTrusts.Location = new System.Drawing.Point(4, 25);
            this.tabDebugTrusts.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabDebugTrusts.Name = "tabDebugTrusts";
            this.tabDebugTrusts.Size = new System.Drawing.Size(1395, 382);
            this.tabDebugTrusts.TabIndex = 10;
            this.tabDebugTrusts.Text = "Debug Trusts";
            this.tabDebugTrusts.UseVisualStyleBackColor = true;
            // 
            // panelDebugAll
            // 
            this.panelDebugAll.Controls.Add(this.panelDebugBottom);
            this.panelDebugAll.Controls.Add(this.panelDebugTop);
            this.panelDebugAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDebugAll.Location = new System.Drawing.Point(0, 0);
            this.panelDebugAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelDebugAll.Name = "panelDebugAll";
            this.panelDebugAll.Size = new System.Drawing.Size(1395, 382);
            this.panelDebugAll.TabIndex = 0;
            // 
            // panelDebugBottom
            // 
            this.panelDebugBottom.Controls.Add(this.dgv11);
            this.panelDebugBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDebugBottom.Location = new System.Drawing.Point(0, 58);
            this.panelDebugBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelDebugBottom.Name = "panelDebugBottom";
            this.panelDebugBottom.Size = new System.Drawing.Size(1395, 324);
            this.panelDebugBottom.TabIndex = 2;
            // 
            // dgv11
            // 
            this.dgv11.ContextMenuStrip = this.contextMenuStrip2;
            this.dgv11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv11.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv11.Location = new System.Drawing.Point(0, 0);
            this.dgv11.LookAndFeel.SkinName = "iMaginary";
            this.dgv11.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv11.MainView = this.gridMain11;
            this.dgv11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv11.Name = "dgv11";
            this.dgv11.Size = new System.Drawing.Size(1395, 324);
            this.dgv11.TabIndex = 9;
            this.dgv11.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain11});
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.recalcTrust85ToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(211, 56);
            // 
            // recalcTrust85ToolStripMenuItem
            // 
            this.recalcTrust85ToolStripMenuItem.Name = "recalcTrust85ToolStripMenuItem";
            this.recalcTrust85ToolStripMenuItem.Size = new System.Drawing.Size(210, 24);
            this.recalcTrust85ToolStripMenuItem.Text = "Recalc Trust85";
            this.recalcTrust85ToolStripMenuItem.Click += new System.EventHandler(this.recalcTrust85ToolStripMenuItem_Click);
            // 
            // gridMain11
            // 
            this.gridMain11.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain11.Appearance.BandPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(153)))), ((int)(((byte)(182)))));
            this.gridMain11.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain11.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain11.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.BandPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain11.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain11.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain11.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain11.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain11.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain11.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain11.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain11.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(153)))), ((int)(((byte)(182)))));
            this.gridMain11.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain11.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.ColumnFilterButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain11.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain11.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain11.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain11.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.White;
            this.gridMain11.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(198)))), ((int)(((byte)(215)))));
            this.gridMain11.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.White;
            this.gridMain11.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.ColumnFilterButtonActive.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain11.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain11.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain11.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain11.Appearance.Empty.BackColor = System.Drawing.Color.White;
            this.gridMain11.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain11.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain11.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain11.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain11.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain11.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(153)))), ((int)(((byte)(182)))));
            this.gridMain11.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain11.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain11.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain11.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain11.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(131)))), ((int)(((byte)(161)))));
            this.gridMain11.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain11.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain11.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain11.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(124)))), ((int)(((byte)(148)))));
            this.gridMain11.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain11.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(180)))), ((int)(((byte)(191)))));
            this.gridMain11.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain11.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain11.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain11.Appearance.FooterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(153)))), ((int)(((byte)(182)))));
            this.gridMain11.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain11.Appearance.FooterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain11.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain11.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain11.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain11.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain11.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain11.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain11.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain11.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain11.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain11.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain11.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain11.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain11.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(131)))), ((int)(((byte)(161)))));
            this.gridMain11.Appearance.GroupPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain11.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain11.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain11.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain11.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain11.Appearance.GroupRow.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain11.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain11.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain11.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain11.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain11.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain11.Appearance.HeaderPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(153)))), ((int)(((byte)(182)))));
            this.gridMain11.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain11.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.HeaderPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain11.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain11.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain11.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain11.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain11.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain11.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(219)))), ((int)(((byte)(226)))));
            this.gridMain11.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(131)))), ((int)(((byte)(161)))));
            this.gridMain11.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain11.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain11.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(164)))), ((int)(((byte)(188)))));
            this.gridMain11.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain11.Appearance.OddRow.BackColor = System.Drawing.Color.White;
            this.gridMain11.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain11.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain11.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(253)))));
            this.gridMain11.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(165)))), ((int)(((byte)(177)))));
            this.gridMain11.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain11.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain11.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain11.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.Row.Options.UseBackColor = true;
            this.gridMain11.Appearance.Row.Options.UseForeColor = true;
            this.gridMain11.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain11.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain11.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(197)))), ((int)(((byte)(205)))));
            this.gridMain11.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain11.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain11.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain11.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(164)))), ((int)(((byte)(188)))));
            this.gridMain11.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain11.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain11.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain11.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand11});
            this.gridMain11.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain11.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn192,
            this.bandedGridColumn218,
            this.bandedGridColumn193,
            this.bandedGridColumn194,
            this.bandedGridColumn195,
            this.bandedGridColumn196,
            this.bandedGridColumn197,
            this.bandedGridColumn206,
            this.bandedGridColumn209,
            this.bandedGridColumn204,
            this.bandedGridColumn203,
            this.bandedGridColumn200,
            this.bandedGridColumn217,
            this.bandedGridColumn208,
            this.bandedGridColumn210,
            this.bandedGridColumn207,
            this.bandedGridColumn202,
            this.bandedGridColumn190,
            this.bandedGridColumn205,
            this.bandedGridColumn215,
            this.bandedGridColumn201,
            this.bandedGridColumn191,
            this.bandedGridColumn198,
            this.bandedGridColumn216,
            this.bandedGridColumn199,
            this.bandedGridColumn211,
            this.bandedGridColumn212,
            this.bandedGridColumn214,
            this.bandedGridColumn213,
            this.calcTrust85_215,
            this.difference_216,
            this.bandedGridColumn219,
            this.bandedGridColumn220});
            this.gridMain11.DetailHeight = 431;
            this.gridMain11.GridControl = this.dgv11;
            this.gridMain11.GroupSummary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "paymentCurrMonth", this.bandedGridColumn211, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "beginningBalance", this.bandedGridColumn198, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ytdPrevious", this.bandedGridColumn199, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "endingBalance", this.bandedGridColumn214, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "currentRemovals", this.bandedGridColumn213, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "calcTrust85", this.calcTrust85_215, "${0:0,0.00}"),
            new DevExpress.XtraGrid.GridGroupSummaryItem(DevExpress.Data.SummaryItemType.Sum, "difference", this.difference_216, "${0:0,0.00}")});
            this.gridMain11.Name = "gridMain11";
            this.gridMain11.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain11.OptionsPrint.PrintBandHeader = false;
            this.gridMain11.OptionsSelection.MultiSelect = true;
            this.gridMain11.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain11.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain11.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain11.OptionsView.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.gridMain11.OptionsView.ShowBands = false;
            this.gridMain11.OptionsView.ShowFooter = true;
            this.gridMain11.OptionsView.ShowGroupPanel = false;
            this.gridMain11.PaintStyleName = "Style3D";
            this.gridMain11.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMain11_CustomDrawCell);
            this.gridMain11.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMain11_CustomRowFilter);
            this.gridMain11.DoubleClick += new System.EventHandler(this.gridMain11_DoubleClick);
            // 
            // gridBand11
            // 
            this.gridBand11.Caption = "gridBandXXX";
            this.gridBand11.Columns.Add(this.bandedGridColumn190);
            this.gridBand11.Columns.Add(this.bandedGridColumn192);
            this.gridBand11.Columns.Add(this.bandedGridColumn191);
            this.gridBand11.Columns.Add(this.bandedGridColumn193);
            this.gridBand11.Columns.Add(this.bandedGridColumn194);
            this.gridBand11.Columns.Add(this.bandedGridColumn195);
            this.gridBand11.Columns.Add(this.bandedGridColumn205);
            this.gridBand11.Columns.Add(this.bandedGridColumn215);
            this.gridBand11.Columns.Add(this.bandedGridColumn216);
            this.gridBand11.Columns.Add(this.bandedGridColumn219);
            this.gridBand11.Columns.Add(this.bandedGridColumn220);
            this.gridBand11.Columns.Add(this.bandedGridColumn207);
            this.gridBand11.Columns.Add(this.bandedGridColumn196);
            this.gridBand11.Columns.Add(this.bandedGridColumn197);
            this.gridBand11.Columns.Add(this.bandedGridColumn198);
            this.gridBand11.Columns.Add(this.bandedGridColumn199);
            this.gridBand11.Columns.Add(this.bandedGridColumn212);
            this.gridBand11.Columns.Add(this.bandedGridColumn200);
            this.gridBand11.Columns.Add(this.bandedGridColumn201);
            this.gridBand11.Columns.Add(this.bandedGridColumn202);
            this.gridBand11.Columns.Add(this.bandedGridColumn203);
            this.gridBand11.Columns.Add(this.bandedGridColumn204);
            this.gridBand11.Columns.Add(this.bandedGridColumn206);
            this.gridBand11.Columns.Add(this.bandedGridColumn208);
            this.gridBand11.Columns.Add(this.bandedGridColumn209);
            this.gridBand11.Columns.Add(this.bandedGridColumn210);
            this.gridBand11.Columns.Add(this.bandedGridColumn211);
            this.gridBand11.Columns.Add(this.bandedGridColumn213);
            this.gridBand11.Columns.Add(this.bandedGridColumn214);
            this.gridBand11.Columns.Add(this.calcTrust85_215);
            this.gridBand11.Columns.Add(this.difference_216);
            this.gridBand11.Columns.Add(this.bandedGridColumn217);
            this.gridBand11.Columns.Add(this.bandedGridColumn218);
            this.gridBand11.MinWidth = 12;
            this.gridBand11.Name = "gridBand11";
            this.gridBand11.VisibleIndex = 0;
            this.gridBand11.Width = 1451;
            // 
            // bandedGridColumn190
            // 
            this.bandedGridColumn190.Caption = "Loc";
            this.bandedGridColumn190.FieldName = "loc";
            this.bandedGridColumn190.MinWidth = 23;
            this.bandedGridColumn190.Name = "bandedGridColumn190";
            this.bandedGridColumn190.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn190.Visible = true;
            this.bandedGridColumn190.Width = 47;
            // 
            // bandedGridColumn192
            // 
            this.bandedGridColumn192.Caption = "Num";
            this.bandedGridColumn192.FieldName = "num";
            this.bandedGridColumn192.MinWidth = 23;
            this.bandedGridColumn192.Name = "bandedGridColumn192";
            this.bandedGridColumn192.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn192.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn192.Visible = true;
            this.bandedGridColumn192.Width = 58;
            // 
            // bandedGridColumn191
            // 
            this.bandedGridColumn191.Caption = "Location Name";
            this.bandedGridColumn191.FieldName = "Location Name";
            this.bandedGridColumn191.MinWidth = 23;
            this.bandedGridColumn191.Name = "bandedGridColumn191";
            this.bandedGridColumn191.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn191.Width = 87;
            // 
            // bandedGridColumn193
            // 
            this.bandedGridColumn193.Caption = "Last Name";
            this.bandedGridColumn193.FieldName = "lastName";
            this.bandedGridColumn193.MinWidth = 23;
            this.bandedGridColumn193.Name = "bandedGridColumn193";
            this.bandedGridColumn193.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn193.Width = 87;
            // 
            // bandedGridColumn194
            // 
            this.bandedGridColumn194.Caption = "First Name";
            this.bandedGridColumn194.FieldName = "firstName";
            this.bandedGridColumn194.MinWidth = 23;
            this.bandedGridColumn194.Name = "bandedGridColumn194";
            this.bandedGridColumn194.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn194.Width = 87;
            // 
            // bandedGridColumn195
            // 
            this.bandedGridColumn195.Caption = "Name";
            this.bandedGridColumn195.FieldName = "fullname";
            this.bandedGridColumn195.MinWidth = 23;
            this.bandedGridColumn195.Name = "bandedGridColumn195";
            this.bandedGridColumn195.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn195.Visible = true;
            this.bandedGridColumn195.Width = 87;
            // 
            // bandedGridColumn205
            // 
            this.bandedGridColumn205.Caption = "Issue Date";
            this.bandedGridColumn205.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn205.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn205.FieldName = "issueDate";
            this.bandedGridColumn205.MinWidth = 23;
            this.bandedGridColumn205.Name = "bandedGridColumn205";
            this.bandedGridColumn205.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn205.Visible = true;
            this.bandedGridColumn205.Width = 87;
            // 
            // bandedGridColumn215
            // 
            this.bandedGridColumn215.Caption = "Deceased Date";
            this.bandedGridColumn215.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn215.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn215.FieldName = "DD";
            this.bandedGridColumn215.MinWidth = 23;
            this.bandedGridColumn215.Name = "bandedGridColumn215";
            this.bandedGridColumn215.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn215.Visible = true;
            this.bandedGridColumn215.Width = 87;
            // 
            // bandedGridColumn216
            // 
            this.bandedGridColumn216.Caption = "# Pmts";
            this.bandedGridColumn216.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn216.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn216.FieldName = "Pmts";
            this.bandedGridColumn216.MinWidth = 23;
            this.bandedGridColumn216.Name = "bandedGridColumn216";
            this.bandedGridColumn216.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn216.Visible = true;
            this.bandedGridColumn216.Width = 58;
            // 
            // bandedGridColumn219
            // 
            this.bandedGridColumn219.Caption = "M";
            this.bandedGridColumn219.FieldName = "method";
            this.bandedGridColumn219.MinWidth = 23;
            this.bandedGridColumn219.Name = "bandedGridColumn219";
            this.bandedGridColumn219.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn219.Visible = true;
            this.bandedGridColumn219.Width = 35;
            // 
            // bandedGridColumn220
            // 
            this.bandedGridColumn220.Caption = "APR";
            this.bandedGridColumn220.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn220.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn220.FieldName = "apr";
            this.bandedGridColumn220.MinWidth = 23;
            this.bandedGridColumn220.Name = "bandedGridColumn220";
            this.bandedGridColumn220.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn220.Visible = true;
            this.bandedGridColumn220.Width = 47;
            // 
            // bandedGridColumn207
            // 
            this.bandedGridColumn207.Caption = "Contract Value";
            this.bandedGridColumn207.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn207.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn207.FieldName = "contractValue";
            this.bandedGridColumn207.MinWidth = 23;
            this.bandedGridColumn207.Name = "bandedGridColumn207";
            this.bandedGridColumn207.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn207.Visible = true;
            this.bandedGridColumn207.Width = 93;
            // 
            // bandedGridColumn196
            // 
            this.bandedGridColumn196.Caption = "Contract";
            this.bandedGridColumn196.FieldName = "contractNumber";
            this.bandedGridColumn196.MinWidth = 23;
            this.bandedGridColumn196.Name = "bandedGridColumn196";
            this.bandedGridColumn196.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn196.Visible = true;
            // 
            // bandedGridColumn197
            // 
            this.bandedGridColumn197.Caption = "SS#";
            this.bandedGridColumn197.FieldName = "ssn";
            this.bandedGridColumn197.MinWidth = 23;
            this.bandedGridColumn197.Name = "bandedGridColumn197";
            this.bandedGridColumn197.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn197.Visible = true;
            this.bandedGridColumn197.Width = 87;
            // 
            // bandedGridColumn198
            // 
            this.bandedGridColumn198.Caption = "17 & Prior Bal PD";
            this.bandedGridColumn198.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn198.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn198.FieldName = "prioryear";
            this.bandedGridColumn198.MinWidth = 23;
            this.bandedGridColumn198.Name = "bandedGridColumn198";
            this.bandedGridColumn198.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn198.Width = 117;
            // 
            // bandedGridColumn199
            // 
            this.bandedGridColumn199.Caption = "Beginning Value";
            this.bandedGridColumn199.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn199.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn199.FieldName = "beginningBalance";
            this.bandedGridColumn199.MinWidth = 23;
            this.bandedGridColumn199.Name = "bandedGridColumn199";
            this.bandedGridColumn199.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn199.Visible = true;
            this.bandedGridColumn199.Width = 105;
            // 
            // bandedGridColumn212
            // 
            this.bandedGridColumn212.Caption = "YTD Previous";
            this.bandedGridColumn212.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn212.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn212.FieldName = "ytdPrevious";
            this.bandedGridColumn212.MinWidth = 23;
            this.bandedGridColumn212.Name = "bandedGridColumn212";
            this.bandedGridColumn212.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn212.Visible = true;
            this.bandedGridColumn212.Width = 93;
            // 
            // bandedGridColumn200
            // 
            this.bandedGridColumn200.Caption = "Agent";
            this.bandedGridColumn200.FieldName = "agentNumber";
            this.bandedGridColumn200.MinWidth = 23;
            this.bandedGridColumn200.Name = "bandedGridColumn200";
            this.bandedGridColumn200.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn200.Width = 70;
            // 
            // bandedGridColumn201
            // 
            this.bandedGridColumn201.Caption = "Agent Name";
            this.bandedGridColumn201.FieldName = "agentName";
            this.bandedGridColumn201.MinWidth = 23;
            this.bandedGridColumn201.Name = "bandedGridColumn201";
            this.bandedGridColumn201.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn201.Width = 87;
            // 
            // bandedGridColumn202
            // 
            this.bandedGridColumn202.Caption = "Trust";
            this.bandedGridColumn202.FieldName = "trust";
            this.bandedGridColumn202.MinWidth = 23;
            this.bandedGridColumn202.Name = "bandedGridColumn202";
            this.bandedGridColumn202.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn202.Width = 58;
            // 
            // bandedGridColumn203
            // 
            this.bandedGridColumn203.Caption = "Due Date";
            this.bandedGridColumn203.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn203.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn203.FieldName = "dueDate8";
            this.bandedGridColumn203.MinWidth = 23;
            this.bandedGridColumn203.Name = "bandedGridColumn203";
            this.bandedGridColumn203.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn203.Width = 76;
            // 
            // bandedGridColumn204
            // 
            this.bandedGridColumn204.Caption = "Date Paid";
            this.bandedGridColumn204.DisplayFormat.FormatString = "mm/dd/yyyy";
            this.bandedGridColumn204.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn204.FieldName = "payDate8";
            this.bandedGridColumn204.MinWidth = 23;
            this.bandedGridColumn204.Name = "bandedGridColumn204";
            this.bandedGridColumn204.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn204.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn204.Width = 76;
            // 
            // bandedGridColumn206
            // 
            this.bandedGridColumn206.Caption = "Customer";
            this.bandedGridColumn206.FieldName = "customer";
            this.bandedGridColumn206.MinWidth = 23;
            this.bandedGridColumn206.Name = "bandedGridColumn206";
            this.bandedGridColumn206.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn206.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn206.Width = 175;
            // 
            // bandedGridColumn208
            // 
            this.bandedGridColumn208.Caption = "Down Payment";
            this.bandedGridColumn208.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn208.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn208.FieldName = "downPayment";
            this.bandedGridColumn208.MinWidth = 23;
            this.bandedGridColumn208.Name = "bandedGridColumn208";
            this.bandedGridColumn208.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn208.Width = 96;
            // 
            // bandedGridColumn209
            // 
            this.bandedGridColumn209.Caption = "Payment";
            this.bandedGridColumn209.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn209.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn209.FieldName = "paymentAmount";
            this.bandedGridColumn209.MinWidth = 23;
            this.bandedGridColumn209.Name = "bandedGridColumn209";
            this.bandedGridColumn209.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn209.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn209.Width = 96;
            // 
            // bandedGridColumn210
            // 
            this.bandedGridColumn210.Caption = "Total Payments";
            this.bandedGridColumn210.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn210.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn210.FieldName = "totalPayments";
            this.bandedGridColumn210.MinWidth = 23;
            this.bandedGridColumn210.Name = "bandedGridColumn210";
            this.bandedGridColumn210.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn210.Width = 96;
            // 
            // bandedGridColumn211
            // 
            this.bandedGridColumn211.Caption = "Current Month";
            this.bandedGridColumn211.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn211.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn211.FieldName = "paymentCurrMonth";
            this.bandedGridColumn211.MinWidth = 23;
            this.bandedGridColumn211.Name = "bandedGridColumn211";
            this.bandedGridColumn211.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn211.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn211.Visible = true;
            this.bandedGridColumn211.Width = 96;
            // 
            // bandedGridColumn213
            // 
            this.bandedGridColumn213.Caption = "Current Removals";
            this.bandedGridColumn213.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn213.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn213.FieldName = "currentRemovals";
            this.bandedGridColumn213.MinWidth = 23;
            this.bandedGridColumn213.Name = "bandedGridColumn213";
            this.bandedGridColumn213.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn213.Visible = true;
            this.bandedGridColumn213.Width = 93;
            // 
            // bandedGridColumn214
            // 
            this.bandedGridColumn214.Caption = "Ending Balance";
            this.bandedGridColumn214.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn214.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn214.FieldName = "endingBalance";
            this.bandedGridColumn214.MinWidth = 23;
            this.bandedGridColumn214.Name = "bandedGridColumn214";
            this.bandedGridColumn214.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn214.Visible = true;
            this.bandedGridColumn214.Width = 117;
            // 
            // calcTrust85_215
            // 
            this.calcTrust85_215.Caption = "Calculated Trust85";
            this.calcTrust85_215.DisplayFormat.FormatString = "N2";
            this.calcTrust85_215.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.calcTrust85_215.FieldName = "calcTrust85";
            this.calcTrust85_215.MinWidth = 23;
            this.calcTrust85_215.Name = "calcTrust85_215";
            this.calcTrust85_215.OptionsColumn.FixedWidth = true;
            this.calcTrust85_215.Visible = true;
            this.calcTrust85_215.Width = 93;
            // 
            // difference_216
            // 
            this.difference_216.Caption = "Difference";
            this.difference_216.DisplayFormat.FormatString = "N2";
            this.difference_216.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.difference_216.FieldName = "difference";
            this.difference_216.MinWidth = 23;
            this.difference_216.Name = "difference_216";
            this.difference_216.OptionsColumn.FixedWidth = true;
            this.difference_216.Visible = true;
            this.difference_216.Width = 93;
            // 
            // bandedGridColumn217
            // 
            this.bandedGridColumn217.Caption = "Commission";
            this.bandedGridColumn217.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn217.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn217.FieldName = "commission";
            this.bandedGridColumn217.MinWidth = 23;
            this.bandedGridColumn217.Name = "bandedGridColumn217";
            this.bandedGridColumn217.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn217.Width = 111;
            // 
            // bandedGridColumn218
            // 
            this.bandedGridColumn218.Caption = "record";
            this.bandedGridColumn218.FieldName = "record";
            this.bandedGridColumn218.MinWidth = 23;
            this.bandedGridColumn218.Name = "bandedGridColumn218";
            this.bandedGridColumn218.RowCount = 2;
            this.bandedGridColumn218.Width = 87;
            // 
            // panelDebugTop
            // 
            this.panelDebugTop.Controls.Add(this.chkOnlyCurrent);
            this.panelDebugTop.Controls.Add(this.chkShowLocations);
            this.panelDebugTop.Controls.Add(this.chkExpand);
            this.panelDebugTop.Controls.Add(this.checkBox1);
            this.panelDebugTop.Controls.Add(this.chk2002);
            this.panelDebugTop.Controls.Add(this.label7);
            this.panelDebugTop.Controls.Add(this.progressBar1);
            this.panelDebugTop.Controls.Add(this.btnRunDiff);
            this.panelDebugTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelDebugTop.Location = new System.Drawing.Point(0, 0);
            this.panelDebugTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelDebugTop.Name = "panelDebugTop";
            this.panelDebugTop.Size = new System.Drawing.Size(1395, 58);
            this.panelDebugTop.TabIndex = 1;
            // 
            // chkOnlyCurrent
            // 
            this.chkOnlyCurrent.AutoSize = true;
            this.chkOnlyCurrent.Location = new System.Drawing.Point(1069, 25);
            this.chkOnlyCurrent.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkOnlyCurrent.Name = "chkOnlyCurrent";
            this.chkOnlyCurrent.Size = new System.Drawing.Size(273, 21);
            this.chkOnlyCurrent.TabIndex = 43;
            this.chkOnlyCurrent.Text = "Show Only Contracts with Current Data";
            this.chkOnlyCurrent.UseVisualStyleBackColor = true;
            this.chkOnlyCurrent.CheckedChanged += new System.EventHandler(this.chkOnlyCurrent_CheckedChanged);
            // 
            // chkShowLocations
            // 
            this.chkShowLocations.AutoSize = true;
            this.chkShowLocations.Location = new System.Drawing.Point(933, 2);
            this.chkShowLocations.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkShowLocations.Name = "chkShowLocations";
            this.chkShowLocations.Size = new System.Drawing.Size(126, 21);
            this.chkShowLocations.TabIndex = 42;
            this.chkShowLocations.Text = "Show Locations";
            this.chkShowLocations.UseVisualStyleBackColor = true;
            this.chkShowLocations.CheckedChanged += new System.EventHandler(this.chkShowLocations_CheckedChanged);
            // 
            // chkExpand
            // 
            this.chkExpand.AutoSize = true;
            this.chkExpand.Location = new System.Drawing.Point(933, 23);
            this.chkExpand.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkExpand.Name = "chkExpand";
            this.chkExpand.Size = new System.Drawing.Size(139, 21);
            this.chkExpand.TabIndex = 41;
            this.chkExpand.Text = "Expand Locations";
            this.chkExpand.UseVisualStyleBackColor = true;
            this.chkExpand.CheckedChanged += new System.EventHandler(this.chkExpand_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(1069, 4);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(243, 21);
            this.checkBox1.TabIndex = 40;
            this.checkBox1.Text = "Show Only Contracts With Balance";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // chk2002
            // 
            this.chk2002.AutoSize = true;
            this.chk2002.Checked = true;
            this.chk2002.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk2002.Location = new System.Drawing.Point(754, 21);
            this.chk2002.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chk2002.Name = "chk2002";
            this.chk2002.Size = new System.Drawing.Size(188, 21);
            this.chk2002.TabIndex = 37;
            this.chk2002.Text = "Run Contracts After 2002";
            this.chk2002.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(553, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 17);
            this.label7.TabIndex = 36;
            this.label7.Text = "label7";
            // 
            // progressBar1
            // 
            this.progressBar1.BackColor = System.Drawing.Color.Lime;
            this.progressBar1.Location = new System.Drawing.Point(121, 23);
            this.progressBar1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(425, 12);
            this.progressBar1.TabIndex = 35;
            // 
            // btnRunDiff
            // 
            this.btnRunDiff.BackColor = System.Drawing.Color.SeaShell;
            this.btnRunDiff.Font = new System.Drawing.Font("Tahoma", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btnRunDiff.Location = new System.Drawing.Point(9, 15);
            this.btnRunDiff.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRunDiff.Name = "btnRunDiff";
            this.btnRunDiff.Size = new System.Drawing.Size(87, 34);
            this.btnRunDiff.TabIndex = 34;
            this.btnRunDiff.Text = "Run";
            this.btnRunDiff.UseVisualStyleBackColor = false;
            this.btnRunDiff.Click += new System.EventHandler(this.btnRunDiff_Click);
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.PeachPuff;
            this.panelTop.Controls.Add(this.label10);
            this.panelTop.Controls.Add(this.cmbRunOn);
            this.panelTop.Controls.Add(this.btnCombine);
            this.panelTop.Controls.Add(this.barImport);
            this.panelTop.Controls.Add(this.chkACH);
            this.panelTop.Controls.Add(this.chkMainDoSplits);
            this.panelTop.Controls.Add(this.cmbSelectColumns);
            this.panelTop.Controls.Add(this.btnSelectColumns);
            this.panelTop.Controls.Add(this.chkDBR);
            this.panelTop.Controls.Add(this.chkFilterNewContracts);
            this.panelTop.Controls.Add(this.btnExcel);
            this.panelTop.Controls.Add(this.groupBox1);
            this.panelTop.Controls.Add(this.chkComboAgentNames);
            this.panelTop.Controls.Add(this.chkComboLocNames);
            this.panelTop.Controls.Add(this.label6);
            this.panelTop.Controls.Add(this.chkComboTrust);
            this.panelTop.Controls.Add(this.label5);
            this.panelTop.Controls.Add(this.chkComboLocation);
            this.panelTop.Controls.Add(this.btnRight);
            this.panelTop.Controls.Add(this.lblAgent);
            this.panelTop.Controls.Add(this.chkComboAgent);
            this.panelTop.Controls.Add(this.btnLeft);
            this.panelTop.Controls.Add(this.btnCalc);
            this.panelTop.Controls.Add(this.pictureBox1);
            this.panelTop.Controls.Add(this.dateTimePicker3);
            this.panelTop.Controls.Add(this.label3);
            this.panelTop.Controls.Add(this.dateTimePicker4);
            this.panelTop.Controls.Add(this.label4);
            this.panelTop.Controls.Add(this.btnRun);
            this.panelTop.Controls.Add(this.dateTimePicker2);
            this.panelTop.Controls.Add(this.label2);
            this.panelTop.Controls.Add(this.dateTimePicker1);
            this.panelTop.Controls.Add(this.label1);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1403, 123);
            this.panelTop.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1080, 27);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 17);
            this.label10.TabIndex = 142;
            this.label10.Text = "Run On :";
            // 
            // cmbRunOn
            // 
            this.cmbRunOn.FormattingEnabled = true;
            this.cmbRunOn.Items.AddRange(new object[] {
            "Trusts",
            "NNM",
            "HC"});
            this.cmbRunOn.Location = new System.Drawing.Point(1147, 25);
            this.cmbRunOn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbRunOn.Name = "cmbRunOn";
            this.cmbRunOn.Size = new System.Drawing.Size(70, 24);
            this.cmbRunOn.TabIndex = 141;
            this.cmbRunOn.Text = "Trusts";
            // 
            // btnCombine
            // 
            this.btnCombine.Appearance.BackColor = System.Drawing.Color.PeachPuff;
            this.btnCombine.Appearance.BackColor2 = System.Drawing.Color.PeachPuff;
            this.btnCombine.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCombine.Appearance.ForeColor = System.Drawing.Color.Red;
            this.btnCombine.Appearance.Options.UseBackColor = true;
            this.btnCombine.Appearance.Options.UseFont = true;
            this.btnCombine.Appearance.Options.UseForeColor = true;
            this.btnCombine.Location = new System.Drawing.Point(1235, 89);
            this.btnCombine.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCombine.Name = "btnCombine";
            this.btnCombine.Size = new System.Drawing.Size(26, 27);
            this.btnCombine.TabIndex = 140;
            this.btnCombine.Text = "+";
            this.btnCombine.Click += new System.EventHandler(this.btnCombine_Click);
            // 
            // barImport
            // 
            this.barImport.BackColor = System.Drawing.Color.Lime;
            this.barImport.Location = new System.Drawing.Point(469, 105);
            this.barImport.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.barImport.Name = "barImport";
            this.barImport.Size = new System.Drawing.Size(299, 15);
            this.barImport.TabIndex = 138;
            // 
            // chkACH
            // 
            this.chkACH.AutoSize = true;
            this.chkACH.Location = new System.Drawing.Point(770, 79);
            this.chkACH.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkACH.Name = "chkACH";
            this.chkACH.Size = new System.Drawing.Size(184, 21);
            this.chkACH.TabIndex = 137;
            this.chkACH.Text = "Move ACH to 2nd Search";
            this.chkACH.UseVisualStyleBackColor = true;
            // 
            // chkMainDoSplits
            // 
            this.chkMainDoSplits.AutoSize = true;
            this.chkMainDoSplits.Checked = true;
            this.chkMainDoSplits.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkMainDoSplits.Location = new System.Drawing.Point(1078, 80);
            this.chkMainDoSplits.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkMainDoSplits.Name = "chkMainDoSplits";
            this.chkMainDoSplits.Size = new System.Drawing.Size(83, 21);
            this.chkMainDoSplits.TabIndex = 88;
            this.chkMainDoSplits.Text = "Do Splits";
            this.chkMainDoSplits.UseVisualStyleBackColor = true;
            this.chkMainDoSplits.CheckedChanged += new System.EventHandler(this.chkMainDoSplits_CheckedChanged);
            // 
            // cmbSelectColumns
            // 
            this.cmbSelectColumns.FormattingEnabled = true;
            this.cmbSelectColumns.Location = new System.Drawing.Point(469, 75);
            this.cmbSelectColumns.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cmbSelectColumns.Name = "cmbSelectColumns";
            this.cmbSelectColumns.Size = new System.Drawing.Size(179, 24);
            this.cmbSelectColumns.TabIndex = 86;
            this.cmbSelectColumns.SelectedIndexChanged += new System.EventHandler(this.cmbSelectColumns_SelectedIndexChanged);
            // 
            // btnSelectColumns
            // 
            this.btnSelectColumns.BackColor = System.Drawing.Color.SandyBrown;
            this.btnSelectColumns.Location = new System.Drawing.Point(654, 74);
            this.btnSelectColumns.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSelectColumns.Name = "btnSelectColumns";
            this.btnSelectColumns.Size = new System.Drawing.Size(113, 28);
            this.btnSelectColumns.TabIndex = 34;
            this.btnSelectColumns.Text = "Select Columns";
            this.btnSelectColumns.UseVisualStyleBackColor = false;
            this.btnSelectColumns.Click += new System.EventHandler(this.button1_Click);
            // 
            // chkDBR
            // 
            this.chkDBR.AutoSize = true;
            this.chkDBR.Location = new System.Drawing.Point(274, 95);
            this.chkDBR.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkDBR.Name = "chkDBR";
            this.chkDBR.Size = new System.Drawing.Size(136, 21);
            this.chkDBR.TabIndex = 33;
            this.chkDBR.Text = "Show Only DBR\'s";
            this.chkDBR.UseVisualStyleBackColor = true;
            this.chkDBR.CheckedChanged += new System.EventHandler(this.chkDBR_CheckedChanged);
            // 
            // chkFilterNewContracts
            // 
            this.chkFilterNewContracts.AutoSize = true;
            this.chkFilterNewContracts.Location = new System.Drawing.Point(274, 74);
            this.chkFilterNewContracts.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkFilterNewContracts.Name = "chkFilterNewContracts";
            this.chkFilterNewContracts.Size = new System.Drawing.Size(190, 21);
            this.chkFilterNewContracts.TabIndex = 32;
            this.chkFilterNewContracts.Text = "Show Only New Contracts";
            this.chkFilterNewContracts.UseVisualStyleBackColor = true;
            this.chkFilterNewContracts.CheckedChanged += new System.EventHandler(this.chkFilterNewContracts_CheckedChanged);
            // 
            // btnExcel
            // 
            this.btnExcel.AccessibleDescription = "";
            this.btnExcel.BackColor = System.Drawing.Color.SandyBrown;
            this.btnExcel.Font = new System.Drawing.Font("Tahoma", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btnExcel.Location = new System.Drawing.Point(1528, 55);
            this.btnExcel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(49, 38);
            this.btnExcel.TabIndex = 31;
            this.btnExcel.Text = "Generate Excel File";
            this.btnExcel.UseVisualStyleBackColor = false;
            this.btnExcel.Visible = false;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioXLSX);
            this.groupBox1.Controls.Add(this.radioXLS);
            this.groupBox1.Controls.Add(this.chkPresent);
            this.groupBox1.Location = new System.Drawing.Point(1379, 10);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(233, 47);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Export File Type";
            this.groupBox1.Visible = false;
            // 
            // radioXLSX
            // 
            this.radioXLSX.AutoSize = true;
            this.radioXLSX.Checked = true;
            this.radioXLSX.Location = new System.Drawing.Point(61, 20);
            this.radioXLSX.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioXLSX.Name = "radioXLSX";
            this.radioXLSX.Size = new System.Drawing.Size(57, 21);
            this.radioXLSX.TabIndex = 1;
            this.radioXLSX.TabStop = true;
            this.radioXLSX.Text = ".xlsx";
            this.radioXLSX.UseVisualStyleBackColor = true;
            // 
            // radioXLS
            // 
            this.radioXLS.AutoSize = true;
            this.radioXLS.Location = new System.Drawing.Point(7, 20);
            this.radioXLS.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioXLS.Name = "radioXLS";
            this.radioXLS.Size = new System.Drawing.Size(49, 21);
            this.radioXLS.TabIndex = 0;
            this.radioXLS.Text = ".xls";
            this.radioXLS.UseVisualStyleBackColor = true;
            // 
            // chkPresent
            // 
            this.chkPresent.AutoSize = true;
            this.chkPresent.Checked = true;
            this.chkPresent.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkPresent.Location = new System.Drawing.Point(124, 5);
            this.chkPresent.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkPresent.Name = "chkPresent";
            this.chkPresent.Size = new System.Drawing.Size(127, 21);
            this.chkPresent.TabIndex = 30;
            this.chkPresent.Text = "View Output File";
            this.chkPresent.UseVisualStyleBackColor = true;
            this.chkPresent.Visible = false;
            // 
            // chkComboAgentNames
            // 
            this.chkComboAgentNames.EditValue = "";
            this.chkComboAgentNames.Location = new System.Drawing.Point(139, 41);
            this.chkComboAgentNames.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkComboAgentNames.Name = "chkComboAgentNames";
            this.chkComboAgentNames.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.chkComboAgentNames.Properties.DisplayMember = "agentNames";
            this.chkComboAgentNames.Properties.SeparatorChar = '|';
            this.chkComboAgentNames.Size = new System.Drawing.Size(127, 22);
            this.chkComboAgentNames.TabIndex = 28;
            this.chkComboAgentNames.EditValueChanged += new System.EventHandler(this.chkComboAgentNames_EditValueChanged);
            // 
            // chkComboLocNames
            // 
            this.chkComboLocNames.EditValue = "";
            this.chkComboLocNames.Location = new System.Drawing.Point(139, 73);
            this.chkComboLocNames.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkComboLocNames.Name = "chkComboLocNames";
            this.chkComboLocNames.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.chkComboLocNames.Properties.DisplayMember = "name";
            this.chkComboLocNames.Properties.SeparatorChar = '|';
            this.chkComboLocNames.Size = new System.Drawing.Size(127, 22);
            this.chkComboLocNames.TabIndex = 27;
            this.chkComboLocNames.EditValueChanged += new System.EventHandler(this.chkComboLocNames_EditValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(43, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 17);
            this.label6.TabIndex = 26;
            this.label6.Text = "Trusts :";
            // 
            // chkComboTrust
            // 
            this.chkComboTrust.EditValue = "";
            this.chkComboTrust.Location = new System.Drawing.Point(97, 10);
            this.chkComboTrust.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkComboTrust.Name = "chkComboTrust";
            this.chkComboTrust.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.chkComboTrust.Properties.DisplayMember = "trusts";
            this.chkComboTrust.Properties.SeparatorChar = '|';
            this.chkComboTrust.Size = new System.Drawing.Size(54, 22);
            this.chkComboTrust.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(2, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 17);
            this.label5.TabIndex = 24;
            this.label5.Text = "Locations :";
            // 
            // chkComboLocation
            // 
            this.chkComboLocation.EditValue = "";
            this.chkComboLocation.Location = new System.Drawing.Point(78, 73);
            this.chkComboLocation.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkComboLocation.Name = "chkComboLocation";
            this.chkComboLocation.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.chkComboLocation.Properties.DisplayMember = "keycode";
            this.chkComboLocation.Properties.SeparatorChar = '|';
            this.chkComboLocation.Size = new System.Drawing.Size(54, 22);
            this.chkComboLocation.TabIndex = 23;
            this.chkComboLocation.EditValueChanged += new System.EventHandler(this.chkComboLocation_EditValueChanged);
            // 
            // btnRight
            // 
            this.btnRight.BackColor = System.Drawing.Color.PeachPuff;
            this.btnRight.Image = ((System.Drawing.Image)(resources.GetObject("btnRight.Image")));
            this.btnRight.Location = new System.Drawing.Point(890, 6);
            this.btnRight.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(33, 28);
            this.btnRight.TabIndex = 21;
            this.btnRight.UseVisualStyleBackColor = false;
            this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
            // 
            // lblAgent
            // 
            this.lblAgent.AutoSize = true;
            this.lblAgent.Location = new System.Drawing.Point(27, 46);
            this.lblAgent.Name = "lblAgent";
            this.lblAgent.Size = new System.Drawing.Size(53, 17);
            this.lblAgent.TabIndex = 20;
            this.lblAgent.Text = "Agent :";
            // 
            // chkComboAgent
            // 
            this.chkComboAgent.EditValue = "";
            this.chkComboAgent.Location = new System.Drawing.Point(78, 41);
            this.chkComboAgent.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkComboAgent.Name = "chkComboAgent";
            this.chkComboAgent.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.chkComboAgent.Properties.DisplayMember = "agentCode";
            this.chkComboAgent.Properties.SeparatorChar = '|';
            this.chkComboAgent.Size = new System.Drawing.Size(54, 22);
            this.chkComboAgent.TabIndex = 19;
            this.chkComboAgent.EditValueChanged += new System.EventHandler(this.chkComboAgent_EditValueChanged);
            // 
            // btnLeft
            // 
            this.btnLeft.BackColor = System.Drawing.Color.PeachPuff;
            this.btnLeft.Image = ((System.Drawing.Image)(resources.GetObject("btnLeft.Image")));
            this.btnLeft.Location = new System.Drawing.Point(341, 6);
            this.btnLeft.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(33, 28);
            this.btnLeft.TabIndex = 17;
            this.btnLeft.UseVisualStyleBackColor = false;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // btnCalc
            // 
            this.btnCalc.BackColor = System.Drawing.Color.SandyBrown;
            this.btnCalc.Font = new System.Drawing.Font("Tahoma", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btnCalc.Location = new System.Drawing.Point(945, 64);
            this.btnCalc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(126, 52);
            this.btnCalc.TabIndex = 15;
            this.btnCalc.Text = "Calculate Commission";
            this.btnCalc.UseVisualStyleBackColor = false;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 27);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Location = new System.Drawing.Point(376, 42);
            this.dateTimePicker3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker3.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(616, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "-To-";
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Location = new System.Drawing.Point(654, 41);
            this.dateTimePicker4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker4.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(308, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "All Other :";
            // 
            // btnRun
            // 
            this.btnRun.BackColor = System.Drawing.Color.SandyBrown;
            this.btnRun.Font = new System.Drawing.Font("Tahoma", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.btnRun.Location = new System.Drawing.Point(945, 6);
            this.btnRun.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(126, 54);
            this.btnRun.TabIndex = 5;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = false;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(654, 7);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker2.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(616, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "-To-";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(376, 7);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker1.TabIndex = 1;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(272, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "All Boxes :";
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Bisque;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.columnsToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1403, 30);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 26);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printPreviewToolStripMenuItem,
            this.printToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(122, 26);
            this.toolStripMenuItem1.Text = "Print";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printPreviewToolStripMenuItem.Text = "Print Preview";
            this.printPreviewToolStripMenuItem.Click += new System.EventHandler(this.printPreviewToolStripMenuItem_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // columnsToolStripMenuItem
            // 
            this.columnsToolStripMenuItem.Name = "columnsToolStripMenuItem";
            this.columnsToolStripMenuItem.Size = new System.Drawing.Size(80, 26);
            this.columnsToolStripMenuItem.Text = "Columns";
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.trustReportsToolStripMenuItem,
            this.historicCommissionsToolStripMenuItem,
            this.agentsPieChartToolStripMenuItem});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(74, 26);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // trustReportsToolStripMenuItem
            // 
            this.trustReportsToolStripMenuItem.Enabled = false;
            this.trustReportsToolStripMenuItem.Name = "trustReportsToolStripMenuItem";
            this.trustReportsToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.trustReportsToolStripMenuItem.Text = "Trust Reports";
            this.trustReportsToolStripMenuItem.Click += new System.EventHandler(this.trustReportsToolStripMenuItem_Click);
            // 
            // historicCommissionsToolStripMenuItem
            // 
            this.historicCommissionsToolStripMenuItem.Name = "historicCommissionsToolStripMenuItem";
            this.historicCommissionsToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.historicCommissionsToolStripMenuItem.Text = "Historic Commissions";
            this.historicCommissionsToolStripMenuItem.Click += new System.EventHandler(this.historicCommissionsToolStripMenuItem_Click);
            // 
            // agentsPieChartToolStripMenuItem
            // 
            this.agentsPieChartToolStripMenuItem.Name = "agentsPieChartToolStripMenuItem";
            this.agentsPieChartToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.agentsPieChartToolStripMenuItem.Text = "Agents Pie Chart";
            this.agentsPieChartToolStripMenuItem.Click += new System.EventHandler(this.agentsPieChartToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(55, 26);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // Trust85
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1403, 562);
            this.Controls.Add(this.panelAll);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Trust85";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trust85 Report";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Trust85_FormClosing);
            this.Load += new System.EventHandler(this.Trust85_Load);
            this.panelAll.ResumeLayout(false);
            this.panelBottom.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).EndInit();
            this.tabLocations.ResumeLayout(false);
            this.panelBAll.ResumeLayout(false);
            this.panelBBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).EndInit();
            this.panelBTop.ResumeLayout(false);
            this.panelBTop.PerformLayout();
            this.tabAgentLocations.ResumeLayout(false);
            this.panelLAAll.ResumeLayout(false);
            this.panelLABottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain4)).EndInit();
            this.panelLATop.ResumeLayout(false);
            this.panelLATop.PerformLayout();
            this.tabAgentTotals.ResumeLayout(false);
            this.panel3All.ResumeLayout(false);
            this.panel3Bottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).EndInit();
            this.panel3Top.ResumeLayout(false);
            this.panel3Top.PerformLayout();
            this.tabLocationTotals.ResumeLayout(false);
            this.panel5All.ResumeLayout(false);
            this.panel5Bottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain5)).EndInit();
            this.panel5Top.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cmbLocationTotals.Properties)).EndInit();
            this.tabContractLocations.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain7)).EndInit();
            this.tabLapse.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain8)).EndInit();
            this.tabReinstate.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain9)).EndInit();
            this.tabCombined.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain12)).EndInit();
            this.tabCommission.ResumeLayout(false);
            this.panelCommAll.ResumeLayout(false);
            this.panelCommBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain10)).EndInit();
            this.panelCommTop.ResumeLayout(false);
            this.panelCommTop.PerformLayout();
            this.tabDebugTrusts.ResumeLayout(false);
            this.panelDebugAll.ResumeLayout(false);
            this.panelDebugBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv11)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridMain11)).EndInit();
            this.panelDebugTop.ResumeLayout(false);
            this.panelDebugTop.PerformLayout();
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboAgentNames.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboLocNames.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboTrust.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboLocation.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkComboAgent.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelAll;
        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.Panel panelTop;
        private DevExpress.XtraGrid.GridControl dgv;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn Num;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn cnum;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn7;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn9;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn8;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn2;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn6;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Button btnLeft;
        private System.Windows.Forms.Label lblAgent;
        private DevExpress.XtraEditors.CheckedComboBoxEdit chkComboAgent;
        private System.Windows.Forms.Button btnRight;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn11;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn12;
        private System.Windows.Forms.Label label6;
        private DevExpress.XtraEditors.CheckedComboBoxEdit chkComboTrust;
        private System.Windows.Forms.Label label5;
        private DevExpress.XtraEditors.CheckedComboBoxEdit chkComboLocation;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn14;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn13;
        private System.Windows.Forms.ToolStripMenuItem columnsToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn15;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn16;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn17;
        private DevExpress.XtraEditors.CheckedComboBoxEdit chkComboAgentNames;
        private DevExpress.XtraEditors.CheckedComboBoxEdit chkComboLocNames;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabLocations;
        private DevExpress.XtraGrid.GridControl dgv2;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn18;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn19;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn20;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn21;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn22;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn contractValue29;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn downPayment30;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn paymentAmount31;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn totalPayments32;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn36;
        private System.Windows.Forms.TabPage tabAgentTotals;
        private DevExpress.XtraGrid.GridControl dgv3;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn23;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn24;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn25;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn26;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn27;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn contractValue28;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn downPayment33;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn paymentAmount34;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn totalPayments35;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn37;
        private System.Windows.Forms.TabPage tabAgentLocations;
        private DevExpress.XtraGrid.GridControl dgv4;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn38;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn39;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn40;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn41;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn42;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn43;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn44;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn45;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn46;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn47;
        private System.Windows.Forms.TabPage tabLocationTotals;
        private DevExpress.XtraGrid.GridControl dgv5;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn48;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn49;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn50;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn51;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn52;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn53;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn54;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn55;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn56;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn57;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn recapAmount58;
        private System.Windows.Forms.CheckBox chkPresent;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioXLSX;
        private System.Windows.Forms.RadioButton radioXLS;
        private System.Windows.Forms.Button btnExcel;
        private DevExpress.XtraReports.ReportGeneration.ReportGenerator reportGenerator1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn74;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn75;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn85;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn86;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn ibTrust87;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn spTrust88;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn total89;
        private System.Windows.Forms.Panel panel3All;
        private System.Windows.Forms.Panel panel3Bottom;
        private System.Windows.Forms.Panel panel3Top;
        private System.Windows.Forms.CheckBox chkMonthly;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn90;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn92;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn91;
        private System.Windows.Forms.TabPage tabContractLocations;
        private DevExpress.XtraGrid.GridControl dgv7;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain7;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn93;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn94;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn95;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn96;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn97;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn contractValue98;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn downPayment99;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn paymentAmount100;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn totalPayments100;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn ibtrust102;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn sptrust103;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn total104;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn105;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn102;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn103;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn98;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn99;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn100;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn101;
        private System.Windows.Forms.CheckBox chkFilterNewContracts;
        private System.Windows.Forms.CheckBox chkDBR;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn104;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem excludeDBRFromTrustsToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn xxTrust106;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn109;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand7;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn xxtrust104;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn107;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn108;
        private System.Windows.Forms.CheckBox chkNoSummary;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn110;
        private System.Windows.Forms.TabPage tabLapse;
        private DevExpress.XtraGrid.GridControl dgv8;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn111;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn112;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn113;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn114;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn115;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn116;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn117;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn118;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn119;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn120;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn121;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn122;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn123;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn124;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn125;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn126;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn127;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn128;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn129;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn130;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn131;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn132;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn133;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn134;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn135;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn136;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn137;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn138;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn139;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn140;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn141;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn142;
        private System.Windows.Forms.TabPage tabReinstate;
        private DevExpress.XtraGrid.GridControl dgv9;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain9;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn143;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn144;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn145;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn146;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn147;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn148;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn149;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn150;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn151;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn152;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn153;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn154;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn155;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn156;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn157;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn158;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn159;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn160;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn161;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn162;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn163;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn164;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn165;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn166;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn167;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn168;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn169;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn170;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn171;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn172;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn173;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn174;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn175;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn176;
        private System.Windows.Forms.ToolStripMenuItem trustReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historicCommissionsToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn59;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn60;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn63;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn64;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn62;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn61;
        private System.Windows.Forms.Button btnSelectColumns;
        private System.Windows.Forms.ComboBox cmbSelectColumns;
        private System.Windows.Forms.TabPage tabCommission;
        private System.Windows.Forms.Panel panelCommAll;
        private System.Windows.Forms.Panel panelCommBottom;
        private System.Windows.Forms.Panel panelCommTop;
        private System.Windows.Forms.CheckBox chkConsolidate;
        private System.Windows.Forms.CheckBox chkDoSplits;
        private System.Windows.Forms.Button btnRunCommissions;
        private System.Windows.Forms.Button btnSaveCommissions;
        private DevExpress.XtraGrid.GridControl dgv10;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn65;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn66;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn67;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn68;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn69;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn70;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn71;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn72;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn73;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn76;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn77;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn78;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn79;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn80;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn81;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn82;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn83;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn84;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn177;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn178;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn179;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn180;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn181;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn182;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn183;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn184;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn interestPaid;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn t_lapseContract;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn t_reinstateContract;
        private System.Windows.Forms.CheckBox chkSummarize;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn cashAdvance185;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn186;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn187;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn188;
        private System.Windows.Forms.ComboBox cmbSelectCommission;
        private System.Windows.Forms.Button btnSelectCommission;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn189;
        private System.Windows.Forms.TabPage tabDebugTrusts;
        private System.Windows.Forms.Panel panelDebugAll;
        private System.Windows.Forms.Panel panelDebugBottom;
        private System.Windows.Forms.Panel panelDebugTop;
        private DevExpress.XtraGrid.GridControl dgv11;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain11;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn190;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn191;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn192;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn193;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn194;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn195;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn196;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn197;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn198;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn199;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn200;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn201;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn202;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn203;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn204;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn205;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn206;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn207;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn208;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn209;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn210;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn211;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn212;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn213;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn214;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn calcTrust85_215;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn difference_216;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn217;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn218;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Button btnRunDiff;
        private System.Windows.Forms.CheckBox chk2002;
        private System.Windows.Forms.CheckBox chkShowLocations;
        private System.Windows.Forms.CheckBox chkExpand;
        private System.Windows.Forms.CheckBox checkBox1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn215;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn216;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn219;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn220;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand11;
        private System.Windows.Forms.CheckBox chkOnlyCurrent;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem recalcTrust85ToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn221;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn222;
        private System.Windows.Forms.CheckBox chkMainDoSplits;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn223;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn224;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand9;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn225;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn226;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn227;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn228;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn229;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn230;
        private System.Windows.Forms.CheckBox chkShowCommissions;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn commission231;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn231;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn232;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn debit233;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn credit234;
        private System.Windows.Forms.CheckBox chkCollapes;
        private System.Windows.Forms.Button btnPrintAll;
        private System.Windows.Forms.Button btnMatch;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn dbc28;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn28;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn33;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn34;
        private System.Windows.Forms.CheckBox chkACH;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn35;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn SplitPayment58;
        private System.Windows.Forms.CheckBox chkToggleGroups;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn SplitDownPayment58;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn interestPaid58;
        private System.Windows.Forms.Panel panel5All;
        private System.Windows.Forms.Panel panel5Bottom;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn58;
        private System.Windows.Forms.Panel panel5Top;
        private DevExpress.XtraEditors.CheckedComboBoxEdit cmbLocationTotals;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbShow;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn233;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn fbi234;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn fbiCommission235;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn234;
        private System.Windows.Forms.ProgressBar barImport;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn235;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand6;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn236;
        private System.Windows.Forms.TabPage tabCombined;
        private DevExpress.XtraGrid.GridControl dgv12;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain12;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand12;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn237;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn238;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn239;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn240;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn241;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn242;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn243;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn244;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn245;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn246;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn247;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn248;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn249;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn250;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn251;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn252;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn253;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn254;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn255;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn256;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn257;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn258;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn259;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn260;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn261;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn262;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn263;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn264;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn265;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn266;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn267;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn268;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn269;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn270;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn271;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn272;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn273;
        private System.Windows.Forms.ToolStripMenuItem agentsPieChartToolStripMenuItem;
        private System.Windows.Forms.Button btnChart;
        private DevExpress.XtraEditors.SimpleButton btnCombine;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn274;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn CashAdvance275;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn dpr276;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn dbc_5_277;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand1;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn ibtrust275;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn sptrust276;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn xxtrust277;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn totalTrusts278;
        private System.Windows.Forms.Panel panelLAAll;
        private System.Windows.Forms.Panel panelLABottom;
        private System.Windows.Forms.Panel panelLATop;
        private System.Windows.Forms.CheckBox chkLocationTotal;
        private System.Windows.Forms.Panel panelBAll;
        private System.Windows.Forms.Panel panelBBottom;
        private System.Windows.Forms.Panel panelBTop;
        private System.Windows.Forms.CheckBox chkAgentByLocationTotalLocations;
        private System.Windows.Forms.CheckBox chkShowOnlyContractValues;
        private System.Windows.Forms.CheckBox chkReverseAgentsAndLocations;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn29;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn30;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbStatus;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn31;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn32;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn87;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn88;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn89;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn185;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn106;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn275;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn277;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn276;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn278;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbRunOn;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn279;
    }
}