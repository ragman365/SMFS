﻿namespace SMFS
{
    partial class CCImport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CCImport));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelAll = new System.Windows.Forms.Panel();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panelTab1All = new System.Windows.Forms.Panel();
            this.panelTab1Bottom = new System.Windows.Forms.Panel();
            this.dgv = new DevExpress.XtraGrid.GridControl();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.duplicatePaymentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editInvoiceNumberToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.gridMain = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand5 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn1 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn69 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn27 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn2 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn3 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn4 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn5 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn6 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn8 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn9 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn10 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn11 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn12 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn13 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn42 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn7 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelTab1Top = new System.Windows.Forms.Panel();
            this.btnSaveNotPosted = new System.Windows.Forms.Button();
            this.btnPullFile = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panelTab2All = new System.Windows.Forms.Panel();
            this.panelTab2Bottom = new System.Windows.Forms.Panel();
            this.dgv2 = new DevExpress.XtraGrid.GridControl();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.duplicatePaymentToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.editInvoiceNumberToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gridMain2 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand1 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn14 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn43 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.bandedGridColumn68 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn46 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn15 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn16 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn17 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn18 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn19 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn48 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn20 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn67 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn21 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn22 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn23 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn24 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox5 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn25 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn45 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn50 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn26 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelTab2Top = new System.Windows.Forms.Panel();
            this.btnSaveChangedData = new System.Windows.Forms.Button();
            this.btnPost = new System.Windows.Forms.Button();
            this.btnPullNotPosted = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lblEffectiveDate = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panelTab3All = new System.Windows.Forms.Panel();
            this.panelTab3Bottom = new System.Windows.Forms.Panel();
            this.dgv3 = new DevExpress.XtraGrid.GridControl();
            this.gridMain3 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand2 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn28 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn44 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn70 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn29 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn30 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn31 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn32 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn33 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn34 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn49 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn35 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn88 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn36 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn37 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn38 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn39 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox2 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn40 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn47 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn51 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn41 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelTab3Top = new System.Windows.Forms.Panel();
            this.chkHonorDates = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnPullPostedData = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panelTab4All = new System.Windows.Forms.Panel();
            this.panelTab4Bottom = new System.Windows.Forms.Panel();
            this.dgv4 = new DevExpress.XtraGrid.GridControl();
            this.gridMain4 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand3 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn52 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn71 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn53 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn54 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn55 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn56 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn57 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn58 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn59 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn60 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn61 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn62 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn63 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox3 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn64 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn65 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn66 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelTab4Top = new System.Windows.Forms.Panel();
            this.chkHonorDates3 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
            this.btnPullDeclined = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panelTab5All = new System.Windows.Forms.Panel();
            this.panelTab5Bottom = new System.Windows.Forms.Panel();
            this.dgv5 = new DevExpress.XtraGrid.GridControl();
            this.gridMain5 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand4 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn72 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn73 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn74 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn75 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn76 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn77 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn78 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn79 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn80 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn81 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn82 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn83 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn84 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox4 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn85 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn86 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn87 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelTab5Top = new System.Windows.Forms.Panel();
            this.chkHonorDates4 = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePicker6 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker7 = new System.Windows.Forms.DateTimePicker();
            this.btnPullVoids = new System.Windows.Forms.Button();
            this.panelTop = new System.Windows.Forms.Panel();
            this.picAdd = new System.Windows.Forms.PictureBox();
            this.pictureDelete = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.unPostToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.panelAll.SuspendLayout();
            this.panelBottom.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panelTab1All.SuspendLayout();
            this.panelTab1Bottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            this.panelTab1Top.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panelTab2All.SuspendLayout();
            this.panelTab2Bottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox5)).BeginInit();
            this.panelTab2Top.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panelTab3All.SuspendLayout();
            this.panelTab3Bottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).BeginInit();
            this.panelTab3Top.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panelTab4All.SuspendLayout();
            this.panelTab4Bottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox3)).BeginInit();
            this.panelTab4Top.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.panelTab5All.SuspendLayout();
            this.panelTab5Bottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox4)).BeginInit();
            this.panelTab5Top.SuspendLayout();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAdd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.contextMenuStrip3.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1712, 30);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 26);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printPreviewToolStripMenuItem,
            this.printToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(122, 26);
            this.toolStripMenuItem1.Text = "Print";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printPreviewToolStripMenuItem.Text = "Print Preview";
            this.printPreviewToolStripMenuItem.Click += new System.EventHandler(this.printPreviewToolStripMenuItem_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // panelAll
            // 
            this.panelAll.Controls.Add(this.panelBottom);
            this.panelAll.Controls.Add(this.panelTop);
            this.panelAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAll.Location = new System.Drawing.Point(0, 30);
            this.panelAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelAll.Name = "panelAll";
            this.panelAll.Size = new System.Drawing.Size(1712, 539);
            this.panelAll.TabIndex = 6;
            // 
            // panelBottom
            // 
            this.panelBottom.Controls.Add(this.tabControl1);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBottom.Location = new System.Drawing.Point(0, 49);
            this.panelBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(1712, 490);
            this.panelBottom.TabIndex = 8;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1712, 490);
            this.tabControl1.TabIndex = 5;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panelTab1All);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(1704, 461);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Import";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panelTab1All
            // 
            this.panelTab1All.Controls.Add(this.panelTab1Bottom);
            this.panelTab1All.Controls.Add(this.panelTab1Top);
            this.panelTab1All.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTab1All.Location = new System.Drawing.Point(3, 4);
            this.panelTab1All.Name = "panelTab1All";
            this.panelTab1All.Size = new System.Drawing.Size(1698, 453);
            this.panelTab1All.TabIndex = 5;
            // 
            // panelTab1Bottom
            // 
            this.panelTab1Bottom.Controls.Add(this.dgv);
            this.panelTab1Bottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTab1Bottom.Location = new System.Drawing.Point(0, 43);
            this.panelTab1Bottom.Name = "panelTab1Bottom";
            this.panelTab1Bottom.Size = new System.Drawing.Size(1698, 410);
            this.panelTab1Bottom.TabIndex = 7;
            // 
            // dgv
            // 
            this.dgv.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv.Location = new System.Drawing.Point(0, 0);
            this.dgv.MainView = this.gridMain;
            this.dgv.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv.Name = "dgv";
            this.dgv.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox1});
            this.dgv.Size = new System.Drawing.Size(1698, 410);
            this.dgv.TabIndex = 4;
            this.dgv.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain});
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.duplicatePaymentToolStripMenuItem,
            this.editInvoiceNumberToolStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(214, 52);
            // 
            // duplicatePaymentToolStripMenuItem
            // 
            this.duplicatePaymentToolStripMenuItem.Name = "duplicatePaymentToolStripMenuItem";
            this.duplicatePaymentToolStripMenuItem.Size = new System.Drawing.Size(213, 24);
            this.duplicatePaymentToolStripMenuItem.Text = "Duplicate Payment";
            this.duplicatePaymentToolStripMenuItem.Click += new System.EventHandler(this.duplicatePaymentToolStripMenuItem_Click);
            // 
            // editInvoiceNumberToolStripMenuItem1
            // 
            this.editInvoiceNumberToolStripMenuItem1.Name = "editInvoiceNumberToolStripMenuItem1";
            this.editInvoiceNumberToolStripMenuItem1.Size = new System.Drawing.Size(213, 24);
            this.editInvoiceNumberToolStripMenuItem1.Text = "Edit Invoice Number";
            this.editInvoiceNumberToolStripMenuItem1.Click += new System.EventHandler(this.editInvoiceNumberToolStripMenuItem1_Click);
            // 
            // gridMain
            // 
            this.gridMain.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.BandPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.BandPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.ColumnFilterButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(244)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(222)))), ((int)(((byte)(183)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(244)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.ColumnFilterButtonActive.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain.Appearance.Empty.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(158)))), ((int)(((byte)(126)))));
            this.gridMain.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(128)))), ((int)(((byte)(88)))));
            this.gridMain.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.FooterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FooterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain.Appearance.GroupFooter.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseFont = true;
            this.gridMain.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(158)))), ((int)(((byte)(126)))));
            this.gridMain.Appearance.GroupPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain.Appearance.GroupRow.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.HeaderPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.HeaderPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(207)))), ((int)(((byte)(170)))));
            this.gridMain.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(168)))), ((int)(((byte)(128)))));
            this.gridMain.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.gridMain.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.Row.Options.UseBackColor = true;
            this.gridMain.Appearance.Row.Options.UseForeColor = true;
            this.gridMain.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(178)))), ((int)(((byte)(133)))));
            this.gridMain.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(160)))), ((int)(((byte)(188)))));
            this.gridMain.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand5});
            this.gridMain.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn1,
            this.bandedGridColumn7,
            this.bandedGridColumn69,
            this.bandedGridColumn27,
            this.bandedGridColumn2,
            this.bandedGridColumn3,
            this.bandedGridColumn4,
            this.bandedGridColumn5,
            this.bandedGridColumn6,
            this.bandedGridColumn8,
            this.bandedGridColumn9,
            this.bandedGridColumn10,
            this.bandedGridColumn11,
            this.bandedGridColumn12,
            this.bandedGridColumn13,
            this.bandedGridColumn42});
            this.gridMain.DetailHeight = 431;
            this.gridMain.GridControl = this.dgv;
            this.gridMain.Name = "gridMain";
            this.gridMain.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridMain.OptionsPrint.PrintBandHeader = false;
            this.gridMain.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain.OptionsView.ShowFooter = true;
            this.gridMain.OptionsView.ShowGroupPanel = false;
            this.gridMain.PaintStyleName = "Flat";
            this.gridMain.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMain_CustomDrawCell);
            this.gridMain.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.gridMain_CustomSummaryCalculate);
            this.gridMain.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain_CustomColumnDisplayText);
            this.gridMain.DoubleClick += new System.EventHandler(this.gridMain_DoubleClick);
            // 
            // gridBand5
            // 
            this.gridBand5.Columns.Add(this.bandedGridColumn1);
            this.gridBand5.Columns.Add(this.bandedGridColumn69);
            this.gridBand5.Columns.Add(this.bandedGridColumn27);
            this.gridBand5.Columns.Add(this.bandedGridColumn2);
            this.gridBand5.Columns.Add(this.bandedGridColumn3);
            this.gridBand5.Columns.Add(this.bandedGridColumn4);
            this.gridBand5.Columns.Add(this.bandedGridColumn5);
            this.gridBand5.Columns.Add(this.bandedGridColumn6);
            this.gridBand5.Columns.Add(this.bandedGridColumn8);
            this.gridBand5.Columns.Add(this.bandedGridColumn9);
            this.gridBand5.Columns.Add(this.bandedGridColumn10);
            this.gridBand5.Columns.Add(this.bandedGridColumn11);
            this.gridBand5.Columns.Add(this.bandedGridColumn12);
            this.gridBand5.Columns.Add(this.bandedGridColumn13);
            this.gridBand5.Columns.Add(this.bandedGridColumn42);
            this.gridBand5.Columns.Add(this.bandedGridColumn7);
            this.gridBand5.MinWidth = 22;
            this.gridBand5.Name = "gridBand5";
            this.gridBand5.VisibleIndex = 0;
            this.gridBand5.Width = 1378;
            // 
            // bandedGridColumn1
            // 
            this.bandedGridColumn1.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn1.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn1.Caption = "Num";
            this.bandedGridColumn1.FieldName = "num";
            this.bandedGridColumn1.MinWidth = 42;
            this.bandedGridColumn1.Name = "bandedGridColumn1";
            this.bandedGridColumn1.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn1.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn1.Visible = true;
            this.bandedGridColumn1.Width = 62;
            // 
            // bandedGridColumn69
            // 
            this.bandedGridColumn69.Caption = "Transaction Date";
            this.bandedGridColumn69.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn69.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn69.FieldName = "transactionDate";
            this.bandedGridColumn69.MinWidth = 25;
            this.bandedGridColumn69.Name = "bandedGridColumn69";
            this.bandedGridColumn69.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn69.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn69.Visible = true;
            this.bandedGridColumn69.Width = 94;
            // 
            // bandedGridColumn27
            // 
            this.bandedGridColumn27.Caption = "Transaction Type";
            this.bandedGridColumn27.FieldName = "transactionType";
            this.bandedGridColumn27.MinWidth = 34;
            this.bandedGridColumn27.Name = "bandedGridColumn27";
            this.bandedGridColumn27.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn27.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn27.Visible = true;
            this.bandedGridColumn27.Width = 99;
            // 
            // bandedGridColumn2
            // 
            this.bandedGridColumn2.Caption = "Card Number";
            this.bandedGridColumn2.FieldName = "cardNumber";
            this.bandedGridColumn2.MinWidth = 40;
            this.bandedGridColumn2.Name = "bandedGridColumn2";
            this.bandedGridColumn2.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn2.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn2.Visible = true;
            this.bandedGridColumn2.Width = 79;
            // 
            // bandedGridColumn3
            // 
            this.bandedGridColumn3.Caption = "Payment Type";
            this.bandedGridColumn3.FieldName = "paymentType";
            this.bandedGridColumn3.MinWidth = 40;
            this.bandedGridColumn3.Name = "bandedGridColumn3";
            this.bandedGridColumn3.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn3.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn3.Visible = true;
            this.bandedGridColumn3.Width = 131;
            // 
            // bandedGridColumn4
            // 
            this.bandedGridColumn4.Caption = "Authorized Amount";
            this.bandedGridColumn4.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn4.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn4.FieldName = "authorizedAmount";
            this.bandedGridColumn4.MinWidth = 40;
            this.bandedGridColumn4.Name = "bandedGridColumn4";
            this.bandedGridColumn4.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn4.Visible = true;
            this.bandedGridColumn4.Width = 104;
            // 
            // bandedGridColumn5
            // 
            this.bandedGridColumn5.Caption = "Transaction Amount";
            this.bandedGridColumn5.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn5.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn5.FieldName = "transactionAmount";
            this.bandedGridColumn5.MinWidth = 40;
            this.bandedGridColumn5.Name = "bandedGridColumn5";
            this.bandedGridColumn5.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn5.Visible = true;
            this.bandedGridColumn5.Width = 114;
            // 
            // bandedGridColumn6
            // 
            this.bandedGridColumn6.Caption = "Return/Void";
            this.bandedGridColumn6.FieldName = "returnVoid";
            this.bandedGridColumn6.MinWidth = 40;
            this.bandedGridColumn6.Name = "bandedGridColumn6";
            this.bandedGridColumn6.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn6.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn6.Visible = true;
            this.bandedGridColumn6.Width = 106;
            // 
            // bandedGridColumn8
            // 
            this.bandedGridColumn8.Caption = "Amount";
            this.bandedGridColumn8.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn8.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn8.FieldName = "amount";
            this.bandedGridColumn8.MinWidth = 40;
            this.bandedGridColumn8.Name = "bandedGridColumn8";
            this.bandedGridColumn8.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn8.Visible = true;
            this.bandedGridColumn8.Width = 121;
            // 
            // bandedGridColumn9
            // 
            this.bandedGridColumn9.Caption = "Sales Tax";
            this.bandedGridColumn9.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn9.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn9.FieldName = "salesTax";
            this.bandedGridColumn9.MinWidth = 40;
            this.bandedGridColumn9.Name = "bandedGridColumn9";
            this.bandedGridColumn9.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn9.Width = 64;
            // 
            // bandedGridColumn10
            // 
            this.bandedGridColumn10.Caption = "Fee";
            this.bandedGridColumn10.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn10.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn10.FieldName = "fee";
            this.bandedGridColumn10.MinWidth = 40;
            this.bandedGridColumn10.Name = "bandedGridColumn10";
            this.bandedGridColumn10.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn10.Width = 71;
            // 
            // bandedGridColumn11
            // 
            this.bandedGridColumn11.Caption = "Surcharge";
            this.bandedGridColumn11.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn11.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn11.FieldName = "surCharge";
            this.bandedGridColumn11.MinWidth = 40;
            this.bandedGridColumn11.Name = "bandedGridColumn11";
            this.bandedGridColumn11.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn11.Width = 89;
            // 
            // bandedGridColumn12
            // 
            this.bandedGridColumn12.Caption = "Trust or Funeral";
            this.bandedGridColumn12.ColumnEdit = this.repositoryItemComboBox1;
            this.bandedGridColumn12.FieldName = "trustFuneral";
            this.bandedGridColumn12.MinWidth = 40;
            this.bandedGridColumn12.Name = "bandedGridColumn12";
            this.bandedGridColumn12.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn12.Visible = true;
            this.bandedGridColumn12.Width = 83;
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.AutoHeight = false;
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox1.Items.AddRange(new object[] {
            "Trust",
            "Insurance",
            "Funeral",
            "DownPmt"});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            // 
            // bandedGridColumn13
            // 
            this.bandedGridColumn13.Caption = "Invoice Number";
            this.bandedGridColumn13.FieldName = "invoiceNumber";
            this.bandedGridColumn13.MinWidth = 40;
            this.bandedGridColumn13.Name = "bandedGridColumn13";
            this.bandedGridColumn13.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn13.Visible = true;
            this.bandedGridColumn13.Width = 228;
            // 
            // bandedGridColumn42
            // 
            this.bandedGridColumn42.Caption = "Reference Number";
            this.bandedGridColumn42.FieldName = "referenceNumber";
            this.bandedGridColumn42.MinWidth = 29;
            this.bandedGridColumn42.Name = "bandedGridColumn42";
            this.bandedGridColumn42.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn42.Visible = true;
            this.bandedGridColumn42.Width = 157;
            // 
            // bandedGridColumn7
            // 
            this.bandedGridColumn7.Caption = "record";
            this.bandedGridColumn7.FieldName = "record";
            this.bandedGridColumn7.MinWidth = 42;
            this.bandedGridColumn7.Name = "bandedGridColumn7";
            this.bandedGridColumn7.Width = 161;
            // 
            // panelTab1Top
            // 
            this.panelTab1Top.Controls.Add(this.btnSaveNotPosted);
            this.panelTab1Top.Controls.Add(this.btnPullFile);
            this.panelTab1Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTab1Top.Location = new System.Drawing.Point(0, 0);
            this.panelTab1Top.Name = "panelTab1Top";
            this.panelTab1Top.Size = new System.Drawing.Size(1698, 43);
            this.panelTab1Top.TabIndex = 6;
            // 
            // btnSaveNotPosted
            // 
            this.btnSaveNotPosted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSaveNotPosted.Location = new System.Drawing.Point(204, 7);
            this.btnSaveNotPosted.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSaveNotPosted.Name = "btnSaveNotPosted";
            this.btnSaveNotPosted.Size = new System.Drawing.Size(171, 28);
            this.btnSaveNotPosted.TabIndex = 162;
            this.btnSaveNotPosted.Text = "Save Data to Not Posted";
            this.btnSaveNotPosted.UseVisualStyleBackColor = false;
            this.btnSaveNotPosted.Click += new System.EventHandler(this.btnSaveNotPosted_Click);
            // 
            // btnPullFile
            // 
            this.btnPullFile.Location = new System.Drawing.Point(19, 7);
            this.btnPullFile.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPullFile.Name = "btnPullFile";
            this.btnPullFile.Size = new System.Drawing.Size(139, 28);
            this.btnPullFile.TabIndex = 150;
            this.btnPullFile.Text = "Pull CC Bank File";
            this.btnPullFile.UseVisualStyleBackColor = true;
            this.btnPullFile.Click += new System.EventHandler(this.btnPullFile_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.panelTab2All);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2.Size = new System.Drawing.Size(1704, 461);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Not Posted";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // panelTab2All
            // 
            this.panelTab2All.Controls.Add(this.panelTab2Bottom);
            this.panelTab2All.Controls.Add(this.panelTab2Top);
            this.panelTab2All.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTab2All.Location = new System.Drawing.Point(3, 4);
            this.panelTab2All.Name = "panelTab2All";
            this.panelTab2All.Size = new System.Drawing.Size(1698, 453);
            this.panelTab2All.TabIndex = 0;
            // 
            // panelTab2Bottom
            // 
            this.panelTab2Bottom.Controls.Add(this.dgv2);
            this.panelTab2Bottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTab2Bottom.Location = new System.Drawing.Point(0, 43);
            this.panelTab2Bottom.Name = "panelTab2Bottom";
            this.panelTab2Bottom.Size = new System.Drawing.Size(1698, 410);
            this.panelTab2Bottom.TabIndex = 2;
            // 
            // dgv2
            // 
            this.dgv2.ContextMenuStrip = this.contextMenuStrip2;
            this.dgv2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv2.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Location = new System.Drawing.Point(0, 0);
            this.dgv2.MainView = this.gridMain2;
            this.dgv2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv2.Name = "dgv2";
            this.dgv2.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemCheckEdit1,
            this.repositoryItemComboBox5});
            this.dgv2.Size = new System.Drawing.Size(1698, 410);
            this.dgv2.TabIndex = 5;
            this.dgv2.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain2});
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.duplicatePaymentToolStripMenuItem1,
            this.editInvoiceNumberToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(214, 52);
            // 
            // duplicatePaymentToolStripMenuItem1
            // 
            this.duplicatePaymentToolStripMenuItem1.Name = "duplicatePaymentToolStripMenuItem1";
            this.duplicatePaymentToolStripMenuItem1.Size = new System.Drawing.Size(213, 24);
            this.duplicatePaymentToolStripMenuItem1.Text = "Duplicate Payment";
            this.duplicatePaymentToolStripMenuItem1.Click += new System.EventHandler(this.duplicatePaymentToolStripMenuItem1_Click);
            // 
            // editInvoiceNumberToolStripMenuItem
            // 
            this.editInvoiceNumberToolStripMenuItem.Name = "editInvoiceNumberToolStripMenuItem";
            this.editInvoiceNumberToolStripMenuItem.Size = new System.Drawing.Size(213, 24);
            this.editInvoiceNumberToolStripMenuItem.Text = "Edit Invoice Number";
            this.editInvoiceNumberToolStripMenuItem.Click += new System.EventHandler(this.editInvoiceNumberToolStripMenuItem_Click);
            // 
            // gridMain2
            // 
            this.gridMain2.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain2.Appearance.BandPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain2.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain2.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.BandPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain2.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain2.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain2.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain2.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain2.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.ColumnFilterButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(244)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(222)))), ((int)(((byte)(183)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(244)))));
            this.gridMain2.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.ColumnFilterButtonActive.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain2.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain2.Appearance.Empty.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain2.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain2.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain2.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain2.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(158)))), ((int)(((byte)(126)))));
            this.gridMain2.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(128)))), ((int)(((byte)(88)))));
            this.gridMain2.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain2.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain2.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain2.Appearance.FooterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain2.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain2.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.FooterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain2.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain2.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain2.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain2.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain2.Appearance.GroupFooter.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseFont = true;
            this.gridMain2.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(158)))), ((int)(((byte)(126)))));
            this.gridMain2.Appearance.GroupPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain2.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain2.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain2.Appearance.GroupRow.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain2.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain2.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain2.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain2.Appearance.HeaderPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain2.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain2.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.HeaderPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain2.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain2.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(207)))), ((int)(((byte)(170)))));
            this.gridMain2.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain2.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(168)))), ((int)(((byte)(128)))));
            this.gridMain2.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain2.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.gridMain2.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain2.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain2.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain2.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain2.Appearance.Row.Options.UseBackColor = true;
            this.gridMain2.Appearance.Row.Options.UseForeColor = true;
            this.gridMain2.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(178)))), ((int)(((byte)(133)))));
            this.gridMain2.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain2.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain2.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain2.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(160)))), ((int)(((byte)(188)))));
            this.gridMain2.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain2.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain2.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain2.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand1});
            this.gridMain2.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn14,
            this.bandedGridColumn26,
            this.bandedGridColumn43,
            this.bandedGridColumn68,
            this.bandedGridColumn46,
            this.bandedGridColumn15,
            this.bandedGridColumn16,
            this.bandedGridColumn17,
            this.bandedGridColumn18,
            this.bandedGridColumn19,
            this.bandedGridColumn20,
            this.bandedGridColumn67,
            this.bandedGridColumn21,
            this.bandedGridColumn22,
            this.bandedGridColumn23,
            this.bandedGridColumn24,
            this.bandedGridColumn25,
            this.bandedGridColumn45,
            this.bandedGridColumn48,
            this.bandedGridColumn50});
            this.gridMain2.DetailHeight = 431;
            this.gridMain2.GridControl = this.dgv2;
            this.gridMain2.Name = "gridMain2";
            this.gridMain2.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain2.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridMain2.OptionsPrint.PrintBandHeader = false;
            this.gridMain2.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain2.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain2.OptionsView.ShowFooter = true;
            this.gridMain2.OptionsView.ShowGroupPanel = false;
            this.gridMain2.PaintStyleName = "Flat";
            this.gridMain2.RowCellStyle += new DevExpress.XtraGrid.Views.Grid.RowCellStyleEventHandler(this.gridMain2_RowCellStyle);
            this.gridMain2.ShowingEditor += new System.ComponentModel.CancelEventHandler(this.gridMain2_ShowingEditor);
            this.gridMain2.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMain2_CellValueChanged);
            this.gridMain2.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain_CustomColumnDisplayText);
            this.gridMain2.DoubleClick += new System.EventHandler(this.gridMain2_DoubleClick);
            this.gridMain2.ValidatingEditor += new DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventHandler(this.gridMain2_ValidatingEditor);
            // 
            // gridBand1
            // 
            this.gridBand1.Columns.Add(this.bandedGridColumn14);
            this.gridBand1.Columns.Add(this.bandedGridColumn43);
            this.gridBand1.Columns.Add(this.bandedGridColumn68);
            this.gridBand1.Columns.Add(this.bandedGridColumn46);
            this.gridBand1.Columns.Add(this.bandedGridColumn15);
            this.gridBand1.Columns.Add(this.bandedGridColumn16);
            this.gridBand1.Columns.Add(this.bandedGridColumn17);
            this.gridBand1.Columns.Add(this.bandedGridColumn18);
            this.gridBand1.Columns.Add(this.bandedGridColumn19);
            this.gridBand1.Columns.Add(this.bandedGridColumn48);
            this.gridBand1.Columns.Add(this.bandedGridColumn20);
            this.gridBand1.Columns.Add(this.bandedGridColumn67);
            this.gridBand1.Columns.Add(this.bandedGridColumn21);
            this.gridBand1.Columns.Add(this.bandedGridColumn22);
            this.gridBand1.Columns.Add(this.bandedGridColumn23);
            this.gridBand1.Columns.Add(this.bandedGridColumn24);
            this.gridBand1.Columns.Add(this.bandedGridColumn25);
            this.gridBand1.Columns.Add(this.bandedGridColumn45);
            this.gridBand1.Columns.Add(this.bandedGridColumn50);
            this.gridBand1.Columns.Add(this.bandedGridColumn26);
            this.gridBand1.MinWidth = 35;
            this.gridBand1.Name = "gridBand1";
            this.gridBand1.VisibleIndex = 0;
            this.gridBand1.Width = 1473;
            // 
            // bandedGridColumn14
            // 
            this.bandedGridColumn14.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn14.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn14.Caption = "Num";
            this.bandedGridColumn14.FieldName = "num";
            this.bandedGridColumn14.MinWidth = 23;
            this.bandedGridColumn14.Name = "bandedGridColumn14";
            this.bandedGridColumn14.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn14.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn14.Visible = true;
            this.bandedGridColumn14.Width = 45;
            // 
            // bandedGridColumn43
            // 
            this.bandedGridColumn43.Caption = "Select";
            this.bandedGridColumn43.ColumnEdit = this.repositoryItemCheckEdit1;
            this.bandedGridColumn43.FieldName = "select";
            this.bandedGridColumn43.MinWidth = 55;
            this.bandedGridColumn43.Name = "bandedGridColumn43";
            this.bandedGridColumn43.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn43.Visible = true;
            this.bandedGridColumn43.Width = 55;
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.DisplayValueChecked = "1";
            this.repositoryItemCheckEdit1.DisplayValueGrayed = "9";
            this.repositoryItemCheckEdit1.DisplayValueUnchecked = "0";
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            this.repositoryItemCheckEdit1.CheckedChanged += new System.EventHandler(this.repositoryItemCheckEdit1_CheckedChanged);
            // 
            // bandedGridColumn68
            // 
            this.bandedGridColumn68.Caption = "Transaction Date";
            this.bandedGridColumn68.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn68.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn68.FieldName = "transactionDate";
            this.bandedGridColumn68.MinWidth = 25;
            this.bandedGridColumn68.Name = "bandedGridColumn68";
            this.bandedGridColumn68.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn68.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn68.Visible = true;
            this.bandedGridColumn68.Width = 96;
            // 
            // bandedGridColumn46
            // 
            this.bandedGridColumn46.Caption = "Transaction Type";
            this.bandedGridColumn46.FieldName = "transactionType";
            this.bandedGridColumn46.MinWidth = 40;
            this.bandedGridColumn46.Name = "bandedGridColumn46";
            this.bandedGridColumn46.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn46.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn46.Visible = true;
            this.bandedGridColumn46.Width = 106;
            // 
            // bandedGridColumn15
            // 
            this.bandedGridColumn15.Caption = "Card Number";
            this.bandedGridColumn15.FieldName = "cardNumber";
            this.bandedGridColumn15.MinWidth = 64;
            this.bandedGridColumn15.Name = "bandedGridColumn15";
            this.bandedGridColumn15.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn15.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn15.Visible = true;
            this.bandedGridColumn15.Width = 65;
            // 
            // bandedGridColumn16
            // 
            this.bandedGridColumn16.Caption = "Payment Type";
            this.bandedGridColumn16.FieldName = "paymentType";
            this.bandedGridColumn16.MinWidth = 64;
            this.bandedGridColumn16.Name = "bandedGridColumn16";
            this.bandedGridColumn16.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn16.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn16.Visible = true;
            this.bandedGridColumn16.Width = 109;
            // 
            // bandedGridColumn17
            // 
            this.bandedGridColumn17.Caption = "Authorized Amount";
            this.bandedGridColumn17.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn17.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn17.FieldName = "authorizedAmount";
            this.bandedGridColumn17.MinWidth = 64;
            this.bandedGridColumn17.Name = "bandedGridColumn17";
            this.bandedGridColumn17.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn17.Visible = true;
            this.bandedGridColumn17.Width = 94;
            // 
            // bandedGridColumn18
            // 
            this.bandedGridColumn18.Caption = "Transaction Amount";
            this.bandedGridColumn18.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn18.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn18.FieldName = "transactionAmount";
            this.bandedGridColumn18.MinWidth = 64;
            this.bandedGridColumn18.Name = "bandedGridColumn18";
            this.bandedGridColumn18.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn18.Visible = true;
            this.bandedGridColumn18.Width = 86;
            // 
            // bandedGridColumn19
            // 
            this.bandedGridColumn19.Caption = "Return/Void";
            this.bandedGridColumn19.FieldName = "returnVoid";
            this.bandedGridColumn19.MinWidth = 64;
            this.bandedGridColumn19.Name = "bandedGridColumn19";
            this.bandedGridColumn19.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn19.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn19.Visible = true;
            this.bandedGridColumn19.Width = 87;
            // 
            // bandedGridColumn48
            // 
            this.bandedGridColumn48.Caption = "Deposit Number";
            this.bandedGridColumn48.FieldName = "depositNumber";
            this.bandedGridColumn48.MinWidth = 34;
            this.bandedGridColumn48.Name = "bandedGridColumn48";
            this.bandedGridColumn48.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn48.Visible = true;
            this.bandedGridColumn48.Width = 78;
            // 
            // bandedGridColumn20
            // 
            this.bandedGridColumn20.Caption = "Amount";
            this.bandedGridColumn20.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn20.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn20.FieldName = "amount";
            this.bandedGridColumn20.MinWidth = 64;
            this.bandedGridColumn20.Name = "bandedGridColumn20";
            this.bandedGridColumn20.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn20.Visible = true;
            this.bandedGridColumn20.Width = 77;
            // 
            // bandedGridColumn67
            // 
            this.bandedGridColumn67.Caption = "CC Fee";
            this.bandedGridColumn67.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn67.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn67.FieldName = "ccFee";
            this.bandedGridColumn67.MinWidth = 25;
            this.bandedGridColumn67.Name = "bandedGridColumn67";
            this.bandedGridColumn67.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn67.Visible = true;
            this.bandedGridColumn67.Width = 96;
            // 
            // bandedGridColumn21
            // 
            this.bandedGridColumn21.Caption = "Sales Tax";
            this.bandedGridColumn21.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn21.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn21.FieldName = "salesTax";
            this.bandedGridColumn21.Name = "bandedGridColumn21";
            this.bandedGridColumn21.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn21.Width = 57;
            // 
            // bandedGridColumn22
            // 
            this.bandedGridColumn22.Caption = "Fee";
            this.bandedGridColumn22.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn22.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn22.FieldName = "fee";
            this.bandedGridColumn22.Name = "bandedGridColumn22";
            this.bandedGridColumn22.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn22.Width = 50;
            // 
            // bandedGridColumn23
            // 
            this.bandedGridColumn23.Caption = "Surcharge";
            this.bandedGridColumn23.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn23.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn23.FieldName = "surCharge";
            this.bandedGridColumn23.MinWidth = 64;
            this.bandedGridColumn23.Name = "bandedGridColumn23";
            this.bandedGridColumn23.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn23.Width = 83;
            // 
            // bandedGridColumn24
            // 
            this.bandedGridColumn24.Caption = "Trust or Funeral";
            this.bandedGridColumn24.ColumnEdit = this.repositoryItemComboBox5;
            this.bandedGridColumn24.FieldName = "trustFuneral";
            this.bandedGridColumn24.MinWidth = 64;
            this.bandedGridColumn24.Name = "bandedGridColumn24";
            this.bandedGridColumn24.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn24.Visible = true;
            this.bandedGridColumn24.Width = 67;
            // 
            // repositoryItemComboBox5
            // 
            this.repositoryItemComboBox5.AutoHeight = false;
            this.repositoryItemComboBox5.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox5.Items.AddRange(new object[] {
            "Trust",
            "Insurance",
            "Funeral",
            "DownPmt"});
            this.repositoryItemComboBox5.Name = "repositoryItemComboBox5";
            // 
            // bandedGridColumn25
            // 
            this.bandedGridColumn25.Caption = "Invoice Number";
            this.bandedGridColumn25.FieldName = "invoiceNumber";
            this.bandedGridColumn25.MinWidth = 64;
            this.bandedGridColumn25.Name = "bandedGridColumn25";
            this.bandedGridColumn25.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn25.Visible = true;
            this.bandedGridColumn25.Width = 186;
            // 
            // bandedGridColumn45
            // 
            this.bandedGridColumn45.Caption = "Reference Number";
            this.bandedGridColumn45.FieldName = "referenceNumber";
            this.bandedGridColumn45.MinWidth = 47;
            this.bandedGridColumn45.Name = "bandedGridColumn45";
            this.bandedGridColumn45.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn45.Visible = true;
            this.bandedGridColumn45.Width = 116;
            // 
            // bandedGridColumn50
            // 
            this.bandedGridColumn50.Caption = "Bank Account";
            this.bandedGridColumn50.FieldName = "bankAccount";
            this.bandedGridColumn50.MinWidth = 29;
            this.bandedGridColumn50.Name = "bandedGridColumn50";
            this.bandedGridColumn50.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn50.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn50.Visible = true;
            this.bandedGridColumn50.Width = 110;
            // 
            // bandedGridColumn26
            // 
            this.bandedGridColumn26.Caption = "record";
            this.bandedGridColumn26.FieldName = "record";
            this.bandedGridColumn26.MinWidth = 66;
            this.bandedGridColumn26.Name = "bandedGridColumn26";
            this.bandedGridColumn26.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn26.Width = 255;
            // 
            // panelTab2Top
            // 
            this.panelTab2Top.Controls.Add(this.btnSaveChangedData);
            this.panelTab2Top.Controls.Add(this.btnPost);
            this.panelTab2Top.Controls.Add(this.btnPullNotPosted);
            this.panelTab2Top.Controls.Add(this.dateTimePicker1);
            this.panelTab2Top.Controls.Add(this.lblEffectiveDate);
            this.panelTab2Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTab2Top.Location = new System.Drawing.Point(0, 0);
            this.panelTab2Top.Name = "panelTab2Top";
            this.panelTab2Top.Size = new System.Drawing.Size(1698, 43);
            this.panelTab2Top.TabIndex = 1;
            // 
            // btnSaveChangedData
            // 
            this.btnSaveChangedData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSaveChangedData.Location = new System.Drawing.Point(167, 8);
            this.btnSaveChangedData.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSaveChangedData.Name = "btnSaveChangedData";
            this.btnSaveChangedData.Size = new System.Drawing.Size(133, 28);
            this.btnSaveChangedData.TabIndex = 164;
            this.btnSaveChangedData.Text = "Save Changes";
            this.btnSaveChangedData.UseVisualStyleBackColor = false;
            this.btnSaveChangedData.Click += new System.EventHandler(this.btnSaveChangedData_Click);
            // 
            // btnPost
            // 
            this.btnPost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnPost.Location = new System.Drawing.Point(815, 5);
            this.btnPost.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPost.Name = "btnPost";
            this.btnPost.Size = new System.Drawing.Size(171, 28);
            this.btnPost.TabIndex = 163;
            this.btnPost.Text = "Process Select Rows";
            this.btnPost.UseVisualStyleBackColor = false;
            this.btnPost.Click += new System.EventHandler(this.btnPost_Click);
            // 
            // btnPullNotPosted
            // 
            this.btnPullNotPosted.Location = new System.Drawing.Point(10, 8);
            this.btnPullNotPosted.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPullNotPosted.Name = "btnPullNotPosted";
            this.btnPullNotPosted.Size = new System.Drawing.Size(139, 28);
            this.btnPullNotPosted.TabIndex = 151;
            this.btnPullNotPosted.Text = "Pull Not Posted";
            this.btnPullNotPosted.UseVisualStyleBackColor = true;
            this.btnPullNotPosted.Click += new System.EventHandler(this.btnPullNotPosted_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(550, 8);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker1.TabIndex = 147;
            // 
            // lblEffectiveDate
            // 
            this.lblEffectiveDate.AutoSize = true;
            this.lblEffectiveDate.Location = new System.Drawing.Point(448, 11);
            this.lblEffectiveDate.Name = "lblEffectiveDate";
            this.lblEffectiveDate.Size = new System.Drawing.Size(102, 17);
            this.lblEffectiveDate.TabIndex = 148;
            this.lblEffectiveDate.Text = "Effective Date :";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panelTab3All);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1704, 461);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Posted";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panelTab3All
            // 
            this.panelTab3All.Controls.Add(this.panelTab3Bottom);
            this.panelTab3All.Controls.Add(this.panelTab3Top);
            this.panelTab3All.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTab3All.Location = new System.Drawing.Point(0, 0);
            this.panelTab3All.Name = "panelTab3All";
            this.panelTab3All.Size = new System.Drawing.Size(1704, 461);
            this.panelTab3All.TabIndex = 0;
            // 
            // panelTab3Bottom
            // 
            this.panelTab3Bottom.Controls.Add(this.dgv3);
            this.panelTab3Bottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTab3Bottom.Location = new System.Drawing.Point(0, 48);
            this.panelTab3Bottom.Name = "panelTab3Bottom";
            this.panelTab3Bottom.Size = new System.Drawing.Size(1704, 413);
            this.panelTab3Bottom.TabIndex = 2;
            // 
            // dgv3
            // 
            this.dgv3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv3.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Location = new System.Drawing.Point(0, 0);
            this.dgv3.MainView = this.gridMain3;
            this.dgv3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Name = "dgv3";
            this.dgv3.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox2});
            this.dgv3.Size = new System.Drawing.Size(1704, 413);
            this.dgv3.TabIndex = 5;
            this.dgv3.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain3});
            // 
            // gridMain3
            // 
            this.gridMain3.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain3.Appearance.BandPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain3.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain3.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain3.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.BandPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain3.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain3.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain3.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain3.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain3.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.ColumnFilterButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(244)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(222)))), ((int)(((byte)(183)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(244)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.ColumnFilterButtonActive.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain3.Appearance.Empty.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain3.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain3.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain3.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain3.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain3.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(158)))), ((int)(((byte)(126)))));
            this.gridMain3.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(128)))), ((int)(((byte)(88)))));
            this.gridMain3.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain3.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain3.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain3.Appearance.FooterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain3.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain3.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FooterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain3.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain3.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain3.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain3.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain3.Appearance.GroupFooter.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain3.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupFooter.Options.UseFont = true;
            this.gridMain3.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(158)))), ((int)(((byte)(126)))));
            this.gridMain3.Appearance.GroupPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain3.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain3.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain3.Appearance.GroupRow.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain3.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain3.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain3.Appearance.HeaderPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain3.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain3.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.HeaderPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain3.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain3.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(207)))), ((int)(((byte)(170)))));
            this.gridMain3.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain3.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(168)))), ((int)(((byte)(128)))));
            this.gridMain3.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain3.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.gridMain3.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain3.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain3.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain3.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.Row.Options.UseBackColor = true;
            this.gridMain3.Appearance.Row.Options.UseForeColor = true;
            this.gridMain3.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain3.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(178)))), ((int)(((byte)(133)))));
            this.gridMain3.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(160)))), ((int)(((byte)(188)))));
            this.gridMain3.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain3.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain3.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain3.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand2});
            this.gridMain3.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn28,
            this.bandedGridColumn41,
            this.bandedGridColumn44,
            this.bandedGridColumn70,
            this.bandedGridColumn29,
            this.bandedGridColumn30,
            this.bandedGridColumn31,
            this.bandedGridColumn32,
            this.bandedGridColumn33,
            this.bandedGridColumn34,
            this.bandedGridColumn35,
            this.bandedGridColumn88,
            this.bandedGridColumn36,
            this.bandedGridColumn37,
            this.bandedGridColumn38,
            this.bandedGridColumn39,
            this.bandedGridColumn40,
            this.bandedGridColumn47,
            this.bandedGridColumn49,
            this.bandedGridColumn51});
            this.gridMain3.DetailHeight = 431;
            this.gridMain3.GridControl = this.dgv3;
            this.gridMain3.Name = "gridMain3";
            this.gridMain3.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain3.OptionsPrint.PrintBandHeader = false;
            this.gridMain3.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain3.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain3.OptionsView.ShowFooter = true;
            this.gridMain3.OptionsView.ShowGroupPanel = false;
            this.gridMain3.PaintStyleName = "Flat";
            this.gridMain3.ShowingEditor += new System.ComponentModel.CancelEventHandler(this.gridMain3_ShowingEditor);
            this.gridMain3.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain_CustomColumnDisplayText);
            this.gridMain3.DoubleClick += new System.EventHandler(this.gridMain3_DoubleClick);
            this.gridMain3.ValidatingEditor += new DevExpress.XtraEditors.Controls.BaseContainerValidateEditorEventHandler(this.gridMain3_ValidatingEditor);
            // 
            // gridBand2
            // 
            this.gridBand2.Columns.Add(this.bandedGridColumn28);
            this.gridBand2.Columns.Add(this.bandedGridColumn44);
            this.gridBand2.Columns.Add(this.bandedGridColumn70);
            this.gridBand2.Columns.Add(this.bandedGridColumn29);
            this.gridBand2.Columns.Add(this.bandedGridColumn30);
            this.gridBand2.Columns.Add(this.bandedGridColumn31);
            this.gridBand2.Columns.Add(this.bandedGridColumn32);
            this.gridBand2.Columns.Add(this.bandedGridColumn33);
            this.gridBand2.Columns.Add(this.bandedGridColumn34);
            this.gridBand2.Columns.Add(this.bandedGridColumn49);
            this.gridBand2.Columns.Add(this.bandedGridColumn35);
            this.gridBand2.Columns.Add(this.bandedGridColumn88);
            this.gridBand2.Columns.Add(this.bandedGridColumn36);
            this.gridBand2.Columns.Add(this.bandedGridColumn37);
            this.gridBand2.Columns.Add(this.bandedGridColumn38);
            this.gridBand2.Columns.Add(this.bandedGridColumn39);
            this.gridBand2.Columns.Add(this.bandedGridColumn40);
            this.gridBand2.Columns.Add(this.bandedGridColumn47);
            this.gridBand2.Columns.Add(this.bandedGridColumn51);
            this.gridBand2.Columns.Add(this.bandedGridColumn41);
            this.gridBand2.MinWidth = 35;
            this.gridBand2.Name = "gridBand2";
            this.gridBand2.VisibleIndex = 0;
            this.gridBand2.Width = 1542;
            // 
            // bandedGridColumn28
            // 
            this.bandedGridColumn28.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn28.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn28.Caption = "Num";
            this.bandedGridColumn28.FieldName = "num";
            this.bandedGridColumn28.MinWidth = 23;
            this.bandedGridColumn28.Name = "bandedGridColumn28";
            this.bandedGridColumn28.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn28.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn28.Visible = true;
            this.bandedGridColumn28.Width = 45;
            // 
            // bandedGridColumn44
            // 
            this.bandedGridColumn44.Caption = "Posted Date";
            this.bandedGridColumn44.DisplayFormat.FormatString = "yyyy-MM-dd";
            this.bandedGridColumn44.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn44.FieldName = "postedDate";
            this.bandedGridColumn44.MinWidth = 47;
            this.bandedGridColumn44.Name = "bandedGridColumn44";
            this.bandedGridColumn44.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn44.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn44.Visible = true;
            this.bandedGridColumn44.Width = 105;
            // 
            // bandedGridColumn70
            // 
            this.bandedGridColumn70.Caption = "Transaction Date";
            this.bandedGridColumn70.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn70.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn70.FieldName = "transactionDate";
            this.bandedGridColumn70.MinWidth = 25;
            this.bandedGridColumn70.Name = "bandedGridColumn70";
            this.bandedGridColumn70.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn70.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn70.Visible = true;
            this.bandedGridColumn70.Width = 94;
            // 
            // bandedGridColumn29
            // 
            this.bandedGridColumn29.Caption = "Transaction Type";
            this.bandedGridColumn29.FieldName = "transactionType";
            this.bandedGridColumn29.MinWidth = 55;
            this.bandedGridColumn29.Name = "bandedGridColumn29";
            this.bandedGridColumn29.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn29.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn29.Visible = true;
            this.bandedGridColumn29.Width = 104;
            // 
            // bandedGridColumn30
            // 
            this.bandedGridColumn30.Caption = "Card Number";
            this.bandedGridColumn30.FieldName = "cardNumber";
            this.bandedGridColumn30.MinWidth = 64;
            this.bandedGridColumn30.Name = "bandedGridColumn30";
            this.bandedGridColumn30.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn30.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn30.Visible = true;
            this.bandedGridColumn30.Width = 64;
            // 
            // bandedGridColumn31
            // 
            this.bandedGridColumn31.Caption = "Payment Type";
            this.bandedGridColumn31.FieldName = "paymentType";
            this.bandedGridColumn31.MinWidth = 64;
            this.bandedGridColumn31.Name = "bandedGridColumn31";
            this.bandedGridColumn31.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn31.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn31.Visible = true;
            this.bandedGridColumn31.Width = 126;
            // 
            // bandedGridColumn32
            // 
            this.bandedGridColumn32.Caption = "Authorized Amount";
            this.bandedGridColumn32.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn32.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn32.FieldName = "authorizedAmount";
            this.bandedGridColumn32.MinWidth = 64;
            this.bandedGridColumn32.Name = "bandedGridColumn32";
            this.bandedGridColumn32.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn32.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn32.Visible = true;
            this.bandedGridColumn32.Width = 84;
            // 
            // bandedGridColumn33
            // 
            this.bandedGridColumn33.Caption = "Transaction Amount";
            this.bandedGridColumn33.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn33.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn33.FieldName = "transactionAmount";
            this.bandedGridColumn33.MinWidth = 64;
            this.bandedGridColumn33.Name = "bandedGridColumn33";
            this.bandedGridColumn33.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn33.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn33.Visible = true;
            this.bandedGridColumn33.Width = 82;
            // 
            // bandedGridColumn34
            // 
            this.bandedGridColumn34.Caption = "Return/Void";
            this.bandedGridColumn34.FieldName = "returnVoid";
            this.bandedGridColumn34.MinWidth = 64;
            this.bandedGridColumn34.Name = "bandedGridColumn34";
            this.bandedGridColumn34.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn34.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn34.Visible = true;
            this.bandedGridColumn34.Width = 99;
            // 
            // bandedGridColumn49
            // 
            this.bandedGridColumn49.Caption = "Deposit Number";
            this.bandedGridColumn49.FieldName = "depositNumber";
            this.bandedGridColumn49.MinWidth = 34;
            this.bandedGridColumn49.Name = "bandedGridColumn49";
            this.bandedGridColumn49.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn49.Visible = true;
            this.bandedGridColumn49.Width = 92;
            // 
            // bandedGridColumn35
            // 
            this.bandedGridColumn35.Caption = "Amount";
            this.bandedGridColumn35.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn35.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn35.FieldName = "amount";
            this.bandedGridColumn35.MinWidth = 64;
            this.bandedGridColumn35.Name = "bandedGridColumn35";
            this.bandedGridColumn35.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn35.Visible = true;
            this.bandedGridColumn35.Width = 89;
            // 
            // bandedGridColumn88
            // 
            this.bandedGridColumn88.Caption = "CC Fee";
            this.bandedGridColumn88.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn88.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn88.FieldName = "ccFee";
            this.bandedGridColumn88.MinWidth = 25;
            this.bandedGridColumn88.Name = "bandedGridColumn88";
            this.bandedGridColumn88.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn88.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn88.Visible = true;
            this.bandedGridColumn88.Width = 94;
            // 
            // bandedGridColumn36
            // 
            this.bandedGridColumn36.Caption = "Sales Tax";
            this.bandedGridColumn36.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn36.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn36.FieldName = "salesTax";
            this.bandedGridColumn36.MinWidth = 64;
            this.bandedGridColumn36.Name = "bandedGridColumn36";
            this.bandedGridColumn36.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn36.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn36.Width = 64;
            // 
            // bandedGridColumn37
            // 
            this.bandedGridColumn37.Caption = "Fee";
            this.bandedGridColumn37.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn37.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn37.FieldName = "fee";
            this.bandedGridColumn37.Name = "bandedGridColumn37";
            this.bandedGridColumn37.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn37.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn37.Width = 49;
            // 
            // bandedGridColumn38
            // 
            this.bandedGridColumn38.Caption = "Surcharge";
            this.bandedGridColumn38.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn38.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn38.FieldName = "surCharge";
            this.bandedGridColumn38.MinWidth = 64;
            this.bandedGridColumn38.Name = "bandedGridColumn38";
            this.bandedGridColumn38.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn38.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn38.Width = 88;
            // 
            // bandedGridColumn39
            // 
            this.bandedGridColumn39.Caption = "Trust or Funeral";
            this.bandedGridColumn39.ColumnEdit = this.repositoryItemComboBox2;
            this.bandedGridColumn39.FieldName = "trustFuneral";
            this.bandedGridColumn39.MinWidth = 64;
            this.bandedGridColumn39.Name = "bandedGridColumn39";
            this.bandedGridColumn39.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn39.Visible = true;
            this.bandedGridColumn39.Width = 67;
            // 
            // repositoryItemComboBox2
            // 
            this.repositoryItemComboBox2.AutoHeight = false;
            this.repositoryItemComboBox2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox2.Items.AddRange(new object[] {
            "Trust",
            "Funeral",
            "Insurance",
            "DownPmt"});
            this.repositoryItemComboBox2.Name = "repositoryItemComboBox2";
            // 
            // bandedGridColumn40
            // 
            this.bandedGridColumn40.Caption = "Invoice Number";
            this.bandedGridColumn40.FieldName = "invoiceNumber";
            this.bandedGridColumn40.MinWidth = 64;
            this.bandedGridColumn40.Name = "bandedGridColumn40";
            this.bandedGridColumn40.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn40.Visible = true;
            this.bandedGridColumn40.Width = 149;
            // 
            // bandedGridColumn47
            // 
            this.bandedGridColumn47.Caption = "Reference Number";
            this.bandedGridColumn47.FieldName = "referenceNumber";
            this.bandedGridColumn47.MinWidth = 40;
            this.bandedGridColumn47.Name = "bandedGridColumn47";
            this.bandedGridColumn47.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn47.Visible = true;
            this.bandedGridColumn47.Width = 138;
            // 
            // bandedGridColumn51
            // 
            this.bandedGridColumn51.Caption = "Bank Account";
            this.bandedGridColumn51.FieldName = "bankAccount";
            this.bandedGridColumn51.MinWidth = 29;
            this.bandedGridColumn51.Name = "bandedGridColumn51";
            this.bandedGridColumn51.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn51.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn51.Visible = true;
            this.bandedGridColumn51.Width = 110;
            // 
            // bandedGridColumn41
            // 
            this.bandedGridColumn41.Caption = "record";
            this.bandedGridColumn41.FieldName = "record";
            this.bandedGridColumn41.MinWidth = 66;
            this.bandedGridColumn41.Name = "bandedGridColumn41";
            this.bandedGridColumn41.Width = 255;
            // 
            // panelTab3Top
            // 
            this.panelTab3Top.Controls.Add(this.chkHonorDates);
            this.panelTab3Top.Controls.Add(this.label8);
            this.panelTab3Top.Controls.Add(this.btnPullPostedData);
            this.panelTab3Top.Controls.Add(this.label5);
            this.panelTab3Top.Controls.Add(this.dateTimePicker2);
            this.panelTab3Top.Controls.Add(this.dateTimePicker3);
            this.panelTab3Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTab3Top.Location = new System.Drawing.Point(0, 0);
            this.panelTab3Top.Name = "panelTab3Top";
            this.panelTab3Top.Size = new System.Drawing.Size(1704, 48);
            this.panelTab3Top.TabIndex = 1;
            // 
            // chkHonorDates
            // 
            this.chkHonorDates.AutoSize = true;
            this.chkHonorDates.Location = new System.Drawing.Point(843, 14);
            this.chkHonorDates.Name = "chkHonorDates";
            this.chkHonorDates.Size = new System.Drawing.Size(153, 21);
            this.chkHonorDates.TabIndex = 161;
            this.chkHonorDates.Text = "Honor Search Dates";
            this.chkHonorDates.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(221, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(98, 17);
            this.label8.TabIndex = 160;
            this.label8.Text = "Search Dates :";
            // 
            // btnPullPostedData
            // 
            this.btnPullPostedData.Location = new System.Drawing.Point(13, 12);
            this.btnPullPostedData.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPullPostedData.Name = "btnPullPostedData";
            this.btnPullPostedData.Size = new System.Drawing.Size(139, 28);
            this.btnPullPostedData.TabIndex = 152;
            this.btnPullPostedData.Text = "Pull Posted Data";
            this.btnPullPostedData.UseVisualStyleBackColor = true;
            this.btnPullPostedData.Click += new System.EventHandler(this.btnPullPostedData_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(556, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 17);
            this.label5.TabIndex = 159;
            this.label5.Text = "-To-";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(320, 13);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker2.TabIndex = 158;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.Location = new System.Drawing.Point(591, 13);
            this.dateTimePicker3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker3.TabIndex = 155;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panelTab4All);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1704, 461);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Declined";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panelTab4All
            // 
            this.panelTab4All.Controls.Add(this.panelTab4Bottom);
            this.panelTab4All.Controls.Add(this.panelTab4Top);
            this.panelTab4All.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTab4All.Location = new System.Drawing.Point(0, 0);
            this.panelTab4All.Name = "panelTab4All";
            this.panelTab4All.Size = new System.Drawing.Size(1704, 461);
            this.panelTab4All.TabIndex = 6;
            // 
            // panelTab4Bottom
            // 
            this.panelTab4Bottom.Controls.Add(this.dgv4);
            this.panelTab4Bottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTab4Bottom.Location = new System.Drawing.Point(0, 46);
            this.panelTab4Bottom.Name = "panelTab4Bottom";
            this.panelTab4Bottom.Size = new System.Drawing.Size(1704, 415);
            this.panelTab4Bottom.TabIndex = 8;
            // 
            // dgv4
            // 
            this.dgv4.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv4.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv4.Location = new System.Drawing.Point(0, 0);
            this.dgv4.MainView = this.gridMain4;
            this.dgv4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv4.Name = "dgv4";
            this.dgv4.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox3});
            this.dgv4.Size = new System.Drawing.Size(1704, 415);
            this.dgv4.TabIndex = 5;
            this.dgv4.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain4});
            // 
            // gridMain4
            // 
            this.gridMain4.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain4.Appearance.BandPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain4.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain4.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.BandPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain4.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain4.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain4.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain4.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain4.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.ColumnFilterButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(244)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(222)))), ((int)(((byte)(183)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(244)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.ColumnFilterButtonActive.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain4.Appearance.Empty.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain4.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain4.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain4.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain4.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain4.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(158)))), ((int)(((byte)(126)))));
            this.gridMain4.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(128)))), ((int)(((byte)(88)))));
            this.gridMain4.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain4.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain4.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain4.Appearance.FooterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain4.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain4.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FooterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain4.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain4.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain4.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain4.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain4.Appearance.GroupFooter.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupFooter.Options.UseFont = true;
            this.gridMain4.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(158)))), ((int)(((byte)(126)))));
            this.gridMain4.Appearance.GroupPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain4.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain4.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain4.Appearance.GroupRow.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain4.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain4.Appearance.HeaderPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain4.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain4.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.HeaderPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain4.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain4.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(207)))), ((int)(((byte)(170)))));
            this.gridMain4.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain4.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(168)))), ((int)(((byte)(128)))));
            this.gridMain4.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain4.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.gridMain4.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain4.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain4.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain4.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.Row.Options.UseBackColor = true;
            this.gridMain4.Appearance.Row.Options.UseForeColor = true;
            this.gridMain4.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain4.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(178)))), ((int)(((byte)(133)))));
            this.gridMain4.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(160)))), ((int)(((byte)(188)))));
            this.gridMain4.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain4.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain4.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain4.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand3});
            this.gridMain4.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn52,
            this.bandedGridColumn66,
            this.bandedGridColumn71,
            this.bandedGridColumn53,
            this.bandedGridColumn54,
            this.bandedGridColumn55,
            this.bandedGridColumn56,
            this.bandedGridColumn57,
            this.bandedGridColumn58,
            this.bandedGridColumn59,
            this.bandedGridColumn60,
            this.bandedGridColumn61,
            this.bandedGridColumn62,
            this.bandedGridColumn63,
            this.bandedGridColumn64,
            this.bandedGridColumn65});
            this.gridMain4.DetailHeight = 431;
            this.gridMain4.GridControl = this.dgv4;
            this.gridMain4.Name = "gridMain4";
            this.gridMain4.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain4.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridMain4.OptionsPrint.PrintBandHeader = false;
            this.gridMain4.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain4.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain4.OptionsView.ShowFooter = true;
            this.gridMain4.OptionsView.ShowGroupPanel = false;
            this.gridMain4.PaintStyleName = "Flat";
            this.gridMain4.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain_CustomColumnDisplayText);
            // 
            // gridBand3
            // 
            this.gridBand3.Columns.Add(this.bandedGridColumn52);
            this.gridBand3.Columns.Add(this.bandedGridColumn71);
            this.gridBand3.Columns.Add(this.bandedGridColumn53);
            this.gridBand3.Columns.Add(this.bandedGridColumn54);
            this.gridBand3.Columns.Add(this.bandedGridColumn55);
            this.gridBand3.Columns.Add(this.bandedGridColumn56);
            this.gridBand3.Columns.Add(this.bandedGridColumn57);
            this.gridBand3.Columns.Add(this.bandedGridColumn58);
            this.gridBand3.Columns.Add(this.bandedGridColumn59);
            this.gridBand3.Columns.Add(this.bandedGridColumn60);
            this.gridBand3.Columns.Add(this.bandedGridColumn61);
            this.gridBand3.Columns.Add(this.bandedGridColumn62);
            this.gridBand3.Columns.Add(this.bandedGridColumn63);
            this.gridBand3.Columns.Add(this.bandedGridColumn64);
            this.gridBand3.Columns.Add(this.bandedGridColumn65);
            this.gridBand3.Columns.Add(this.bandedGridColumn66);
            this.gridBand3.MinWidth = 22;
            this.gridBand3.Name = "gridBand3";
            this.gridBand3.VisibleIndex = 0;
            this.gridBand3.Width = 1358;
            // 
            // bandedGridColumn52
            // 
            this.bandedGridColumn52.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn52.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn52.Caption = "Num";
            this.bandedGridColumn52.FieldName = "num";
            this.bandedGridColumn52.MinWidth = 42;
            this.bandedGridColumn52.Name = "bandedGridColumn52";
            this.bandedGridColumn52.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn52.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn52.Visible = true;
            this.bandedGridColumn52.Width = 42;
            // 
            // bandedGridColumn71
            // 
            this.bandedGridColumn71.Caption = "Transaction Date";
            this.bandedGridColumn71.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn71.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn71.FieldName = "transactionDate";
            this.bandedGridColumn71.MinWidth = 25;
            this.bandedGridColumn71.Name = "bandedGridColumn71";
            this.bandedGridColumn71.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn71.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn71.Visible = true;
            this.bandedGridColumn71.Width = 94;
            // 
            // bandedGridColumn53
            // 
            this.bandedGridColumn53.Caption = "Transaction Type";
            this.bandedGridColumn53.FieldName = "transactionType";
            this.bandedGridColumn53.MinWidth = 34;
            this.bandedGridColumn53.Name = "bandedGridColumn53";
            this.bandedGridColumn53.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn53.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn53.Visible = true;
            this.bandedGridColumn53.Width = 99;
            // 
            // bandedGridColumn54
            // 
            this.bandedGridColumn54.Caption = "Card Number";
            this.bandedGridColumn54.FieldName = "cardNumber";
            this.bandedGridColumn54.MinWidth = 40;
            this.bandedGridColumn54.Name = "bandedGridColumn54";
            this.bandedGridColumn54.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn54.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn54.Visible = true;
            this.bandedGridColumn54.Width = 79;
            // 
            // bandedGridColumn55
            // 
            this.bandedGridColumn55.Caption = "Payment Type";
            this.bandedGridColumn55.FieldName = "paymentType";
            this.bandedGridColumn55.MinWidth = 40;
            this.bandedGridColumn55.Name = "bandedGridColumn55";
            this.bandedGridColumn55.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn55.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn55.Visible = true;
            this.bandedGridColumn55.Width = 131;
            // 
            // bandedGridColumn56
            // 
            this.bandedGridColumn56.Caption = "Authorized Amount";
            this.bandedGridColumn56.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn56.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn56.FieldName = "authorizedAmount";
            this.bandedGridColumn56.MinWidth = 40;
            this.bandedGridColumn56.Name = "bandedGridColumn56";
            this.bandedGridColumn56.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn56.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn56.Visible = true;
            this.bandedGridColumn56.Width = 104;
            // 
            // bandedGridColumn57
            // 
            this.bandedGridColumn57.Caption = "Transaction Amount";
            this.bandedGridColumn57.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn57.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn57.FieldName = "transactionAmount";
            this.bandedGridColumn57.MinWidth = 40;
            this.bandedGridColumn57.Name = "bandedGridColumn57";
            this.bandedGridColumn57.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn57.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn57.Visible = true;
            this.bandedGridColumn57.Width = 114;
            // 
            // bandedGridColumn58
            // 
            this.bandedGridColumn58.Caption = "Return/Void";
            this.bandedGridColumn58.FieldName = "returnVoid";
            this.bandedGridColumn58.MinWidth = 40;
            this.bandedGridColumn58.Name = "bandedGridColumn58";
            this.bandedGridColumn58.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn58.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn58.Visible = true;
            this.bandedGridColumn58.Width = 106;
            // 
            // bandedGridColumn59
            // 
            this.bandedGridColumn59.Caption = "Amount";
            this.bandedGridColumn59.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn59.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn59.FieldName = "amount";
            this.bandedGridColumn59.MinWidth = 40;
            this.bandedGridColumn59.Name = "bandedGridColumn59";
            this.bandedGridColumn59.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn59.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn59.Visible = true;
            this.bandedGridColumn59.Width = 121;
            // 
            // bandedGridColumn60
            // 
            this.bandedGridColumn60.Caption = "Sales Tax";
            this.bandedGridColumn60.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn60.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn60.FieldName = "salesTax";
            this.bandedGridColumn60.MinWidth = 40;
            this.bandedGridColumn60.Name = "bandedGridColumn60";
            this.bandedGridColumn60.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn60.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn60.Width = 64;
            // 
            // bandedGridColumn61
            // 
            this.bandedGridColumn61.Caption = "Fee";
            this.bandedGridColumn61.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn61.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn61.FieldName = "fee";
            this.bandedGridColumn61.MinWidth = 40;
            this.bandedGridColumn61.Name = "bandedGridColumn61";
            this.bandedGridColumn61.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn61.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn61.Width = 71;
            // 
            // bandedGridColumn62
            // 
            this.bandedGridColumn62.Caption = "Surcharge";
            this.bandedGridColumn62.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn62.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn62.FieldName = "surCharge";
            this.bandedGridColumn62.MinWidth = 40;
            this.bandedGridColumn62.Name = "bandedGridColumn62";
            this.bandedGridColumn62.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn62.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn62.Width = 89;
            // 
            // bandedGridColumn63
            // 
            this.bandedGridColumn63.Caption = "Trust or Funeral";
            this.bandedGridColumn63.ColumnEdit = this.repositoryItemComboBox3;
            this.bandedGridColumn63.FieldName = "trustFuneral";
            this.bandedGridColumn63.MinWidth = 40;
            this.bandedGridColumn63.Name = "bandedGridColumn63";
            this.bandedGridColumn63.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn63.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn63.Visible = true;
            this.bandedGridColumn63.Width = 83;
            // 
            // repositoryItemComboBox3
            // 
            this.repositoryItemComboBox3.AutoHeight = false;
            this.repositoryItemComboBox3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox3.Items.AddRange(new object[] {
            "Trust",
            "Insurance",
            "Funeral"});
            this.repositoryItemComboBox3.Name = "repositoryItemComboBox3";
            // 
            // bandedGridColumn64
            // 
            this.bandedGridColumn64.Caption = "Invoice Number";
            this.bandedGridColumn64.FieldName = "invoiceNumber";
            this.bandedGridColumn64.MinWidth = 40;
            this.bandedGridColumn64.Name = "bandedGridColumn64";
            this.bandedGridColumn64.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn64.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn64.Visible = true;
            this.bandedGridColumn64.Width = 228;
            // 
            // bandedGridColumn65
            // 
            this.bandedGridColumn65.Caption = "Reference Number";
            this.bandedGridColumn65.FieldName = "referenceNumber";
            this.bandedGridColumn65.MinWidth = 29;
            this.bandedGridColumn65.Name = "bandedGridColumn65";
            this.bandedGridColumn65.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn65.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn65.Visible = true;
            this.bandedGridColumn65.Width = 157;
            // 
            // bandedGridColumn66
            // 
            this.bandedGridColumn66.Caption = "record";
            this.bandedGridColumn66.FieldName = "record";
            this.bandedGridColumn66.MinWidth = 42;
            this.bandedGridColumn66.Name = "bandedGridColumn66";
            this.bandedGridColumn66.Width = 161;
            // 
            // panelTab4Top
            // 
            this.panelTab4Top.Controls.Add(this.chkHonorDates3);
            this.panelTab4Top.Controls.Add(this.label1);
            this.panelTab4Top.Controls.Add(this.label2);
            this.panelTab4Top.Controls.Add(this.dateTimePicker4);
            this.panelTab4Top.Controls.Add(this.dateTimePicker5);
            this.panelTab4Top.Controls.Add(this.btnPullDeclined);
            this.panelTab4Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTab4Top.Location = new System.Drawing.Point(0, 0);
            this.panelTab4Top.Name = "panelTab4Top";
            this.panelTab4Top.Size = new System.Drawing.Size(1704, 46);
            this.panelTab4Top.TabIndex = 7;
            // 
            // chkHonorDates3
            // 
            this.chkHonorDates3.AutoSize = true;
            this.chkHonorDates3.Location = new System.Drawing.Point(959, 14);
            this.chkHonorDates3.Name = "chkHonorDates3";
            this.chkHonorDates3.Size = new System.Drawing.Size(228, 21);
            this.chkHonorDates3.TabIndex = 167;
            this.chkHonorDates3.Text = "Honor Search Transaction Dates";
            this.chkHonorDates3.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(337, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 17);
            this.label1.TabIndex = 166;
            this.label1.Text = "Search Dates :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(672, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 17);
            this.label2.TabIndex = 165;
            this.label2.Text = "-To-";
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.Location = new System.Drawing.Point(436, 13);
            this.dateTimePicker4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker4.TabIndex = 164;
            // 
            // dateTimePicker5
            // 
            this.dateTimePicker5.Location = new System.Drawing.Point(707, 13);
            this.dateTimePicker5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker5.Name = "dateTimePicker5";
            this.dateTimePicker5.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker5.TabIndex = 163;
            // 
            // btnPullDeclined
            // 
            this.btnPullDeclined.Location = new System.Drawing.Point(154, 10);
            this.btnPullDeclined.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPullDeclined.Name = "btnPullDeclined";
            this.btnPullDeclined.Size = new System.Drawing.Size(139, 28);
            this.btnPullDeclined.TabIndex = 162;
            this.btnPullDeclined.Text = "Pull Declined Data";
            this.btnPullDeclined.UseVisualStyleBackColor = true;
            this.btnPullDeclined.Click += new System.EventHandler(this.btnPullDeclined_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.panelTab5All);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1704, 461);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Voided";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // panelTab5All
            // 
            this.panelTab5All.Controls.Add(this.panelTab5Bottom);
            this.panelTab5All.Controls.Add(this.panelTab5Top);
            this.panelTab5All.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTab5All.Location = new System.Drawing.Point(0, 0);
            this.panelTab5All.Name = "panelTab5All";
            this.panelTab5All.Size = new System.Drawing.Size(1704, 461);
            this.panelTab5All.TabIndex = 0;
            // 
            // panelTab5Bottom
            // 
            this.panelTab5Bottom.Controls.Add(this.dgv5);
            this.panelTab5Bottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTab5Bottom.Location = new System.Drawing.Point(0, 46);
            this.panelTab5Bottom.Name = "panelTab5Bottom";
            this.panelTab5Bottom.Size = new System.Drawing.Size(1704, 415);
            this.panelTab5Bottom.TabIndex = 2;
            // 
            // dgv5
            // 
            this.dgv5.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv5.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv5.Location = new System.Drawing.Point(0, 0);
            this.dgv5.MainView = this.gridMain5;
            this.dgv5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv5.Name = "dgv5";
            this.dgv5.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox4});
            this.dgv5.Size = new System.Drawing.Size(1704, 415);
            this.dgv5.TabIndex = 6;
            this.dgv5.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain5});
            // 
            // gridMain5
            // 
            this.gridMain5.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain5.Appearance.BandPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain5.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain5.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain5.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.BandPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain5.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain5.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain5.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain5.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain5.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain5.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain5.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.ColumnFilterButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain5.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain5.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain5.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain5.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(244)))));
            this.gridMain5.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(222)))), ((int)(((byte)(183)))));
            this.gridMain5.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(244)))));
            this.gridMain5.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.ColumnFilterButtonActive.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain5.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain5.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain5.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain5.Appearance.Empty.BackColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain5.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain5.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain5.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain5.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain5.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain5.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain5.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain5.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain5.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(158)))), ((int)(((byte)(126)))));
            this.gridMain5.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(128)))), ((int)(((byte)(88)))));
            this.gridMain5.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain5.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain5.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain5.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain5.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain5.Appearance.FooterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain5.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain5.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FooterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain5.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain5.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain5.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain5.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain5.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain5.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain5.Appearance.GroupFooter.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain5.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain5.Appearance.GroupFooter.Options.UseFont = true;
            this.gridMain5.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(158)))), ((int)(((byte)(126)))));
            this.gridMain5.Appearance.GroupPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain5.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain5.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain5.Appearance.GroupRow.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain5.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain5.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain5.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain5.Appearance.HeaderPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain5.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain5.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.HeaderPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain5.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain5.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain5.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(207)))), ((int)(((byte)(170)))));
            this.gridMain5.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain5.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(168)))), ((int)(((byte)(128)))));
            this.gridMain5.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain5.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.gridMain5.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain5.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain5.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain5.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.Row.Options.UseBackColor = true;
            this.gridMain5.Appearance.Row.Options.UseForeColor = true;
            this.gridMain5.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain5.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(178)))), ((int)(((byte)(133)))));
            this.gridMain5.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(160)))), ((int)(((byte)(188)))));
            this.gridMain5.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain5.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain5.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain5.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand4});
            this.gridMain5.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn72,
            this.bandedGridColumn87,
            this.bandedGridColumn73,
            this.bandedGridColumn74,
            this.bandedGridColumn75,
            this.bandedGridColumn76,
            this.bandedGridColumn77,
            this.bandedGridColumn78,
            this.bandedGridColumn79,
            this.bandedGridColumn80,
            this.bandedGridColumn81,
            this.bandedGridColumn82,
            this.bandedGridColumn83,
            this.bandedGridColumn84,
            this.bandedGridColumn85,
            this.bandedGridColumn86});
            this.gridMain5.DetailHeight = 431;
            this.gridMain5.GridControl = this.dgv5;
            this.gridMain5.Name = "gridMain5";
            this.gridMain5.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain5.OptionsNavigation.EnterMoveNextColumn = true;
            this.gridMain5.OptionsPrint.PrintBandHeader = false;
            this.gridMain5.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain5.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain5.OptionsView.ShowFooter = true;
            this.gridMain5.OptionsView.ShowGroupPanel = false;
            this.gridMain5.PaintStyleName = "Flat";
            this.gridMain5.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain_CustomColumnDisplayText);
            // 
            // gridBand4
            // 
            this.gridBand4.Columns.Add(this.bandedGridColumn72);
            this.gridBand4.Columns.Add(this.bandedGridColumn73);
            this.gridBand4.Columns.Add(this.bandedGridColumn74);
            this.gridBand4.Columns.Add(this.bandedGridColumn75);
            this.gridBand4.Columns.Add(this.bandedGridColumn76);
            this.gridBand4.Columns.Add(this.bandedGridColumn77);
            this.gridBand4.Columns.Add(this.bandedGridColumn78);
            this.gridBand4.Columns.Add(this.bandedGridColumn79);
            this.gridBand4.Columns.Add(this.bandedGridColumn80);
            this.gridBand4.Columns.Add(this.bandedGridColumn81);
            this.gridBand4.Columns.Add(this.bandedGridColumn82);
            this.gridBand4.Columns.Add(this.bandedGridColumn83);
            this.gridBand4.Columns.Add(this.bandedGridColumn84);
            this.gridBand4.Columns.Add(this.bandedGridColumn85);
            this.gridBand4.Columns.Add(this.bandedGridColumn86);
            this.gridBand4.Columns.Add(this.bandedGridColumn87);
            this.gridBand4.MinWidth = 22;
            this.gridBand4.Name = "gridBand4";
            this.gridBand4.VisibleIndex = 0;
            this.gridBand4.Width = 1358;
            // 
            // bandedGridColumn72
            // 
            this.bandedGridColumn72.AppearanceHeader.ForeColor = System.Drawing.Color.Black;
            this.bandedGridColumn72.AppearanceHeader.Options.UseForeColor = true;
            this.bandedGridColumn72.Caption = "Num";
            this.bandedGridColumn72.FieldName = "num";
            this.bandedGridColumn72.MinWidth = 42;
            this.bandedGridColumn72.Name = "bandedGridColumn72";
            this.bandedGridColumn72.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn72.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn72.Visible = true;
            this.bandedGridColumn72.Width = 42;
            // 
            // bandedGridColumn73
            // 
            this.bandedGridColumn73.Caption = "Transaction Date";
            this.bandedGridColumn73.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn73.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn73.FieldName = "transactionDate";
            this.bandedGridColumn73.MinWidth = 25;
            this.bandedGridColumn73.Name = "bandedGridColumn73";
            this.bandedGridColumn73.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn73.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn73.Visible = true;
            this.bandedGridColumn73.Width = 94;
            // 
            // bandedGridColumn74
            // 
            this.bandedGridColumn74.Caption = "Transaction Type";
            this.bandedGridColumn74.FieldName = "transactionType";
            this.bandedGridColumn74.MinWidth = 34;
            this.bandedGridColumn74.Name = "bandedGridColumn74";
            this.bandedGridColumn74.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn74.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn74.Visible = true;
            this.bandedGridColumn74.Width = 99;
            // 
            // bandedGridColumn75
            // 
            this.bandedGridColumn75.Caption = "Card Number";
            this.bandedGridColumn75.FieldName = "cardNumber";
            this.bandedGridColumn75.MinWidth = 40;
            this.bandedGridColumn75.Name = "bandedGridColumn75";
            this.bandedGridColumn75.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn75.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn75.Visible = true;
            this.bandedGridColumn75.Width = 79;
            // 
            // bandedGridColumn76
            // 
            this.bandedGridColumn76.Caption = "Payment Type";
            this.bandedGridColumn76.FieldName = "paymentType";
            this.bandedGridColumn76.MinWidth = 40;
            this.bandedGridColumn76.Name = "bandedGridColumn76";
            this.bandedGridColumn76.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn76.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn76.Visible = true;
            this.bandedGridColumn76.Width = 131;
            // 
            // bandedGridColumn77
            // 
            this.bandedGridColumn77.Caption = "Authorized Amount";
            this.bandedGridColumn77.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn77.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn77.FieldName = "authorizedAmount";
            this.bandedGridColumn77.MinWidth = 40;
            this.bandedGridColumn77.Name = "bandedGridColumn77";
            this.bandedGridColumn77.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn77.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn77.Visible = true;
            this.bandedGridColumn77.Width = 104;
            // 
            // bandedGridColumn78
            // 
            this.bandedGridColumn78.Caption = "Transaction Amount";
            this.bandedGridColumn78.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn78.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn78.FieldName = "transactionAmount";
            this.bandedGridColumn78.MinWidth = 40;
            this.bandedGridColumn78.Name = "bandedGridColumn78";
            this.bandedGridColumn78.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn78.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn78.Visible = true;
            this.bandedGridColumn78.Width = 114;
            // 
            // bandedGridColumn79
            // 
            this.bandedGridColumn79.Caption = "Return/Void";
            this.bandedGridColumn79.FieldName = "returnVoid";
            this.bandedGridColumn79.MinWidth = 40;
            this.bandedGridColumn79.Name = "bandedGridColumn79";
            this.bandedGridColumn79.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn79.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn79.Visible = true;
            this.bandedGridColumn79.Width = 106;
            // 
            // bandedGridColumn80
            // 
            this.bandedGridColumn80.Caption = "Amount";
            this.bandedGridColumn80.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn80.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn80.FieldName = "amount";
            this.bandedGridColumn80.MinWidth = 40;
            this.bandedGridColumn80.Name = "bandedGridColumn80";
            this.bandedGridColumn80.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn80.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn80.Visible = true;
            this.bandedGridColumn80.Width = 121;
            // 
            // bandedGridColumn81
            // 
            this.bandedGridColumn81.Caption = "Sales Tax";
            this.bandedGridColumn81.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn81.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn81.FieldName = "salesTax";
            this.bandedGridColumn81.MinWidth = 40;
            this.bandedGridColumn81.Name = "bandedGridColumn81";
            this.bandedGridColumn81.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn81.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn81.Width = 64;
            // 
            // bandedGridColumn82
            // 
            this.bandedGridColumn82.Caption = "Fee";
            this.bandedGridColumn82.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn82.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn82.FieldName = "fee";
            this.bandedGridColumn82.MinWidth = 40;
            this.bandedGridColumn82.Name = "bandedGridColumn82";
            this.bandedGridColumn82.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn82.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn82.Width = 71;
            // 
            // bandedGridColumn83
            // 
            this.bandedGridColumn83.Caption = "Surcharge";
            this.bandedGridColumn83.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn83.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn83.FieldName = "surCharge";
            this.bandedGridColumn83.MinWidth = 40;
            this.bandedGridColumn83.Name = "bandedGridColumn83";
            this.bandedGridColumn83.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn83.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn83.Width = 89;
            // 
            // bandedGridColumn84
            // 
            this.bandedGridColumn84.Caption = "Trust or Funeral";
            this.bandedGridColumn84.ColumnEdit = this.repositoryItemComboBox4;
            this.bandedGridColumn84.FieldName = "trustFuneral";
            this.bandedGridColumn84.MinWidth = 40;
            this.bandedGridColumn84.Name = "bandedGridColumn84";
            this.bandedGridColumn84.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn84.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn84.Visible = true;
            this.bandedGridColumn84.Width = 83;
            // 
            // repositoryItemComboBox4
            // 
            this.repositoryItemComboBox4.AutoHeight = false;
            this.repositoryItemComboBox4.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox4.Items.AddRange(new object[] {
            "Trust",
            "Insurance",
            "Funeral"});
            this.repositoryItemComboBox4.Name = "repositoryItemComboBox4";
            // 
            // bandedGridColumn85
            // 
            this.bandedGridColumn85.Caption = "Invoice Number";
            this.bandedGridColumn85.FieldName = "invoiceNumber";
            this.bandedGridColumn85.MinWidth = 40;
            this.bandedGridColumn85.Name = "bandedGridColumn85";
            this.bandedGridColumn85.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn85.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn85.Visible = true;
            this.bandedGridColumn85.Width = 228;
            // 
            // bandedGridColumn86
            // 
            this.bandedGridColumn86.Caption = "Reference Number";
            this.bandedGridColumn86.FieldName = "referenceNumber";
            this.bandedGridColumn86.MinWidth = 29;
            this.bandedGridColumn86.Name = "bandedGridColumn86";
            this.bandedGridColumn86.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn86.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn86.Visible = true;
            this.bandedGridColumn86.Width = 157;
            // 
            // bandedGridColumn87
            // 
            this.bandedGridColumn87.Caption = "record";
            this.bandedGridColumn87.FieldName = "record";
            this.bandedGridColumn87.MinWidth = 42;
            this.bandedGridColumn87.Name = "bandedGridColumn87";
            this.bandedGridColumn87.Width = 161;
            // 
            // panelTab5Top
            // 
            this.panelTab5Top.Controls.Add(this.chkHonorDates4);
            this.panelTab5Top.Controls.Add(this.label3);
            this.panelTab5Top.Controls.Add(this.label4);
            this.panelTab5Top.Controls.Add(this.dateTimePicker6);
            this.panelTab5Top.Controls.Add(this.dateTimePicker7);
            this.panelTab5Top.Controls.Add(this.btnPullVoids);
            this.panelTab5Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTab5Top.Location = new System.Drawing.Point(0, 0);
            this.panelTab5Top.Name = "panelTab5Top";
            this.panelTab5Top.Size = new System.Drawing.Size(1704, 46);
            this.panelTab5Top.TabIndex = 1;
            // 
            // chkHonorDates4
            // 
            this.chkHonorDates4.AutoSize = true;
            this.chkHonorDates4.Location = new System.Drawing.Point(1087, 13);
            this.chkHonorDates4.Name = "chkHonorDates4";
            this.chkHonorDates4.Size = new System.Drawing.Size(228, 21);
            this.chkHonorDates4.TabIndex = 168;
            this.chkHonorDates4.Text = "Honor Search Transaction Dates";
            this.chkHonorDates4.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(465, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 17);
            this.label3.TabIndex = 167;
            this.label3.Text = "Search Dates :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(800, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 17);
            this.label4.TabIndex = 166;
            this.label4.Text = "-To-";
            // 
            // dateTimePicker6
            // 
            this.dateTimePicker6.Location = new System.Drawing.Point(564, 12);
            this.dateTimePicker6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker6.Name = "dateTimePicker6";
            this.dateTimePicker6.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker6.TabIndex = 165;
            // 
            // dateTimePicker7
            // 
            this.dateTimePicker7.Location = new System.Drawing.Point(835, 12);
            this.dateTimePicker7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dateTimePicker7.Name = "dateTimePicker7";
            this.dateTimePicker7.Size = new System.Drawing.Size(233, 23);
            this.dateTimePicker7.TabIndex = 164;
            // 
            // btnPullVoids
            // 
            this.btnPullVoids.Location = new System.Drawing.Point(299, 11);
            this.btnPullVoids.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnPullVoids.Name = "btnPullVoids";
            this.btnPullVoids.Size = new System.Drawing.Size(139, 28);
            this.btnPullVoids.TabIndex = 163;
            this.btnPullVoids.Text = "Pull Voided Data";
            this.btnPullVoids.UseVisualStyleBackColor = true;
            this.btnPullVoids.Click += new System.EventHandler(this.btnPullVoids_Click);
            // 
            // panelTop
            // 
            this.panelTop.Controls.Add(this.picAdd);
            this.panelTop.Controls.Add(this.pictureDelete);
            this.panelTop.Controls.Add(this.pictureBox1);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1712, 49);
            this.panelTop.TabIndex = 7;
            // 
            // picAdd
            // 
            this.picAdd.Image = ((System.Drawing.Image)(resources.GetObject("picAdd.Image")));
            this.picAdd.Location = new System.Drawing.Point(65, 10);
            this.picAdd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.picAdd.Name = "picAdd";
            this.picAdd.Size = new System.Drawing.Size(36, 28);
            this.picAdd.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picAdd.TabIndex = 153;
            this.picAdd.TabStop = false;
            this.picAdd.Tag = "Add Extra ACH";
            this.picAdd.Click += new System.EventHandler(this.picAdd_Click);
            // 
            // pictureDelete
            // 
            this.pictureDelete.Image = ((System.Drawing.Image)(resources.GetObject("pictureDelete.Image")));
            this.pictureDelete.Location = new System.Drawing.Point(120, 10);
            this.pictureDelete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureDelete.Name = "pictureDelete";
            this.pictureDelete.Size = new System.Drawing.Size(36, 28);
            this.pictureDelete.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureDelete.TabIndex = 151;
            this.pictureDelete.TabStop = false;
            this.pictureDelete.Tag = "Ignore ACH";
            this.pictureDelete.Click += new System.EventHandler(this.pictureDelete_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(33, 27);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 146;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unPostToolStripMenuItem});
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(130, 28);
            // 
            // unPostToolStripMenuItem
            // 
            this.unPostToolStripMenuItem.Name = "unPostToolStripMenuItem";
            this.unPostToolStripMenuItem.Size = new System.Drawing.Size(129, 24);
            this.unPostToolStripMenuItem.Text = "Un-Post";
            this.unPostToolStripMenuItem.Click += new System.EventHandler(this.unPostToolStripMenuItem_Click);
            // 
            // CCImport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1712, 569);
            this.Controls.Add(this.panelAll);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "CCImport";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Import Bank Credit Card File";
            this.Load += new System.EventHandler(this.CCImport_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelAll.ResumeLayout(false);
            this.panelBottom.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panelTab1All.ResumeLayout(false);
            this.panelTab1Bottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            this.panelTab1Top.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.panelTab2All.ResumeLayout(false);
            this.panelTab2Bottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv2)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridMain2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox5)).EndInit();
            this.panelTab2Top.ResumeLayout(false);
            this.panelTab2Top.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.panelTab3All.ResumeLayout(false);
            this.panelTab3Bottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).EndInit();
            this.panelTab3Top.ResumeLayout(false);
            this.panelTab3Top.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.panelTab4All.ResumeLayout(false);
            this.panelTab4Bottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox3)).EndInit();
            this.panelTab4Top.ResumeLayout(false);
            this.panelTab4Top.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.panelTab5All.ResumeLayout(false);
            this.panelTab5Bottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox4)).EndInit();
            this.panelTab5Top.ResumeLayout(false);
            this.panelTab5Top.PerformLayout();
            this.panelTop.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picAdd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.contextMenuStrip3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Panel panelAll;
        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label lblEffectiveDate;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevExpress.XtraGrid.GridControl dgv;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn7;
        private System.Windows.Forms.PictureBox pictureDelete;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.PictureBox picAdd;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.Panel panelTab1All;
        private System.Windows.Forms.Panel panelTab1Bottom;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn8;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn9;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn11;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn12;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn13;
        private System.Windows.Forms.Panel panelTab1Top;
        private System.Windows.Forms.Button btnPullFile;
        private System.Windows.Forms.Panel panelTab2All;
        private System.Windows.Forms.Panel panelTab2Bottom;
        private System.Windows.Forms.Panel panelTab2Top;
        private DevExpress.XtraGrid.GridControl dgv2;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn14;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn15;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn16;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn17;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn18;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn19;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn20;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn21;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn22;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn23;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn24;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn25;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn26;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn27;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        private System.Windows.Forms.Button btnSaveNotPosted;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panelTab3All;
        private System.Windows.Forms.Panel panelTab3Bottom;
        private DevExpress.XtraGrid.GridControl dgv3;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn28;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn29;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn30;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn31;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn32;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn33;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn34;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn35;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn36;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn37;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn38;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn39;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn40;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn41;
        private System.Windows.Forms.Panel panelTab3Top;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn42;
        private System.Windows.Forms.Button btnPullNotPosted;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn43;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private System.Windows.Forms.Button btnPost;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn44;
        private System.Windows.Forms.CheckBox chkHonorDates;
        private System.Windows.Forms.Button btnPullPostedData;
        private System.Windows.Forms.ToolStripMenuItem duplicatePaymentToolStripMenuItem;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn45;
        private System.Windows.Forms.Button btnSaveChangedData;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem duplicatePaymentToolStripMenuItem1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn46;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn47;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn48;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn49;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand1;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn50;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn51;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel panelTab4All;
        private System.Windows.Forms.Panel panelTab4Bottom;
        private DevExpress.XtraGrid.GridControl dgv4;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain4;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn52;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn53;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn54;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn55;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn56;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn57;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn58;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn59;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn60;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn61;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn62;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn63;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn64;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn65;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn66;
        private System.Windows.Forms.Panel panelTab4Top;
        private System.Windows.Forms.Button btnPullDeclined;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn67;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn68;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn69;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn70;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn71;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn88;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Panel panelTab5All;
        private System.Windows.Forms.Panel panelTab5Bottom;
        private DevExpress.XtraGrid.GridControl dgv5;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain5;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn72;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn73;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn74;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn75;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn76;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn77;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn78;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn79;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn80;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn81;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn82;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn83;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn84;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn85;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn86;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn87;
        private System.Windows.Forms.Panel panelTab5Top;
        private System.Windows.Forms.Button btnPullVoids;
        private System.Windows.Forms.CheckBox chkHonorDates3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dateTimePicker4;
        private System.Windows.Forms.DateTimePicker dateTimePicker5;
        private System.Windows.Forms.CheckBox chkHonorDates4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePicker6;
        private System.Windows.Forms.DateTimePicker dateTimePicker7;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox5;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.ToolStripMenuItem unPostToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editInvoiceNumberToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editInvoiceNumberToolStripMenuItem1;
    }
}