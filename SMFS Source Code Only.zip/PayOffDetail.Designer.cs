﻿namespace SMFS
{
    partial class PayOffDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelAll = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgv = new DevExpress.XtraGrid.GridControl();
            this.gridMain = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand2 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn12 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn1 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn8 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn22 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repositoryItemComboBox2 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panelRecalcAll = new System.Windows.Forms.Panel();
            this.panelRecalcBottom = new System.Windows.Forms.Panel();
            this.dgv3 = new DevExpress.XtraGrid.GridControl();
            this.gridMain3 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand4 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn38 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn39 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn40 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn41 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn42 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn43 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn44 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand5 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn45 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn46 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn47 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn48 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn24 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn49 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn50 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn51 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn52 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn23 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn53 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn54 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn55 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn56 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn57 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn58 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn59 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn60 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn61 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn62 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn10 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn11 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn63 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn64 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn65 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn66 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn67 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn68 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn69 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn70 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn71 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn72 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn73 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn74 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn75 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelRecalcTop = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.txtScale = new System.Windows.Forms.TextBox();
            this.btnCA = new System.Windows.Forms.Button();
            this.btnRecalc = new System.Windows.Forms.Button();
            this.txtAPR = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtAsOf = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTotalTrust85P = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTrust85Pending = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtFixTrust85P = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCPTrust85P = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTrust85P = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTrust100P = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panelAmortAll = new System.Windows.Forms.Panel();
            this.panelAmortBottom = new System.Windows.Forms.Panel();
            this.dgv4 = new DevExpress.XtraGrid.GridControl();
            this.gridMain4 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand6 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn76 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn77 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn78 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn79 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn80 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn81 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn82 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand7 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn83 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn84 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn85 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn86 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn87 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn88 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn89 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn90 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn91 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn92 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn93 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn94 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn95 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn96 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn97 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn98 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn99 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn2 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn3 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn13 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn14 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn100 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn101 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn102 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn103 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn104 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn105 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn106 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn107 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn108 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn109 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn110 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn111 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn112 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn113 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.panelAmortTop = new System.Windows.Forms.Panel();
            this.txtAPR_2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.btnRun = new System.Windows.Forms.Button();
            this.chkUseCalcualatedPayment = new System.Windows.Forms.CheckBox();
            this.txtCalculatedPayment = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtContractPayment = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgv5 = new DevExpress.XtraGrid.GridControl();
            this.gridMain5 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand1 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn4 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn9 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.gridBand3 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn5 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn16 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn7 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn6 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn21 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn118 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dgv6 = new DevExpress.XtraGrid.GridControl();
            this.gridMain6 = new DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView();
            this.gridBand8 = new DevExpress.XtraGrid.Views.BandedGrid.GridBand();
            this.bandedGridColumn15 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn17 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn18 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn19 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.bandedGridColumn20 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.repositoryItemComboBox3 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.repositoryItemComboBox4 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bandedGridColumn25 = new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn();
            this.menuStrip1.SuspendLayout();
            this.panelAll.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.panelRecalcAll.SuspendLayout();
            this.panelRecalcBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).BeginInit();
            this.panelRecalcTop.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panelAmortAll.SuspendLayout();
            this.panelAmortBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain4)).BeginInit();
            this.panelAmortTop.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain5)).BeginInit();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1665, 28);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printPreviewToolStripMenuItem,
            this.printToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(122, 26);
            this.toolStripMenuItem1.Text = "Print";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printPreviewToolStripMenuItem.Text = "Print Preview";
            this.printPreviewToolStripMenuItem.Click += new System.EventHandler(this.printPreviewToolStripMenuItem_Click);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.printToolStripMenuItem.Text = "Print";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(122, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // panelAll
            // 
            this.panelAll.Controls.Add(this.tabControl1);
            this.panelAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAll.Location = new System.Drawing.Point(0, 28);
            this.panelAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelAll.Name = "panelAll";
            this.panelAll.Size = new System.Drawing.Size(1665, 492);
            this.panelAll.TabIndex = 6;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1665, 492);
            this.tabControl1.TabIndex = 8;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgv);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1.Size = new System.Drawing.Size(1657, 463);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Payoff Detail";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgv
            // 
            this.dgv.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv.Location = new System.Drawing.Point(3, 4);
            this.dgv.LookAndFeel.SkinName = "iMaginary";
            this.dgv.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv.MainView = this.gridMain;
            this.dgv.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv.Name = "dgv";
            this.dgv.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox1,
            this.repositoryItemComboBox2});
            this.dgv.Size = new System.Drawing.Size(1651, 455);
            this.dgv.TabIndex = 7;
            this.dgv.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain});
            // 
            // gridMain
            // 
            this.gridMain.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.BandPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.BandPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.ColumnFilterButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(244)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(213)))), ((int)(((byte)(222)))), ((int)(((byte)(183)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(255)))), ((int)(((byte)(244)))));
            this.gridMain.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.ColumnFilterButtonActive.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain.Appearance.Empty.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(158)))), ((int)(((byte)(126)))));
            this.gridMain.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(96)))), ((int)(((byte)(128)))), ((int)(((byte)(88)))));
            this.gridMain.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedCell.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FocusedCell.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FocusedCell.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedCell.Options.UseForeColor = true;
            this.gridMain.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.FooterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.FooterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain.Appearance.GroupFooter.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupFooter.Options.UseFont = true;
            this.gridMain.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(139)))), ((int)(((byte)(158)))), ((int)(((byte)(126)))));
            this.gridMain.Appearance.GroupPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(230)))), ((int)(((byte)(195)))));
            this.gridMain.Appearance.GroupRow.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.HeaderPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(199)))), ((int)(((byte)(146)))));
            this.gridMain.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(244)))), ((int)(((byte)(247)))), ((int)(((byte)(222)))));
            this.gridMain.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.HeaderPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(197)))), ((int)(((byte)(207)))), ((int)(((byte)(170)))));
            this.gridMain.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(168)))), ((int)(((byte)(128)))));
            this.gridMain.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(253)))), ((int)(((byte)(247)))));
            this.gridMain.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(160)))), ((int)(((byte)(112)))));
            this.gridMain.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain.Appearance.Row.Options.UseBackColor = true;
            this.gridMain.Appearance.Row.Options.UseForeColor = true;
            this.gridMain.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(178)))), ((int)(((byte)(133)))));
            this.gridMain.Appearance.SelectedRow.ForeColor = System.Drawing.Color.White;
            this.gridMain.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain.Appearance.TopNewRow.BackColor = System.Drawing.Color.White;
            this.gridMain.Appearance.TopNewRow.Options.UseBackColor = true;
            this.gridMain.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(160)))), ((int)(((byte)(188)))));
            this.gridMain.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand2});
            this.gridMain.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn12,
            this.bandedGridColumn1,
            this.bandedGridColumn8,
            this.bandedGridColumn22});
            this.gridMain.DetailHeight = 431;
            this.gridMain.GridControl = this.dgv;
            this.gridMain.Name = "gridMain";
            this.gridMain.OptionsBehavior.AutoPopulateColumns = false;
            this.gridMain.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.Click;
            this.gridMain.OptionsPrint.AutoWidth = false;
            this.gridMain.OptionsPrint.PrintBandHeader = false;
            this.gridMain.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain.OptionsView.ShowBands = false;
            this.gridMain.OptionsView.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowAlways;
            this.gridMain.OptionsView.ShowFooter = true;
            this.gridMain.OptionsView.ShowGroupPanel = false;
            this.gridMain.PaintStyleName = "Flat";
            this.gridMain.CustomDrawCell += new DevExpress.XtraGrid.Views.Base.RowCellCustomDrawEventHandler(this.gridMain_CustomDrawCell);
            this.gridMain.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gridMain_CellValueChanged);
            // 
            // gridBand2
            // 
            this.gridBand2.Caption = "gridBand1";
            this.gridBand2.Columns.Add(this.bandedGridColumn12);
            this.gridBand2.Columns.Add(this.bandedGridColumn1);
            this.gridBand2.Columns.Add(this.bandedGridColumn8);
            this.gridBand2.Columns.Add(this.bandedGridColumn22);
            this.gridBand2.MinWidth = 19;
            this.gridBand2.Name = "gridBand2";
            this.gridBand2.VisibleIndex = 0;
            this.gridBand2.Width = 667;
            // 
            // bandedGridColumn12
            // 
            this.bandedGridColumn12.Caption = "Description";
            this.bandedGridColumn12.FieldName = "description";
            this.bandedGridColumn12.MinWidth = 23;
            this.bandedGridColumn12.Name = "bandedGridColumn12";
            this.bandedGridColumn12.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn12.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn12.Visible = true;
            this.bandedGridColumn12.Width = 292;
            // 
            // bandedGridColumn1
            // 
            this.bandedGridColumn1.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn1.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn1.Caption = "Trust85P";
            this.bandedGridColumn1.FieldName = "value";
            this.bandedGridColumn1.MinWidth = 31;
            this.bandedGridColumn1.Name = "bandedGridColumn1";
            this.bandedGridColumn1.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn1.Visible = true;
            this.bandedGridColumn1.Width = 125;
            // 
            // bandedGridColumn8
            // 
            this.bandedGridColumn8.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn8.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn8.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn8.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn8.Caption = "Calculated Trust100P";
            this.bandedGridColumn8.FieldName = "trust100P";
            this.bandedGridColumn8.MinWidth = 40;
            this.bandedGridColumn8.Name = "bandedGridColumn8";
            this.bandedGridColumn8.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn8.Visible = true;
            this.bandedGridColumn8.Width = 125;
            // 
            // bandedGridColumn22
            // 
            this.bandedGridColumn22.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn22.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn22.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn22.AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.bandedGridColumn22.Caption = "Daily History Trust100";
            this.bandedGridColumn22.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn22.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn22.FieldName = "dailyTrust100";
            this.bandedGridColumn22.MinWidth = 29;
            this.bandedGridColumn22.Name = "bandedGridColumn22";
            this.bandedGridColumn22.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn22.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn22.Visible = true;
            this.bandedGridColumn22.Width = 125;
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.AutoHeight = false;
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox1.Items.AddRange(new object[] {
            "Cash",
            "Check",
            "Master Card",
            "Visa",
            "American Express",
            "Trust",
            "Policy",
            "Insurance",
            "Other"});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            // 
            // repositoryItemComboBox2
            // 
            this.repositoryItemComboBox2.AutoComplete = false;
            this.repositoryItemComboBox2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox2.Items.AddRange(new object[] {
            "Cancelled",
            "Accept",
            "Rejected",
            "Pending"});
            this.repositoryItemComboBox2.Name = "repositoryItemComboBox2";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panelRecalcAll);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1657, 463);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Recalc Daily History";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panelRecalcAll
            // 
            this.panelRecalcAll.Controls.Add(this.panelRecalcBottom);
            this.panelRecalcAll.Controls.Add(this.panelRecalcTop);
            this.panelRecalcAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelRecalcAll.Location = new System.Drawing.Point(0, 0);
            this.panelRecalcAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelRecalcAll.Name = "panelRecalcAll";
            this.panelRecalcAll.Size = new System.Drawing.Size(1657, 463);
            this.panelRecalcAll.TabIndex = 6;
            // 
            // panelRecalcBottom
            // 
            this.panelRecalcBottom.Controls.Add(this.dgv3);
            this.panelRecalcBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelRecalcBottom.Location = new System.Drawing.Point(0, 64);
            this.panelRecalcBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelRecalcBottom.Name = "panelRecalcBottom";
            this.panelRecalcBottom.Size = new System.Drawing.Size(1657, 399);
            this.panelRecalcBottom.TabIndex = 8;
            // 
            // dgv3
            // 
            this.dgv3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv3.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Location = new System.Drawing.Point(0, 0);
            this.dgv3.LookAndFeel.SkinName = "iMaginary";
            this.dgv3.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv3.MainView = this.gridMain3;
            this.dgv3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv3.Name = "dgv3";
            this.dgv3.Size = new System.Drawing.Size(1657, 399);
            this.dgv3.TabIndex = 5;
            this.dgv3.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain3});
            // 
            // gridMain3
            // 
            this.gridMain3.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain3.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain3.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain3.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain3.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain3.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain3.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain3.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain3.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain3.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain3.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain3.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain3.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain3.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain3.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain3.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain3.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain3.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain3.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain3.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain3.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain3.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain3.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain3.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain3.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain3.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain3.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain3.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain3.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain3.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain3.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain3.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain3.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain3.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain3.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain3.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain3.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain3.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain3.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain3.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain3.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain3.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain3.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain3.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain3.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.Row.Options.UseBackColor = true;
            this.gridMain3.Appearance.Row.Options.UseForeColor = true;
            this.gridMain3.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain3.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain3.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain3.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain3.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain3.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain3.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain3.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain3.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain3.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain3.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain3.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand4,
            this.gridBand5});
            this.gridMain3.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain3.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn38,
            this.bandedGridColumn75,
            this.bandedGridColumn41,
            this.bandedGridColumn42,
            this.bandedGridColumn58,
            this.bandedGridColumn24,
            this.bandedGridColumn49,
            this.bandedGridColumn23,
            this.bandedGridColumn53,
            this.bandedGridColumn54,
            this.bandedGridColumn56,
            this.bandedGridColumn62,
            this.bandedGridColumn43,
            this.bandedGridColumn44,
            this.bandedGridColumn59,
            this.bandedGridColumn61,
            this.bandedGridColumn60,
            this.bandedGridColumn64,
            this.bandedGridColumn65,
            this.bandedGridColumn66,
            this.bandedGridColumn45,
            this.bandedGridColumn55,
            this.bandedGridColumn39,
            this.bandedGridColumn40,
            this.bandedGridColumn25,
            this.bandedGridColumn48,
            this.bandedGridColumn70,
            this.bandedGridColumn71,
            this.bandedGridColumn67,
            this.bandedGridColumn68,
            this.bandedGridColumn69,
            this.bandedGridColumn74,
            this.bandedGridColumn50,
            this.bandedGridColumn51,
            this.bandedGridColumn52,
            this.bandedGridColumn72,
            this.bandedGridColumn73,
            this.bandedGridColumn57,
            this.bandedGridColumn63,
            this.bandedGridColumn46,
            this.bandedGridColumn47,
            this.bandedGridColumn10,
            this.bandedGridColumn11});
            this.gridMain3.DetailHeight = 431;
            this.gridMain3.GridControl = this.dgv3;
            this.gridMain3.Name = "gridMain3";
            this.gridMain3.OptionsBehavior.Editable = false;
            this.gridMain3.OptionsBehavior.ReadOnly = true;
            this.gridMain3.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain3.OptionsPrint.AllowMultilineHeaders = true;
            this.gridMain3.OptionsPrint.PrintBandHeader = false;
            this.gridMain3.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain3.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain3.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain3.OptionsView.ShowBands = false;
            this.gridMain3.OptionsView.ShowFooter = true;
            this.gridMain3.OptionsView.ShowGroupPanel = false;
            this.gridMain3.PaintStyleName = "Style3D";
            this.gridMain3.CustomDrawFooterCell += new DevExpress.XtraGrid.Views.Grid.FooterCellCustomDrawEventHandler(this.gridMain_CustomDrawFooterCell);
            this.gridMain3.CustomSummaryCalculate += new DevExpress.Data.CustomSummaryEventHandler(this.gridMain3_CustomSummaryCalculate);
            this.gridMain3.CustomRowFilter += new DevExpress.XtraGrid.Views.Base.RowFilterEventHandler(this.gridMain3_CustomRowFilter);
            this.gridMain3.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain3_CustomColumnDisplayText);
            // 
            // gridBand4
            // 
            this.gridBand4.Caption = "gridBand2";
            this.gridBand4.Columns.Add(this.bandedGridColumn38);
            this.gridBand4.Columns.Add(this.bandedGridColumn39);
            this.gridBand4.Columns.Add(this.bandedGridColumn40);
            this.gridBand4.Columns.Add(this.bandedGridColumn41);
            this.gridBand4.Columns.Add(this.bandedGridColumn42);
            this.gridBand4.Columns.Add(this.bandedGridColumn43);
            this.gridBand4.Columns.Add(this.bandedGridColumn44);
            this.gridBand4.MinWidth = 14;
            this.gridBand4.Name = "gridBand4";
            this.gridBand4.VisibleIndex = 0;
            this.gridBand4.Width = 266;
            // 
            // bandedGridColumn38
            // 
            this.bandedGridColumn38.Caption = "Num";
            this.bandedGridColumn38.FieldName = "num";
            this.bandedGridColumn38.MinWidth = 23;
            this.bandedGridColumn38.Name = "bandedGridColumn38";
            this.bandedGridColumn38.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn38.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn38.Visible = true;
            this.bandedGridColumn38.Width = 58;
            // 
            // bandedGridColumn39
            // 
            this.bandedGridColumn39.Caption = "Stat";
            this.bandedGridColumn39.FieldName = "fill";
            this.bandedGridColumn39.MinWidth = 23;
            this.bandedGridColumn39.Name = "bandedGridColumn39";
            this.bandedGridColumn39.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn39.Width = 58;
            // 
            // bandedGridColumn40
            // 
            this.bandedGridColumn40.Caption = "Agent";
            this.bandedGridColumn40.FieldName = "agentNumber";
            this.bandedGridColumn40.MinWidth = 23;
            this.bandedGridColumn40.Name = "bandedGridColumn40";
            this.bandedGridColumn40.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn40.Width = 87;
            // 
            // bandedGridColumn41
            // 
            this.bandedGridColumn41.Caption = "Due Date";
            this.bandedGridColumn41.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn41.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn41.FieldName = "dueDate8";
            this.bandedGridColumn41.MinWidth = 23;
            this.bandedGridColumn41.Name = "bandedGridColumn41";
            this.bandedGridColumn41.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn41.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn41.Visible = true;
            this.bandedGridColumn41.Width = 104;
            // 
            // bandedGridColumn42
            // 
            this.bandedGridColumn42.Caption = "Due Date";
            this.bandedGridColumn42.FieldName = "dueDate8Print";
            this.bandedGridColumn42.MinWidth = 23;
            this.bandedGridColumn42.Name = "bandedGridColumn42";
            this.bandedGridColumn42.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn42.Width = 76;
            // 
            // bandedGridColumn43
            // 
            this.bandedGridColumn43.Caption = "Date Paid";
            this.bandedGridColumn43.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn43.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn43.FieldName = "payDate8";
            this.bandedGridColumn43.MinWidth = 23;
            this.bandedGridColumn43.Name = "bandedGridColumn43";
            this.bandedGridColumn43.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn43.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn43.Visible = true;
            this.bandedGridColumn43.Width = 104;
            // 
            // bandedGridColumn44
            // 
            this.bandedGridColumn44.Caption = "Date Paid";
            this.bandedGridColumn44.FieldName = "payDate8Print";
            this.bandedGridColumn44.MinWidth = 23;
            this.bandedGridColumn44.Name = "bandedGridColumn44";
            this.bandedGridColumn44.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn44.Width = 76;
            // 
            // gridBand5
            // 
            this.gridBand5.Caption = "gridBand1";
            this.gridBand5.Columns.Add(this.bandedGridColumn45);
            this.gridBand5.Columns.Add(this.bandedGridColumn46);
            this.gridBand5.Columns.Add(this.bandedGridColumn47);
            this.gridBand5.Columns.Add(this.bandedGridColumn25);
            this.gridBand5.Columns.Add(this.bandedGridColumn48);
            this.gridBand5.Columns.Add(this.bandedGridColumn24);
            this.gridBand5.Columns.Add(this.bandedGridColumn49);
            this.gridBand5.Columns.Add(this.bandedGridColumn50);
            this.gridBand5.Columns.Add(this.bandedGridColumn51);
            this.gridBand5.Columns.Add(this.bandedGridColumn52);
            this.gridBand5.Columns.Add(this.bandedGridColumn23);
            this.gridBand5.Columns.Add(this.bandedGridColumn53);
            this.gridBand5.Columns.Add(this.bandedGridColumn54);
            this.gridBand5.Columns.Add(this.bandedGridColumn55);
            this.gridBand5.Columns.Add(this.bandedGridColumn56);
            this.gridBand5.Columns.Add(this.bandedGridColumn57);
            this.gridBand5.Columns.Add(this.bandedGridColumn58);
            this.gridBand5.Columns.Add(this.bandedGridColumn59);
            this.gridBand5.Columns.Add(this.bandedGridColumn60);
            this.gridBand5.Columns.Add(this.bandedGridColumn61);
            this.gridBand5.Columns.Add(this.bandedGridColumn62);
            this.gridBand5.Columns.Add(this.bandedGridColumn10);
            this.gridBand5.Columns.Add(this.bandedGridColumn11);
            this.gridBand5.Columns.Add(this.bandedGridColumn63);
            this.gridBand5.Columns.Add(this.bandedGridColumn64);
            this.gridBand5.Columns.Add(this.bandedGridColumn65);
            this.gridBand5.Columns.Add(this.bandedGridColumn66);
            this.gridBand5.Columns.Add(this.bandedGridColumn67);
            this.gridBand5.Columns.Add(this.bandedGridColumn68);
            this.gridBand5.Columns.Add(this.bandedGridColumn69);
            this.gridBand5.Columns.Add(this.bandedGridColumn70);
            this.gridBand5.Columns.Add(this.bandedGridColumn71);
            this.gridBand5.Columns.Add(this.bandedGridColumn72);
            this.gridBand5.Columns.Add(this.bandedGridColumn73);
            this.gridBand5.Columns.Add(this.bandedGridColumn74);
            this.gridBand5.Columns.Add(this.bandedGridColumn75);
            this.gridBand5.MinWidth = 14;
            this.gridBand5.Name = "gridBand5";
            this.gridBand5.VisibleIndex = 1;
            this.gridBand5.Width = 1451;
            // 
            // bandedGridColumn45
            // 
            this.bandedGridColumn45.Caption = "Days";
            this.bandedGridColumn45.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn45.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn45.FieldName = "days";
            this.bandedGridColumn45.MinWidth = 23;
            this.bandedGridColumn45.Name = "bandedGridColumn45";
            this.bandedGridColumn45.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn45.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn45.Visible = true;
            this.bandedGridColumn45.Width = 96;
            // 
            // bandedGridColumn46
            // 
            this.bandedGridColumn46.Caption = "Last Name";
            this.bandedGridColumn46.FieldName = "lastName";
            this.bandedGridColumn46.MinWidth = 23;
            this.bandedGridColumn46.Name = "bandedGridColumn46";
            this.bandedGridColumn46.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn46.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn46.Width = 87;
            // 
            // bandedGridColumn47
            // 
            this.bandedGridColumn47.Caption = "First Name";
            this.bandedGridColumn47.FieldName = "firstName";
            this.bandedGridColumn47.MinWidth = 23;
            this.bandedGridColumn47.Name = "bandedGridColumn47";
            this.bandedGridColumn47.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn47.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn47.Width = 87;
            // 
            // bandedGridColumn48
            // 
            this.bandedGridColumn48.Caption = "Old Down Payment";
            this.bandedGridColumn48.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn48.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn48.FieldName = "downPayment";
            this.bandedGridColumn48.MinWidth = 23;
            this.bandedGridColumn48.Name = "bandedGridColumn48";
            this.bandedGridColumn48.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn48.Visible = true;
            this.bandedGridColumn48.Width = 87;
            // 
            // bandedGridColumn24
            // 
            this.bandedGridColumn24.Caption = "Payment";
            this.bandedGridColumn24.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn24.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn24.FieldName = "ap";
            this.bandedGridColumn24.MinWidth = 25;
            this.bandedGridColumn24.Name = "bandedGridColumn24";
            this.bandedGridColumn24.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn24.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn24.Visible = true;
            this.bandedGridColumn24.Width = 94;
            // 
            // bandedGridColumn49
            // 
            this.bandedGridColumn49.Caption = "Old Payment";
            this.bandedGridColumn49.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn49.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn49.FieldName = "paymentAmount";
            this.bandedGridColumn49.MinWidth = 23;
            this.bandedGridColumn49.Name = "bandedGridColumn49";
            this.bandedGridColumn49.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn49.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn49.Visible = true;
            this.bandedGridColumn49.Width = 82;
            // 
            // bandedGridColumn50
            // 
            this.bandedGridColumn50.Caption = "# Pmts";
            this.bandedGridColumn50.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn50.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn50.FieldName = "NumPayments";
            this.bandedGridColumn50.MinWidth = 23;
            this.bandedGridColumn50.Name = "bandedGridColumn50";
            this.bandedGridColumn50.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn50.Visible = true;
            this.bandedGridColumn50.Width = 58;
            // 
            // bandedGridColumn51
            // 
            this.bandedGridColumn51.Caption = "Location";
            this.bandedGridColumn51.FieldName = "location";
            this.bandedGridColumn51.MinWidth = 23;
            this.bandedGridColumn51.Name = "bandedGridColumn51";
            this.bandedGridColumn51.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn51.Width = 87;
            // 
            // bandedGridColumn52
            // 
            this.bandedGridColumn52.Caption = "Deposit Number";
            this.bandedGridColumn52.FieldName = "depositNumber";
            this.bandedGridColumn52.MinWidth = 23;
            this.bandedGridColumn52.Name = "bandedGridColumn52";
            this.bandedGridColumn52.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn52.Width = 87;
            // 
            // bandedGridColumn23
            // 
            this.bandedGridColumn23.Caption = "CC Fee";
            this.bandedGridColumn23.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn23.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn23.FieldName = "ccFee";
            this.bandedGridColumn23.MinWidth = 25;
            this.bandedGridColumn23.Name = "bandedGridColumn23";
            this.bandedGridColumn23.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn23.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn23.Visible = true;
            this.bandedGridColumn23.Width = 73;
            // 
            // bandedGridColumn53
            // 
            this.bandedGridColumn53.Caption = "Debit";
            this.bandedGridColumn53.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn53.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn53.FieldName = "debit";
            this.bandedGridColumn53.MinWidth = 12;
            this.bandedGridColumn53.Name = "bandedGridColumn53";
            this.bandedGridColumn53.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn53.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn53.Visible = true;
            this.bandedGridColumn53.Width = 96;
            // 
            // bandedGridColumn54
            // 
            this.bandedGridColumn54.Caption = "Credit";
            this.bandedGridColumn54.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn54.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn54.FieldName = "credit";
            this.bandedGridColumn54.MinWidth = 23;
            this.bandedGridColumn54.Name = "bandedGridColumn54";
            this.bandedGridColumn54.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn54.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn54.Visible = true;
            this.bandedGridColumn54.Width = 96;
            // 
            // bandedGridColumn55
            // 
            this.bandedGridColumn55.Caption = "Principal";
            this.bandedGridColumn55.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn55.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn55.FieldName = "prince";
            this.bandedGridColumn55.MinWidth = 23;
            this.bandedGridColumn55.Name = "bandedGridColumn55";
            this.bandedGridColumn55.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn55.Visible = true;
            this.bandedGridColumn55.Width = 87;
            // 
            // bandedGridColumn56
            // 
            this.bandedGridColumn56.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn56.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.bandedGridColumn56.Caption = "Interest Paid";
            this.bandedGridColumn56.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn56.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn56.FieldName = "interestPaid";
            this.bandedGridColumn56.MinWidth = 12;
            this.bandedGridColumn56.Name = "bandedGridColumn56";
            this.bandedGridColumn56.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn56.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn56.Visible = true;
            this.bandedGridColumn56.Width = 87;
            // 
            // bandedGridColumn57
            // 
            this.bandedGridColumn57.Caption = "Unpaid Interest";
            this.bandedGridColumn57.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn57.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn57.FieldName = "unpaid_interest";
            this.bandedGridColumn57.MinWidth = 23;
            this.bandedGridColumn57.Name = "bandedGridColumn57";
            this.bandedGridColumn57.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn57.Width = 87;
            // 
            // bandedGridColumn58
            // 
            this.bandedGridColumn58.Caption = "Balance";
            this.bandedGridColumn58.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn58.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn58.FieldName = "balance";
            this.bandedGridColumn58.MinWidth = 23;
            this.bandedGridColumn58.Name = "bandedGridColumn58";
            this.bandedGridColumn58.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn58.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn58.Visible = true;
            this.bandedGridColumn58.Width = 96;
            // 
            // bandedGridColumn59
            // 
            this.bandedGridColumn59.Caption = "Retained";
            this.bandedGridColumn59.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn59.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn59.FieldName = "retained";
            this.bandedGridColumn59.MinWidth = 23;
            this.bandedGridColumn59.Name = "bandedGridColumn59";
            this.bandedGridColumn59.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn59.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn59.Visible = true;
            this.bandedGridColumn59.Width = 87;
            // 
            // bandedGridColumn60
            // 
            this.bandedGridColumn60.Caption = "trust85P";
            this.bandedGridColumn60.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn60.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn60.FieldName = "trust85P";
            this.bandedGridColumn60.MinWidth = 23;
            this.bandedGridColumn60.Name = "bandedGridColumn60";
            this.bandedGridColumn60.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn60.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn60.Visible = true;
            this.bandedGridColumn60.Width = 96;
            // 
            // bandedGridColumn61
            // 
            this.bandedGridColumn61.Caption = "trust100P";
            this.bandedGridColumn61.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn61.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn61.FieldName = "trust100P";
            this.bandedGridColumn61.MinWidth = 23;
            this.bandedGridColumn61.Name = "bandedGridColumn61";
            this.bandedGridColumn61.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn61.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn61.Visible = true;
            this.bandedGridColumn61.Width = 96;
            // 
            // bandedGridColumn62
            // 
            this.bandedGridColumn62.Caption = "Reason";
            this.bandedGridColumn62.FieldName = "reason";
            this.bandedGridColumn62.MinWidth = 23;
            this.bandedGridColumn62.Name = "bandedGridColumn62";
            this.bandedGridColumn62.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn62.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn62.Width = 233;
            // 
            // bandedGridColumn10
            // 
            this.bandedGridColumn10.Caption = "Cumulative Trust85";
            this.bandedGridColumn10.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn10.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn10.FieldName = "cumulativeTrust85";
            this.bandedGridColumn10.MinWidth = 29;
            this.bandedGridColumn10.Name = "bandedGridColumn10";
            this.bandedGridColumn10.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn10.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn10.Visible = true;
            this.bandedGridColumn10.Width = 110;
            // 
            // bandedGridColumn11
            // 
            this.bandedGridColumn11.Caption = "Cumulative Trust100";
            this.bandedGridColumn11.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn11.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn11.FieldName = "cumulativeTrust100";
            this.bandedGridColumn11.MinWidth = 29;
            this.bandedGridColumn11.Name = "bandedGridColumn11";
            this.bandedGridColumn11.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn11.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn11.Visible = true;
            this.bandedGridColumn11.Width = 110;
            // 
            // bandedGridColumn63
            // 
            this.bandedGridColumn63.Caption = "ID";
            this.bandedGridColumn63.FieldName = "s50";
            this.bandedGridColumn63.MinWidth = 23;
            this.bandedGridColumn63.Name = "bandedGridColumn63";
            this.bandedGridColumn63.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn63.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn63.Width = 87;
            // 
            // bandedGridColumn64
            // 
            this.bandedGridColumn64.Caption = "Principal";
            this.bandedGridColumn64.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn64.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn64.FieldName = "principal";
            this.bandedGridColumn64.MinWidth = 23;
            this.bandedGridColumn64.Name = "bandedGridColumn64";
            this.bandedGridColumn64.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn64.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn64.Width = 87;
            // 
            // bandedGridColumn65
            // 
            this.bandedGridColumn65.Caption = "Interest";
            this.bandedGridColumn65.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn65.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn65.FieldName = "int";
            this.bandedGridColumn65.MinWidth = 23;
            this.bandedGridColumn65.Name = "bandedGridColumn65";
            this.bandedGridColumn65.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn65.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn65.Width = 87;
            // 
            // bandedGridColumn66
            // 
            this.bandedGridColumn66.Caption = "Balance";
            this.bandedGridColumn66.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn66.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn66.FieldName = "newbalance";
            this.bandedGridColumn66.MinWidth = 23;
            this.bandedGridColumn66.Name = "bandedGridColumn66";
            this.bandedGridColumn66.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn66.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn66.Width = 87;
            // 
            // bandedGridColumn67
            // 
            this.bandedGridColumn67.Caption = "Calculated Trust85";
            this.bandedGridColumn67.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn67.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn67.FieldName = "calculatedTrust85";
            this.bandedGridColumn67.MinWidth = 23;
            this.bandedGridColumn67.Name = "bandedGridColumn67";
            this.bandedGridColumn67.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn67.Width = 87;
            // 
            // bandedGridColumn68
            // 
            this.bandedGridColumn68.Caption = "Calculated Trust100";
            this.bandedGridColumn68.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn68.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn68.FieldName = "calculatedTrust100";
            this.bandedGridColumn68.MinWidth = 23;
            this.bandedGridColumn68.Name = "bandedGridColumn68";
            this.bandedGridColumn68.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn68.Width = 87;
            // 
            // bandedGridColumn69
            // 
            this.bandedGridColumn69.Caption = "Method";
            this.bandedGridColumn69.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn69.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn69.FieldName = "method";
            this.bandedGridColumn69.MinWidth = 23;
            this.bandedGridColumn69.Name = "bandedGridColumn69";
            this.bandedGridColumn69.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn69.Width = 70;
            // 
            // bandedGridColumn70
            // 
            this.bandedGridColumn70.AutoFillDown = true;
            this.bandedGridColumn70.Caption = "Next Due Date";
            this.bandedGridColumn70.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn70.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn70.FieldName = "nextDueDate";
            this.bandedGridColumn70.MinWidth = 23;
            this.bandedGridColumn70.Name = "bandedGridColumn70";
            this.bandedGridColumn70.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn70.Width = 87;
            // 
            // bandedGridColumn71
            // 
            this.bandedGridColumn71.Caption = "Credit Balance";
            this.bandedGridColumn71.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn71.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn71.FieldName = "creditBalance";
            this.bandedGridColumn71.MinWidth = 23;
            this.bandedGridColumn71.Name = "bandedGridColumn71";
            this.bandedGridColumn71.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn71.Width = 87;
            // 
            // bandedGridColumn72
            // 
            this.bandedGridColumn72.Caption = "Running CB";
            this.bandedGridColumn72.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn72.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn72.FieldName = "runningCB";
            this.bandedGridColumn72.MinWidth = 23;
            this.bandedGridColumn72.Name = "bandedGridColumn72";
            this.bandedGridColumn72.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn72.Width = 87;
            // 
            // bandedGridColumn73
            // 
            this.bandedGridColumn73.Caption = "Major CB";
            this.bandedGridColumn73.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn73.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn73.FieldName = "majorCB";
            this.bandedGridColumn73.MinWidth = 23;
            this.bandedGridColumn73.Name = "bandedGridColumn73";
            this.bandedGridColumn73.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn73.Width = 87;
            // 
            // bandedGridColumn74
            // 
            this.bandedGridColumn74.Caption = "Balance Used";
            this.bandedGridColumn74.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn74.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn74.FieldName = "oldBalance";
            this.bandedGridColumn74.MinWidth = 23;
            this.bandedGridColumn74.Name = "bandedGridColumn74";
            this.bandedGridColumn74.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn74.Width = 87;
            // 
            // bandedGridColumn75
            // 
            this.bandedGridColumn75.Caption = "record";
            this.bandedGridColumn75.FieldName = "record";
            this.bandedGridColumn75.MinWidth = 23;
            this.bandedGridColumn75.Name = "bandedGridColumn75";
            this.bandedGridColumn75.RowCount = 2;
            this.bandedGridColumn75.Width = 87;
            // 
            // panelRecalcTop
            // 
            this.panelRecalcTop.BackColor = System.Drawing.Color.PeachPuff;
            this.panelRecalcTop.Controls.Add(this.label12);
            this.panelRecalcTop.Controls.Add(this.txtScale);
            this.panelRecalcTop.Controls.Add(this.btnCA);
            this.panelRecalcTop.Controls.Add(this.btnRecalc);
            this.panelRecalcTop.Controls.Add(this.txtAPR);
            this.panelRecalcTop.Controls.Add(this.label10);
            this.panelRecalcTop.Controls.Add(this.txtAsOf);
            this.panelRecalcTop.Controls.Add(this.label9);
            this.panelRecalcTop.Controls.Add(this.txtTotalTrust85P);
            this.panelRecalcTop.Controls.Add(this.label8);
            this.panelRecalcTop.Controls.Add(this.txtTrust85Pending);
            this.panelRecalcTop.Controls.Add(this.label7);
            this.panelRecalcTop.Controls.Add(this.txtFixTrust85P);
            this.panelRecalcTop.Controls.Add(this.label6);
            this.panelRecalcTop.Controls.Add(this.txtCPTrust85P);
            this.panelRecalcTop.Controls.Add(this.label5);
            this.panelRecalcTop.Controls.Add(this.txtTrust85P);
            this.panelRecalcTop.Controls.Add(this.label4);
            this.panelRecalcTop.Controls.Add(this.txtTrust100P);
            this.panelRecalcTop.Controls.Add(this.label3);
            this.panelRecalcTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelRecalcTop.Location = new System.Drawing.Point(0, 0);
            this.panelRecalcTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelRecalcTop.Name = "panelRecalcTop";
            this.panelRecalcTop.Size = new System.Drawing.Size(1657, 64);
            this.panelRecalcTop.TabIndex = 7;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1022, 5);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(39, 17);
            this.label12.TabIndex = 152;
            this.label12.Text = "Scale";
            // 
            // txtScale
            // 
            this.txtScale.Location = new System.Drawing.Point(953, 5);
            this.txtScale.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtScale.Name = "txtScale";
            this.txtScale.Size = new System.Drawing.Size(63, 23);
            this.txtScale.TabIndex = 151;
            this.txtScale.Text = "100.00";
            this.txtScale.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtScale.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtScale_KeyUp);
            // 
            // btnCA
            // 
            this.btnCA.BackColor = System.Drawing.Color.DarkOrange;
            this.btnCA.Font = new System.Drawing.Font("Tahoma", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCA.Location = new System.Drawing.Point(1243, 6);
            this.btnCA.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCA.Name = "btnCA";
            this.btnCA.Size = new System.Drawing.Size(137, 49);
            this.btnCA.TabIndex = 17;
            this.btnCA.Text = "Issue CA";
            this.btnCA.UseVisualStyleBackColor = false;
            this.btnCA.Click += new System.EventHandler(this.btnCA_Click);
            // 
            // btnRecalc
            // 
            this.btnRecalc.BackColor = System.Drawing.Color.DarkOrange;
            this.btnRecalc.Location = new System.Drawing.Point(687, 2);
            this.btnRecalc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRecalc.Name = "btnRecalc";
            this.btnRecalc.Size = new System.Drawing.Size(87, 28);
            this.btnRecalc.TabIndex = 16;
            this.btnRecalc.Text = "ReCalc";
            this.btnRecalc.UseVisualStyleBackColor = false;
            this.btnRecalc.Click += new System.EventHandler(this.btnRecalc_Click);
            // 
            // txtAPR
            // 
            this.txtAPR.Location = new System.Drawing.Point(562, 3);
            this.txtAPR.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAPR.Name = "txtAPR";
            this.txtAPR.Size = new System.Drawing.Size(116, 23);
            this.txtAPR.TabIndex = 15;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(520, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 17);
            this.label10.TabIndex = 14;
            this.label10.Text = "APR :";
            // 
            // txtAsOf
            // 
            this.txtAsOf.Enabled = false;
            this.txtAsOf.Location = new System.Drawing.Point(307, 2);
            this.txtAsOf.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAsOf.Name = "txtAsOf";
            this.txtAsOf.Size = new System.Drawing.Size(116, 23);
            this.txtAsOf.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(257, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 17);
            this.label9.TabIndex = 12;
            this.label9.Text = "As Of :";
            // 
            // txtTotalTrust85P
            // 
            this.txtTotalTrust85P.Enabled = false;
            this.txtTotalTrust85P.Location = new System.Drawing.Point(796, 31);
            this.txtTotalTrust85P.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTotalTrust85P.Name = "txtTotalTrust85P";
            this.txtTotalTrust85P.Size = new System.Drawing.Size(116, 23);
            this.txtTotalTrust85P.TabIndex = 11;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(684, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(107, 17);
            this.label8.TabIndex = 10;
            this.label8.Text = "Total Trust85P :";
            // 
            // txtTrust85Pending
            // 
            this.txtTrust85Pending.Enabled = false;
            this.txtTrust85Pending.Location = new System.Drawing.Point(562, 31);
            this.txtTrust85Pending.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTrust85Pending.Name = "txtTrust85Pending";
            this.txtTrust85Pending.Size = new System.Drawing.Size(116, 23);
            this.txtTrust85Pending.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(437, 34);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(126, 17);
            this.label7.TabIndex = 8;
            this.label7.Text = "Pending Trust85P :";
            // 
            // txtFixTrust85P
            // 
            this.txtFixTrust85P.Enabled = false;
            this.txtFixTrust85P.Location = new System.Drawing.Point(1051, 32);
            this.txtFixTrust85P.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtFixTrust85P.Name = "txtFixTrust85P";
            this.txtFixTrust85P.Size = new System.Drawing.Size(116, 23);
            this.txtFixTrust85P.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(962, 36);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Fix Trust85P :";
            // 
            // txtCPTrust85P
            // 
            this.txtCPTrust85P.Enabled = false;
            this.txtCPTrust85P.Location = new System.Drawing.Point(307, 31);
            this.txtCPTrust85P.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCPTrust85P.Name = "txtCPTrust85P";
            this.txtCPTrust85P.Size = new System.Drawing.Size(116, 23);
            this.txtCPTrust85P.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(219, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "CP Trust85P :";
            // 
            // txtTrust85P
            // 
            this.txtTrust85P.Enabled = false;
            this.txtTrust85P.Location = new System.Drawing.Point(84, 31);
            this.txtTrust85P.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTrust85P.Name = "txtTrust85P";
            this.txtTrust85P.Size = new System.Drawing.Size(116, 23);
            this.txtTrust85P.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 17);
            this.label4.TabIndex = 2;
            this.label4.Text = "Trust85P :";
            // 
            // txtTrust100P
            // 
            this.txtTrust100P.Enabled = false;
            this.txtTrust100P.Location = new System.Drawing.Point(84, 2);
            this.txtTrust100P.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtTrust100P.Name = "txtTrust100P";
            this.txtTrust100P.Size = new System.Drawing.Size(116, 23);
            this.txtTrust100P.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "Trust100P :";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panelAmortAll);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1657, 461);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Amortization";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panelAmortAll
            // 
            this.panelAmortAll.Controls.Add(this.panelAmortBottom);
            this.panelAmortAll.Controls.Add(this.panelAmortTop);
            this.panelAmortAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAmortAll.Location = new System.Drawing.Point(0, 0);
            this.panelAmortAll.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelAmortAll.Name = "panelAmortAll";
            this.panelAmortAll.Size = new System.Drawing.Size(1657, 461);
            this.panelAmortAll.TabIndex = 6;
            // 
            // panelAmortBottom
            // 
            this.panelAmortBottom.Controls.Add(this.dgv4);
            this.panelAmortBottom.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAmortBottom.Location = new System.Drawing.Point(0, 49);
            this.panelAmortBottom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelAmortBottom.Name = "panelAmortBottom";
            this.panelAmortBottom.Size = new System.Drawing.Size(1657, 412);
            this.panelAmortBottom.TabIndex = 8;
            // 
            // dgv4
            // 
            this.dgv4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv4.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv4.Location = new System.Drawing.Point(0, 0);
            this.dgv4.LookAndFeel.SkinName = "iMaginary";
            this.dgv4.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv4.MainView = this.gridMain4;
            this.dgv4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv4.Name = "dgv4";
            this.dgv4.Size = new System.Drawing.Size(1657, 412);
            this.dgv4.TabIndex = 5;
            this.dgv4.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain4});
            // 
            // gridMain4
            // 
            this.gridMain4.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain4.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain4.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain4.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain4.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain4.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain4.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain4.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain4.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain4.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain4.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain4.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain4.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain4.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain4.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain4.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain4.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain4.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain4.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain4.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain4.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain4.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain4.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain4.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain4.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain4.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain4.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain4.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain4.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain4.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain4.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain4.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain4.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain4.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain4.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain4.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain4.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain4.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain4.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain4.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain4.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain4.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain4.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.Row.Options.UseBackColor = true;
            this.gridMain4.Appearance.Row.Options.UseForeColor = true;
            this.gridMain4.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain4.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain4.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain4.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain4.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain4.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain4.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain4.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain4.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain4.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain4.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain4.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand6,
            this.gridBand7});
            this.gridMain4.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain4.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn76,
            this.bandedGridColumn113,
            this.bandedGridColumn79,
            this.bandedGridColumn80,
            this.bandedGridColumn96,
            this.bandedGridColumn87,
            this.bandedGridColumn91,
            this.bandedGridColumn92,
            this.bandedGridColumn94,
            this.bandedGridColumn100,
            this.bandedGridColumn81,
            this.bandedGridColumn82,
            this.bandedGridColumn97,
            this.bandedGridColumn99,
            this.bandedGridColumn98,
            this.bandedGridColumn102,
            this.bandedGridColumn103,
            this.bandedGridColumn104,
            this.bandedGridColumn83,
            this.bandedGridColumn93,
            this.bandedGridColumn77,
            this.bandedGridColumn78,
            this.bandedGridColumn86,
            this.bandedGridColumn108,
            this.bandedGridColumn109,
            this.bandedGridColumn105,
            this.bandedGridColumn106,
            this.bandedGridColumn107,
            this.bandedGridColumn112,
            this.bandedGridColumn88,
            this.bandedGridColumn89,
            this.bandedGridColumn90,
            this.bandedGridColumn110,
            this.bandedGridColumn111,
            this.bandedGridColumn95,
            this.bandedGridColumn101,
            this.bandedGridColumn84,
            this.bandedGridColumn85,
            this.bandedGridColumn2,
            this.bandedGridColumn3,
            this.bandedGridColumn13,
            this.bandedGridColumn14});
            this.gridMain4.DetailHeight = 431;
            this.gridMain4.GridControl = this.dgv4;
            this.gridMain4.Name = "gridMain4";
            this.gridMain4.OptionsBehavior.Editable = false;
            this.gridMain4.OptionsBehavior.ReadOnly = true;
            this.gridMain4.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain4.OptionsPrint.AllowMultilineHeaders = true;
            this.gridMain4.OptionsPrint.PrintBandHeader = false;
            this.gridMain4.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain4.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain4.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain4.OptionsView.ShowBands = false;
            this.gridMain4.OptionsView.ShowFooter = true;
            this.gridMain4.OptionsView.ShowGroupPanel = false;
            this.gridMain4.PaintStyleName = "Style3D";
            this.gridMain4.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain4_CustomColumnDisplayText);
            // 
            // gridBand6
            // 
            this.gridBand6.Caption = "gridBand2";
            this.gridBand6.Columns.Add(this.bandedGridColumn76);
            this.gridBand6.Columns.Add(this.bandedGridColumn77);
            this.gridBand6.Columns.Add(this.bandedGridColumn78);
            this.gridBand6.Columns.Add(this.bandedGridColumn79);
            this.gridBand6.Columns.Add(this.bandedGridColumn80);
            this.gridBand6.Columns.Add(this.bandedGridColumn81);
            this.gridBand6.Columns.Add(this.bandedGridColumn82);
            this.gridBand6.MinWidth = 14;
            this.gridBand6.Name = "gridBand6";
            this.gridBand6.VisibleIndex = 0;
            this.gridBand6.Width = 58;
            // 
            // bandedGridColumn76
            // 
            this.bandedGridColumn76.Caption = "Num";
            this.bandedGridColumn76.FieldName = "num";
            this.bandedGridColumn76.MinWidth = 23;
            this.bandedGridColumn76.Name = "bandedGridColumn76";
            this.bandedGridColumn76.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn76.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn76.Visible = true;
            this.bandedGridColumn76.Width = 58;
            // 
            // bandedGridColumn77
            // 
            this.bandedGridColumn77.Caption = "Stat";
            this.bandedGridColumn77.FieldName = "fill";
            this.bandedGridColumn77.MinWidth = 23;
            this.bandedGridColumn77.Name = "bandedGridColumn77";
            this.bandedGridColumn77.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn77.Width = 58;
            // 
            // bandedGridColumn78
            // 
            this.bandedGridColumn78.Caption = "Agent";
            this.bandedGridColumn78.FieldName = "agentNumber";
            this.bandedGridColumn78.MinWidth = 23;
            this.bandedGridColumn78.Name = "bandedGridColumn78";
            this.bandedGridColumn78.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn78.Width = 87;
            // 
            // bandedGridColumn79
            // 
            this.bandedGridColumn79.Caption = "Due Date";
            this.bandedGridColumn79.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn79.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn79.FieldName = "dueDate8";
            this.bandedGridColumn79.MinWidth = 23;
            this.bandedGridColumn79.Name = "bandedGridColumn79";
            this.bandedGridColumn79.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn79.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn79.Width = 76;
            // 
            // bandedGridColumn80
            // 
            this.bandedGridColumn80.Caption = "Due Date";
            this.bandedGridColumn80.FieldName = "dueDate8Print";
            this.bandedGridColumn80.MinWidth = 23;
            this.bandedGridColumn80.Name = "bandedGridColumn80";
            this.bandedGridColumn80.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn80.Width = 76;
            // 
            // bandedGridColumn81
            // 
            this.bandedGridColumn81.Caption = "Date Paid";
            this.bandedGridColumn81.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn81.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn81.FieldName = "payDate8";
            this.bandedGridColumn81.MinWidth = 23;
            this.bandedGridColumn81.Name = "bandedGridColumn81";
            this.bandedGridColumn81.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn81.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn81.Width = 76;
            // 
            // bandedGridColumn82
            // 
            this.bandedGridColumn82.Caption = "Date Paid";
            this.bandedGridColumn82.FieldName = "payDate8Print";
            this.bandedGridColumn82.MinWidth = 23;
            this.bandedGridColumn82.Name = "bandedGridColumn82";
            this.bandedGridColumn82.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn82.Width = 76;
            // 
            // gridBand7
            // 
            this.gridBand7.Caption = "gridBand1";
            this.gridBand7.Columns.Add(this.bandedGridColumn83);
            this.gridBand7.Columns.Add(this.bandedGridColumn84);
            this.gridBand7.Columns.Add(this.bandedGridColumn85);
            this.gridBand7.Columns.Add(this.bandedGridColumn86);
            this.gridBand7.Columns.Add(this.bandedGridColumn87);
            this.gridBand7.Columns.Add(this.bandedGridColumn88);
            this.gridBand7.Columns.Add(this.bandedGridColumn89);
            this.gridBand7.Columns.Add(this.bandedGridColumn90);
            this.gridBand7.Columns.Add(this.bandedGridColumn91);
            this.gridBand7.Columns.Add(this.bandedGridColumn92);
            this.gridBand7.Columns.Add(this.bandedGridColumn93);
            this.gridBand7.Columns.Add(this.bandedGridColumn94);
            this.gridBand7.Columns.Add(this.bandedGridColumn95);
            this.gridBand7.Columns.Add(this.bandedGridColumn96);
            this.gridBand7.Columns.Add(this.bandedGridColumn97);
            this.gridBand7.Columns.Add(this.bandedGridColumn98);
            this.gridBand7.Columns.Add(this.bandedGridColumn99);
            this.gridBand7.Columns.Add(this.bandedGridColumn2);
            this.gridBand7.Columns.Add(this.bandedGridColumn3);
            this.gridBand7.Columns.Add(this.bandedGridColumn13);
            this.gridBand7.Columns.Add(this.bandedGridColumn14);
            this.gridBand7.Columns.Add(this.bandedGridColumn100);
            this.gridBand7.Columns.Add(this.bandedGridColumn101);
            this.gridBand7.Columns.Add(this.bandedGridColumn102);
            this.gridBand7.Columns.Add(this.bandedGridColumn103);
            this.gridBand7.Columns.Add(this.bandedGridColumn104);
            this.gridBand7.Columns.Add(this.bandedGridColumn105);
            this.gridBand7.Columns.Add(this.bandedGridColumn106);
            this.gridBand7.Columns.Add(this.bandedGridColumn107);
            this.gridBand7.Columns.Add(this.bandedGridColumn108);
            this.gridBand7.Columns.Add(this.bandedGridColumn109);
            this.gridBand7.Columns.Add(this.bandedGridColumn110);
            this.gridBand7.Columns.Add(this.bandedGridColumn111);
            this.gridBand7.Columns.Add(this.bandedGridColumn112);
            this.gridBand7.Columns.Add(this.bandedGridColumn113);
            this.gridBand7.MinWidth = 14;
            this.gridBand7.Name = "gridBand7";
            this.gridBand7.VisibleIndex = 1;
            this.gridBand7.Width = 1220;
            // 
            // bandedGridColumn83
            // 
            this.bandedGridColumn83.Caption = "Days";
            this.bandedGridColumn83.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn83.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn83.FieldName = "days";
            this.bandedGridColumn83.MinWidth = 23;
            this.bandedGridColumn83.Name = "bandedGridColumn83";
            this.bandedGridColumn83.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn83.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn83.Width = 70;
            // 
            // bandedGridColumn84
            // 
            this.bandedGridColumn84.Caption = "Last Name";
            this.bandedGridColumn84.FieldName = "lastName";
            this.bandedGridColumn84.MinWidth = 23;
            this.bandedGridColumn84.Name = "bandedGridColumn84";
            this.bandedGridColumn84.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn84.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn84.Width = 87;
            // 
            // bandedGridColumn85
            // 
            this.bandedGridColumn85.Caption = "First Name";
            this.bandedGridColumn85.FieldName = "firstName";
            this.bandedGridColumn85.MinWidth = 23;
            this.bandedGridColumn85.Name = "bandedGridColumn85";
            this.bandedGridColumn85.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn85.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn85.Width = 87;
            // 
            // bandedGridColumn86
            // 
            this.bandedGridColumn86.Caption = "Down Payment";
            this.bandedGridColumn86.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn86.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn86.FieldName = "downPayment";
            this.bandedGridColumn86.MinWidth = 23;
            this.bandedGridColumn86.Name = "bandedGridColumn86";
            this.bandedGridColumn86.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn86.Visible = true;
            this.bandedGridColumn86.Width = 87;
            // 
            // bandedGridColumn87
            // 
            this.bandedGridColumn87.Caption = "Payment";
            this.bandedGridColumn87.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn87.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn87.FieldName = "paymentAmount";
            this.bandedGridColumn87.MinWidth = 23;
            this.bandedGridColumn87.Name = "bandedGridColumn87";
            this.bandedGridColumn87.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn87.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn87.Visible = true;
            this.bandedGridColumn87.Width = 96;
            // 
            // bandedGridColumn88
            // 
            this.bandedGridColumn88.Caption = "# Pmts";
            this.bandedGridColumn88.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn88.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn88.FieldName = "NumPayments";
            this.bandedGridColumn88.MinWidth = 23;
            this.bandedGridColumn88.Name = "bandedGridColumn88";
            this.bandedGridColumn88.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn88.Visible = true;
            this.bandedGridColumn88.Width = 58;
            // 
            // bandedGridColumn89
            // 
            this.bandedGridColumn89.Caption = "Location";
            this.bandedGridColumn89.FieldName = "location";
            this.bandedGridColumn89.MinWidth = 23;
            this.bandedGridColumn89.Name = "bandedGridColumn89";
            this.bandedGridColumn89.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn89.Width = 87;
            // 
            // bandedGridColumn90
            // 
            this.bandedGridColumn90.Caption = "Deposit Number";
            this.bandedGridColumn90.FieldName = "depositNumber";
            this.bandedGridColumn90.MinWidth = 23;
            this.bandedGridColumn90.Name = "bandedGridColumn90";
            this.bandedGridColumn90.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn90.Width = 87;
            // 
            // bandedGridColumn91
            // 
            this.bandedGridColumn91.Caption = "Debit";
            this.bandedGridColumn91.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn91.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn91.FieldName = "debit";
            this.bandedGridColumn91.MinWidth = 12;
            this.bandedGridColumn91.Name = "bandedGridColumn91";
            this.bandedGridColumn91.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn91.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn91.Width = 96;
            // 
            // bandedGridColumn92
            // 
            this.bandedGridColumn92.Caption = "Credit";
            this.bandedGridColumn92.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn92.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn92.FieldName = "credit";
            this.bandedGridColumn92.MinWidth = 23;
            this.bandedGridColumn92.Name = "bandedGridColumn92";
            this.bandedGridColumn92.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn92.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn92.Width = 96;
            // 
            // bandedGridColumn93
            // 
            this.bandedGridColumn93.Caption = "Principal";
            this.bandedGridColumn93.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn93.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn93.FieldName = "prince";
            this.bandedGridColumn93.MinWidth = 23;
            this.bandedGridColumn93.Name = "bandedGridColumn93";
            this.bandedGridColumn93.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn93.Visible = true;
            this.bandedGridColumn93.Width = 87;
            // 
            // bandedGridColumn94
            // 
            this.bandedGridColumn94.AppearanceHeader.Options.UseTextOptions = true;
            this.bandedGridColumn94.AppearanceHeader.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.bandedGridColumn94.Caption = "Interest Paid";
            this.bandedGridColumn94.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn94.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn94.FieldName = "interestPaid";
            this.bandedGridColumn94.MinWidth = 12;
            this.bandedGridColumn94.Name = "bandedGridColumn94";
            this.bandedGridColumn94.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn94.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn94.Visible = true;
            this.bandedGridColumn94.Width = 87;
            // 
            // bandedGridColumn95
            // 
            this.bandedGridColumn95.Caption = "Unpaid Interest";
            this.bandedGridColumn95.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn95.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn95.FieldName = "unpaid_interest";
            this.bandedGridColumn95.MinWidth = 23;
            this.bandedGridColumn95.Name = "bandedGridColumn95";
            this.bandedGridColumn95.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn95.Width = 87;
            // 
            // bandedGridColumn96
            // 
            this.bandedGridColumn96.Caption = "Balance";
            this.bandedGridColumn96.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn96.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn96.FieldName = "balance";
            this.bandedGridColumn96.MinWidth = 23;
            this.bandedGridColumn96.Name = "bandedGridColumn96";
            this.bandedGridColumn96.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn96.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn96.Visible = true;
            this.bandedGridColumn96.Width = 96;
            // 
            // bandedGridColumn97
            // 
            this.bandedGridColumn97.Caption = "Retained";
            this.bandedGridColumn97.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn97.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn97.FieldName = "retained";
            this.bandedGridColumn97.MinWidth = 23;
            this.bandedGridColumn97.Name = "bandedGridColumn97";
            this.bandedGridColumn97.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn97.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn97.Visible = true;
            this.bandedGridColumn97.Width = 87;
            // 
            // bandedGridColumn98
            // 
            this.bandedGridColumn98.Caption = "trust85P";
            this.bandedGridColumn98.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn98.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn98.FieldName = "trust85P";
            this.bandedGridColumn98.MinWidth = 23;
            this.bandedGridColumn98.Name = "bandedGridColumn98";
            this.bandedGridColumn98.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn98.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn98.Visible = true;
            this.bandedGridColumn98.Width = 96;
            // 
            // bandedGridColumn99
            // 
            this.bandedGridColumn99.Caption = "trust100P";
            this.bandedGridColumn99.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn99.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn99.FieldName = "trust100P";
            this.bandedGridColumn99.MinWidth = 23;
            this.bandedGridColumn99.Name = "bandedGridColumn99";
            this.bandedGridColumn99.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn99.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn99.Visible = true;
            this.bandedGridColumn99.Width = 96;
            // 
            // bandedGridColumn2
            // 
            this.bandedGridColumn2.Caption = "Cumulative Interest";
            this.bandedGridColumn2.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn2.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn2.FieldName = "cInterest";
            this.bandedGridColumn2.MinWidth = 23;
            this.bandedGridColumn2.Name = "bandedGridColumn2";
            this.bandedGridColumn2.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn2.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn2.Visible = true;
            this.bandedGridColumn2.Width = 105;
            // 
            // bandedGridColumn3
            // 
            this.bandedGridColumn3.Caption = "Cumulative Retained Interest";
            this.bandedGridColumn3.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn3.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn3.FieldName = "cRetained";
            this.bandedGridColumn3.MinWidth = 23;
            this.bandedGridColumn3.Name = "bandedGridColumn3";
            this.bandedGridColumn3.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn3.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn3.Visible = true;
            this.bandedGridColumn3.Width = 105;
            // 
            // bandedGridColumn13
            // 
            this.bandedGridColumn13.Caption = "Cumulative Trust85";
            this.bandedGridColumn13.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn13.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn13.FieldName = "cumulativeTrust85";
            this.bandedGridColumn13.MinWidth = 29;
            this.bandedGridColumn13.Name = "bandedGridColumn13";
            this.bandedGridColumn13.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn13.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn13.Visible = true;
            this.bandedGridColumn13.Width = 110;
            // 
            // bandedGridColumn14
            // 
            this.bandedGridColumn14.Caption = "Cumulative Trust100";
            this.bandedGridColumn14.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn14.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn14.FieldName = "cumulativeTrust100";
            this.bandedGridColumn14.MinWidth = 29;
            this.bandedGridColumn14.Name = "bandedGridColumn14";
            this.bandedGridColumn14.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn14.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn14.Visible = true;
            this.bandedGridColumn14.Width = 110;
            // 
            // bandedGridColumn100
            // 
            this.bandedGridColumn100.Caption = "Reason";
            this.bandedGridColumn100.FieldName = "reason";
            this.bandedGridColumn100.MinWidth = 23;
            this.bandedGridColumn100.Name = "bandedGridColumn100";
            this.bandedGridColumn100.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn100.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn100.Width = 233;
            // 
            // bandedGridColumn101
            // 
            this.bandedGridColumn101.Caption = "ID";
            this.bandedGridColumn101.FieldName = "s50";
            this.bandedGridColumn101.MinWidth = 23;
            this.bandedGridColumn101.Name = "bandedGridColumn101";
            this.bandedGridColumn101.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn101.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn101.Width = 87;
            // 
            // bandedGridColumn102
            // 
            this.bandedGridColumn102.Caption = "Principal";
            this.bandedGridColumn102.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn102.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn102.FieldName = "principal";
            this.bandedGridColumn102.MinWidth = 23;
            this.bandedGridColumn102.Name = "bandedGridColumn102";
            this.bandedGridColumn102.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn102.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn102.Width = 87;
            // 
            // bandedGridColumn103
            // 
            this.bandedGridColumn103.Caption = "Interest";
            this.bandedGridColumn103.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn103.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn103.FieldName = "int";
            this.bandedGridColumn103.MinWidth = 23;
            this.bandedGridColumn103.Name = "bandedGridColumn103";
            this.bandedGridColumn103.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn103.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn103.Width = 87;
            // 
            // bandedGridColumn104
            // 
            this.bandedGridColumn104.Caption = "Balance";
            this.bandedGridColumn104.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn104.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn104.FieldName = "newbalance";
            this.bandedGridColumn104.MinWidth = 23;
            this.bandedGridColumn104.Name = "bandedGridColumn104";
            this.bandedGridColumn104.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn104.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn104.Width = 87;
            // 
            // bandedGridColumn105
            // 
            this.bandedGridColumn105.Caption = "Calculated Trust85";
            this.bandedGridColumn105.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn105.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn105.FieldName = "calculatedTrust85";
            this.bandedGridColumn105.MinWidth = 23;
            this.bandedGridColumn105.Name = "bandedGridColumn105";
            this.bandedGridColumn105.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn105.Width = 87;
            // 
            // bandedGridColumn106
            // 
            this.bandedGridColumn106.Caption = "Calculated Trust100";
            this.bandedGridColumn106.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn106.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn106.FieldName = "calculatedTrust100";
            this.bandedGridColumn106.MinWidth = 23;
            this.bandedGridColumn106.Name = "bandedGridColumn106";
            this.bandedGridColumn106.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn106.Width = 87;
            // 
            // bandedGridColumn107
            // 
            this.bandedGridColumn107.Caption = "Method";
            this.bandedGridColumn107.DisplayFormat.FormatString = "N0";
            this.bandedGridColumn107.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn107.FieldName = "method";
            this.bandedGridColumn107.MinWidth = 23;
            this.bandedGridColumn107.Name = "bandedGridColumn107";
            this.bandedGridColumn107.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn107.Width = 70;
            // 
            // bandedGridColumn108
            // 
            this.bandedGridColumn108.AutoFillDown = true;
            this.bandedGridColumn108.Caption = "Next Due Date";
            this.bandedGridColumn108.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn108.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn108.FieldName = "nextDueDate";
            this.bandedGridColumn108.MinWidth = 23;
            this.bandedGridColumn108.Name = "bandedGridColumn108";
            this.bandedGridColumn108.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn108.Width = 87;
            // 
            // bandedGridColumn109
            // 
            this.bandedGridColumn109.Caption = "Credit Balance";
            this.bandedGridColumn109.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn109.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn109.FieldName = "creditBalance";
            this.bandedGridColumn109.MinWidth = 23;
            this.bandedGridColumn109.Name = "bandedGridColumn109";
            this.bandedGridColumn109.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn109.Width = 87;
            // 
            // bandedGridColumn110
            // 
            this.bandedGridColumn110.Caption = "Running CB";
            this.bandedGridColumn110.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn110.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn110.FieldName = "runningCB";
            this.bandedGridColumn110.MinWidth = 23;
            this.bandedGridColumn110.Name = "bandedGridColumn110";
            this.bandedGridColumn110.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn110.Width = 87;
            // 
            // bandedGridColumn111
            // 
            this.bandedGridColumn111.Caption = "Major CB";
            this.bandedGridColumn111.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn111.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn111.FieldName = "majorCB";
            this.bandedGridColumn111.MinWidth = 23;
            this.bandedGridColumn111.Name = "bandedGridColumn111";
            this.bandedGridColumn111.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn111.Width = 87;
            // 
            // bandedGridColumn112
            // 
            this.bandedGridColumn112.Caption = "Balance Used";
            this.bandedGridColumn112.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn112.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn112.FieldName = "oldBalance";
            this.bandedGridColumn112.MinWidth = 23;
            this.bandedGridColumn112.Name = "bandedGridColumn112";
            this.bandedGridColumn112.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn112.Width = 87;
            // 
            // bandedGridColumn113
            // 
            this.bandedGridColumn113.Caption = "record";
            this.bandedGridColumn113.FieldName = "record";
            this.bandedGridColumn113.MinWidth = 23;
            this.bandedGridColumn113.Name = "bandedGridColumn113";
            this.bandedGridColumn113.RowCount = 2;
            this.bandedGridColumn113.Width = 87;
            // 
            // panelAmortTop
            // 
            this.panelAmortTop.BackColor = System.Drawing.Color.Wheat;
            this.panelAmortTop.Controls.Add(this.txtAPR_2);
            this.panelAmortTop.Controls.Add(this.label11);
            this.panelAmortTop.Controls.Add(this.btnRun);
            this.panelAmortTop.Controls.Add(this.chkUseCalcualatedPayment);
            this.panelAmortTop.Controls.Add(this.txtCalculatedPayment);
            this.panelAmortTop.Controls.Add(this.label2);
            this.panelAmortTop.Controls.Add(this.txtContractPayment);
            this.panelAmortTop.Controls.Add(this.label1);
            this.panelAmortTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelAmortTop.Location = new System.Drawing.Point(0, 0);
            this.panelAmortTop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelAmortTop.Name = "panelAmortTop";
            this.panelAmortTop.Size = new System.Drawing.Size(1657, 49);
            this.panelAmortTop.TabIndex = 7;
            // 
            // txtAPR_2
            // 
            this.txtAPR_2.Location = new System.Drawing.Point(970, 14);
            this.txtAPR_2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtAPR_2.Name = "txtAPR_2";
            this.txtAPR_2.Size = new System.Drawing.Size(116, 23);
            this.txtAPR_2.TabIndex = 17;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(928, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 17);
            this.label11.TabIndex = 16;
            this.label11.Text = "APR :";
            // 
            // btnRun
            // 
            this.btnRun.BackColor = System.Drawing.Color.DarkOrange;
            this.btnRun.Location = new System.Drawing.Point(801, 11);
            this.btnRun.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(87, 28);
            this.btnRun.TabIndex = 5;
            this.btnRun.Text = "Run Again";
            this.btnRun.UseVisualStyleBackColor = false;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // chkUseCalcualatedPayment
            // 
            this.chkUseCalcualatedPayment.AutoSize = true;
            this.chkUseCalcualatedPayment.Location = new System.Drawing.Point(615, 16);
            this.chkUseCalcualatedPayment.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.chkUseCalcualatedPayment.Name = "chkUseCalcualatedPayment";
            this.chkUseCalcualatedPayment.Size = new System.Drawing.Size(177, 21);
            this.chkUseCalcualatedPayment.TabIndex = 4;
            this.chkUseCalcualatedPayment.Text = "Use Calculated Payment";
            this.chkUseCalcualatedPayment.UseVisualStyleBackColor = true;
            // 
            // txtCalculatedPayment
            // 
            this.txtCalculatedPayment.Enabled = false;
            this.txtCalculatedPayment.Location = new System.Drawing.Point(467, 14);
            this.txtCalculatedPayment.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtCalculatedPayment.Name = "txtCalculatedPayment";
            this.txtCalculatedPayment.Size = new System.Drawing.Size(125, 23);
            this.txtCalculatedPayment.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(332, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Calculated Payment :";
            // 
            // txtContractPayment
            // 
            this.txtContractPayment.Enabled = false;
            this.txtContractPayment.Location = new System.Drawing.Point(166, 14);
            this.txtContractPayment.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtContractPayment.Name = "txtContractPayment";
            this.txtContractPayment.Size = new System.Drawing.Size(116, 23);
            this.txtContractPayment.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Contract Payment in DB :";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dgv5);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(1657, 461);
            this.tabPage2.TabIndex = 4;
            this.tabPage2.Text = "Charlotte Data";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dgv5
            // 
            this.dgv5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv5.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv5.Location = new System.Drawing.Point(0, 0);
            this.dgv5.LookAndFeel.SkinName = "iMaginary";
            this.dgv5.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv5.MainView = this.gridMain5;
            this.dgv5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv5.Name = "dgv5";
            this.dgv5.Size = new System.Drawing.Size(1657, 461);
            this.dgv5.TabIndex = 6;
            this.dgv5.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain5});
            // 
            // gridMain5
            // 
            this.gridMain5.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain5.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(206)))), ((int)(((byte)(164)))));
            this.gridMain5.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain5.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain5.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain5.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.gridMain5.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain5.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain5.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Gray;
            this.gridMain5.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain5.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain5.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain5.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain5.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(241)))), ((int)(((byte)(209)))));
            this.gridMain5.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain5.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Blue;
            this.gridMain5.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain5.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain5.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain5.Appearance.Empty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain5.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain5.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.EvenRow.BackColor2 = System.Drawing.Color.GhostWhite;
            this.gridMain5.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.EvenRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain5.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain5.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(90)))), ((int)(((byte)(90)))));
            this.gridMain5.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain5.Appearance.FilterCloseButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain5.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain5.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain5.Appearance.FilterCloseButton.Options.UseForeColor = true;
            this.gridMain5.Appearance.FilterPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FilterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain5.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.FilterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
            this.gridMain5.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(96)))), ((int)(((byte)(0)))));
            this.gridMain5.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain5.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain5.Appearance.FocusedRow.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(216)))), ((int)(((byte)(120)))));
            this.gridMain5.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.FooterPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain5.Appearance.FooterPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain5.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain5.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(226)))), ((int)(((byte)(184)))));
            this.gridMain5.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain5.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupPanel.BackColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.GroupPanel.BackColor2 = System.Drawing.Color.White;
            this.gridMain5.Appearance.GroupPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain5.Appearance.GroupPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupPanel.Options.UseFont = true;
            this.gridMain5.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(166)))), ((int)(((byte)(70)))));
            this.gridMain5.Appearance.GroupRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain5.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.HeaderPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain5.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain5.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain5.Appearance.HeaderPanel.Options.UseFont = true;
            this.gridMain5.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain5.Appearance.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain5.Appearance.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain5.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.gridMain5.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain5.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.Gray;
            this.gridMain5.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(208)))), ((int)(((byte)(200)))));
            this.gridMain5.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain5.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(236)))), ((int)(((byte)(215)))));
            this.gridMain5.Appearance.OddRow.BackColor2 = System.Drawing.Color.White;
            this.gridMain5.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.OddRow.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
            this.gridMain5.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(234)))));
            this.gridMain5.Appearance.Preview.BackColor2 = System.Drawing.Color.White;
            this.gridMain5.Appearance.Preview.ForeColor = System.Drawing.Color.Maroon;
            this.gridMain5.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain5.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain5.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.Row.Options.UseBackColor = true;
            this.gridMain5.Appearance.Row.Options.UseForeColor = true;
            this.gridMain5.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain5.Appearance.RowSeparator.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(236)))), ((int)(((byte)(194)))));
            this.gridMain5.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain5.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(176)))), ((int)(((byte)(80)))));
            this.gridMain5.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain5.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain5.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain5.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(216)))), ((int)(((byte)(174)))));
            this.gridMain5.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain5.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain5.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain5.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand1,
            this.gridBand3});
            this.gridMain5.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain5.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn4,
            this.bandedGridColumn118,
            this.bandedGridColumn9,
            this.bandedGridColumn5,
            this.bandedGridColumn7,
            this.bandedGridColumn16,
            this.bandedGridColumn6,
            this.bandedGridColumn21});
            this.gridMain5.DetailHeight = 431;
            this.gridMain5.GridControl = this.dgv5;
            this.gridMain5.Name = "gridMain5";
            this.gridMain5.OptionsBehavior.Editable = false;
            this.gridMain5.OptionsBehavior.ReadOnly = true;
            this.gridMain5.OptionsCustomization.ShowBandsInCustomizationForm = false;
            this.gridMain5.OptionsPrint.AllowMultilineHeaders = true;
            this.gridMain5.OptionsPrint.PrintBandHeader = false;
            this.gridMain5.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain5.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain5.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain5.OptionsView.ShowBands = false;
            this.gridMain5.OptionsView.ShowFooter = true;
            this.gridMain5.OptionsView.ShowGroupPanel = false;
            this.gridMain5.PaintStyleName = "Style3D";
            this.gridMain5.CustomColumnDisplayText += new DevExpress.XtraGrid.Views.Base.CustomColumnDisplayTextEventHandler(this.gridMain5_CustomColumnDisplayText);
            // 
            // gridBand1
            // 
            this.gridBand1.Caption = "gridBand2";
            this.gridBand1.Columns.Add(this.bandedGridColumn4);
            this.gridBand1.Columns.Add(this.bandedGridColumn9);
            this.gridBand1.MinWidth = 22;
            this.gridBand1.Name = "gridBand1";
            this.gridBand1.VisibleIndex = 0;
            this.gridBand1.Width = 248;
            // 
            // bandedGridColumn4
            // 
            this.bandedGridColumn4.Caption = "Num";
            this.bandedGridColumn4.FieldName = "num";
            this.bandedGridColumn4.MinWidth = 42;
            this.bandedGridColumn4.Name = "bandedGridColumn4";
            this.bandedGridColumn4.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn4.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn4.Visible = true;
            this.bandedGridColumn4.Width = 107;
            // 
            // bandedGridColumn9
            // 
            this.bandedGridColumn9.Caption = "Date Paid";
            this.bandedGridColumn9.DisplayFormat.FormatString = "MM/dd/yyyy";
            this.bandedGridColumn9.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.bandedGridColumn9.FieldName = "payDate8";
            this.bandedGridColumn9.MinWidth = 42;
            this.bandedGridColumn9.Name = "bandedGridColumn9";
            this.bandedGridColumn9.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn9.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn9.Visible = true;
            this.bandedGridColumn9.Width = 141;
            // 
            // gridBand3
            // 
            this.gridBand3.Caption = "gridBand1";
            this.gridBand3.Columns.Add(this.bandedGridColumn5);
            this.gridBand3.Columns.Add(this.bandedGridColumn16);
            this.gridBand3.Columns.Add(this.bandedGridColumn7);
            this.gridBand3.Columns.Add(this.bandedGridColumn6);
            this.gridBand3.Columns.Add(this.bandedGridColumn21);
            this.gridBand3.Columns.Add(this.bandedGridColumn118);
            this.gridBand3.MinWidth = 22;
            this.gridBand3.Name = "gridBand3";
            this.gridBand3.VisibleIndex = 1;
            this.gridBand3.Width = 636;
            // 
            // bandedGridColumn5
            // 
            this.bandedGridColumn5.Caption = "Beginning Balance";
            this.bandedGridColumn5.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn5.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn5.FieldName = "beginningBalance";
            this.bandedGridColumn5.MinWidth = 47;
            this.bandedGridColumn5.Name = "bandedGridColumn5";
            this.bandedGridColumn5.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn5.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn5.Visible = true;
            this.bandedGridColumn5.Width = 174;
            // 
            // bandedGridColumn16
            // 
            this.bandedGridColumn16.Caption = "Payment Current Month";
            this.bandedGridColumn16.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn16.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn16.FieldName = "paymentCurrMonth";
            this.bandedGridColumn16.MinWidth = 42;
            this.bandedGridColumn16.Name = "bandedGridColumn16";
            this.bandedGridColumn16.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn16.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn16.Visible = true;
            this.bandedGridColumn16.Width = 178;
            // 
            // bandedGridColumn7
            // 
            this.bandedGridColumn7.Caption = "Current Payments";
            this.bandedGridColumn7.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn7.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn7.FieldName = "currentPayments";
            this.bandedGridColumn7.MinWidth = 40;
            this.bandedGridColumn7.Name = "bandedGridColumn7";
            this.bandedGridColumn7.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn7.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn7.Width = 149;
            // 
            // bandedGridColumn6
            // 
            this.bandedGridColumn6.Caption = "Ending Balance";
            this.bandedGridColumn6.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn6.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn6.FieldName = "endingBalance";
            this.bandedGridColumn6.MinWidth = 47;
            this.bandedGridColumn6.Name = "bandedGridColumn6";
            this.bandedGridColumn6.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn6.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn6.Visible = true;
            this.bandedGridColumn6.Width = 174;
            // 
            // bandedGridColumn21
            // 
            this.bandedGridColumn21.Caption = "Daily History";
            this.bandedGridColumn21.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn21.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn21.FieldName = "dailyHistory";
            this.bandedGridColumn21.MinWidth = 29;
            this.bandedGridColumn21.Name = "bandedGridColumn21";
            this.bandedGridColumn21.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn21.Visible = true;
            this.bandedGridColumn21.Width = 110;
            // 
            // bandedGridColumn118
            // 
            this.bandedGridColumn118.Caption = "record";
            this.bandedGridColumn118.FieldName = "record";
            this.bandedGridColumn118.MinWidth = 42;
            this.bandedGridColumn118.Name = "bandedGridColumn118";
            this.bandedGridColumn118.RowCount = 2;
            this.bandedGridColumn118.Width = 161;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.dgv6);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1657, 461);
            this.tabPage5.TabIndex = 5;
            this.tabPage5.Text = "Payoff Summary";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // dgv6
            // 
            this.dgv6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv6.EmbeddedNavigator.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv6.Location = new System.Drawing.Point(0, 0);
            this.dgv6.LookAndFeel.SkinName = "iMaginary";
            this.dgv6.LookAndFeel.UseDefaultLookAndFeel = false;
            this.dgv6.MainView = this.gridMain6;
            this.dgv6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dgv6.Name = "dgv6";
            this.dgv6.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemComboBox3,
            this.repositoryItemComboBox4});
            this.dgv6.Size = new System.Drawing.Size(1657, 461);
            this.dgv6.TabIndex = 8;
            this.dgv6.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridMain6});
            // 
            // gridMain6
            // 
            this.gridMain6.Appearance.BandPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain6.Appearance.BandPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(153)))), ((int)(((byte)(182)))));
            this.gridMain6.Appearance.BandPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain6.Appearance.BandPanel.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain6.Appearance.BandPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.BandPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain6.Appearance.BandPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.BandPanel.Options.UseBorderColor = true;
            this.gridMain6.Appearance.BandPanel.Options.UseFont = true;
            this.gridMain6.Appearance.BandPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.BandPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.BandPanelBackground.Options.UseBackColor = true;
            this.gridMain6.Appearance.ColumnFilterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain6.Appearance.ColumnFilterButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(153)))), ((int)(((byte)(182)))));
            this.gridMain6.Appearance.ColumnFilterButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain6.Appearance.ColumnFilterButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.ColumnFilterButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain6.Appearance.ColumnFilterButton.Options.UseBackColor = true;
            this.gridMain6.Appearance.ColumnFilterButton.Options.UseBorderColor = true;
            this.gridMain6.Appearance.ColumnFilterButton.Options.UseForeColor = true;
            this.gridMain6.Appearance.ColumnFilterButtonActive.BackColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.ColumnFilterButtonActive.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(198)))), ((int)(((byte)(215)))));
            this.gridMain6.Appearance.ColumnFilterButtonActive.BorderColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.ColumnFilterButtonActive.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.ColumnFilterButtonActive.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain6.Appearance.ColumnFilterButtonActive.Options.UseBackColor = true;
            this.gridMain6.Appearance.ColumnFilterButtonActive.Options.UseBorderColor = true;
            this.gridMain6.Appearance.ColumnFilterButtonActive.Options.UseForeColor = true;
            this.gridMain6.Appearance.Empty.BackColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.Empty.Options.UseBackColor = true;
            this.gridMain6.Appearance.EvenRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain6.Appearance.EvenRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.EvenRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.EvenRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.FilterCloseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain6.Appearance.FilterCloseButton.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(153)))), ((int)(((byte)(182)))));
            this.gridMain6.Appearance.FilterCloseButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain6.Appearance.FilterCloseButton.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain6.Appearance.FilterCloseButton.Options.UseBackColor = true;
            this.gridMain6.Appearance.FilterCloseButton.Options.UseBorderColor = true;
            this.gridMain6.Appearance.FilterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(131)))), ((int)(((byte)(161)))));
            this.gridMain6.Appearance.FilterPanel.ForeColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.FilterPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.FilterPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.FixedLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(124)))), ((int)(((byte)(148)))));
            this.gridMain6.Appearance.FixedLine.Options.UseBackColor = true;
            this.gridMain6.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(178)))), ((int)(((byte)(180)))), ((int)(((byte)(191)))));
            this.gridMain6.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.FocusedRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.FocusedRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.FooterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain6.Appearance.FooterPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(153)))), ((int)(((byte)(182)))));
            this.gridMain6.Appearance.FooterPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain6.Appearance.FooterPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain6.Appearance.FooterPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.FooterPanel.Options.UseBorderColor = true;
            this.gridMain6.Appearance.GroupButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain6.Appearance.GroupButton.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain6.Appearance.GroupButton.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.GroupButton.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupButton.Options.UseBorderColor = true;
            this.gridMain6.Appearance.GroupButton.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupFooter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain6.Appearance.GroupFooter.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain6.Appearance.GroupFooter.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.GroupFooter.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupFooter.Options.UseBorderColor = true;
            this.gridMain6.Appearance.GroupFooter.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(131)))), ((int)(((byte)(161)))));
            this.gridMain6.Appearance.GroupPanel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain6.Appearance.GroupPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.GroupRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain6.Appearance.GroupRow.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.gridMain6.Appearance.GroupRow.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.gridMain6.Appearance.GroupRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.GroupRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.GroupRow.Options.UseBorderColor = true;
            this.gridMain6.Appearance.GroupRow.Options.UseFont = true;
            this.gridMain6.Appearance.GroupRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.HeaderPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain6.Appearance.HeaderPanel.BackColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(154)))), ((int)(((byte)(153)))), ((int)(((byte)(182)))));
            this.gridMain6.Appearance.HeaderPanel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(244)))), ((int)(((byte)(250)))));
            this.gridMain6.Appearance.HeaderPanel.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.HeaderPanel.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.gridMain6.Appearance.HeaderPanel.Options.UseBackColor = true;
            this.gridMain6.Appearance.HeaderPanel.Options.UseBorderColor = true;
            this.gridMain6.Appearance.HeaderPanel.Options.UseForeColor = true;
            this.gridMain6.Appearance.HeaderPanelBackground.BackColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.HeaderPanelBackground.Options.UseBackColor = true;
            this.gridMain6.Appearance.HideSelectionRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(219)))), ((int)(((byte)(226)))));
            this.gridMain6.Appearance.HideSelectionRow.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(131)))), ((int)(((byte)(161)))));
            this.gridMain6.Appearance.HideSelectionRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.HideSelectionRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.HorzLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(164)))), ((int)(((byte)(188)))));
            this.gridMain6.Appearance.HorzLine.Options.UseBackColor = true;
            this.gridMain6.Appearance.OddRow.BackColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.OddRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.OddRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.OddRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.Preview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(253)))));
            this.gridMain6.Appearance.Preview.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(163)))), ((int)(((byte)(165)))), ((int)(((byte)(177)))));
            this.gridMain6.Appearance.Preview.Options.UseBackColor = true;
            this.gridMain6.Appearance.Preview.Options.UseForeColor = true;
            this.gridMain6.Appearance.Row.BackColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.Row.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.Row.Options.UseBackColor = true;
            this.gridMain6.Appearance.Row.Options.UseForeColor = true;
            this.gridMain6.Appearance.RowSeparator.BackColor = System.Drawing.Color.White;
            this.gridMain6.Appearance.RowSeparator.Options.UseBackColor = true;
            this.gridMain6.Appearance.SelectedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(197)))), ((int)(((byte)(205)))));
            this.gridMain6.Appearance.SelectedRow.ForeColor = System.Drawing.Color.Black;
            this.gridMain6.Appearance.SelectedRow.Options.UseBackColor = true;
            this.gridMain6.Appearance.SelectedRow.Options.UseForeColor = true;
            this.gridMain6.Appearance.VertLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(164)))), ((int)(((byte)(164)))), ((int)(((byte)(188)))));
            this.gridMain6.Appearance.VertLine.Options.UseBackColor = true;
            this.gridMain6.AppearancePrint.HeaderPanel.Options.UseTextOptions = true;
            this.gridMain6.AppearancePrint.HeaderPanel.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap;
            this.gridMain6.Bands.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.GridBand[] {
            this.gridBand8});
            this.gridMain6.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridMain6.Columns.AddRange(new DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn[] {
            this.bandedGridColumn15,
            this.bandedGridColumn17,
            this.bandedGridColumn18,
            this.bandedGridColumn19,
            this.bandedGridColumn20});
            this.gridMain6.DetailHeight = 431;
            this.gridMain6.GridControl = this.dgv6;
            this.gridMain6.Name = "gridMain6";
            this.gridMain6.OptionsBehavior.AutoPopulateColumns = false;
            this.gridMain6.OptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.Click;
            this.gridMain6.OptionsPrint.AutoWidth = false;
            this.gridMain6.OptionsPrint.PrintBandHeader = false;
            this.gridMain6.OptionsPrint.PrintHeader = false;
            this.gridMain6.OptionsPrint.PrintHorzLines = false;
            this.gridMain6.OptionsPrint.PrintVertLines = false;
            this.gridMain6.OptionsView.ColumnHeaderAutoHeight = DevExpress.Utils.DefaultBoolean.True;
            this.gridMain6.OptionsView.EnableAppearanceEvenRow = true;
            this.gridMain6.OptionsView.EnableAppearanceOddRow = true;
            this.gridMain6.OptionsView.ShowBands = false;
            this.gridMain6.OptionsView.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowAlways;
            this.gridMain6.OptionsView.ShowGroupPanel = false;
            this.gridMain6.PaintStyleName = "Flat";
            this.gridMain6.RowCellStyle += new DevExpress.XtraGrid.Views.Grid.RowCellStyleEventHandler(this.gridMain6_RowCellStyle);
            // 
            // gridBand8
            // 
            this.gridBand8.Caption = "gridBand1";
            this.gridBand8.Columns.Add(this.bandedGridColumn15);
            this.gridBand8.Columns.Add(this.bandedGridColumn17);
            this.gridBand8.Columns.Add(this.bandedGridColumn18);
            this.gridBand8.Columns.Add(this.bandedGridColumn19);
            this.gridBand8.Columns.Add(this.bandedGridColumn20);
            this.gridBand8.MinWidth = 26;
            this.gridBand8.Name = "gridBand8";
            this.gridBand8.VisibleIndex = 0;
            this.gridBand8.Width = 830;
            // 
            // bandedGridColumn15
            // 
            this.bandedGridColumn15.AppearanceCell.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bandedGridColumn15.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn15.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn15.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.bandedGridColumn15.Caption = "C1";
            this.bandedGridColumn15.FieldName = "c1";
            this.bandedGridColumn15.MinWidth = 31;
            this.bandedGridColumn15.Name = "bandedGridColumn15";
            this.bandedGridColumn15.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn15.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn15.Visible = true;
            this.bandedGridColumn15.Width = 250;
            // 
            // bandedGridColumn17
            // 
            this.bandedGridColumn17.AppearanceCell.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bandedGridColumn17.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn17.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn17.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.bandedGridColumn17.Caption = "C2";
            this.bandedGridColumn17.FieldName = "c2";
            this.bandedGridColumn17.MinWidth = 42;
            this.bandedGridColumn17.Name = "bandedGridColumn17";
            this.bandedGridColumn17.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn17.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn17.Visible = true;
            this.bandedGridColumn17.Width = 230;
            // 
            // bandedGridColumn18
            // 
            this.bandedGridColumn18.AppearanceCell.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bandedGridColumn18.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn18.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn18.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.bandedGridColumn18.Caption = "C3";
            this.bandedGridColumn18.FieldName = "c3";
            this.bandedGridColumn18.MinWidth = 47;
            this.bandedGridColumn18.Name = "bandedGridColumn18";
            this.bandedGridColumn18.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn18.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn18.Visible = true;
            this.bandedGridColumn18.Width = 100;
            // 
            // bandedGridColumn19
            // 
            this.bandedGridColumn19.AppearanceCell.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bandedGridColumn19.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn19.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn19.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn19.Caption = "C4";
            this.bandedGridColumn19.FieldName = "c4";
            this.bandedGridColumn19.MinWidth = 34;
            this.bandedGridColumn19.Name = "bandedGridColumn19";
            this.bandedGridColumn19.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn19.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn19.Visible = true;
            this.bandedGridColumn19.Width = 125;
            // 
            // bandedGridColumn20
            // 
            this.bandedGridColumn20.AppearanceCell.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bandedGridColumn20.AppearanceCell.Options.UseFont = true;
            this.bandedGridColumn20.AppearanceCell.Options.UseTextOptions = true;
            this.bandedGridColumn20.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.bandedGridColumn20.Caption = "C5";
            this.bandedGridColumn20.FieldName = "c5";
            this.bandedGridColumn20.MinWidth = 34;
            this.bandedGridColumn20.Name = "bandedGridColumn20";
            this.bandedGridColumn20.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn20.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn20.Visible = true;
            this.bandedGridColumn20.Width = 125;
            // 
            // repositoryItemComboBox3
            // 
            this.repositoryItemComboBox3.AutoHeight = false;
            this.repositoryItemComboBox3.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox3.Items.AddRange(new object[] {
            "Cash",
            "Check",
            "Master Card",
            "Visa",
            "American Express",
            "Trust",
            "Policy",
            "Insurance",
            "Other"});
            this.repositoryItemComboBox3.Name = "repositoryItemComboBox3";
            // 
            // repositoryItemComboBox4
            // 
            this.repositoryItemComboBox4.AutoComplete = false;
            this.repositoryItemComboBox4.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemComboBox4.Items.AddRange(new object[] {
            "Cancelled",
            "Accept",
            "Rejected",
            "Pending"});
            this.repositoryItemComboBox4.Name = "repositoryItemComboBox4";
            // 
            // bandedGridColumn25
            // 
            this.bandedGridColumn25.Caption = "Down Payment";
            this.bandedGridColumn25.DisplayFormat.FormatString = "N2";
            this.bandedGridColumn25.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.bandedGridColumn25.FieldName = "dpp";
            this.bandedGridColumn25.MinWidth = 25;
            this.bandedGridColumn25.Name = "bandedGridColumn25";
            this.bandedGridColumn25.OptionsColumn.AllowEdit = false;
            this.bandedGridColumn25.OptionsColumn.FixedWidth = true;
            this.bandedGridColumn25.Visible = true;
            this.bandedGridColumn25.Width = 94;
            // 
            // PayOffDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1665, 520);
            this.Controls.Add(this.panelAll);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "PayOffDetail";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PayOffDetail";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PayOffDetail_FormClosing);
            this.Load += new System.EventHandler(this.PayOffDetail_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelAll.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.panelRecalcAll.ResumeLayout(false);
            this.panelRecalcBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain3)).EndInit();
            this.panelRecalcTop.ResumeLayout(false);
            this.panelRecalcTop.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.panelAmortAll.ResumeLayout(false);
            this.panelAmortBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain4)).EndInit();
            this.panelAmortTop.ResumeLayout(false);
            this.panelAmortTop.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain5)).EndInit();
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridMain6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Panel panelAll;
        private DevExpress.XtraGrid.GridControl dgv;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn12;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn1;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private DevExpress.XtraGrid.GridControl dgv3;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn38;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn39;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn40;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn41;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn42;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn43;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn44;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn45;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn46;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn47;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn48;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn49;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn50;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn51;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn52;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn53;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn54;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn55;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn56;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn57;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn58;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn59;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn60;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn61;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn62;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn63;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn64;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn65;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn66;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn67;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn68;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn69;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn70;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn71;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn72;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn73;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn74;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn75;
        private DevExpress.XtraGrid.GridControl dgv4;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn76;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn77;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn78;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn79;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn80;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn81;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn82;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn83;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn84;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn85;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn86;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn87;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn88;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn89;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn90;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn91;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn92;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn93;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn94;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn95;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn96;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn97;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn98;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn99;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn100;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn101;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn102;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn103;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn104;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn105;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn106;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn107;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn108;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn109;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn110;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn111;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn112;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn113;
        private System.Windows.Forms.Panel panelAmortAll;
        private System.Windows.Forms.Panel panelAmortBottom;
        private System.Windows.Forms.Panel panelAmortTop;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.CheckBox chkUseCalcualatedPayment;
        private System.Windows.Forms.TextBox txtCalculatedPayment;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtContractPayment;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panelRecalcAll;
        private System.Windows.Forms.Panel panelRecalcBottom;
        private System.Windows.Forms.Panel panelRecalcTop;
        private System.Windows.Forms.TextBox txtFixTrust85P;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtCPTrust85P;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTrust85P;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTrust100P;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTotalTrust85P;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTrust85Pending;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAsOf;
        private System.Windows.Forms.Label label9;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn3;
        private System.Windows.Forms.TabPage tabPage2;
        private DevExpress.XtraGrid.GridControl dgv5;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn4;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn9;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn16;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn118;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn7;
        private System.Windows.Forms.Button btnRecalc;
        private System.Windows.Forms.TextBox txtAPR;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtAPR_2;
        private System.Windows.Forms.Label label11;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn8;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand4;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand5;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn10;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn11;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand6;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand7;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn13;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn14;
        private System.Windows.Forms.Button btnCA;
        private System.Windows.Forms.TabPage tabPage5;
        private DevExpress.XtraGrid.GridControl dgv6;
        private DevExpress.XtraGrid.Views.BandedGrid.AdvBandedGridView gridMain6;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn15;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn17;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn18;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn19;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn20;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox3;
        private DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox4;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand8;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand1;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand3;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn21;
        private DevExpress.XtraGrid.Views.BandedGrid.GridBand gridBand2;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn22;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtScale;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn23;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn24;
        private DevExpress.XtraGrid.Views.BandedGrid.BandedGridColumn bandedGridColumn25;
    }
}